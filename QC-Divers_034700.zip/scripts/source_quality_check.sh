#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

failures=0
check_zero() {
  local label="$1"
  local pattern="$2"
  local path="$3"
  echo "[check] $label"
  if grep -RInE "$pattern" "$path" >/tmp/dumpsterscout-quality-match.txt 2>/dev/null; then
    cat /tmp/dumpsterscout-quality-match.txt
    failures=$((failures + 1))
  else
    echo "  ok"
  fi
}

check_zero "TODO/FIXME markers in source/docs/supabase" "TODO|FIXME" "app/src/main/java docs supabase"
echo "[check] raw android.util.Log imports outside DsLogger"
if grep -RIn "import android.util.Log" app/src/main/java | grep -v "DsLogger.kt"; then
  failures=$((failures + 1))
else
  echo "  ok"
fi
check_zero "public Supabase photo URL usage" "publicUrl|getPublicUrl" "app/src/main/java supabase"
check_zero "hardcoded Google Maps API key pattern" "AIza[0-9A-Za-z_-]{20,}" "."
check_zero "committed keystore/cert/private-key files" "BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY|RELEASE_STORE_PASSWORD|RELEASE_KEY_PASSWORD" "app src docs supabase scripts .github"

echo "[check] local/build artifact directories"
for d in .gradle .idea .kotlin build app/build; do
  if [ -e "$d" ]; then
    echo "  found unexpected $d"
    failures=$((failures + 1))
  fi
done

if [ "$failures" -ne 0 ]; then
  echo "source quality checks failed: $failures" >&2
  exit 1
fi

echo "source quality checks passed"
