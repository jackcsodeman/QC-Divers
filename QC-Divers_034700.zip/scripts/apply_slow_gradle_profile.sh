#!/usr/bin/env bash
set -Eeuo pipefail

TARGET="${1:-gradle.properties}"
PROFILE="gradle/gradle.properties.slow-processor"

if [ ! -f "$PROFILE" ]; then
  echo "Missing $PROFILE. Run from the repository root." >&2
  exit 1
fi

# Preserve any existing API keys / Supabase values by only replacing known non-secret Gradle tuning keys.
while IFS= read -r line; do
  case "$line" in
    \#*|'') continue ;;
  esac
  key="${line%%=*}"
  value="${line#*=}"
  case "$key" in
    MAPS_API_KEY|SUPABASE_URL|SUPABASE_ANON_KEY|RELEASE_STORE_FILE|RELEASE_STORE_PASSWORD|RELEASE_KEY_ALIAS|RELEASE_KEY_PASSWORD)
      continue
      ;;
  esac
  if grep -qE "^${key}=" "$TARGET" 2>/dev/null; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$TARGET"
  else
    printf '%s=%s\n' "$key" "$value" >> "$TARGET"
  fi
done < "$PROFILE"

echo "Applied non-secret slow-processor Gradle profile to $TARGET."
echo "Your MAPS_API_KEY/SUPABASE_URL/SUPABASE_ANON_KEY values were not changed."
