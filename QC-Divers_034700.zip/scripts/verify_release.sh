#!/usr/bin/env bash
set -euo pipefail

MAPS_API_KEY_VALUE="${MAPS_API_KEY:-}"

echo "Gradle version"
./gradlew --version

echo "Clean"
./gradlew clean -PMAPS_API_KEY="$MAPS_API_KEY_VALUE"

echo "Lint"
./gradlew lint --warning-mode=all -PMAPS_API_KEY="$MAPS_API_KEY_VALUE"

echo "Unit tests"
./gradlew test --warning-mode=all -PMAPS_API_KEY="$MAPS_API_KEY_VALUE"

echo "Debug APK"
./gradlew assembleDebug --warning-mode=all -PMAPS_API_KEY="$MAPS_API_KEY_VALUE"

echo "Release AAB"
./gradlew bundleRelease --warning-mode=all -PMAPS_API_KEY="$MAPS_API_KEY_VALUE"

cat <<MSG
Release verification completed.
AAB should be at app/build/outputs/bundle/release/app-release.aab

Run instrumentation tests separately when an emulator/device is available:
  ./gradlew connectedDebugAndroidTest --warning-mode=all -PMAPS_API_KEY=\"$MAPS_API_KEY_VALUE\"
MSG
