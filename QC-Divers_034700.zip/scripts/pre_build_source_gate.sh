#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

fail() {
  echo "[FAIL] $*" >&2
  exit 1
}

warn() {
  echo "[WARN] $*" >&2
}

require_contains() {
  local file="$1"
  local needle="$2"
  local message="$3"
  grep -q "$needle" "$file" || fail "$message"
}

echo "[1/13] Running source quality policy checks..."
./scripts/source_quality_check.sh

echo "[2/13] Checking Room schema exports..."
SCHEMA_DIR="app/schemas/com.dumpsterscout.data.local.DumpsterScoutDatabase"
[ -d "$SCHEMA_DIR" ] || fail "Missing Room schema directory: $SCHEMA_DIR"
for version in $(seq 1 13); do
  [ -f "$SCHEMA_DIR/$version.json" ] || fail "Missing Room schema export: $SCHEMA_DIR/$version.json"
done

echo "[3/13] Checking current database version and migration registration..."
require_contains "app/src/main/java/com/dumpsterscout/data/local/DumpsterScoutDatabase.kt" "version = 13" "Database version is not 12."
require_contains "app/src/main/java/com/dumpsterscout/data/local/DumpsterScoutDatabase.kt" "MIGRATION_11_12" "MIGRATION_11_12 is not defined."
require_contains "app/src/main/java/com/dumpsterscout/data/local/DumpsterScoutDatabase.kt" "MIGRATION_12_13" "MIGRATION_12_13 is not defined."
require_contains "app/src/main/java/com/dumpsterscout/di/DatabaseModule.kt" "MIGRATION_12_13" "MIGRATION_12_13 is not registered in DatabaseModule."

echo "[4/13] Checking key feature source files..."
required_files=(
  "app/src/main/java/com/dumpsterscout/data/local/entity/RouteStopEntity.kt"
  "app/src/main/java/com/dumpsterscout/ui/conflicts/ConflictRemoteApplyUseCase.kt"
  "app/src/main/java/com/dumpsterscout/data/remote/RemoteLocationIdResolver.kt"
  "app/src/main/java/com/dumpsterscout/data/remote/SupabaseRouteDataSource.kt"
  "app/src/main/java/com/dumpsterscout/data/remote/SupabaseCollectionDataSource.kt"
  "app/src/main/java/com/dumpsterscout/data/remote/SupabaseFieldSessionDataSource.kt"
  "app/src/main/java/com/dumpsterscout/data/remote/SupabaseReminderDataSource.kt"
  "app/src/main/java/com/dumpsterscout/data/remote/SupabaseGearChecklistDataSource.kt"
  "app/src/main/java/com/dumpsterscout/ui/photos/PhotoAttachmentSection.kt"
  "app/src/main/java/com/dumpsterscout/data/local/entity/FieldLocationReportEntity.kt"
  "app/src/main/java/com/dumpsterscout/data/local/dao/FieldLocationReportDao.kt"
  "app/src/main/java/com/dumpsterscout/data/remote/RemoteFieldLocationReportDataSource.kt"
  "app/src/main/java/com/dumpsterscout/data/remote/SupabaseFieldLocationReportDataSource.kt"
  "app/src/main/java/com/dumpsterscout/data/remote/dto/FieldLocationReportRow.kt"
  "docs/supabase/SUPABASE_FULL_SETUP.md"
  "docs/supabase/COMMUNITY_AND_SYNC_SETUP.md"
  "docs/supabase/SYNC_OPERATION_MATRIX.md"
  "docs/testing/ANDROID_STUDIO_AGENT_TEST_AND_FIX_PROMPT.md"
  "docs/testing/FEATURE_RUNTIME_QA_MATRIX.md"
  "app/src/main/java/com/dumpsterscout/ui/map/MapMarkerModel.kt"
  "app/src/test/java/com/dumpsterscout/ui/map/MapClustererTest.kt"
  "app/src/test/java/com/dumpsterscout/notifications/ReminderSchedulerTest.kt"
  "docs/supabase/COMMUNITY_MODERATION_READINESS.md"
  "supabase/migrations/202605220006_community_moderation_readiness.sql"
)
for file in "${required_files[@]}"; do
  [ -f "$file" ] || fail "Missing required source/doc file: $file"
done

echo "[5/13] Checking backup/import hardening markers..."
require_contains "app/src/main/java/com/dumpsterscout/data/repository/LocalBackupRepository.kt" "previewImport" "Backup import dry-run preview is missing."
require_contains "app/src/main/java/com/dumpsterscout/data/repository/LocalBackupRepository.kt" "BackupImportPreview" "Backup import preview model is missing."
require_contains "app/src/main/java/com/dumpsterscout/ui/settings/SettingsScreen.kt" "ActivityResultContracts.CreateDocument" "Settings export does not use Storage Access Framework CreateDocument."
require_contains "app/src/main/java/com/dumpsterscout/ui/settings/SettingsScreen.kt" "ActivityResultContracts.OpenDocument" "Settings import does not use Storage Access Framework OpenDocument."

echo "[6/13] Checking Android Studio handoff prompt references current DB version..."
require_contains "docs/testing/ANDROID_STUDIO_AGENT_TEST_AND_FIX_PROMPT.md" "Room database version 13" "Android Studio agent prompt does not mention Room database version 13."

echo "[7/13] Checking Kotlin Android plugin wiring..."
require_contains "build.gradle.kts" "alias(libs.plugins.kotlin.android) apply false" "Root build.gradle.kts does not declare the Kotlin Android plugin alias."
require_contains "app/build.gradle.kts" "alias(libs.plugins.kotlin.android)" "App module does not apply the Kotlin Android plugin."

echo "[8/13] Checking Play-safe photo picker permission posture..."
if grep -q 'READ_MEDIA_IMAGES\|READ_EXTERNAL_STORAGE' app/src/main/AndroidManifest.xml; then
  fail "Manifest still requests broad media-library permissions. Use Android Photo Picker instead."
fi
grep -RIn 'PickVisualMedia' app/src/main/java/com/dumpsterscout/ui >/dev/null || fail "Photo picking does not appear to use Android Photo Picker."

echo "[9/13] Checking child pull/merge source markers..."
require_contains "app/src/main/java/com/dumpsterscout/data/remote/RemoteRouteDataSource.kt" "fetchMyRouteStops" "route stop remote pull contract is missing."
require_contains "app/src/main/java/com/dumpsterscout/data/remote/RemoteCollectionDataSource.kt" "fetchMyCollectionItems" "collection item remote pull contract is missing."
require_contains "app/src/main/java/com/dumpsterscout/data/remote/RemoteFieldSessionDataSource.kt" "fetchMyFieldSessionVisits" "field-session visit remote pull contract is missing."
require_contains "app/src/main/java/com/dumpsterscout/data/remote/RemoteGearChecklistDataSource.kt" "fetchMyChecklistItems" "gear checklist item remote pull contract is missing."
require_contains "app/src/main/java/com/dumpsterscout/worker/SyncWorker.kt" "pullMyRouteStops" "SyncWorker does not pull route stops."
require_contains "app/src/main/java/com/dumpsterscout/worker/SyncWorker.kt" "pullMyCollectionItems" "SyncWorker does not pull collection items."
require_contains "app/src/main/java/com/dumpsterscout/worker/SyncWorker.kt" "pullMyFieldSessionVisits" "SyncWorker does not pull field-session visits."
require_contains "app/src/main/java/com/dumpsterscout/worker/SyncWorker.kt" "pullMyGearChecklistItems" "SyncWorker does not pull gear checklist items."

echo "[10/13] Checking Supabase setup documentation markers..."
require_contains "docs/supabase/SUPABASE_FULL_SETUP.md" "supabase db push" "Supabase setup guide does not include database deployment instructions."
require_contains "docs/supabase/COMMUNITY_AND_SYNC_SETUP.md" "COMMUNITY_PUBLIC" "Community setup guide does not document community visibility."
require_contains "docs/supabase/SYNC_OPERATION_MATRIX.md" "Field-location reports" "Sync operation matrix does not include field-location reports."

echo "[11/13] Checking reminder deep-link and map navigation source markers..."
require_contains "app/src/main/java/com/dumpsterscout/MainActivity.kt" "EXTRA_NAV_ROUTE" "MainActivity does not expose notification/deep-link navigation extra."
require_contains "app/src/main/java/com/dumpsterscout/notifications/ReminderWorker.kt" "Screen.Reminders.route" "Reminder notifications do not deep-link to the reminders destination."
require_contains "app/src/main/java/com/dumpsterscout/ui/map/MapScreen.kt" "openExternalNavigation" "Map previews do not expose external navigation."
require_contains "app/src/main/java/com/dumpsterscout/ui/map/MapScreen.kt" "MAX_RENDERED_MAP_MARKERS" "Map marker rendering safety limit is missing."


echo "[12/13] Checking map clustering and moderation-readiness markers..."
require_contains "app/src/main/java/com/dumpsterscout/ui/map/MapMarkerModel.kt" "MapClusterer" "Map clusterer source is missing."
require_contains "app/src/main/java/com/dumpsterscout/ui/map/MapScreen.kt" "MapMarkerUiModel.Cluster" "Map screen does not render cluster markers."
require_contains "app/src/test/java/com/dumpsterscout/ui/map/MapClustererTest.kt" "large nearby location lists are clustered" "Map clusterer tests are missing."
require_contains "supabase/migrations/202605220006_community_moderation_readiness.sql" "community_reports" "Community moderation migration is missing report table."
require_contains "docs/supabase/COMMUNITY_MODERATION_READINESS.md" "Before enabling public/community sharing" "Community moderation readiness docs are missing launch gating guidance."

echo "[13/13] Checking clean-package hygiene markers..."
if find . -path './.git' -prune -o \( -path './.gradle' -o -path './.idea' -o -path './.kotlin' -o -path './build' -o -path './app/build' \) -print | grep -q .; then
  warn "Local build/cache/editor directories exist in the working tree. They should not be included in the clean zip."
fi

echo "[OK] Pre-build source gate passed. Next step: run Gradle in Android Studio or local terminal."
