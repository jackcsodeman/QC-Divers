
## Latest source-only Batch 0 stabilization pass

- Applied the Kotlin Android Gradle plugin to the app module and root plugin catalog usage.
- Removed broad media-library permissions and migrated gallery selection flows to Android Photo Picker.
- Wired first-run onboarding through `AppPreferences.onboardingDone`.
- Hardened remote report pull so unresolved child reports are skipped until their parent location exists.
- Added remote parent pull coverage for route plans, collections, field sessions, reminders, and gear checklists.
- Expanded the pre-build source gate to check plugin wiring and Play-safe media permission posture.

See `docs/audit/NEXT_PLAN_BATCH0_SOURCE_PROGRESS.md`.

# QC Divers / DumpsterScout Project Status

## Current source status

This source is a native Android Kotlin / Jetpack Compose app using Room, DataStore, Hilt, WorkManager, Supabase, and Google Maps Compose.

Recent local build evidence in the provided workspace showed:

- Debug APK generated locally
- Release AAB generated locally
- 139 unit tests reported passing
- Gradle wrapper restored to 9.5.0, the last known locally-built baseline
- Android Gradle Plugin 9.2.1
- Database version 7

This cleanup pass also added:

- Slow-processor Gradle profile template and safe apply script
- Cleaner source packaging rules that exclude local secret-bearing files and build outputs
- Lint-warning cleanup from the embedded lint report: target SDK/compile SDK, dependency versions, unused resources, plural candidates, obsolete launcher resource folder, launcher icon duplicate warnings, KTX URI use, and Compose modifier ordering
- Deeper conflict-review UI that parses queued local payload fields and hides sensitive values
- Source-trace documentation for future feature-completion audits

## What is strong

- Offline-first Room data foundation
- Multiple persisted feature domains: dumpster spots, tire spots, field locations, collections, field sessions, reminders, photos, gear checklists, routes, reports, sync queue
- Supabase client integration plus migration/RLS/storage artifacts
- Durable local sync queue foundation
- Photo attachment support across several owner types
- Account/cloud deletion Edge Function scaffold and Android call path
- Play Store/release/privacy/Data Safety docs
- Passing unit-test evidence from the provided build reports

## Still requiring real local verification

The sandbox environment cannot download Gradle from `services.gradle.org`, so this pass could not rerun the full build. Run these on your PC after restoring your local keys:

```bash
chmod +x gradlew
./gradlew clean -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew lint --warning-mode=all -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew test --warning-mode=all -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew assembleDebug --warning-mode=all -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew bundleRelease --warning-mode=all -PMAPS_API_KEY="$MAPS_API_KEY"
```

## Known remaining production work

- Rebuild with Gradle 9.5.0 and the restored built-baseline versions to confirm compatibility.
- Re-run lint and address any new warnings that appear after dependency/version updates.
- Run emulator/device QA for camera, gallery, reminders, notifications, map, auth, sync, backup/restore, and deletion.
- Capture final Play Store screenshots from a release-quality build.
- Finalize signing using your local keystore values; do not upload signing files to source control.
- Consider adding true remote conflict snapshots to the sync queue if you want full local-vs-remote field merge beyond queued-payload review.

## Ready for next audit

The repo now includes `docs/audit/SOURCE_TRACE.md` and `docs/audit/source_trace.csv`. These files are intended for the next feature-completion audit so each feature can be scored against concrete source files and implementation evidence.

## Latest rollback and feature-progress pass

- Restored build versions to the last known locally-built baseline from `IMPROVEMENTS.zip`.
- Kept AGP 9.2.1, Gradle 9.5.0, Kotlin 2.2.10, KSP 2.2.10-2.0.2, compileSdk 36, and targetSdk 35.
- Extended the sync queue/Supabase path to first-class field locations.
- Added Supabase DTO/remote-source support for `field_locations`.
- Added field-location pull support to `SyncWorker`.
- Updated the account-deletion Edge Function to remove field-location cloud rows.
- Upgraded the Map screen from dumpster-only to unified dumpster/tire/field-site display.
- Added source-trace refresh files for the next feature completion audit.



## Route completion pass

Routes now use normalized `route_stops`, support mixed saved locations, stop ordering, removal, and external navigation handoff. Remote route sync and drag/drop optimization remain future hardening work.


## Latest Source-Level Progress

- Added Supabase route remote source support for `route_plans` and normalized `route_stops`.
- Added sync queue processor handling for `ROUTE_PLAN` create/update/delete operations.
- Updated route UI logic to enqueue route changes when Supabase is configured.
- Added route stop display metadata to Supabase migrations.
- Improved conflict review with local/remote payload comparison support and redaction of sensitive fields.
- Added parser tests for conflict changed-field detection.


## Current Sync / Feature Progress Batch

This source package adds collection and field-session Supabase sync coverage on top of the normalized route work:

- Collections now enqueue create/update/delete operations and have a Supabase remote data source for `collections` and `collection_items`.
- Field sessions now enqueue start/end/visit mutations and have a Supabase remote data source for `field_sessions` and `field_session_visits`.
- The sync queue processor now handles `COLLECTION` and `FIELD_SESSION` parent operations.
- Supabase core schema now includes `field_sessions` and `field_session_visits` plus owner-only RLS policies.
- Analytics now includes routes, collections, sessions, and gear item counts.
- DTO regression tests were added for collection and field-session remote mapping.

Gradle/build verification still needs to be run locally in Android Studio or a network-enabled build environment.


## Reminder and Gear Sync Progress

This batch moves two previously local-first utility domains into the durable sync architecture:

- Database version is now 9.
- `MIGRATION_8_9` adds sync metadata to reminders and gear checklist tables.
- Reminders now enqueue create/update/delete operations when Supabase is configured.
- Gear checklist state now enqueues create/update operations when Supabase is configured.
- `SyncQueueProcessor` handles `REMINDER` and `GEAR_CHECKLIST` operations.
- Supabase remote data sources and DTOs were added for reminders and gear checklists.
- Supabase migration hardening adds reminder/gear indexes and gear item emoji metadata.

Remaining verification: run Gradle, regenerate the current Room schema from annotation processing, and test reminder/gear sync with real Supabase credentials.

## Final Source-Only Progress Pass

This batch advances the source package without running Gradle/build commands:

- Database version is now 10.
- `MIGRATION_10_11` adds conflict-resolution audit metadata to `sync_queue`.
- `sync_queue` now supports separate remote snapshots, resolution action, resolution notes, and resolved timestamps.
- Conflict Review now parses inline or separate remote payload snapshots and records keep-local, keep-remote, and duplicate-reviewed actions.
- Analytics now uses aggregate DAO flows instead of loading entire entity lists for simple counts.
- Analytics now includes route stops, collection items, session visits, active reminders, high-priority field locations, gear completion, average stops per route, and average visits per session.
- Migration test sources now target schema version 10.
- Android Studio agent test/fix prompt added at `docs/testing/ANDROID_STUDIO_AGENT_TEST_AND_FIX_PROMPT.md`.

Remaining verification: run Gradle locally, regenerate the real Room schema, execute migration tests, and complete device QA.


## Supabase setup and community/sync configuration

Complete Supabase setup instructions now live in:

- `docs/supabase/SUPABASE_FULL_SETUP.md`
- `docs/supabase/COMMUNITY_AND_SYNC_SETUP.md`
- `docs/supabase/SYNC_OPERATION_MATRIX.md`
- `supabase/verification/community_and_sync_checks.sql`

Use these before enabling optional cloud sync or any community/public visibility UI in production.


## Latest source-only runtime hardening

The current source targets Room database version 13. It adds remote metadata and remote pull coverage for normalized child rows: route stops, collection items, field-session visits, and gear checklist items. It also moves backup export/import to Android Storage Access Framework, routes reminder notification taps into the app, and adds map preview external navigation plus marker-count safeguards. These changes require Android Studio/Gradle verification, Room schema regeneration, and device/Supabase staging tests before release claims are made.

## Latest source-only map/test/moderation hardening pass

This source package adds pure Kotlin map clustering readiness, additional map accessibility labels, unit tests for map clustering and reminder scheduling delay logic, WorkManager test dependency scaffolding, and optional Supabase community-moderation readiness tables/docs. Public/community sharing remains disabled by launch posture until full moderation/reporting/blocking UI and policy updates are implemented and verified.

No Gradle/build commands were run in this environment. Run Android Studio/Gradle next to verify compile, KSP/Room schema generation, unit tests, instrumentation tests, WorkManager tests, Google Maps runtime behavior, and Supabase staging behavior.
