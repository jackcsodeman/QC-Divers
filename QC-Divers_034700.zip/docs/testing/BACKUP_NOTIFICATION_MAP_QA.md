# Backup, Reminder Notification, and Map Runtime QA

Use this checklist after the app builds in Android Studio.

## Backup/export/import

1. Open Settings.
2. Tap Export Data.
3. Save the JSON file through the Android file picker.
4. Confirm the file exists and is non-empty.
5. Create or edit at least one record after export.
6. Tap Import Data.
7. Choose the exported JSON file through the Android file picker.
8. Confirm the import preview shows expected record and table counts.
9. Cancel once and verify no data changes.
10. Repeat import and confirm.
11. Verify restored records appear in the app.
12. Test a malformed JSON file and confirm an error is shown.
13. Test a backup containing an unsupported table and confirm import is blocked.

## Reminder notification deep links

1. Create a reminder scheduled soon.
2. Grant notification permission on Android 13+.
3. Wait for the notification.
4. Tap the notification from a cold app state.
5. Confirm the app opens to Reminders after onboarding is complete.
6. Tap the notification while the app is already running.
7. Confirm the existing activity routes to Reminders.
8. Disable the reminder and confirm the work is cancelled or no notification appears.
9. Test notification denial and confirm the app does not crash.

## Map external navigation

1. Create a dumpster location with coordinates.
2. Create a tire location with coordinates.
3. Create a cleanup/salvage/custom field location with coordinates.
4. Open the map.
5. Select each marker type.
6. Tap Navigate.
7. Confirm Android opens a navigation-capable app or a chooser.
8. Test a location without coordinates and confirm Navigate is disabled.
9. Add enough sample records to exceed the map marker cap, or temporarily lower the cap for testing.
10. Confirm the density banner appears and list view still shows all records.

## Pass criteria

- No crash.
- No silent failure.
- Backup does not use clipboard as the primary path.
- Reminder taps route to a meaningful app screen.
- Map preview navigation launches a real external navigation intent.
