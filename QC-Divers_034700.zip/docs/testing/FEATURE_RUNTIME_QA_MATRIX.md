# Feature Runtime QA Matrix

Use this matrix after the source-only completion passes. It focuses on proving runtime readiness on an emulator or device. Do not mark a feature production-complete until the relevant checks pass on a real build.

| Feature | Required runtime checks | Pass evidence |
| --- | --- | --- |
| App shell/navigation | Cold launch, onboarding, back stack, all Settings links, dark mode | Screen recording or checklist initials/date |
| Dumpster spots | Create/edit/detail/favorite/delete/report/history/photo while offline | Local DB persists after restart |
| Tire spots | Create/edit/detail/favorite/delete/report/history/photo while offline | Local DB persists after restart |
| Field locations | Create cleanup/salvage/custom, filter/search, favorite, delete, attach photo | All type filters work |
| Map | Dumpster/tire/field markers, permission allow/deny, list fallback, external nav | Screenshot per state |
| Routes | Create route, add mixed stops, reorder, remove, open navigation, backup restore | Route survives restart/import |
| Collections | Create, add/remove mixed locations, delete, backup restore, sync queue | Collection survives restart/import |
| Field sessions | Start, add/remove visits, end, view history, backup restore, sync queue | Session survives restart/import |
| Gear checklist | Seed default, check/uncheck, reset, sync queue, backup restore | State survives restart/import |
| Reminders | Create/edit/enable/disable/delete, notification permission allow/deny, tap notification | WorkManager job observed or notification received |
| Photos | Camera, gallery, delete, missing-file state, upload queue, failed upload retry | Private storage reference only |
| Sync status | Offline queue, retry failed, clear completed, stale in-progress recovery | Queue transitions recorded |
| Conflict resolution | Remote snapshot display, sensitive redaction, keep local, accept remote, duplicate-review audit | sync_queue audit row verified |
| Backup/import | Preview import, reject unknown tables, import after local wipe | Counts match preview/result |
| Account/cloud deletion | Signed-in deletion call, Edge Function returns success, local data preserved unless wiped | Supabase project checked |
| Analytics | Counts match known test data; no slow full-table UI loads | Test dataset screenshot |
| Accessibility | TalkBack pass for top screens, touch targets, content descriptions, non-color status | Manual accessibility pass |
| Release | Debug APK, release AAB, lint, tests, R8/minification | Command output saved |
