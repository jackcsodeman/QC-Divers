# Pre-build handoff checklist

Use this checklist before handing the source to Android Studio for the real Gradle/device pass.

## Source-only gates

Run:

```bash
./scripts/pre_build_source_gate.sh
```

This does not run Gradle. It verifies source hygiene, key feature files, Room schema exports, migration registration, backup import hardening, and handoff prompt freshness.

## Local files that should stay local

Do not include these in source handoffs:

- `gradle.properties` when it contains real API keys or signing values
- `local.properties`
- `.gradle/`
- `.idea/`
- `.kotlin/`
- `build/`
- `app/build/`
- APKs/AABs
- keystores/certificates/private keys

## Real build gate

Android Studio or local terminal should run:

```bash
./gradlew clean -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew test -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew lint -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew assembleDebug -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew bundleRelease -PMAPS_API_KEY="$MAPS_API_KEY"
```

## Runtime proof gate

Run on a device or emulator:

- Fresh install and launch
- Upgrade database from an older version if possible
- Add/edit/delete dumpster spot
- Add/edit/delete tire spot
- Add/edit/delete field location
- Add photo from camera/gallery and delete it
- Create reminder and verify notification behavior
- Create route, add mixed stops, reorder, open navigation
- Create collection, add/remove mixed locations
- Start/end field session, add/remove visits
- Run backup dry-run and import confirmation
- Sign in/out and test local-only mode
- Test sync status, failed sync retry, and conflict review
- Verify TalkBack on dashboard, routes, collections, sessions, photo actions, and settings

## Completion rule

Do not mark any area 100% until it has source coverage, build proof, and runtime proof.
