
## Latest source-only Batch 0 stabilization context

The current source should now include:

- `alias(libs.plugins.kotlin.android) apply false` in root `build.gradle.kts`.
- `alias(libs.plugins.kotlin.android)` in `app/build.gradle.kts`.
- No `READ_MEDIA_IMAGES` or `READ_EXTERNAL_STORAGE` declarations in `AndroidManifest.xml`.
- Photo selection using `ActivityResultContracts.PickVisualMedia`.
- First-run onboarding controlled by `AppPreferences.onboardingDone`.
- `SyncWorker` remote parent pull for route plans, collections, field sessions, reminders, and gear checklists.
- Safer remote report pull that skips unresolved child reports instead of inserting parent ID `0L`.

Run `./scripts/pre_build_source_gate.sh` before Gradle. It should pass before build work starts.

# Android Studio AI Agent Prompt: Test, Fix, and Verify QC Divers

Paste this into Android Studio's AI agent with the repository open.

```text
You are my senior Android test/fix engineer, Kotlin/Compose build engineer, Room migration reviewer, Supabase sync reviewer, and QA lead.

Treat the open QC Divers / DumpsterScout repository as the source of truth. Do not rewrite the app. Do not remove features to make tests pass. Do not print or modify my local API keys, Supabase values, signing values, keystores, or local.properties. Do not commit build outputs.

The latest source state is intended to include:
- Gradle wrapper 9.5.0
- AGP 9.2.1
- Kotlin 2.2.10
- KSP 2.2.10-2.0.2
- compileSdk 36
- targetSdk 35
- Room database version 13
- field-location report remote sync
- Supabase setup docs under docs/supabase/
- community and sync verification SQL under supabase/verification/community_and_sync_checks.sql
- normalized route_stops
- sync coverage for routes, collections, field sessions, reminders, gear checklists, field locations, photos, dumpster/tire spots, and reports
- conflict-resolution metadata in sync_queue
- conflict remote-apply support for dumpster spots, dumpster reports, tire spots, tire reports, field locations, routes, collections, sessions, reminders, and gear checklists
- aggregate analytics DAO flows
- Storage Access Framework backup export/import using CreateDocument/OpenDocument
- reminder notification deep links into the Reminders screen
- map preview external navigation actions
- map marker rendering safety cap for large datasets

First, inspect the repo state and confirm those items are present. Then run the source-only hygiene check before Gradle:

0. Source-only hygiene checks:
   ./scripts/source_quality_check.sh
   ./scripts/pre_build_source_gate.sh

1. Build/tooling checks:
   ./gradlew --version
   ./gradlew clean -PMAPS_API_KEY="$MAPS_API_KEY"
   ./gradlew test -PMAPS_API_KEY="$MAPS_API_KEY"
   ./gradlew assembleDebug -PMAPS_API_KEY="$MAPS_API_KEY"
   ./gradlew bundleRelease -PMAPS_API_KEY="$MAPS_API_KEY"

2. Lint/warnings:
   ./gradlew lint -PMAPS_API_KEY="$MAPS_API_KEY"
   ./gradlew test --warning-mode=all -PMAPS_API_KEY="$MAPS_API_KEY"
   ./gradlew assembleDebug --warning-mode=all -PMAPS_API_KEY="$MAPS_API_KEY"
   ./gradlew bundleRelease --warning-mode=all -PMAPS_API_KEY="$MAPS_API_KEY"

3. Instrumentation only if an emulator/device is available:
   ./gradlew connectedDebugAndroidTest -PMAPS_API_KEY="$MAPS_API_KEY"

Fix all compile errors, missing imports, missing resources, Hilt binding errors, KSP/Room errors, migration failures, lint issues, and release/R8 errors. Prefer root-cause fixes. Do not suppress warnings broadly.

Room/migration verification:
- Regenerate the real Room schema for version 12 from annotation processing.
- Verify schemas 1 through 12 are present.
- Verify migrations are registered through MIGRATION_11_12.
- Ensure migration tests cover 1->12, 2->12, 3->12, 4->12, 5->12, 6->12, 7->12, 8->12, 9->12, 10->12, 11->12, and fresh v12 validation.
- Fix any schema mismatch between entities, migrations, and exported JSON.

Feature QA/fix scope:
- App launch and navigation.
- Dumpster create/edit/detail/report/photo/favorite/history.
- Tire create/edit/detail/report/photo/favorite/history.
- Field locations create/search/filter/photo/favorite/delete.
- Map shows dumpster, tire, and field locations, handles large marker sets safely, and opens external navigation from preview cards.
- Routes create/add stops/remove stops/reorder/open external navigation.
- Collections create/add/remove/delete and sync queue operations.
- Field sessions start/end/add/remove visits and sync queue operations.
- Gear checklist seed/check/reset/persist/sync queue operations.
- Reminders create/edit/delete/enable/disable/complete/snooze/schedule/notification permission/notification tap/sync queue operations.
- Photos camera/gallery/delete/upload queue/private references/missing file handling.
- Sync status queue visibility/retry/clear completed.
- Conflict resolution shows local and remote payload fields, redacts sensitive fields, supports keep local, accept remote, duplicate-reviewed, preserves audit metadata, and verifies accept-remote/duplicate-local behavior for dumpster spots, dumpster reports, tire spots, tire reports, field locations, routes, collections, sessions, reminders, and gear checklists.
- Analytics uses aggregate DAO flows and shows meaningful metrics without full-table UI loads.
- Backup/export/import uses Storage Access Framework file pickers, includes current supported tables, and shows the dry-run preview before replacing local data.
- Account/cloud deletion calls the Edge Function and docs match behavior.

Manual/device QA checklist:
- Fresh install.
- Upgrade from older DB if possible.
- Dark mode.
- Offline CRUD.
- Reconnect and sync.
- Camera/gallery permission allow and deny.
- Notification permission allow and deny.
- Map permission allow and deny.
- Supabase signed-in and local-only modes.
- Backup/export/import round trip through Android file picker, including cancel and malformed-file cases.
- Release AAB smoke test.

Final output required:
1. Commands run and pass/fail output summary.
2. Exact files changed.
3. Source-quality/build/test/lint status.
4. Room schema/migration status.
5. Remaining warnings, if any.
6. Feature issues found and fixed.
7. Feature issues still requiring manual QA.
8. Confirmation that no secrets/local files were printed or committed.
9. Recommended next patch batch.
```


Supabase configuration verification:
- Read `docs/supabase/SUPABASE_FULL_SETUP.md`.
- Read `docs/supabase/COMMUNITY_AND_SYNC_SETUP.md`.
- Read `docs/supabase/SYNC_OPERATION_MATRIX.md`.
- Verify migrations can be applied in order on a staging Supabase project.
- Verify `supabase/verification/community_and_sync_checks.sql` passes or produces expected manual-check output.
- Do not enable community/public UI claims unless moderation/reporting requirements are satisfied.


## Latest source-only sync closure

The current source targets Room database version 13. It adds remote metadata and remote pull coverage for normalized child rows: route stops, collection items, field-session visits, and gear checklist items. These changes require Android Studio/Gradle verification, Room schema regeneration, and Supabase staging tests before release claims are made.


## Latest source-only runtime hardening

The current source also adds Storage Access Framework backup/export/import, reminder notification deep links to the Reminders screen, map preview external navigation, and a large-map marker rendering safety cap. Use `docs/testing/BACKUP_NOTIFICATION_MAP_QA.md` for the focused runtime QA checklist.

Additional latest-source checks:

- Verify `MapClustererTest` passes.
- Verify `ReminderSchedulerTest` passes.
- Verify the app compiles after adding `androidx.work:work-testing` as an androidTest dependency.
- Verify map cluster markers display correctly on large datasets.
- Verify map preview action labels are TalkBack-readable.
- Do not enable public/community sharing UI unless `community_reports` and `blocked_users` behavior is implemented, tested, and reflected in Play policy answers.
