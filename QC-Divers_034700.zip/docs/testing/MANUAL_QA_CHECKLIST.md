# Manual QA Checklist

Use this checklist before internal testing, closed testing, and production release. Mark any failed item with the build number, device, Android version, reproduction steps, and logs/screenshots.

## Fresh install

- [ ] App launches without Supabase credentials
- [ ] Local-only mode is clear
- [ ] Home/dashboard empty state is understandable
- [ ] No sign-in required for core use
- [ ] Dark mode and light mode both look intentional
- [ ] No placeholder screens or dead settings rows are visible

## Offline local flows

- [ ] Enable airplane mode
- [ ] Create dumpster spot
- [ ] Create tire spot
- [ ] Create cleanup field location
- [ ] Create salvage/resource field location
- [ ] Create custom field location
- [ ] Edit existing dumpster/tire records
- [ ] Favorite/unfavorite dumpster, tire, and field-location records
- [ ] Add dumpster report
- [ ] Add tire report
- [ ] Add voice report and review before save
- [ ] Search/filter/sort local data
- [ ] Restart app and confirm data persists

## Field organization

- [ ] Create collection
- [ ] Add dumpster spot to collection
- [ ] Add tire spot to collection
- [ ] Add field location to collection
- [ ] Remove item from collection
- [ ] Delete collection
- [ ] Start field session
- [ ] Add visited locations to active session
- [ ] End field session
- [ ] Reopen field sessions list after app restart
- [ ] Gear checklist seeds default template
- [ ] Check all gear items
- [ ] Reset gear checklist

## Maps and location

- [ ] Map opens with no crash when Maps key is empty or invalid
- [ ] Location permission is requested only from location flow
- [ ] Permission denied state is understandable
- [ ] Manual coordinates validate latitude/longitude bounds
- [ ] Dumpster spot markers render when coordinates exist
- [ ] List-mode map fallback works
- [ ] External navigation handoff works where present

## Photos

- [ ] Camera permission requested only when capturing photo
- [ ] Gallery/media permission requested only when picking photo
- [ ] Capture photo for dumpster spot
- [ ] Pick photo for dumpster spot
- [ ] Photo appears in spot detail gallery
- [ ] Photo metadata persists locally after restart
- [ ] Delete photo prompts/behaves correctly
- [ ] Missing local file state is handled gracefully
- [ ] Private Supabase storage references are not public URLs

## Reminders and notifications

- [ ] Notification permission is requested only when scheduling reminders
- [ ] Create one-time reminder
- [ ] Create weekly reminder
- [ ] Disable reminder
- [ ] Delete reminder
- [ ] Reminder notification appears when due
- [ ] Tapping notification opens the relevant app flow
- [ ] Clearing local data cancels scheduled reminder work

## Analytics and dashboard

- [ ] Analytics opens without data and shows helpful empty state
- [ ] Analytics counts update after adding spots, reports, photos, reminders, field locations, and sync failures
- [ ] Home dashboard remains smooth with sample data
- [ ] Dashboard cards navigate to expected flows where applicable

## Supabase sync

- [ ] App works with credentials missing
- [ ] App signs in when credentials are configured
- [ ] OTP/magic-code flow remembers email correctly
- [ ] Offline changes enter pending queue state
- [ ] Sync Status shows pending items
- [ ] Reconnect sync attempts run
- [ ] Failures are visible and retryable
- [ ] Conflict/failure review screen lists failed queue items
- [ ] Private records are not visible to another account
- [ ] Private photos are not public
- [ ] Sign out does not accidentally upload new local-only data

## Data management

- [ ] Export full local backup explains included data
- [ ] Backup JSON includes supported Room tables
- [ ] Import validates input
- [ ] Import restores a known sample backup
- [ ] Clear local data confirms destructive action
- [ ] Clear local data removes spots, reports, photos metadata, reminders, routes, collections, sessions, gear, and sync queue
- [ ] Account/cloud deletion flow exists and is documented before release

## Performance smoke

- [ ] 1,000+ locations list scrolls smoothly
- [ ] Search is debounced and responsive
- [ ] Photo thumbnails do not jank scrolling
- [ ] Sync queue processing does not block UI
- [ ] Backup export/import shows progress or stays responsive for large data

## Accessibility smoke

- [ ] Large font does not break primary screens
- [ ] Tap targets are usable
- [ ] Screen reader labels exist for primary action buttons
- [ ] Status indicators do not rely only on color
- [ ] Map has list alternative
- [ ] Error messages are readable and actionable

## Release smoke

- [ ] Debug build installs
- [ ] Release bundle builds
- [ ] Minified release does not crash on launch
- [ ] No hardcoded secrets appear in repository search
- [ ] No Supabase service-role key exists in client source
- [ ] No unnecessary permissions are requested
- [ ] Privacy policy and Data Safety guidance match actual implementation
