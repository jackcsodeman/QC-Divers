# Future Features Roadmap

The following features have been identified as high-priority additions for future development cycles.

## Community & Social
- [ ] **Trust Verification**: Allow users to tap "Verified Today" on someone else's community spot to boost its trust score. (Item 1)
- [ ] **Community Hotspots**: A heatmap overlay on the main map showing where the most activity is happening. (Item 2)
- [ ] **Scout Rivalries**: Optional local "Top Diver" leaderboards for specific cities. (Item 3)
- [ ] **Anonymized Presence**: Show a count of "Active Scouts" currently in the field in your region. (Item 4)
- [ ] **Spot Comments**: A simple, moderated comment thread for "Access Updates". (Item 5)
- [ ] **Direct Messaging**: Secure, opt-in messaging for coordinated group dives. (Item 6)
- [ ] **Community Alerts**: Push notifications when a "Favorite" spot gets a "Good Haul" report. (Item 7)
- [ ] **Shared Routes**: Allow legendary scouts to publish their "Efficient Route" for others. (Item 8)
- [ ] **Badge System**: Unlockable visual badges for "Night Owl" or "High Roller". (Item 9)
- [ ] **Moderator Portal**: In-app UI for trusted "Elder Scouts" to review reported content. (Item 10)

## Advanced Tooling
- [ ] **Quick-Switch Themes**: A "Stealth Mode" theme (Red/Black) to preserve night vision. (Item 14)
- [ ] **Smart Sorting**: Sort spots by "Probability of Success" using predictive analytics. (Item 15)
- [ ] **Field Session Timer**: Visual indicator of how long you've been in the field to prevent fatigue. (Item 19)
- [ ] **Loot Value Calculator**: Log specific items and estimate "Money Saved" stats. (Item 20)
