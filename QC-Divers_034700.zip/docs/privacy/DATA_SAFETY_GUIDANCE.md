# Data Safety Guidance

Use this as a starting point for the Play Console Data Safety form. Final answers must match the shipped build and any production services actually enabled.

## Data categories likely collected or processed

- Location: approximate/precise location if user captures current location or uses map location features.
- Photos/videos: user-selected or captured spot/report photos.
- User-generated content: notes, reports, tags, routes, reminders, checklist items.
- Account info: email/user ID if Supabase Auth is enabled.
- App activity/diagnostics: only if crash reporting or analytics are added.

## Collection/upload behavior

- Core data is stored locally first.
- Cloud upload/sync is optional and requires user opt-in.
- Local-only mode does not require account creation.
- Private photos should use private storage and authenticated/signed access.

## Security practices

- RLS enabled for user-owned Supabase tables.
- No service-role key in client code.
- Private storage bucket for photos.
- Data deletion controls required before production release.

## Permissions to disclose

- Location
- Camera
- Photos/media
- Microphone
- Notifications
- Internet/network access

## Release blocker

Do not submit the Data Safety form until the final production behavior is verified on the release build.
