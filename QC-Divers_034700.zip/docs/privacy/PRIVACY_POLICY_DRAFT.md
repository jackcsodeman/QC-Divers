# Privacy Policy Draft

Last updated: May 18, 2026

QC Divers / Dumpster Scout is designed as a local-first field scouting app.

## Data stored locally

The app may store the following data on your device:

- saved locations
- GPS coordinates you enter or capture
- field notes
- reports and history
- photos you attach
- routes
- reminders
- gear checklist data
- app preferences

## Optional account sync

If you choose to sign in and enable sync, selected app data may be uploaded to Supabase so it can be backed up or used on other devices. Sync is optional. Local-only mode remains available without an account.

## Photos

Photos are stored locally first. If sync is enabled, photos may be uploaded to a private Supabase Storage bucket. Private photos are not intended to be public.

## Location data

Location data is used to save and display spots, show nearby items, and support map features. Exact coordinates should remain private unless you explicitly choose to share or publish a location.

## Voice reports

Voice reporting uses speech recognition to create a transcript for review. The app should save only the reviewed report unless you choose to keep transcript data. Transcript data should not be uploaded unless the saved report syncs with your consent.

## Data sharing

Private data is not shared publicly by default. Any community/public sharing feature must require explicit user action.

## Data deletion

The app should provide controls to:

- delete local data
- delete synced cloud data
- delete an account and associated cloud data, when accounts are enabled

## Analytics and crash reporting

This repository does not require third-party analytics. If crash reporting or analytics are added later, they must be disclosed and must not include exact coordinates, private notes, tokens, photo URLs, or sensitive field data.

## Contact

Support/contact email: support@example.com (replace before Play Store submission).
