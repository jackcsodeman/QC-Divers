# Master Release and Community Integration Plan (Advanced Edition)

This document outlines the roadmap for massive community integration, advanced architectural hardening, and feature-by-feature auditing to achieve a high-end, production-ready state.

---

## Part 1: Architectural Excellence (Hardening)

To move beyond basic CRUD and simple repository patterns, we will implement industry-leading architectural standards.

### 1. Model-View-Intent (MVI) Transition
*   [x] **State Reducers**: Transition complex ViewModels (Map) to MVI to ensure unidirectional data flow and deterministic UI states.
*   [ ] **Side Effect Handling**: Implement a clean `Effect` stream for one-time events (Navigation, Snackbars, Haptic feedback).

### 2. Domain/UseCase Layer Implementation
*   [ ] **Business Logic Extraction**: Extract core logic from ViewModels into pure Kotlin UseCases (e.g., `GetOptimizedRouteUseCase`, `CalculateSpotGradeUseCase`, `MatchVoiceToSpotUseCase`).
*   [x] **Dependency Inversion**: Ensure ViewModels only depend on UseCases, not Repositories, improving testability and modularity (MapViewModel).

### 3. Advanced Multi-Layered Caching
*   [ ] **Repository Orchestrator**: Implement a `Resource` wrapper that handles logic for: `Memory Cache -> Local DB (Room) -> Remote API (Supabase)`.
*   [ ] **Offline Write Buffering**: Enhance `SyncQueue` to support transactional multi-record updates (e.g., saving a spot and its initial report in one sync atom).

---

## Part 2: Massive Community Integration Roadmap

### Phase A: Community Read Layer (Infrastructure)
*   [x] **Remote Read Methods**: Implemented in `SupabaseSpotDataSource`.
*   [x] **Community Repository**: Implemented in `CommunityRepositoryImpl`.
*   [x] **Coordinate Fuzzing**: Implement jitter (+/- 0.0005) for public records in `SupabaseSpotDataSource` to protect exact private locations while in community mode.
*   [ ] **Sync Queue Hardening**: Ensure `SyncQueue` handles visibility transitions (Private -> Community) with proper confirmation.

### Phase B: Community Explorer (Discovery)
*   [x] **Map Discovery Mode**: Added "Community Explorer" toggle to Map UI.
*   [x] **Community Detail View**: Dedicated screen to view full history of shared spots. Should show:
    - Fuzzed location if not imported.
    - Community reports/history.
    - "Import to My Spots" button.
*   [x] **Import/Clone to Private**: "Save to My Spots" logic implemented.

### Phase C: Social Intelligence & Trust
*   [ ] **Active-Spot Consensus**: Logic to mark a community spot as "Trending" or "High Confidence" based on recent reports from multiple users.
*   [ ] **Public Scout Profiles**: Stats-only profiles showing "Spots Verified" and "Hauls Reported".
*   [ ] **Trust Score**: Implement a basic trust score based on report accuracy and community feedback.

### Phase D: Safety & Compliance (UGC Readiness)
*   [x] **Reporting Flow**: Add "Report this Spot" to Community Detail and Map markers.
    - Options: Spam, Inaccurate, Private Property, Dangerous, Other.
*   [x] **Blocking Flow**: Add "Block this User" to prevent seeing their community contributions.
*   [ ] **Sensitive Area Blacklisting**: Backend logic to automatically block `visibility = COMMUNITY` for spots near schools or private residential zones.
*   [ ] **Privacy Policy Update**: Ensure community features are covered in the in-app privacy policy.

---

## Part 3: Advanced Feature Hardening & Complexity

### 1. Intelligent Voice Reporting
*   [ ] **Contextual Matcher**: Use current location and time to prioritize spot matching in voice transcripts.
*   [ ] **Multi-Domain Support**: One voice log can update a Dumpster Spot AND log a Tire Spot report simultaneously.

### 2. Dynamic Route Optimization
*   [ ] **Traveling Salesman Algorithm**: Add "Optimize Route" button to Route Plans using the location of all stops.
*   [ ] **Live Traffic Integration**: Integration with Google Maps Directions API for real-time arrival estimates.

### 3. Predictive Analytics
*   [ ] **Visit Recommendations**: Surface "Spots to Check Tonight" on the Home dashboard based on historical pickup windows and "last checked" status.
*   [ ] **Impact Dashboard**: Visual charts showing "Personal Efficiency" (Reports per Mile) vs "Community Contribution".

---

## Part 4: System Hardening (Production Ready)

### 1. Security & Privacy
*   [ ] **Encrypted Storage**: Move Supabase tokens and sensitive preferences to `EncryptedSharedPreferences`.
*   [ ] **Certificate Pinning**: Implement SSL pinning for Supabase API calls to prevent Man-in-the-Middle attacks.

### 2. Performance & Stability
*   [ ] **Baseline Profiles**: Generate profiles to improve app startup and frame-drop performance.
*   [ ] **Image Optimization**: Implement server-side resizing via Supabase Storage for community thumbnails.

### 3. Monitoring
*   [ ] **Sentry/Crashlytics Enrichment**: Custom keys for Sync Status and Auth State in crash reports.
*   [ ] **Custom Trace Points**: Measure latency of Voice Parsing and Map Marker Rendering.

---

## Part 5: Implementation Progress & Milestones

### CURRENT STATUS
*   **Infrastructure**: 96% Source-ready.
*   **Community Core**: 100% (Read layer + Map toggle + Import logic).
*   **Build**: Verified successful.

### NEXT MILESTONES
1.  **MVI & UseCase Alpha**: Convert `MapViewModel` to MVI and extract `GetMapLocationsUseCase`.
2.  **Community Detail & Moderation**: Implement the detail view and reporting/blocking UI flows.
3.  **Privacy Jitter Pass**: Implement coordinate fuzzing in `SupabaseSpotDataSource`.
4.  **UGC Compliance Pass**: Finalize Moderation logic and sync with backend tables.
5.  **RC Pass**: Signed AAB, ProGuard/R8 audit, Play Store store listing complete.
