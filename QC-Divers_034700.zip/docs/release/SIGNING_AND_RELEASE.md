# Android Signing and Release Build

Google Play currently requires new apps and updates to target Android 15 / API 35 or higher. This app targets API 35 and builds with compileSdk 36. New apps on Google Play are published with Android App Bundles (`.aab`).

## Signing properties
Do not commit keystores or signing passwords.

Provide release signing through local `~/.gradle/gradle.properties`, CI secrets, or one-time command-line `-P` properties:

```properties
RELEASE_STORE_FILE=/absolute/path/to/qc-divers-upload-key.jks
RELEASE_STORE_PASSWORD=replace-me
RELEASE_KEY_ALIAS=qc-divers-upload
RELEASE_KEY_PASSWORD=replace-me
MAPS_API_KEY=replace-me
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=replace-me
```

## Generate an upload key

```bash
keytool -genkeypair \
  -alias qc-divers-upload \
  -keyalg RSA \
  -keysize 4096 \
  -validity 10000 \
  -keystore qc-divers-upload-key.jks
```

Store the keystore in a secure password manager or CI secret store. Do not place it inside the repo.

## Build commands

```bash
chmod +x gradlew
./gradlew clean -PMAPS_API_KEY=""
./gradlew test -PMAPS_API_KEY=""
./gradlew connectedDebugAndroidTest -PMAPS_API_KEY=""
./gradlew assembleDebug -PMAPS_API_KEY=""
./gradlew bundleRelease \
  -PMAPS_API_KEY="$MAPS_API_KEY" \
  -PSUPABASE_URL="$SUPABASE_URL" \
  -PSUPABASE_ANON_KEY="$SUPABASE_ANON_KEY" \
  -PRELEASE_STORE_FILE="$RELEASE_STORE_FILE" \
  -PRELEASE_STORE_PASSWORD="$RELEASE_STORE_PASSWORD" \
  -PRELEASE_KEY_ALIAS="$RELEASE_KEY_ALIAS" \
  -PRELEASE_KEY_PASSWORD="$RELEASE_KEY_PASSWORD"
```

Expected Play upload artifact:

```text
app/build/outputs/bundle/release/app-release.aab
```

## Pre-upload checks

- Confirm no hardcoded secrets exist.
- Confirm release build has no debug-only diagnostics exposed.
- Confirm Data Safety guidance matches actual permissions/network/data use.
- Confirm privacy policy URL is live.
- Confirm account deletion/cloud data deletion flow works if account sync is enabled.
- Install and smoke test a release build on a real device or emulator.
