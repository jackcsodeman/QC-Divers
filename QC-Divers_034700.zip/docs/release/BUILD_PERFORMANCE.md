# Build performance profile

This repo keeps secret-bearing Gradle values local. The clean source archive does not include `gradle.properties` or `local.properties` because they may contain Maps, Supabase, and signing values.

For a slower CPU with plenty of RAM, such as Android Studio using about 8 GB on a 64 GB machine, apply the non-secret profile:

```bash
./scripts/apply_slow_gradle_profile.sh gradle.properties
```

The script only changes non-secret Gradle tuning keys. It deliberately preserves these values when present:

- `MAPS_API_KEY`
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `RELEASE_STORE_FILE`
- `RELEASE_STORE_PASSWORD`
- `RELEASE_KEY_ALIAS`
- `RELEASE_KEY_PASSWORD`

Recommended local profile:

```properties
org.gradle.jvmargs=-Xmx8192m -XX:MaxMetaspaceSize=2g -XX:+HeapDumpOnOutOfMemoryError -Dfile.encoding=UTF-8 -XX:+UseParallelGC
org.gradle.daemon=true
org.gradle.parallel=false
org.gradle.workers.max=4
org.gradle.caching=true
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
android.disallowKotlinSourceSets=false
```

Rationale:

- Keeps Android Studio responsive on slower CPUs by limiting worker fan-out.
- Gives Gradle enough heap for AGP, KSP, Room, Hilt, Compose, and release builds.
- Avoids over-parallelizing annotation processing and Kotlin compilation.
- Leaves API keys and signing values untouched.

For a fast desktop CPU, you can raise `org.gradle.workers.max` after verifying clean builds.
