# Build verification results

## Latest included local build evidence

The source snapshot this cleanup was based on included generated local build outputs and reports showing:

- Debug APK generated: `app/build/outputs/apk/debug/app-debug.apk`
- Release AAB generated: `app/build/outputs/bundle/release/app-release.aab`
- Unit tests reported: 139 tests, 0 failures, 0 errors, 0 skipped
- Gradle wrapper in source: 9.5.0 before cleanup, updated to 9.5.0 to resolve the lint newer-Gradle warning
- Android Gradle Plugin: 9.2.1
- Kotlin: restored to 2.2.10, the last known built baseline
- Database version: 7

## Current sandbox verification

This environment cannot download Gradle distributions from `services.gradle.org`, so I could not independently rerun a fresh Gradle build here. The attempted wrapper run failed at network resolution before project configuration.

## Required verification on your PC

Run from the repository root after restoring your local `gradle.properties` / `local.properties` values:

```bash
chmod +x gradlew
./gradlew clean -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew lint --warning-mode=all -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew test --warning-mode=all -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew assembleDebug --warning-mode=all -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew bundleRelease --warning-mode=all -PMAPS_API_KEY="$MAPS_API_KEY"
```

After any compile/lint issues are fixed, run the strict pass:

```bash
./gradlew lint --warning-mode=fail -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew test --warning-mode=fail -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew assembleDebug --warning-mode=fail -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew bundleRelease --warning-mode=fail -PMAPS_API_KEY="$MAPS_API_KEY"
```

Instrumentation tests still require an emulator or connected device:

```bash
./gradlew connectedDebugAndroidTest -PMAPS_API_KEY="$MAPS_API_KEY"
```

## Remaining verification dependency

The clean source package intentionally excludes build directories and local secret-bearing properties files. Rebuild outputs should be regenerated locally rather than copied from an archive.
