# Production Completion Strategy & Final Release Roadmap (v1.0)

This document serves as the absolute technical requirement set for transitioning **QC Divers** from a feature-complete beta to a 100% production-hardened, high-end Android application.

---

## 1. Feature Completion: The "100% Implementation" Path

### 1.1 Community & Social Trust (Phase C & D)
To reach 100% on community features, the app must move from "Discovery" to "Intelligence."

*   **Active-Spot Consensus Engine**:
    *   *Implementation*: Create `CalculateSpotConfidenceUseCase`.
    *   *Logic*: If a spot has >3 "Good Haul" reports in the last 48 hours from different users, mark as "🔥 Trending". If it has >2 "Nothing There" reports, mark as "⚠️ Likely Empty".
*   **Public Scout Profiles**:
    *   *Implementation*: `ProfileViewModel` + `ScoutProfileScreen`.
    *   *Scope*: Read-only stats (Total Spots Verified, Total Hauls, Rank Title). No private data leak.
*   **Safety: Sensitive Area Blacklisting**:
    *   *Implementation*: Add a `GeoBlacklistDataSource`.
    *   *Logic*: Cross-reference new community-visibility spots against a Geo-JSON list of schools, government buildings, and strictly residential zones. Auto-revert to `PRIVATE` if matched.
*   **UGC Compliance**: Finalize the In-App Privacy Policy and Data Safety labels for Google Play.

### 1.2 Advanced Tooling Hardening
*   **Intelligent Voice Context Matcher**:
    *   *Advanced Logic*: Instead of just string matching, use `GetNearestSpotsUseCase` within the voice flow. Prioritize the closest spot (< 500m) and the spot currently being checked in an active `FieldSession`.
*   **Traveling Salesman Route Optimization**:
    *   *Implementation*: `OptimizeRouteUseCase`.
    *   *Logic*: Given a `RoutePlan` with N stops, use a simple Kotlin-based TSP algorithm (or Google Maps Distance Matrix API) to reorder stops for minimum travel distance.
*   **Predictive Analytics Dashboard**:
    *   *Implementation*: `PredictiveVisitUseCase`.
    *   *Logic*: "Optimal Check Window" = `LastChecked + (AvgPickupInterval - 4 hours)`.

---

## 2. Advanced Architectural Hardening

### 2.1 Complete MVI Ubiquity
While the `MapViewModel` is now MVI, the following must be migrated to ensure deterministic state management:
*   **ViewModels to Migrate**: `SpotViewModel`, `VoiceViewModel`, `HomeViewModel`.
*   **Side Effect Handling**: Implement `BaseViewModel<State, Intent, Effect>`.
    *   `Effect` should be a `Channel<Effect>(BUFFERED)` consumed as a `Flow`.
    *   Used for: Navigation, Haptic Feedback, Snackbars.

### 2.2 UseCase/Domain Layer Extraction
Repositories should be treated as "dumb" data providers. All logic moves to UseCases:
*   **Mandatory UseCases**:
    *   `SynchronizeSpotDataUseCase` (Handles the logic of merging local vs remote).
    *   `ProcessVoiceTranscriptUseCase` (The NLP/Matching logic).
    *   `CalculatePersonalEfficiencyUseCase` (The stats logic).

### 2.3 Advanced Repository Orchestration
Transition from "Repository calls DataSource" to "Repository manages Resource State":
*   **Resource Pattern**: `data class Resource<T>(val status: Status, val data: T?, val message: String?)`.
*   **Strategy**: `LocalFirstThenRemote`. Return Room data immediately, fetch from Supabase in background, update Room, and emit the new state.

### 2.4 Transactional Sync Queue
*   **Atomic Updates**: Enhance `SyncQueueProcessor` to support "Sync Atoms".
*   *Example*: If a user creates a Spot AND a Report simultaneously while offline, the Sync Queue must ensure the Spot is successfully created in Supabase before the Report attempts to link to its `remoteId`.

---

## 3. Production Hardening (Security & Performance)

### 3.1 Security Hardening
*   **Encrypted Data Store**: Migrate `UserPreferences` and Supabase Auth Tokens to `EncryptedSharedPreferences` or `EncryptedDataStore`.
*   **SSL Pinning**: Implement `CertificatePinner` in the OkHttpClient (used by Supabase/Postgrest) to prevent MITM attacks on community data.
*   **ProGuard/R8 Audit**: Ensure `proguard-rules.pro` is strictly configured to obfuscate business logic while keeping necessary Supabase/Serialization classes.

### 3.2 Performance Optimization
*   **Baseline Profiles**: Generate a `baseline-prof.txt` to pre-compile critical paths (App Startup, Map Marker Rendering, Voice Flow).
*   **Map Marker Clustering (Advanced)**: Implement `DefaultClusterRenderer` for the Google Maps SDK to handle 1000+ community markers without UI jank.
*   **Image Pipeline**: Use `Supabase Storage` transformation parameters in `Coil` (e.g., `?width=300&quality=80`) to reduce bandwidth on community thumbnails.

### 3.3 Monitoring & Stability
*   **Sentry/Crashlytics Context**: Auto-log `sync_status`, `is_authenticated`, and `last_known_location` (coarse) with every crash report.
*   **Trace Points**: Implement `Firebase Performance Monitoring` traces on `VoiceParsing` and `MapLoad` to identify bottlenecks in the field.

---

## 4. Release Readiness Checklist

| Category | Item | Status |
| :--- | :--- | :--- |
| **QA** | Full Offline-to-Online Sync Test (100 records) | [ ] |
| **QA** | Voice Match Accuracy Audit (>90% target) | [ ] |
| **Legal** | Privacy Policy & Terms of Service in-app | [ ] |
| **Store** | High-Res Store Screenshots (Dark/Night Mode) | [ ] |
| **Store** | Content Rating (UGC Moderation Section) | [ ] |
| **DevOps** | CI/CD Pipeline for Signed AAB Production Builds | [ ] |

---

## 5. Implementation Roadmap (Final Sprint)

1.  **Sprint 1: MVI & UseCase Ubiquity** (ViewModels refactor).
2.  **Sprint 2: Sync & Transactional Integrity** (SyncQueue hardening).
3.  **Sprint 3: Community Intelligence** (Consensus, Profiles, Trust).
4.  **Sprint 4: Production Hardening** (Security, Performance, Monitoring).
5.  **Sprint 5: RC & Store Submission**.
