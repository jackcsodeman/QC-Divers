# Release Checklist

## Build verification

- [ ] `./gradlew clean -PMAPS_API_KEY=""`
- [ ] `./gradlew assembleDebug -PMAPS_API_KEY=""`
- [ ] `./gradlew test -PMAPS_API_KEY=""`
- [ ] `./gradlew bundleRelease -PMAPS_API_KEY=""`
- [ ] Install debug APK on emulator/device
- [ ] Install release build signed with internal/test signing config
- [ ] Verify minification does not break Supabase serialization/auth/storage

## Signing

- [ ] Create upload key outside source control
- [ ] Enroll in Play App Signing
- [ ] Store keystore in a secure password manager or CI secret store
- [ ] Document local and CI signing properties without committing secrets

## Configuration

- [ ] `MAPS_API_KEY` supplied through Gradle property or CI secret
- [ ] `SUPABASE_URL` supplied through Gradle property or CI secret
- [ ] `SUPABASE_ANON_KEY` supplied through Gradle property or CI secret
- [ ] No service-role key exists in app source, Gradle files, docs, or CI logs
- [ ] Release build has no debug credentials or test endpoints

## Supabase

- [ ] Apply all `supabase/migrations/*.sql` files
- [ ] Confirm RLS is enabled on all user-owned tables
- [ ] Confirm storage bucket `spot-photos` is private
- [ ] Run/adapt `supabase/verification/rls_checks.sql`
- [ ] Confirm user A cannot read/update/delete user B private data
- [ ] Confirm community/public records are read-only to non-owners
- [ ] Confirm private photos are not publicly readable

## Privacy and policy

- [ ] Finalize privacy policy
- [ ] Complete Data Safety form
- [ ] Complete permissions declaration/rationales
- [ ] Verify account deletion and cloud data deletion flows
- [ ] Verify local data wipe flow
- [ ] Verify export before delete copy

## QA

- [ ] Run `docs/testing/MANUAL_QA_CHECKLIST.md`
- [ ] Verify local-only mode with airplane mode
- [ ] Verify signed-in sync after reconnecting
- [ ] Verify sync failure and retry behavior
- [ ] Verify maps without key fails gracefully
- [ ] Verify permissions are requested just-in-time

## Play Store

- [ ] App name, short description, full description ready
- [ ] Screenshots captured from release-like build
- [ ] Feature graphic prepared
- [ ] Content rating completed
- [ ] Internal test uploaded
- [ ] Closed test uploaded if required
- [ ] Release notes prepared
- [ ] Known limitations documented
