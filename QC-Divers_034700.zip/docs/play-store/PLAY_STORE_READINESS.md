# Play Store Readiness

This repo has the native Android foundation needed to generate a Play Store bundle, but final release still requires signing, policy, QA, and store assets.

## Release command

```bash
./gradlew bundleRelease -PMAPS_API_KEY=""
```

The generated bundle should appear under:

```text
app/build/outputs/bundle/release/
```

Use a real signing setup before production upload. Do not commit keystores or passwords.

## Store listing draft

App name: QC Divers / Dumpster Scout

Short description:

> Offline-first field scouting for dumpster, tire, cleanup, and salvage locations.

Full description draft:

> QC Divers helps field users privately track useful outdoor locations, site reports, photos, routes, reminders, tire spots, and scouting history. The app works offline first, stores data locally by default, and supports optional Supabase account sync when configured. Users can record reports manually or by voice, view saved spots on a map, mark favorites, plan routes, and export local data.

## Permissions rationale

- Location: used only to show current location, sort nearby spots, and add a spot from current location.
- Camera: used only when the user captures a spot/report photo.
- Photos/media: used only when the user chooses a photo from the device.
- Microphone: used only for voice reporting.
- Notifications: used only for reminders.
- Internet/network state: used for maps and optional Supabase sync.

Exact alarm permissions are intentionally not requested in this repository version.

## Screenshot plan

- Home dashboard
- Dumpster spot list
- Tire spot list
- Map screen
- Add/edit spot
- Spot detail with history
- Voice report review
- Settings/account sync state

## Play review notes

If Supabase sync is enabled for review, provide either:

- a demo account, or
- clear instructions that the app works in local-only mode without login.

The app should not require sign-in for core functionality.
