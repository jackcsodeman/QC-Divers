# Screenshot and Asset Plan

Actual screenshots must be captured from a real device or emulator release/preview build. This repository cannot generate final Play Store screenshots without a graphical Android runtime.

## Required screenshot set
Capture at least 8 phone screenshots:

1. Home dashboard with summary cards and quick actions.
2. All/spot list showing polished cards, search, and filters.
3. Dumpster detail with hero, status badges, reports, and photo gallery.
4. Tire spot detail with tire-specific fields and photo gallery.
5. Cleanup/salvage field locations screen.
6. Map screen with markers, filters, and bottom sheet preview.
7. Sync Status / Conflict Resolution screen showing transparent offline sync.
8. Settings privacy/data controls, backup/restore, and account sync options.

## Optional additional screenshots
- Voice report review flow.
- Reminders screen.
- Field sessions summary.
- Analytics dashboard.
- Gear checklist.

## Capture requirements
- Use release or near-release build, not debug UI.
- Use representative sample data.
- Do not show real private coordinates, private notes, personal email, API keys, or real phone/account data.
- Capture both light and dark mode for internal review; submit the best coherent set to Play.
- Ensure status bars/navigation bars are clean.
- Ensure screenshots match the store listing copy and Data Safety declarations.

## Feature graphic guidance
Create a 1024x500 feature graphic with:
- App name: QC Divers
- Subheading: Offline-first field scouting
- Visual motifs: map pin, field route, shield/privacy, notebook/report, tire/dumpster iconography
- No small text that will be unreadable in Play Store surfaces.
