# QC Divers Play Store Listing Package

## App name
QC Divers

## Short description
Offline-first field scouting for dumpsters, tire spots, cleanup sites, routes, reminders, and reports.

## Full description
QC Divers is a private, offline-first field scouting app for tracking useful outdoor locations, dumpster spots, tire dump sites, cleanup opportunities, salvage/resource spots, routes, photos, reminders, and field reports.

Designed for real field use, QC Divers works without a network connection and stores core data locally first. Optional Supabase sync can back up account data when enabled by the user. Private/local mode is the default.

### Highlights
- Track dumpster spots, tire spots, cleanup sites, salvage/resource locations, and custom scouting locations.
- Add reports, notes, conditions, hazards, access details, tags, and photos.
- Use voice reporting for fast field updates.
- View saved locations on a map and open external navigation.
- Plan routes and track field sessions.
- Use reminders and a durable gear checklist before heading out.
- Export and restore local backups.
- Review sync queue status, retry failures, and keep private data private.

### Privacy posture
QC Divers is local/private by default. Cloud sync is optional. Photos use private storage references when sync is enabled; private photos are not exposed through public URLs.

## Suggested category
Maps & Navigation or Productivity. Use Maps & Navigation if field-location workflows are the main marketing angle; use Productivity if private scouting/logging is the primary angle.

## Content rating notes
The app does not contain user-generated public social content by default. If community-public sharing is enabled, complete the Play content rating questionnaire according to public UGC/moderation behavior.

## Support/contact placeholder
Support email: support@example.com
Privacy policy URL: https://example.com/qc-divers/privacy

## Demo account guidance
Most app functionality works in local-only mode. If Play Review needs cloud sync testing, create a Supabase test account and document credentials in Play Console review notes only, never in source control.

## Release notes template
Version 1.0.0
- Initial beta release of QC Divers.
- Offline-first scouting, reports, photos, reminders, sync status, backup/restore, and privacy controls.
- Optional Supabase-backed account sync.
