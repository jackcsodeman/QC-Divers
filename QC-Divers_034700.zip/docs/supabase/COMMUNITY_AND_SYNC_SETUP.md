# Community, Visibility, and Sync Setup

QC Divers is private/local-first by default. Community/public behavior must stay explicit.

## Visibility values

Supported visibility states across app and Supabase policies:

```text
PRIVATE
SHARED_WITH_LINK
COMMUNITY_PUBLIC
ARCHIVED
```

Some older migrations also accept compatibility aliases:

```text
COMMUNITY
PUBLIC
```

Use `PRIVATE` as the default for all new rows.

## Recommended first-release community posture

For the first Play Store release, keep community sharing disabled in UI unless the full moderation workflow is ready.

Recommended behavior:

- Saved field records are private by default.
- Cloud sync is optional.
- Public/community visibility requires an explicit user action.
- Do not expose public feeds unless moderation, reporting, and takedown workflows are implemented.
- Do not publicly expose exact private coordinates accidentally.

## Enabling community/public read behavior

The Supabase RLS policies allow select access for visible rows:

```sql
visibility in ('COMMUNITY','PUBLIC','SHARED_WITH_LINK','COMMUNITY_PUBLIC')
```

Owners remain the only users allowed to insert/update/delete their own rows.

To enable community features safely:

1. Add a visible UI control that clearly changes a record from `PRIVATE` to `COMMUNITY_PUBLIC`.
2. Show a warning explaining what will become visible.
3. Confirm the user understands coordinates/photos/notes may be visible depending on feature design.
4. Provide a way to switch back to `PRIVATE` where appropriate.
5. Add in-app report/flag functionality before any public feed is shown.
6. Add moderation workflows before allowing user-to-user public content discovery at scale.

## Community moderation tables

The core schema includes `moderation_flags` for future public/community reporting. A complete community release should add or verify:

- Report content flow in Android.
- Admin/moderator review process.
- Takedown/hide behavior for flagged public rows.
- Abuse prevention for repeated false reports.
- Updated Play Store content rating answers.
- Updated privacy policy and Data Safety answers.

## Sync versus sharing

Sync is not the same as sharing.

- `PRIVATE + synced` means the user’s private cloud copy.
- `COMMUNITY_PUBLIC` means eligible for public/community read behavior.
- Sync status should never imply public visibility.
- Visibility badges should be shown separately from sync badges.

## Google Play content rating guidance

If the app does not expose public UGC, answer content-rating/community questions as a private productivity/tool app.

If public community sharing ships later, update:

- Content rating answers.
- Data Safety answers.
- Privacy policy.
- App access/reviewer notes.
- In-app moderation/reporting features.
