# Supabase Full Setup for QC Divers

This guide configures Supabase for optional account, sync, private photo storage, account deletion, and community/public visibility behavior.

## 1. Create the Supabase project

1. Create a new Supabase project.
2. Save these values for Android local configuration:
   - Project URL
   - Anon public key
3. Never put the service-role key in Android source, Gradle files, GitHub, or Play Console.
4. Use the service-role key only in Supabase Edge Functions or secure server-side automation.

## 2. Configure Android local properties

Put these in your local `gradle.properties`, `~/.gradle/gradle.properties`, or CI secrets. Do not commit real values.

```properties
SUPABASE_URL=https://your-project-ref.supabase.co
SUPABASE_ANON_KEY=your-public-anon-key
MAPS_API_KEY=your-google-maps-key
```

For release signing, keep these local too:

```properties
RELEASE_STORE_FILE=/absolute/path/to/upload-key.jks
RELEASE_STORE_PASSWORD=your-password
RELEASE_KEY_ALIAS=your-alias
RELEASE_KEY_PASSWORD=your-password
```

## 3. Apply database migrations

Apply migrations in order from `supabase/migrations`:

```bash
supabase link --project-ref your-project-ref
supabase db push
```

Or paste/run the SQL files in order through Supabase SQL Editor.

Required migration order:

```text
202605180001_core_schema.sql
202605180002_private_storage.sql
202605220001_route_stop_metadata.sql
202605220002_field_sessions.sql
202605220003_gear_reminder_sync_hardening.sql
202605220004_field_location_reports_reminder_state.sql
```

After applying migrations, verify these tables exist:

```text
profiles
field_locations
field_location_reports
dumpster_spots
dumpster_reports
tire_spots
tire_reports
spot_photos
route_plans
route_stops
collections
collection_items
field_sessions
field_session_visits
reminders
gear_checklists
gear_checklist_items
moderation_flags
sync_audit_events
```

## 4. Configure storage

The private photo bucket is created by migration:

```text
spot-photos
```

Expected behavior:

- Private bucket by default.
- Paths should include the owner/user namespace.
- Android stores private storage references, not permanent public photo URLs.
- Use signed/authenticated access for private media.

Do not make private photo buckets public for production.

## 5. Configure Auth redirect URLs

In Supabase Auth settings, configure redirect URLs used by the app.

Recommended values:

```text
qcdivers://auth/callback
https://qcdivers.app/auth/callback
```

Enable only the providers you actually support. For the current app, email OTP/magic-code style auth is the safest baseline.

## 6. Deploy the account deletion Edge Function

Set secrets locally for Supabase functions:

```bash
supabase secrets set SUPABASE_URL=https://your-project-ref.supabase.co
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

Deploy:

```bash
supabase functions deploy delete-account
```

The Android app calls:

```text
/functions/v1/delete-account
```

The Edge Function should delete user-owned app records, storage objects under the user prefix, the profile row, and the Supabase Auth user. Keep service-role credentials server-side only.

## 7. Verify RLS

Run:

```text
supabase/verification/rls_checks.sql
```

Minimum RLS expectations:

- Signed-out users cannot read private rows.
- Signed-in users can read/write their own private rows.
- Public/community rows can be read according to `visibility` policies.
- Non-owners cannot update/delete public/community rows.
- Storage objects are scoped by owner.

## 8. Android sync behavior

The Android app uses a durable `sync_queue` outbox.

Expected flow:

1. User creates/updates/deletes a supported record offline or online.
2. The app writes local Room data first.
3. The app enqueues an operation in `sync_queue`.
4. `SyncWorker` pushes queued operations when Supabase is configured and network is available.
5. Rows are marked `SYNCED` only after remote confirmation.
6. Failed items keep retry metadata and last errors.
7. Conflict review surfaces local/remote payloads when available.

Supported sync areas include:

```text
dumpster spots and reports
tire spots and reports
field locations and field-location reports
photos
routes and route stops
collections and collection items
field sessions and visits
reminders
gear checklists and items
```

## 9. Production checklist

Before release:

- Run Android Gradle build/test/lint locally.
- Regenerate Room schema from annotation processing.
- Run migration tests.
- Run `supabase db push` against staging first.
- Verify RLS with two test users.
- Verify private photo upload/download/delete.
- Verify account deletion fully deletes cloud rows and storage objects.
- Verify local-only mode works without Supabase credentials.
- Verify no service-role key is present in Android source.
