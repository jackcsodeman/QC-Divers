# Community Moderation Readiness

QC Divers should remain **private/local-first by default**. Public/community sharing should stay disabled in user-facing UI until moderation, reporting, review, and blocking flows are fully tested.

## Optional backend tables

The migration below creates moderation-ready tables without enabling public UI by itself:

```text
supabase/migrations/202605220006_community_moderation_readiness.sql
```

It adds:

- `community_reports` for user-submitted reports about public/community content.
- `blocked_users` for future user-level blocking.

## Recommended launch posture

For first release:

- Keep records `PRIVATE` by default.
- Allow optional sync without public sharing.
- Do not expose `COMMUNITY_PUBLIC` controls unless moderation is complete.
- Answer Google Play content-rating questions as **not a social/communication app** unless public UGC is enabled.

## Before enabling public/community sharing

Implement and verify all of the following:

1. A visible report action on every public record.
2. A visible block/hide action for public contributors.
3. A moderation review process for `community_reports`.
4. Removal or hiding behavior for reported content.
5. Abuse-prevention rate limits.
6. Updated Privacy Policy and Data Safety responses.
7. Updated Play content-rating answers.
8. Manual QA with two test users.
9. RLS verification proving private records stay private.
10. Clear in-app copy explaining that public records may be visible to other users.

## Verification queries

Run:

```sql
select to_regclass('public.community_reports') as community_reports;
select to_regclass('public.blocked_users') as blocked_users;

select tablename, rowsecurity
from pg_tables
where schemaname = 'public'
  and tablename in ('community_reports', 'blocked_users');
```

Both tables should exist and have RLS enabled.
