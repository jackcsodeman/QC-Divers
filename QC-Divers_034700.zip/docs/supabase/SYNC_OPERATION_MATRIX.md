# Sync Operation Matrix

This matrix documents source-level sync support and remaining runtime proof needed.

| Domain | Local Room | Queue create/update/delete | Remote push | Remote pull | Child remote IDs | Notes |
|---|---:|---:|---:|---:|---:|---|
| Dumpster spots | Yes | Yes | Yes | Yes | N/A | Legacy and queue paths exist. |
| Dumpster reports | Yes | Yes | Yes | Yes | Parent spot resolved | Skips pull until parent exists. |
| Tire spots | Yes | Yes | Yes | Yes | N/A | Legacy and queue paths exist. |
| Tire reports | Yes | Yes | Yes | Yes | Parent tire spot resolved | Skips pull until parent exists. |
| Field locations | Yes | Yes | Yes | Yes | N/A | Cleanup/salvage/custom domain. |
| Field-location reports | Yes | Yes | Yes | Yes | Parent field location resolved | Added for field-location report parity. |
| Photos | Yes | Upload/delete | Yes | Metadata-only | Owner type/id | Private storage references, not public URLs. |
| Routes | Yes | Yes | Yes | Parent pull | Location remote IDs resolved | Child route-stop pull still needs runtime proof. |
| Collections | Yes | Yes | Yes | Parent pull | Location remote IDs resolved | Child item pull still needs runtime proof. |
| Field sessions | Yes | Yes | Yes | Parent pull | Location remote IDs resolved | Child visit pull still needs runtime proof. |
| Reminders | Yes | Yes | Yes | Yes | Parent location resolved | Notification runtime proof required. |
| Gear checklists | Yes | Yes | Yes | Parent pull | N/A | Child item pull still needs runtime proof. |

## Runtime proof still required

- Compile with Hilt/KSP/Room.
- Run migration tests.
- Run sync tests against staging Supabase.
- Verify retry/failure UI.
- Verify conflict review with real remote snapshots.


## Latest source-only sync closure

The current source targets Room database version 13. It adds remote metadata and remote pull coverage for normalized child rows: route stops, collection items, field-session visits, and gear checklist items. These changes require Android Studio/Gradle verification, Room schema regeneration, and Supabase staging tests before release claims are made.
