# Next Extensive Runtime Hardening Progress

This source-only batch focused on runtime-adjacent gaps that were still blocking production confidence after the Room v12 child-pull work.

No Gradle, lint, unit-test, instrumentation-test, or device commands were run in this environment.

## Completed

### Storage Access Framework backup/export/import

Settings export/import no longer depends on clipboard-only JSON transfer.

Source changes:

- `SettingsScreen` now uses `ActivityResultContracts.CreateDocument("application/json")` for backup export.
- `SettingsScreen` now uses `ActivityResultContracts.OpenDocument()` for backup import.
- Backup import still goes through the existing dry-run preview before replacing local data.
- Export/import status and failure messages are shown through user-facing strings.

This is safer for large backups and avoids putting sensitive field-location backup JSON on the clipboard by default.

### Reminder notification deep links

Reminder notifications now include a destination route extra for the app shell.

Source changes:

- `MainActivity` accepts `EXTRA_NAV_ROUTE` and `EXTRA_REMINDER_ID`.
- `MainActivity.onNewIntent(...)` updates the pending navigation route for already-running app instances.
- `DumpsterScoutNavGraph` consumes an initial route after onboarding is complete.
- `ReminderWorker` routes notification taps to the Reminders screen.

Runtime proof still requires installing the app, creating a reminder, receiving a notification, and tapping it.

### Map external navigation and marker safety

The map screen now has source-level support for launching external navigation from the selected map preview card.

Source changes:

- `MapScreen` builds a `geo:` intent for selected locations with coordinates.
- Location preview cards now include a `Navigate` action.
- The map applies a marker rendering safety cap through `MAX_RENDERED_MAP_MARKERS`.
- A density banner explains when the map is rendering a capped marker set and recommends filters/list view.

This is not full marker clustering, but it reduces large-dataset map jank risk until clustering is implemented and tested.

### Pre-build source gate expanded

`scripts/pre_build_source_gate.sh` now checks:

- Storage Access Framework export/import markers.
- Reminder notification deep-link markers.
- Map external navigation markers.
- Map marker rendering safety markers.

## Still requires Android Studio/device proof

- SAF export/import round trip with real user-selected files.
- Reminder notification scheduling and tap routing.
- External navigation intent handling on a device with Google Maps or another navigation app.
- Map behavior with hundreds/thousands of saved locations.
- Gradle compile, lint, tests, Room schema generation, and migration execution.
