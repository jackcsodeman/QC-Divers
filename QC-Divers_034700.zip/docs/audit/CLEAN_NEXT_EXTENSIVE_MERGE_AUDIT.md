# Clean + next-extensive merge audit

## Verdict

The `dumpsterscout-next-extensive-map-test-moderation` variant was the more progressed feature branch, but the corrected package now preserves the clean variant as the baseline and layers the next-extensive work on top of it.

The first generated ZIP was re-audited and found to be too close to a straight next-extensive tree copy. This corrected package restores the non-artifact clean-only source changes while retaining the next-extensive Room/sync/map/moderation additions.

## Changes carried into this corrected clean package

- Room database source advanced to version 13 with schema exports through `app/schemas/.../13.json`.
- Restored clean-only current-location support for add/edit spot flows:
  - `LocationRepository`
  - `LocationRepositoryImpl`
  - `LocationModule`
  - `FakeLocationRepository`
  - `SpotViewModel.useCurrentLocation()`
  - Add Spot location permission/current-location UI hook
- Restored clean-only voice parsing/reporting improvements:
  - transcript location hints
  - geocoding helper
  - proximity-assisted voice spot matching
  - voice-created dumpster/tire spot fallback behavior
  - tire report voice/location metadata
- Added migration `MIGRATION_12_13` for restored tire report metadata columns:
  - `voiceTranscript`
  - `isFromVoice`
  - `latitude`
  - `longitude`
- Preserved clean launcher resources while avoiding duplicate drawable names.
- Preserved clean release metadata posture where safe: `targetSdk = 36`, `versionName = "1.1.1b"`.
- Preserved next-extensive field-location report persistence, DAO, DTO, no-op remote, Supabase remote source, and DTO tests.
- Preserved next-extensive remote child-row pull contracts and sync-worker pull coverage for route stops, collection items, field-session visits, and gear checklist items.
- Preserved next-extensive route/reminder/map runtime hardening, including reminder notification deep-link routing and external navigation hooks.
- Preserved next-extensive map marker model and clusterer test coverage.
- Preserved next-extensive WorkManager test dependency scaffolding.
- Preserved Play-safe media permission posture by keeping broad media-library permissions out of the manifest.
- Preserved Supabase setup, sync-operation, verification, and moderation-readiness docs/migrations.
- Preserved and updated the pre-build source gate.

## Cleanups applied during merge

- Removed committed local secrets from the clean variant (`MAPS_API_KEY`, Supabase anon key, and local signing passwords were present in the original clean package).
- Removed local-only/build artifacts from the clean variant:
  - `local.properties`
  - release AAB
  - lint output
  - logcat output
  - `shipping/`
- Replaced hard-coded keystore configuration with property-driven release signing.
- Added a sanitized `gradle.properties` containing only non-secret build defaults.

## Verification status

Static source gate passed in this sandbox.

Full Gradle build/test execution was not possible because the Gradle wrapper tries to download Gradle 9.5.0 from `services.gradle.org`, and this environment has no network access.

Run locally next:

```bash
chmod +x gradlew scripts/*.sh
./scripts/pre_build_source_gate.sh
./gradlew clean test lint assembleDebug -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew bundleRelease \
  -PMAPS_API_KEY="$MAPS_API_KEY" \
  -PSUPABASE_URL="$SUPABASE_URL" \
  -PSUPABASE_ANON_KEY="$SUPABASE_ANON_KEY" \
  -PRELEASE_STORE_FILE="$RELEASE_STORE_FILE" \
  -PRELEASE_STORE_PASSWORD="$RELEASE_STORE_PASSWORD" \
  -PRELEASE_KEY_ALIAS="$RELEASE_KEY_ALIAS" \
  -PRELEASE_KEY_PASSWORD="$RELEASE_KEY_PASSWORD"
```
