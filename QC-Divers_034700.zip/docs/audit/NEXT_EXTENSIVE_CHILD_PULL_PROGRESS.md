# Next Extensive Child Pull Progress

This source-only batch improves remote sync completeness for normalized child rows.

## Completed

- Advanced Room to database version 12.
- Added remote metadata to normalized child tables:
  - `route_stops.remoteId`, `ownerUserId`, `syncStatus`
  - `collection_items.remoteId`, `ownerUserId`, `syncStatus`
  - `field_session_visits.remoteId`, `ownerUserId`, `syncStatus`, `deletedAt`
- Added `MIGRATION_11_12` and registered it in Hilt database setup.
- Added remote child pull contracts and Supabase implementations for:
  - route stops
  - collection items
  - field-session visits
  - gear checklist items
- Updated `SyncWorker` to pull child rows after parent rows and skip unresolved children safely.
- Added local child remote-ID lookup DAO methods to avoid duplicate imports.
- Added Supabase index migration `202605220005_child_pull_metadata.sql`.
- Updated the pre-build source gate to require database v12 and child pull coverage.

## Still requires Android Studio / Supabase proof

- KSP/Room schema generation for v12.
- Migration execution on emulator/device.
- Hilt graph compile with expanded remote interfaces.
- Real Supabase pull/merge verification with two-device/staging data.
