# Route Completion and Feature Percentage Progress

## Summary

This pass targets the lowest-scoring feature from the deep audit: **Routes**. The previous route implementation stored a JSON list of dumpster spot IDs and did not support mixed tire/field locations, ordered route stops, route detail expansion, or navigation handoff.

## Implemented

- Added `RouteStopEntity` as normalized Room persistence for route stops.
- Upgraded Room database to version `8`.
- Added `MIGRATION_7_8`.
- Migrates legacy `route_plans.spotIds` into `route_stops`.
- Added sync-ready metadata to `RoutePlanEntity`.
- Expanded `RoutePlanDao` with stop observation, insertion, soft deletion, and ordering.
- Rebuilt `SavedRoutesScreen` into an expandable route planner:
  - mixed dumpster/tire/cleanup/salvage/custom location candidates
  - add stop
  - remove stop
  - reorder up/down
  - route stop count
  - Google Maps navigation handoff for routable coordinate stops
  - route details inside polished route cards
- Rebuilt `RoutePlanViewModel` to combine route plans, route stops, dumpster spots, tire spots, and field locations.
- Expanded local backup/restore to include `route_stops`.
- Expanded migration tests through version 8.
- Updated source trace docs.

## Completion Estimate Changes

- Routes: estimated improvement from ~45% to ~72-78% source-level completion.
- Room local database: estimated improvement from ~82% to ~85-88% due normalized route table and migration path.
- Map/routes integration: route navigation handoff now exists, but direct map route preview remains future work.
- Sync: route remote sync remains incomplete; source score does not mark routes as fully remote-synced yet.

## Remaining route work

- Add Supabase `RemoteRouteDataSource` and sync processor support for `route_plans`/`route_stops`.
- Add a dedicated full-screen route detail view if cards become too dense.
- Add route stop drag-and-drop reorder.
- Add route optimization.
- Add route sync tests and DAO tests.
- Run real Gradle build and migration tests locally.

## Build verification

Static checks were performed in this environment. Real Gradle build/test execution remains blocked here by lack of network access to Gradle distribution services. Run on your PC:

```bash
chmod +x gradlew
./gradlew clean -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew test -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew assembleDebug -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew bundleRelease -PMAPS_API_KEY="$MAPS_API_KEY"
```
