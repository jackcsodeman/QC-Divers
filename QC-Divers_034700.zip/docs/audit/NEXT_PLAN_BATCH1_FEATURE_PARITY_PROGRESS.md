# Next Plan Batch 1 — Feature Parity Source Progress

This source-only batch continues after Batch 0 stabilization. It does not include Gradle, lint, Room annotation processing, emulator, device, or Supabase runtime proof.

## Completed source changes

- Advanced Room to database version 11.
- Added `field_location_reports` for cleanup, salvage/resource, and custom field-location report/history parity.
- Added `FieldLocationReportEntity` and `FieldLocationReportDao`.
- Added field-location report history UI inside the Field Locations screen.
- Added field-location edit support from the list card.
- Added report count/latest-report summary to field-location cards.
- Added reminder completion and snooze metadata (`completedAt`, `snoozedUntil`).
- Added reminder edit, complete, and snooze actions in the Reminders screen.
- Expanded backup/export/import and clear-local-data coverage to include field-location reports.
- Expanded analytics to include field-location reports in total report coverage.
- Added Supabase migration `202605220004_field_location_reports_reminder_state.sql`.
- Updated account deletion backend table coverage to include `field_location_reports`.
- Expanded migration test source to validate paths through Room v11.
- Updated pre-build source gate to validate Room v11, `MIGRATION_10_11`, and new report files.

## Still pending runtime proof

- Gradle compile/lint/test.
- Room v11 schema regeneration from annotation processing.
- Migration execution on emulator/device.
- Field-location report sync as a first-class remote data source.
- Reminder notification deep-link runtime validation.
- UI/UX QA for the added field-location report and reminder actions.
