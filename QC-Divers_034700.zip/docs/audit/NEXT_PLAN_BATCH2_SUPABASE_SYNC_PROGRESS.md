# Next Plan Batch 2 — Supabase Sync and Community Setup Progress

This source-only batch focuses on making Supabase sync and community/public visibility behavior easier to configure, audit, and ship safely.

## Source changes

- Added remote DTO/data-source coverage for `field_location_reports`.
- Added no-op and Supabase-backed field-location report remote implementations.
- Added Hilt binding for `RemoteFieldLocationReportDataSource`.
- Added `FIELD_LOCATION_REPORT` sync queue entity type.
- Added sync queue processor handling for field-location report create/update/delete.
- Field-location report create/delete now enqueue first-class report operations instead of piggybacking on parent field-location updates.
- Report queue items depend on the parent field-location queue item when the parent location has not synced yet.
- SyncWorker now pulls remote field-location reports only when the parent field location exists locally.
- Added DTO mapping tests for `FieldLocationReportRow`.

## Supabase/community docs added

- `docs/supabase/SUPABASE_FULL_SETUP.md`
- `docs/supabase/COMMUNITY_AND_SYNC_SETUP.md`
- `docs/supabase/SYNC_OPERATION_MATRIX.md`
- `supabase/verification/community_and_sync_checks.sql`

These documents cover:

- Supabase project creation.
- Local Android secret/property setup.
- Migration order.
- Private photo storage bucket setup.
- Auth redirect URLs.
- Account deletion Edge Function deployment.
- RLS verification.
- Community/public visibility posture.
- Difference between private sync and public sharing.
- How to enable community features safely later.

## Source gate updates

`./scripts/pre_build_source_gate.sh` now verifies:

- field-location report remote files exist;
- Supabase setup docs exist;
- setup docs include `supabase db push` deployment instructions;
- community docs include `COMMUNITY_PUBLIC` visibility guidance;
- sync matrix includes field-location report coverage.

## Remaining runtime proof

Still requires Android Studio/Gradle/Supabase staging verification:

- Hilt constructor graph compile.
- KSP/Room schema generation.
- SyncWorker instantiation with the new injected data source.
- Field-location report sync against a real Supabase project.
- RLS behavior with two test accounts.
- Community/public visibility select/update restrictions.
