# Feature Percentage Progress — Route Sync and Conflict Review Pass

This pass intentionally skipped Gradle execution because the current environment cannot build. It is a source-level implementation pass against the latest route-completion source.

## Completed in this pass

### Routes

- Added `RemoteRouteDataSource`, `NoOpRemoteRouteDataSource`, and `SupabaseRouteDataSource`.
- Added serializable `RoutePlanRow` and `RouteStopRow` DTOs.
- Added Hilt binding for `RemoteRouteDataSource`.
- Extended `SyncQueueProcessor` to process `ROUTE_PLAN` create/update/delete operations.
- Updated `RoutePlanViewModel` to enqueue route create/update/delete operations when Supabase is configured.
- Added route sync payloads containing the route and normalized stops.
- Added route stop display metadata to the Supabase schema (`label`, `latitude`, `longitude`).
- Added an additive Supabase migration for existing Supabase projects: `202605220001_route_stop_metadata.sql`.
- Fixed the duplicate `owner_id` source definition in the `reminders` table migration.

### Conflict review

- Added `ConflictPayloadParser`, a source-testable parser for local/remote payload snapshots.
- Conflict review now supports payloads shaped as either a plain local snapshot or `{ "local": ..., "remote": ... }`.
- Conflict field rows now show remote values when available.
- Sensitive fields remain hidden/redacted in the UI.
- Added unit coverage for conflict payload parsing and changed-field detection.

## Estimated source-level score impact

| Area | Previous estimate | New source-level estimate | Notes |
|---|---:|---:|---|
| Routes | 72-78% | 82-88% | Local routes were already normalized; now route plans have a Supabase remote source and sync queue processor support. |
| Sync queue/offline sync | 65% | 70-74% | Route sync is now covered. Newer domains beyond field locations/routes still need processor coverage. |
| Conflict resolution | 42% | 52-58% | Now has local/remote diff parsing support, but remote conflict snapshots are not yet stored by the sync processor. |
| Supabase backend/RLS/storage | 70% | 72-75% | Route stop schema was brought closer to Android v8 route data. |

## Remaining route gaps

- Add direct tests for `RoutePlanViewModel` route queueing.
- Add route remote source tests with a fake client or repository abstraction.
- Persist remote IDs for route stops if per-stop conflict resolution becomes required.
- Add drag-and-drop route reordering if desired; current UI supports move up/down.

## Remaining sync/conflict gaps

- Store remote conflict snapshots when remote upsert detects stale remote data.
- Add keep-remote and merge actions that write resolved records back to Room.
- Expand sync processor support to collections, field sessions, gear checklists, reminders, and any route-stop-specific operation if required.
- Add more processor tests using fake remote data sources.
