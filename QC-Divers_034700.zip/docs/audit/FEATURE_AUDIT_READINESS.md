# Feature audit readiness

This repository is ready for a code-trace-based feature-completion audit after you rebuild it locally.

## Source trace inputs

- `docs/audit/SOURCE_TRACE.md`
- `docs/audit/source_trace.csv`

These map Kotlin source files to feature areas so completion percentages can be based on concrete code paths.

## Audit method to use next

For each feature, inspect and score these layers:

1. UI entry point and navigation route
2. UI state and ViewModel
3. Domain model / repository contract
4. Repository implementation
5. Room entity / DAO / migration
6. Sync queue integration, if syncable
7. Supabase data source / backend migration / RLS, if remote-backed
8. Error, empty, loading, offline, permission-denied, and success states
9. Unit/instrumentation/manual QA coverage
10. Docs/release/privacy implications

## Suggested completion bands

- 0%: no source present
- 20%: model or placeholder only
- 40%: local CRUD partial, missing UI or persistence pieces
- 60%: local end-to-end works, missing sync/tests/polish
- 80%: feature works with persistence, UI states, sync or documented local-only behavior, and basic tests
- 90%: feature is beta-ready with QA docs, error handling, privacy, and performance considerations
- 100%: feature is build-verified, device-verified, fully tested, documented, and Play Store-ready

## Features to score

- Home dashboard
- Dumpster spots
- Tire spots
- Cleanup/salvage/custom field locations
- Reports/history
- Voice reporting
- Map/location
- Search/filter/sort
- Favorites
- Collections
- Routes
- Field sessions
- Gear checklist
- Photos/media
- Reminders/notifications
- Analytics
- Import/export/backup/restore
- Auth/account/cloud deletion
- Supabase sync
- Conflict resolution
- Privacy/security controls
- Play Store release readiness

## Known audit caveat

A final percentage audit should be run only after a fresh local build with the cleaned source package. This cleanup removed local build outputs from the source archive, so current build artifacts should be regenerated on your PC.
