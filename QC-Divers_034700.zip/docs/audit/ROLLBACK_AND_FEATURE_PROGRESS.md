# Rollback and Feature Progress Pass

## Version rollback

The repo has been restored to the last known locally-built toolchain baseline from `IMPROVEMENTS.zip`:

- Gradle wrapper: 9.5.0
- Android Gradle Plugin: 9.2.1
- Kotlin: 2.2.10
- KSP: 2.2.10-2.0.2
- Compose BOM: 2026.05.00
- DataStore: 1.1.3
- compileSdk: 36
- targetSdk: 35

This intentionally backs out the later lint-driven version bumps that had not been proven in your build environment.

## Feature work completed in this pass

### High-percentage feature hardening

- Preserved the modern native Android/Kotlin/Compose stack.
- Preserved Room database version 7 and the current schema exports.
- Added a regression unit test for field-location remote DTO mapping.
- Updated source trace artifacts after current code changes.

### Lowest-percentage feature improvements

- Extended Supabase-backed sync to generic `field_locations`.
- Added `RemoteFieldLocationDataSource`, no-op local-only implementation, Supabase implementation, and DTO mapping.
- Added field-location sync queue processing in `SyncQueueProcessor`.
- Added field-location remote pull in `SyncWorker`.
- Queued create/update/delete operations from `FieldLocationsViewModel` when Supabase is configured.
- Updated account/cloud deletion Edge Function to delete `field_locations`.
- Unified the Map screen across dumpster spots, tire spots, and field locations.
- Added type filters for all/dumpsters/tires/field sites on the Map screen.
- Map list and preview cards now display sync/privacy status for all mapped location types.

## Remaining verification needed

This environment cannot download the Gradle wrapper distribution, so this pass still requires local verification:

```bash
chmod +x gradlew
./gradlew clean -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew test -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew assembleDebug -PMAPS_API_KEY="$MAPS_API_KEY"
./gradlew bundleRelease -PMAPS_API_KEY="$MAPS_API_KEY"
```

If those pass, the next implementation targets should be route detail/route stops, true remote conflict snapshots, and report-photo parity.
