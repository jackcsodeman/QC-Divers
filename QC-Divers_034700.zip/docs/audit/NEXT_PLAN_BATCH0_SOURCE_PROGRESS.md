# Next Plan Batch 0 Source Progress

Date: 2026-05-24

This source-only pass targeted the highest-risk findings from the latest code-trace audit before the next real Android Studio build.

## Completed

### Kotlin Android plugin wiring

The app module now applies the Kotlin Android plugin:

- Root `build.gradle.kts` declares `alias(libs.plugins.kotlin.android) apply false`.
- `app/build.gradle.kts` applies `alias(libs.plugins.kotlin.android)`.

This addresses the high-confidence compile risk where Kotlin source existed but the app module did not explicitly apply the Android Kotlin plugin.

### Play-safe image picking posture

The manifest no longer requests broad media-library permissions:

- Removed `android.permission.READ_MEDIA_IMAGES`.
- Removed legacy `android.permission.READ_EXTERNAL_STORAGE`.
- Removed `android.permission.READ_MEDIA_VISUAL_USER_SELECTED` because the app now uses the Android Photo Picker contract for user-selected images.

Photo attachment flows now use `ActivityResultContracts.PickVisualMedia` for:

- Dumpster spot photos
- Tire spot photos
- Field-location photos

Camera capture remains user-initiated and still uses the app-private `FileProvider` path.

### First-run onboarding is now wired

The navigation graph now starts at onboarding until `AppPreferences.onboardingDone` is true. Completing onboarding stores that preference and navigates to Home.

### Safer remote report pull

Remote dumpster/tire report pull no longer inserts child reports with a fake local parent ID of `0L`. Reports are skipped until their parent spot/tire spot exists locally, avoiding foreign-key failures and corrupted local history.

### Newer-domain remote parent pull

`SyncWorker` now pulls remote parent records for:

- Route plans
- Collections
- Field sessions
- Reminders
- Gear checklists

This does not yet pull every remote child row, but it closes the parent-record restore gap and documents deferred child-snapshot work in code comments.

### DAO lookup support

Added `remoteId` lookup helpers for:

- Route plans
- Collections
- Field sessions
- Reminders
- Gear checklists

### Source gates expanded

`scripts/pre_build_source_gate.sh` now verifies:

- Kotlin Android plugin wiring
- No broad image-library permissions
- Android Photo Picker usage
- Existing Room/schema/source quality checks

## Source-only checks run

- `./scripts/pre_build_source_gate.sh` passed.
- XML resource parse check passed.
- Missing `R.string` / `R.plurals` reference check passed.
- Kotlin brace-balance sanity check passed.
- No old invalid Hilt ViewModel imports found.
- No broad media permissions remain.
- No Google Maps API key patterns found.

## Not run here

Gradle, lint, tests, Room annotation processing, migration execution, and device QA were intentionally not run in this environment.

## Remaining required build-proof tasks

1. Run Gradle in Android Studio/local terminal.
2. Regenerate the real Room v10 schema through annotation processing.
3. Execute migration tests.
4. Verify Android Photo Picker behavior on device.
5. Verify onboarding first-run behavior.
6. Verify sync pull for parent records and document/implement child-row remote pull where needed.
