# Source Trace

Generated source trace for the current source-only package.

- Kotlin production files traced: 191
- Current Room database version expected by source gate: 12
- Latest source-only focus: map clustering readiness, WorkManager test dependency scaffolding, reminder scheduling tests, and optional community moderation readiness tables/docs.

See `docs/audit/source_trace.csv` for file-by-file mapping.
