# Reminder and Gear Sync Progress

This source-level batch extends the durable sync queue to the remaining local-first utility domains that were not previously covered.

## Added

- Room database version 9.
- `MIGRATION_8_9` for sync metadata on `reminders`, `gear_checklists`, and `gear_checklist_items`.
- Remote reminder source abstractions and Supabase implementation.
- Remote gear checklist source abstractions and Supabase implementation.
- Sync queue processing for `REMINDER` create/update/delete.
- Sync queue processing for `GEAR_CHECKLIST` create/update/delete.
- Reminder UI mutations now enqueue sync operations when Supabase is configured.
- Gear checklist mutations now enqueue sync operations when Supabase is configured.
- Supabase migration hardening for reminder/gear indexes and gear item emoji metadata.
- DTO tests for reminder and gear remote row mapping.

## Still requiring build/device verification

- Gradle compile, lint, unit tests, and release bundle generation.
- Room schema v9 regeneration from annotation processing.
- WorkManager sync pass with real Supabase credentials.
- Reminder notification behavior on a physical device/emulator.
- Gear checklist cross-device sync behavior after remote pull/merge is implemented.

## Remaining hardening

- Remote pull/merge into local reminders and gear checklists.
- Parent remote ID resolution for non-dumpster reminder targets once tire/field reminders are exposed in the UI.
- True conflict writeback actions for reminder and gear fields.
