# Next Batch Sync / Analytics Progress

## Scope

This pass targets the next weakest feature cluster after route normalization:

- collection sync coverage
- field session sync coverage
- conflict-review payload usefulness through richer queued payloads
- analytics depth
- Supabase backend parity for field sessions

Build execution was intentionally skipped because the current environment cannot build the project. This is a source-level implementation pass and still requires local Gradle verification.

## Completed source-level changes

### Collections

- Added `RemoteCollectionDataSource` contract.
- Added no-op local-only implementation.
- Added Supabase implementation for `collections` and `collection_items`.
- Added DTOs for collection remote rows.
- Added queue write support from `CollectionsViewModel` for create/update/delete collection mutations.
- Collection add/remove item operations now enqueue a parent collection update when Supabase is configured.
- Collection item removal now soft-deletes locally instead of immediately hard-deleting so the remote replacement path can observe intent.
- Added DAO helpers for snapshots, lookup, pending sync, synced, and failed sync state transitions.

### Field sessions

- Added `RemoteFieldSessionDataSource` contract.
- Added no-op local-only implementation.
- Added Supabase implementation for `field_sessions` and `field_session_visits`.
- Added DTOs for field session remote rows.
- Added queue write support from `FieldSessionsViewModel` for start/end/add visit/remove visit mutations.
- Added DAO helpers for snapshots, lookup, pending sync, synced, and failed sync state transitions.
- Added Supabase schema tables, indexes, RLS enablement, and owner-only policies for field sessions and visits.
- Added an additive Supabase migration for existing projects.

### Sync queue processor

- Added processor support for `COLLECTION` create/update/delete.
- Added processor support for `FIELD_SESSION` create/update/delete.
- Processor now pushes parent records plus normalized child rows and marks local parents synced only after remote confirmation.

### Analytics

- Analytics now includes counts for routes, collections, field sessions, and gear items in addition to existing location/report/photo/reminder/sync stats.
- The analytics screen now displays these additional metrics as first-class cards.

## Completion impact estimate

| Feature area | Prior estimate | New source-level estimate |
|---|---:|---:|
| Collections | ~55% | ~72-78% |
| Field sessions | ~53% | ~72-78% |
| Sync queue/offline sync | ~74-78% | ~80-84% |
| Supabase backend coverage | ~75-78% | ~80-84% |
| Analytics | ~55% | ~63-68% |

## Remaining work before 96-100%

- Run real Gradle compile/test/lint locally.
- Add DAO/repository tests for collections and field sessions.
- Add remote pull/merge into local collections/sessions rather than push-only support.
- Resolve target location remote IDs for collection items and field session visits where possible.
- Add sync queue support for reminders and gear checklist domains, or explicitly label them local-only in UI until synchronized.
- Add richer analytics aggregation queries and charts.
- Add device QA for collection/session sync and Supabase RLS.
