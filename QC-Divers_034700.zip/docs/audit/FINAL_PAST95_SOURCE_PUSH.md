# Final source-only push toward 95%+

This pass pushes the remaining non-runtime blockers closer to production completion without running Gradle or device tests.

## Completed in this pass

- Added `ConflictRemoteApplyUseCase` to support actual local row updates for accepting remote conflict snapshots on newer domains:
  - field locations
  - collections
  - field sessions
  - reminders
  - route plans
  - gear checklists
- Added safe local duplicate creation for the same newer domains when a conflict should preserve both local and remote intent.
- Wired conflict actions to the new apply/duplicate use case while preserving sync queue audit metadata.
- Added `RemoteLocationIdResolver` so synced child rows can include remote IDs for their target locations.
- Updated route, collection, and field-session Supabase data sources to resolve child `location_remote_id` values for:
  - `route_stops`
  - `collection_items`
  - `field_session_visits`
- Kept local/API/signing files excluded from the clean source package.

## Remaining work that cannot be honestly closed source-only

- Compile/lint/test verification in Android Studio or Gradle.
- Room schema regeneration from annotation processing.
- Migration execution through database version 10.
- Device QA for camera, gallery, notifications, map, backup/import, auth, and sync.
- True conflict writeback for the older richer dumpster/tire/report entities.
- End-to-end Supabase pull/merge verification against a real project.
- TalkBack/manual accessibility review.
- Release AAB signing and Play Store screenshot capture.

## Source-level completion posture

The repo is now very close to source-complete for most app domains. The remaining percentage gap is primarily runtime proof, Android compiler proof, and older-domain conflict writeback.
