---
applyTo: "app/src/main/**/*.kt"
---

# Android / Kotlin source file conventions

## Compose composables

- Every screen composable must accept a `NavController` (or navigation lambdas) and a `ViewModel` injected via `hiltViewModel()`.
- Screen-level composables are named `<Feature>Screen` and live in `ui/<feature>/<Feature>Screen.kt`.
- Helper / reusable composables are named descriptively without the `Screen` suffix and live in `ui/components/` or inline in the screen file if used only once.
- Every public composable must have at least one `@Preview` (light + dark where relevant).
- Prefer `Scaffold` + `TopAppBar` for full screens.
- Prefer `LazyColumn` / `LazyRow` for long or dynamic lists; avoid `Column` with `verticalScroll` for very large or data-driven content.

## ViewModels

- Annotate with `@HiltViewModel` and inject with `@Inject constructor(…)`.
- Expose UI state as `val uiState: StateFlow<…UiState> = _uiState.asStateFlow()`.
- Accept events via a `fun onEvent(event: …UiEvent)` function.
- Use `viewModelScope.launch` for coroutine work; never `GlobalScope`.
- Never hold `Context` in a ViewModel — inject `@ApplicationContext` only if absolutely necessary.

## Room entities

- Annotate with `@Entity(tableName = "…")`.
- Primary key: `@PrimaryKey(autoGenerate = true) val id: Long = 0`.
- Store enums and lists as `String` columns and handle conversion in mapper functions (e.g., JSON array string for `List<String>`, enum name for enums); no `@TypeConverters` by default.
- Rely on Room's default column naming: column names match the Kotlin property names in `camelCase` (avoid `@ColumnInfo` renames unless absolutely necessary).

## Hilt DI

- Modules are annotated `@Module @InstallIn(SingletonComponent::class)`.
- `@Provides` functions follow naming: `provide<Type>`.
- `@Singleton` scope for database, DAOs, and repositories.

## Material 3

- Use `MaterialTheme.colorScheme.*` and `MaterialTheme.typography.*` — never hardcode colors or text sizes.
- Use `LocalFieldMode.current` to branch UI for field mode (larger touch targets, dimmer palette).
- Annotate with `@OptIn(ExperimentalMaterial3Api::class)` when using experimental M3 APIs.

## Coroutines / Flow

- Collect `Flow` in composables with `collectAsStateWithLifecycle()` (lifecycle-aware).
- Map database flows through the repository; never expose `Flow<Entity>` from a ViewModel.
- Use `combine` / `map` / `flatMapLatest` instead of nested `launch` blocks.

## Supabase / sync

- Preserve local-first behavior: Room is always the source of truth.
- Supabase sync is optional and must be explicit/user-controlled.
- New syncable mutations should enqueue a durable `sync_queue` item in addition to updating any per-record sync status.
- Do not use permanent public URLs for private photos. Use private storage references and signed/authenticated access.
- Use `DsLogger`; do not use raw `Log` for new code.
