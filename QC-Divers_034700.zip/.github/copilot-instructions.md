# Dumpster Scout / QC Divers - Repository Instructions

Treat this repository as the source of truth. Preserve the native Android/Kotlin stack unless a rewrite is explicitly approved.

## Product truth

Dumpster Scout is an offline-first Android field-scouting app with optional Supabase sync. It is not a purely local-only app anymore.

Core behavior:

- Local/private mode is the default.
- The app must work without an account and without network.
- Supabase account/sync is optional.
- No data may upload unless the user opts into sync/sharing.
- Private photos must not use permanent public URLs.
- Exact coordinates, private notes, transcripts, photo URLs, tokens, and user identity must not be logged.

## Current stack

| Layer | Technology |
|---|---|
| Language | Kotlin |
| UI | Jetpack Compose + Material 3 |
| Architecture | Single-activity, MVVM, StateFlow/UDF |
| DI | Hilt |
| Database | Room |
| Preferences | DataStore |
| Navigation | Navigation Compose |
| Images | Coil |
| Maps | Google Maps Compose + Play Services Location |
| Background | WorkManager |
| Remote backend | Supabase Kotlin SDK |
| Testing | JUnit 4 + MockK + Turbine + coroutine tests |

Do not convert this repository to Expo, Flutter, or another stack without explicit approval.

## Repository rules

- Inspect existing files before editing.
- Prefer small, verifiable patches over broad rewrites.
- Keep the app buildable after each change.
- Add Room migrations for schema changes.
- Update docs when product behavior changes.
- Never commit real API keys, service-role keys, signing keys, passwords, or tokens.
- Never add dependencies without updating `gradle/libs.versions.toml`.
- Do not show unfinished features as complete in UI or docs.
- Do not add broad permissions without a shipped feature that needs them.

## Architecture rules

- Domain models in `domain/model/` remain pure Kotlin with no Android imports.
- ViewModels expose immutable `StateFlow<UiState>`.
- Repositories have interfaces in `domain/repository/` and implementations in `data/repository/`.
- Room entities and DAOs stay in `data/local/`.
- Supabase code stays behind data-source/repository abstractions.
- Use `DsLogger`; do not use raw `Log` for sensitive or release-visible logging.
- Room is the local source of truth.
- Supabase is a remote sync target, not a requirement for core local use.

## Sync rules

- Per-record `syncStatus` is not enough by itself.
- Use the durable `sync_queue` outbox for new syncable mutations.
- Queue items need operation, entity type, local ID, remote ID, payload snapshot, retry metadata, idempotency key, and optional dependency.
- Child records must not upload before parent records have remote IDs.
- Failed syncs must be visible/retryable.
- Never mark records synced until remote confirmation succeeds.

## Supabase rules

- Backend migrations live in `supabase/migrations/`.
- RLS must be enabled on every user-owned table.
- Storage buckets must be private by default.
- Storage object paths must be scoped by user ID and record ID.
- Do not expose service-role keys to the client.
- Include RLS verification steps in `supabase/verification/`.

## Testing expectations

Existing unit tests are useful but not enough. High-priority additions:

- Room migration tests
- DAO integration tests
- sync queue tests
- WorkManager sync tests
- Supabase/RLS verification scripts
- photo upload retry tests
- import/export tests
- data deletion tests
- Compose UI smoke tests
- release build smoke tests

## Build commands

```bash
./gradlew assembleDebug -PMAPS_API_KEY=""
./gradlew test -PMAPS_API_KEY=""
./gradlew bundleRelease -PMAPS_API_KEY=""
```
