-- QC Divers community/sync verification checklist.
-- Run these manually with test users in Supabase SQL Editor or psql.
-- Replace UUID placeholders with real test user IDs and test row IDs.

-- 1. Confirm all sync tables exist.
select table_name
from information_schema.tables
where table_schema = 'public'
  and table_name in (
    'field_locations','field_location_reports','dumpster_spots','dumpster_reports',
    'tire_spots','tire_reports','spot_photos','route_plans','route_stops',
    'collections','collection_items','field_sessions','field_session_visits',
    'reminders','gear_checklists','gear_checklist_items','moderation_flags','sync_audit_events'
  )
order by table_name;

-- 2. Confirm RLS is enabled for user-owned tables.
select schemaname, tablename, rowsecurity
from pg_tables
where schemaname = 'public'
  and tablename in (
    'field_locations','field_location_reports','dumpster_spots','dumpster_reports',
    'tire_spots','tire_reports','spot_photos','route_plans','route_stops',
    'collections','collection_items','field_sessions','field_session_visits',
    'reminders','gear_checklists','gear_checklist_items'
  )
order by tablename;

-- 3. Confirm visibility policy names exist.
select schemaname, tablename, policyname, cmd
from pg_policies
where schemaname = 'public'
order by tablename, policyname;

-- 4. Manual test plan:
-- User A creates a PRIVATE field_locations row. User B should not be able to select it.
-- User A changes visibility to COMMUNITY_PUBLIC. User B should be able to select it.
-- User B still must not be able to update or delete User A's visible row.
-- Repeat for field_location_reports, dumpster_spots/reports, tire_spots/reports, and spot_photos.

-- 5. Storage test plan:
-- User A uploads a photo under their owner path. User B should not be able to read/delete it unless
-- your app explicitly creates a signed URL or exposes a community-public photo flow.
