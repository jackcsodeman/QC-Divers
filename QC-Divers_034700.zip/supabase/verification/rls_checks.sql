-- Manual RLS verification checklist.
-- Run these with two authenticated test users in Supabase SQL editor or adapt
-- them into automated integration tests.

-- Expected behavior:
-- 1. Signed-out / anon requests cannot select private rows.
-- 2. User A can insert/select/update/delete rows where owner_id = auth.uid().
-- 3. User A cannot update/delete User B rows.
-- 4. COMMUNITY/PUBLIC/COMMUNITY_PUBLIC rows are selectable by other users.
-- 5. Other users cannot modify public/community rows they do not own.
-- 6. Storage object paths must start with auth.uid() for insert/update/delete.
-- 7. Private photo objects are not publicly readable.

-- Example checks to perform through API clients:
-- insert into dumpster_spots(owner_id,name,category,address,latitude,longitude,visibility,created_at,updated_at)
-- values ('<user-a-uuid>','RLS test','OTHER','',0,0,'PRIVATE',0,0);
-- As user B: select should return no private row; update/delete should be denied.
-- Change visibility to COMMUNITY as user A; user B may select but still cannot update/delete.
