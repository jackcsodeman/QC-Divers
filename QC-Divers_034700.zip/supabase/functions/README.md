# Supabase Edge Functions

## `delete-account`

Deletes all cloud data owned by the authenticated user and then removes the Supabase Auth account.

Deploy:

```bash
supabase functions deploy delete-account
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=<service-role-key>
```

The service-role key must never be committed or placed in the Android app. The Android client should call this function only after an explicit destructive confirmation screen.
