// Supabase Edge Function: delete-account
// Deploy with: supabase functions deploy delete-account
// Required secret: SUPABASE_SERVICE_ROLE_KEY
// This function deletes all app-owned cloud data for the authenticated user and
// then removes the Supabase Auth account. Do not put service-role keys in the Android client.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !anonKey || !serviceKey) {
      return json({ error: "Server is not configured." }, 500);
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return json({ error: "Missing Authorization header." }, 401);

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userError } = await userClient.auth.getUser();
    if (userError || !userData.user) return json({ error: "Invalid session." }, 401);

    const userId = userData.user.id;
    const admin = createClient(supabaseUrl, serviceKey);

    const ownerTables = [
      "spot_photos",
      "field_session_visits",
      "field_sessions",
      "route_stops",
      "route_plans",
      "gear_checklist_items",
      "gear_checklists",
      "collection_items",
      "collections",
      "reminders",
      "field_location_reports",
      "field_locations",
      "dumpster_reports",
      "tire_reports",
      "dumpster_spots",
      "tire_spots",
      "cleanup_details",
      "salvage_details",
      "sync_audit_events",
    ];

    // Remove private storage objects under the user's prefix. Ignore missing bucket/list errors
    // so account deletion is not blocked by storage drift.
    const { data: files } = await admin.storage.from("spot-photos").list(userId, { limit: 1000 });
    if (files && files.length > 0) {
      await admin.storage.from("spot-photos").remove(files.map((file) => `${userId}/${file.name}`));
    }

    for (const table of ownerTables) {
      const { error } = await admin.from(table).delete().eq("owner_id", userId);
      if (error) throw new Error(`Failed deleting ${table}: ${error.message}`);
    }
    await admin.from("moderation_flags").delete().eq("reporter_id", userId);
    await admin.from("profiles").delete().eq("id", userId);

    const { error: deleteUserError } = await admin.auth.admin.deleteUser(userId);
    if (deleteUserError) throw deleteUserError;

    return json({ deleted: true }, 200);
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : "Unknown error" }, 500);
  }
});

function json(body: unknown, status: number) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
