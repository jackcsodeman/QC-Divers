-- Private Supabase Storage setup for QC Divers photos.
-- The Android app stores private references like supabase://spot-photos/<path>.
-- Do not make this bucket public for private user media.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'spot-photos',
  'spot-photos',
  false,
  10485760,
  array['image/jpeg','image/png','image/webp']
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

create policy "spot photos owner read" on storage.objects
for select using (
  bucket_id = 'spot-photos'
  and auth.uid()::text = split_part(name, '/', 1)
);

create policy "spot photos owner insert" on storage.objects
for insert with check (
  bucket_id = 'spot-photos'
  and auth.uid()::text = split_part(name, '/', 1)
);

create policy "spot photos owner update" on storage.objects
for update using (
  bucket_id = 'spot-photos'
  and auth.uid()::text = split_part(name, '/', 1)
) with check (
  bucket_id = 'spot-photos'
  and auth.uid()::text = split_part(name, '/', 1)
);

create policy "spot photos owner delete" on storage.objects
for delete using (
  bucket_id = 'spot-photos'
  and auth.uid()::text = split_part(name, '/', 1)
);
