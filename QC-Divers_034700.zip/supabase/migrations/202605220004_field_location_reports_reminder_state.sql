-- Field-location report parity and reminder completion/snooze metadata.

alter table if exists public.reminders
  add column if not exists completed_at bigint,
  add column if not exists snoozed_until bigint;

create index if not exists idx_reminders_completed_at on public.reminders(owner_id, completed_at);
create index if not exists idx_reminders_snoozed_until on public.reminders(owner_id, snoozed_until);

create table if not exists public.field_location_reports (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  field_location_id uuid not null references public.field_locations(id) on delete cascade,
  location_name text not null default '',
  report_type text not null default 'VISIT',
  status text not null default 'UNKNOWN',
  access_status text not null default 'UNKNOWN',
  hazard_level text not null default 'NONE',
  cleanup_status text not null default 'OPEN',
  cleanup_progress integer not null default 0,
  findings text not null default '',
  notes text not null default '',
  photo_uris text not null default '',
  voice_transcript text,
  is_from_voice boolean not null default false,
  latitude double precision,
  longitude double precision,
  visibility text not null default 'PRIVATE',
  created_at bigint not null,
  updated_at bigint not null,
  timestamp bigint not null,
  deleted_at bigint
);

create index if not exists idx_field_location_reports_owner_updated on public.field_location_reports(owner_id, updated_at);
create index if not exists idx_field_location_reports_location on public.field_location_reports(field_location_id, timestamp);
create index if not exists idx_field_location_reports_visibility on public.field_location_reports(visibility);
create index if not exists idx_field_location_reports_deleted on public.field_location_reports(deleted_at);

alter table public.field_location_reports enable row level security;

create policy "field_location_reports owner or visible select"
  on public.field_location_reports
  for select
  using (auth.uid() = owner_id or visibility in ('COMMUNITY','PUBLIC','SHARED_WITH_LINK','COMMUNITY_PUBLIC'));

create policy "field_location_reports owner insert"
  on public.field_location_reports
  for insert
  with check (auth.uid() = owner_id);

create policy "field_location_reports owner update"
  on public.field_location_reports
  for update
  using (auth.uid() = owner_id)
  with check (auth.uid() = owner_id);

create policy "field_location_reports owner delete"
  on public.field_location_reports
  for delete
  using (auth.uid() = owner_id);
