-- QC Divers / DumpsterScout Supabase core schema.
-- Run in Supabase SQL editor or through the Supabase CLI.
-- The Android client remains local-first. These tables are used only after
-- the user signs in and explicitly enables sync.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  is_verified_contributor boolean not null default false,
  created_at bigint not null default (extract(epoch from now()) * 1000)::bigint,
  updated_at bigint not null default (extract(epoch from now()) * 1000)::bigint,
  deleted_at bigint
);


create table if not exists public.field_locations (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  location_type text not null default 'CUSTOM',
  name text not null,
  description text not null default '',
  address text not null default '',
  latitude double precision not null default 0,
  longitude double precision not null default 0,
  tags text not null default '',
  grade text not null default 'UNKNOWN',
  access_status text not null default 'UNKNOWN',
  safety_notes text not null default '',
  hazard_notes text not null default '',
  hazard_level text not null default 'NONE',
  cleanup_priority text not null default 'NONE',
  cleanup_status text not null default 'OPEN',
  resource_type text not null default '',
  resource_availability text not null default 'UNKNOWN',
  is_favorite boolean not null default false,
  is_archived boolean not null default false,
  visibility text not null default 'PRIVATE',
  source text not null default 'MANUAL',
  last_visited_at bigint,
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint,
  check (location_type in ('CLEANUP_SITE','SALVAGE_RESOURCE','CUSTOM')),
  check (visibility in ('PRIVATE','COMMUNITY','PUBLIC','SHARED_WITH_LINK','COMMUNITY_PUBLIC','ARCHIVED'))
);

create table if not exists public.dumpster_spots (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  category text not null default 'OTHER',
  address text not null default '',
  latitude double precision not null default 0,
  longitude double precision not null default 0,
  visibility text not null default 'PRIVATE',
  personal_notes text not null default '',
  tags text not null default '',
  is_favorite boolean not null default false,
  is_verified boolean not null default false,
  is_retired boolean not null default false,
  last_status text not null default 'UNKNOWN',
  last_checked bigint,
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint,
  check (visibility in ('PRIVATE','COMMUNITY','PUBLIC','SHARED_WITH_LINK','COMMUNITY_PUBLIC','ARCHIVED'))
);

create table if not exists public.tire_spots (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  category text not null default 'OTHER',
  address text not null default '',
  latitude double precision not null default 0,
  longitude double precision not null default 0,
  visibility text not null default 'PRIVATE',
  access_notes text not null default '',
  is_fenced boolean not null default false,
  is_gated boolean not null default false,
  is_locked boolean not null default false,
  is_exposed boolean not null default false,
  easy_access boolean not null default true,
  has_cameras boolean not null default false,
  security_common boolean not null default false,
  best_time_of_day text not null default 'VARIES',
  best_days text not null default '',
  better_on_weekends boolean,
  is_seasonal boolean not null default false,
  season text not null default 'YEAR_ROUND',
  puts_out_around_closing boolean not null default false,
  puncture_pattern text not null default 'UNKNOWN',
  usable_disappear_fast boolean not null default false,
  others_get_there_first boolean not null default false,
  worth_checking_when_light boolean not null default false,
  usually_puts_out_many boolean not null default false,
  is_verified boolean not null default false,
  is_favorite boolean not null default false,
  is_retired boolean not null default false,
  last_status text not null default 'UNKNOWN',
  last_checked bigint,
  notes text not null default '',
  tags text not null default '',
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint,
  check (visibility in ('PRIVATE','COMMUNITY','PUBLIC','SHARED_WITH_LINK','COMMUNITY_PUBLIC','ARCHIVED'))
);

create table if not exists public.dumpster_reports (
  id uuid primary key default gen_random_uuid(),
  spot_id uuid references public.dumpster_spots(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'UNKNOWN',
  fill_level text not null default 'UNKNOWN',
  notes text not null default '',
  tags text not null default '',
  visibility text not null default 'PRIVATE',
  is_from_voice boolean not null default false,
  timestamp bigint not null,
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint,
  check (visibility in ('PRIVATE','COMMUNITY','PUBLIC','SHARED_WITH_LINK','COMMUNITY_PUBLIC','ARCHIVED'))
);

create table if not exists public.tire_reports (
  id uuid primary key default gen_random_uuid(),
  tire_spot_id uuid references public.tire_spots(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'UNKNOWN',
  estimated_count integer not null default 0,
  estimated_usable_count integer not null default 0,
  notes text not null default '',
  visibility text not null default 'PRIVATE',
  is_from_voice boolean not null default false,
  timestamp bigint not null,
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint,
  check (visibility in ('PRIVATE','COMMUNITY','PUBLIC','SHARED_WITH_LINK','COMMUNITY_PUBLIC','ARCHIVED'))
);

create table if not exists public.spot_photos (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  owner_type text not null,
  owner_remote_id uuid,
  storage_bucket text not null default 'spot-photos',
  storage_path text not null,
  caption text not null default '',
  mime_type text not null default 'image/jpeg',
  file_size_bytes bigint not null default 0,
  visibility text not null default 'PRIVATE',
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint,
  unique(storage_bucket, storage_path),
  check (visibility in ('PRIVATE','COMMUNITY','PUBLIC','SHARED_WITH_LINK','COMMUNITY_PUBLIC','ARCHIVED'))
);

create table if not exists public.route_plans (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  notes text not null default '',
  visibility text not null default 'PRIVATE',
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint
);

create table if not exists public.route_stops (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  route_id uuid not null references public.route_plans(id) on delete cascade,
  location_type text not null,
  location_remote_id uuid,
  label text not null default '',
  latitude double precision not null default 0,
  longitude double precision not null default 0,
  sort_order integer not null default 0,
  notes text not null default '',
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint
);

create table if not exists public.reminders (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  location_type text not null default 'DUMPSTER',
  location_remote_id uuid,
  label text not null default '',
  scheduled_at bigint,
  day_of_week integer not null default 0,
  time_hour integer not null default 20,
  time_minute integer not null default 0,
  is_active boolean not null default true,
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint
);

create table if not exists public.gear_checklists (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  is_template boolean not null default false,
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint
);

create table if not exists public.gear_checklist_items (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  checklist_id uuid not null references public.gear_checklists(id) on delete cascade,
  label text not null,
  category text not null default 'GENERAL',
  emoji text not null default '•',
  is_checked boolean not null default false,
  sort_order integer not null default 0,
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint
);

create table if not exists public.collections (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  notes text not null default '',
  visibility text not null default 'PRIVATE',
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint
);

create table if not exists public.collection_items (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  collection_id uuid not null references public.collections(id) on delete cascade,
  location_type text not null,
  location_remote_id uuid,
  sort_order integer not null default 0,
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint
);

create table if not exists public.field_sessions (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  notes text not null default '',
  started_at bigint not null,
  ended_at bigint,
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint
);

create table if not exists public.field_session_visits (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  session_id uuid not null references public.field_sessions(id) on delete cascade,
  location_type text not null,
  location_remote_id uuid,
  label text not null default '',
  notes text not null default '',
  visited_at bigint not null,
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint
);

create table if not exists public.moderation_flags (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  target_type text not null,
  target_id uuid,
  reason text not null,
  notes text not null default '',
  status text not null default 'PENDING',
  reviewed_by uuid references auth.users(id),
  review_notes text not null default '',
  created_at bigint not null,
  updated_at bigint not null
);

create table if not exists public.sync_audit_events (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  entity_type text not null,
  entity_id uuid,
  operation text not null,
  status text not null,
  error text,
  created_at bigint not null default (extract(epoch from now()) * 1000)::bigint
);

-- Future normalized detail tables. The current Android client still writes the
-- legacy dumpster_spots/tire_spots tables above; these reserve the target model
-- without forcing a client rewrite.
create table if not exists public.cleanup_details (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  cleanup_priority text not null default 'NONE',
  cleanup_status text not null default 'OPEN',
  notes text not null default '',
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint
);

create table if not exists public.salvage_details (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  resource_type text not null default 'OTHER',
  is_depleted boolean not null default false,
  notes text not null default '',
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint
);

-- Indexes for owner filtering, sync pulls, soft deletes, and common filters.
create index if not exists idx_field_locations_owner_updated on public.field_locations(owner_id, updated_at);
create index if not exists idx_field_locations_type on public.field_locations(location_type);
create index if not exists idx_field_locations_visibility on public.field_locations(visibility);
create index if not exists idx_field_locations_deleted on public.field_locations(deleted_at);
create index if not exists idx_field_locations_favorite on public.field_locations(owner_id, is_favorite);

create index if not exists idx_dumpster_spots_owner_updated on public.dumpster_spots(owner_id, updated_at);
create index if not exists idx_dumpster_spots_visibility on public.dumpster_spots(visibility);
create index if not exists idx_dumpster_spots_deleted on public.dumpster_spots(deleted_at);
create index if not exists idx_tire_spots_owner_updated on public.tire_spots(owner_id, updated_at);
create index if not exists idx_tire_spots_visibility on public.tire_spots(visibility);
create index if not exists idx_tire_spots_deleted on public.tire_spots(deleted_at);
create index if not exists idx_dumpster_reports_owner_updated on public.dumpster_reports(owner_id, updated_at);
create index if not exists idx_dumpster_reports_spot on public.dumpster_reports(spot_id);
create index if not exists idx_tire_reports_owner_updated on public.tire_reports(owner_id, updated_at);
create index if not exists idx_tire_reports_spot on public.tire_reports(tire_spot_id);
create index if not exists idx_spot_photos_owner_updated on public.spot_photos(owner_id, updated_at);
create index if not exists idx_spot_photos_owner_record on public.spot_photos(owner_type, owner_remote_id);
create index if not exists idx_field_sessions_owner_updated on public.field_sessions(owner_id, updated_at);
create index if not exists idx_field_sessions_deleted on public.field_sessions(deleted_at);
create index if not exists idx_field_session_visits_session on public.field_session_visits(session_id);
create index if not exists idx_field_session_visits_owner_updated on public.field_session_visits(owner_id, updated_at);

-- RLS enablement.
alter table public.profiles enable row level security;
alter table public.field_locations enable row level security;
alter table public.dumpster_spots enable row level security;
alter table public.tire_spots enable row level security;
alter table public.dumpster_reports enable row level security;
alter table public.tire_reports enable row level security;
alter table public.spot_photos enable row level security;
alter table public.route_plans enable row level security;
alter table public.route_stops enable row level security;
alter table public.reminders enable row level security;
alter table public.gear_checklists enable row level security;
alter table public.gear_checklist_items enable row level security;
alter table public.collections enable row level security;
alter table public.collection_items enable row level security;
alter table public.field_sessions enable row level security;
alter table public.field_session_visits enable row level security;
alter table public.moderation_flags enable row level security;
alter table public.sync_audit_events enable row level security;
alter table public.cleanup_details enable row level security;
alter table public.salvage_details enable row level security;

-- Helper predicate: public/community rows are readable, but only owners mutate.
-- Duplicate policies are explicit to keep audit/review simple.
create policy "profiles owner select" on public.profiles for select using (auth.uid() = id);
create policy "profiles owner insert" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles owner update" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);
create policy "profiles owner delete" on public.profiles for delete using (auth.uid() = id);

create policy "field_locations owner or visible select" on public.field_locations for select using (auth.uid() = owner_id or visibility in ('COMMUNITY','PUBLIC','SHARED_WITH_LINK','COMMUNITY_PUBLIC'));
create policy "field_locations owner insert" on public.field_locations for insert with check (auth.uid() = owner_id);
create policy "field_locations owner update" on public.field_locations for update using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "field_locations owner delete" on public.field_locations for delete using (auth.uid() = owner_id);

create policy "dumpster_spots owner or visible select" on public.dumpster_spots for select using (auth.uid() = owner_id or visibility in ('COMMUNITY','PUBLIC','SHARED_WITH_LINK','COMMUNITY_PUBLIC'));
create policy "dumpster_spots owner insert" on public.dumpster_spots for insert with check (auth.uid() = owner_id);
create policy "dumpster_spots owner update" on public.dumpster_spots for update using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "dumpster_spots owner delete" on public.dumpster_spots for delete using (auth.uid() = owner_id);

create policy "tire_spots owner or visible select" on public.tire_spots for select using (auth.uid() = owner_id or visibility in ('COMMUNITY','PUBLIC','SHARED_WITH_LINK','COMMUNITY_PUBLIC'));
create policy "tire_spots owner insert" on public.tire_spots for insert with check (auth.uid() = owner_id);
create policy "tire_spots owner update" on public.tire_spots for update using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "tire_spots owner delete" on public.tire_spots for delete using (auth.uid() = owner_id);

create policy "dumpster_reports owner or visible select" on public.dumpster_reports for select using (auth.uid() = owner_id or visibility in ('COMMUNITY','PUBLIC','SHARED_WITH_LINK','COMMUNITY_PUBLIC'));
create policy "dumpster_reports owner insert" on public.dumpster_reports for insert with check (auth.uid() = owner_id);
create policy "dumpster_reports owner update" on public.dumpster_reports for update using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "dumpster_reports owner delete" on public.dumpster_reports for delete using (auth.uid() = owner_id);

create policy "tire_reports owner or visible select" on public.tire_reports for select using (auth.uid() = owner_id or visibility in ('COMMUNITY','PUBLIC','SHARED_WITH_LINK','COMMUNITY_PUBLIC'));
create policy "tire_reports owner insert" on public.tire_reports for insert with check (auth.uid() = owner_id);
create policy "tire_reports owner update" on public.tire_reports for update using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "tire_reports owner delete" on public.tire_reports for delete using (auth.uid() = owner_id);

create policy "spot_photos owner or visible select" on public.spot_photos for select using (auth.uid() = owner_id or visibility in ('COMMUNITY','PUBLIC','SHARED_WITH_LINK','COMMUNITY_PUBLIC'));
create policy "spot_photos owner insert" on public.spot_photos for insert with check (auth.uid() = owner_id);
create policy "spot_photos owner update" on public.spot_photos for update using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "spot_photos owner delete" on public.spot_photos for delete using (auth.uid() = owner_id);

-- Simple owner-only policies for support tables.
do $$
declare t text;
begin
  foreach t in array array[
    'route_plans','route_stops','reminders','gear_checklists','gear_checklist_items',
    'collections','collection_items','field_sessions','field_session_visits','sync_audit_events','cleanup_details','salvage_details'
  ] loop
    execute format('create policy %I on public.%I for select using (auth.uid() = owner_id)', t || ' owner select', t);
    execute format('create policy %I on public.%I for insert with check (auth.uid() = owner_id)', t || ' owner insert', t);
    execute format('create policy %I on public.%I for update using (auth.uid() = owner_id) with check (auth.uid() = owner_id)', t || ' owner update', t);
    execute format('create policy %I on public.%I for delete using (auth.uid() = owner_id)', t || ' owner delete', t);
  end loop;
end $$;

create policy "moderation_flags reporter select" on public.moderation_flags for select using (auth.uid() = reporter_id);
create policy "moderation_flags reporter insert" on public.moderation_flags for insert with check (auth.uid() = reporter_id);
