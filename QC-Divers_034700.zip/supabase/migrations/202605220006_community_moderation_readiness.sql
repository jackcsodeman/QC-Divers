-- Optional community moderation readiness for future public/community features.
-- This migration does not make any Android UI public by itself. It creates
-- the tables needed before enabling COMMUNITY_PUBLIC sharing in production.

create table if not exists public.community_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  target_owner_id uuid references auth.users(id) on delete set null,
  target_table text not null,
  target_id uuid not null,
  reason text not null,
  notes text not null default '',
  status text not null default 'OPEN',
  created_at bigint not null default (extract(epoch from now()) * 1000)::bigint,
  updated_at bigint not null default (extract(epoch from now()) * 1000)::bigint,
  resolved_at bigint,
  check (target_table in (
    'dumpster_spots',
    'tire_spots',
    'field_locations',
    'personal_reports',
    'tire_reports',
    'field_location_reports',
    'spot_photos'
  )),
  check (status in ('OPEN','REVIEWING','RESOLVED','DISMISSED'))
);

create table if not exists public.blocked_users (
  id uuid primary key default gen_random_uuid(),
  blocker_id uuid not null references auth.users(id) on delete cascade,
  blocked_id uuid not null references auth.users(id) on delete cascade,
  created_at bigint not null default (extract(epoch from now()) * 1000)::bigint,
  unique (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);

create index if not exists idx_community_reports_reporter on public.community_reports(reporter_id, created_at desc);
create index if not exists idx_community_reports_target on public.community_reports(target_table, target_id);
create index if not exists idx_community_reports_status on public.community_reports(status, created_at desc);
create index if not exists idx_blocked_users_blocker on public.blocked_users(blocker_id, blocked_id);
create index if not exists idx_blocked_users_blocked on public.blocked_users(blocked_id);

alter table public.community_reports enable row level security;
alter table public.blocked_users enable row level security;

create policy if not exists community_reports_insert_own
  on public.community_reports for insert
  with check (reporter_id = auth.uid());

create policy if not exists community_reports_read_own
  on public.community_reports for select
  using (reporter_id = auth.uid());

create policy if not exists blocked_users_manage_own
  on public.blocked_users for all
  using (blocker_id = auth.uid())
  with check (blocker_id = auth.uid());

comment on table public.community_reports is 'Future moderation intake table. Do not enable public/community UI until reporting review workflows and policy docs are complete.';
comment on table public.blocked_users is 'Future user blocking table. Used only if public/community viewing is enabled.';
