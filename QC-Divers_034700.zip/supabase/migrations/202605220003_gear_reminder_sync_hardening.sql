-- Adds gear checklist emoji metadata used by Android's persisted field-kit UI.
-- Existing deployments can run this after the core schema migration.
alter table public.gear_checklist_items
  add column if not exists emoji text not null default '•';

create index if not exists idx_reminders_owner_updated on public.reminders(owner_id, updated_at);
create index if not exists idx_reminders_location on public.reminders(location_type, location_remote_id);
create index if not exists idx_reminders_deleted on public.reminders(deleted_at);
create index if not exists idx_gear_checklists_owner_updated on public.gear_checklists(owner_id, updated_at);
create index if not exists idx_gear_checklist_items_checklist on public.gear_checklist_items(checklist_id, sort_order);
create index if not exists idx_gear_checklist_items_deleted on public.gear_checklist_items(deleted_at);
