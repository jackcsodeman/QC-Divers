-- Add field session sync tables for existing Supabase projects.

create table if not exists public.field_sessions (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  notes text not null default '',
  started_at bigint not null,
  ended_at bigint,
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint
);

create table if not exists public.field_session_visits (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  session_id uuid not null references public.field_sessions(id) on delete cascade,
  location_type text not null,
  location_remote_id uuid,
  label text not null default '',
  notes text not null default '',
  visited_at bigint not null,
  created_at bigint not null,
  updated_at bigint not null,
  deleted_at bigint
);

create index if not exists idx_field_sessions_owner_updated on public.field_sessions(owner_id, updated_at);
create index if not exists idx_field_sessions_deleted on public.field_sessions(deleted_at);
create index if not exists idx_field_session_visits_session on public.field_session_visits(session_id);
create index if not exists idx_field_session_visits_owner_updated on public.field_session_visits(owner_id, updated_at);

alter table public.field_sessions enable row level security;
alter table public.field_session_visits enable row level security;

do $$
declare t text;
begin
  foreach t in array array['field_sessions','field_session_visits'] loop
    execute format('drop policy if exists %I on public.%I', t || ' owner select', t);
    execute format('drop policy if exists %I on public.%I', t || ' owner insert', t);
    execute format('drop policy if exists %I on public.%I', t || ' owner update', t);
    execute format('drop policy if exists %I on public.%I', t || ' owner delete', t);
    execute format('create policy %I on public.%I for select using (auth.uid() = owner_id)', t || ' owner select', t);
    execute format('create policy %I on public.%I for insert with check (auth.uid() = owner_id)', t || ' owner insert', t);
    execute format('create policy %I on public.%I for update using (auth.uid() = owner_id) with check (auth.uid() = owner_id)', t || ' owner update', t);
    execute format('create policy %I on public.%I for delete using (auth.uid() = owner_id)', t || ' owner delete', t);
  end loop;
end $$;
