-- Child pull/merge hardening for normalized child tables.
-- These indexes improve pull by owner and parent relationship lookups.

create index if not exists idx_route_stops_owner_route_deleted
    on public.route_stops(owner_id, route_id, deleted_at);

create index if not exists idx_route_stops_location_remote
    on public.route_stops(location_type, location_remote_id);

create index if not exists idx_collection_items_owner_collection_deleted
    on public.collection_items(owner_id, collection_id, deleted_at);

create index if not exists idx_collection_items_location_remote
    on public.collection_items(location_type, location_remote_id);

create index if not exists idx_field_session_visits_owner_session_deleted
    on public.field_session_visits(owner_id, session_id, deleted_at);

create index if not exists idx_field_session_visits_location_remote
    on public.field_session_visits(location_type, location_remote_id);

create index if not exists idx_gear_checklist_items_owner_checklist_deleted
    on public.gear_checklist_items(owner_id, checklist_id, deleted_at);
