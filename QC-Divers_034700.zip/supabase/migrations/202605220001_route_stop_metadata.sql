-- Add route stop display metadata used by the Android v8 route planner.
alter table public.route_stops add column if not exists label text not null default '';
alter table public.route_stops add column if not exists latitude double precision not null default 0;
alter table public.route_stops add column if not exists longitude double precision not null default 0;

-- Defensive cleanup for projects created from an intermediate draft migration that
-- accidentally duplicated the reminders.owner_id column definition in source.
-- Postgres itself would reject the duplicate column during initial migration, so
-- this file intentionally contains no destructive reminder-table changes.
