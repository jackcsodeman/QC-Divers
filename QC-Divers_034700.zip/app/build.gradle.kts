import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.hilt.android)
    alias(libs.plugins.room.plugin)
    alias(libs.plugins.ksp)
    alias(libs.plugins.google.gms.google.services)
    alias(libs.plugins.google.firebase.crashlytics)
}

android {
    namespace = "com.dumpsterscout"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.dumpsterscout"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.1.1b"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }

        manifestPlaceholders["MAPS_API_KEY"] =
            project.findProperty("MAPS_API_KEY") as? String ?: ""

        // ── Supabase credentials ───────────────────────────────────────────────
        // Provide via gradle.properties or ~/.gradle/gradle.properties (do NOT commit real keys):
        //   SUPABASE_URL=https://tnrxalbpaqzlvzhmjmft.supabase.co
        //   SUPABASE_ANON_KEY=<publishable/anon key from Supabase dashboard>
        // Note: Supabase calls this the "publishable key" in newer project dashboards.
        buildConfigField("String", "SUPABASE_URL",
            "\"${project.findProperty("SUPABASE_URL") as? String ?: ""}\"")
        buildConfigField("String", "SUPABASE_ANON_KEY",
            "\"${project.findProperty("SUPABASE_ANON_KEY") as? String ?: ""}\"")
    }

    signingConfigs {
        create("release") {
            val releaseStoreFile = project.findProperty("RELEASE_STORE_FILE") as? String
            val releaseStorePassword = project.findProperty("RELEASE_STORE_PASSWORD") as? String
            val releaseKeyAlias = project.findProperty("RELEASE_KEY_ALIAS") as? String
            val releaseKeyPassword = project.findProperty("RELEASE_KEY_PASSWORD") as? String
            if (!releaseStoreFile.isNullOrBlank() &&
                !releaseStorePassword.isNullOrBlank() &&
                !releaseKeyAlias.isNullOrBlank() &&
                !releaseKeyPassword.isNullOrBlank()
            ) {
                storeFile = file(releaseStoreFile)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            val hasReleaseSigning = listOf(
                project.findProperty("RELEASE_STORE_FILE") as? String,
                project.findProperty("RELEASE_STORE_PASSWORD") as? String,
                project.findProperty("RELEASE_KEY_ALIAS") as? String,
                project.findProperty("RELEASE_KEY_PASSWORD") as? String
            ).all { !it.isNullOrBlank() }
            if (hasReleaseSigning) {
                signingConfig = signingConfigs.getByName("release")
            }
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget = JvmTarget.JVM_17
        freeCompilerArgs.add("-XXLanguage:+PropertyParamAnnotationDefaultTargetMode")
    }
}

room {
    schemaDirectory("$projectDir/schemas")
}

dependencies {
    // Core
    implementation(libs.core.ktx)
    implementation(libs.firebase.crashlytics)
    implementation(libs.lifecycle.runtime.ktx)
    implementation(libs.lifecycle.viewmodel.compose)
    implementation(libs.lifecycle.runtime.compose)
    implementation(libs.activity.compose)
    implementation(libs.splashscreen)

    // Compose BOM
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3)
    implementation(libs.compose.material.icons.extended)
    implementation(libs.compose.animation)

    // Navigation
    implementation(libs.navigation.compose)

    // Room
    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)

    // Hilt
    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.hilt.navigation.compose)

    // DataStore
    implementation(libs.datastore.preferences)

    // WorkManager
    implementation(libs.work.runtime.ktx)
    implementation(libs.hilt.work)
    ksp(libs.hilt.work.compiler)

    // Coil
    implementation(libs.coil.compose)

    // Maps & Location
    implementation(libs.play.services.maps)
    implementation(libs.play.services.location)
    implementation(libs.maps.compose)

    // Coroutines
    implementation(libs.coroutines.android)
    implementation(libs.kotlinx.serialization.json)

    // Accompanist
    implementation(libs.accompanist.permissions)

    // ── Supabase ──────────────────────────────────────────────────────────────
    implementation(platform(libs.supabase.bom))
    implementation(libs.supabase.postgrest)
    implementation(libs.supabase.auth)
    implementation(libs.supabase.storage)
    implementation(libs.supabase.realtime)
    implementation(libs.ktor.client.android)

    // Testing
    testImplementation(libs.junit)
    testImplementation(libs.mockk)
    testImplementation(libs.turbine)
    testImplementation(libs.coroutines.test)
    androidTestImplementation(libs.junit.ext)
    androidTestImplementation(libs.espresso.core)
    androidTestImplementation(libs.test.rules)
    androidTestImplementation(libs.room.testing)
    androidTestImplementation(libs.work.testing)
    androidTestImplementation(platform(libs.compose.bom))
    androidTestImplementation(libs.compose.ui.test.junit4)
    debugImplementation(libs.compose.ui.tooling)
    debugImplementation(libs.compose.ui.test.manifest)
}
