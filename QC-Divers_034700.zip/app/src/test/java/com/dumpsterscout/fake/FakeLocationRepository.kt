package com.dumpsterscout.fake

import android.location.Location
import com.dumpsterscout.domain.repository.LocationRepository
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow

class FakeLocationRepository : LocationRepository {
    private val _locationFlow = MutableStateFlow<Location?>(null)
    
    fun setLocation(lat: Double, lng: Double) {
        val mockLocation = mockk<Location>()
        every { mockLocation.latitude } returns lat
        every { mockLocation.longitude } returns lng
        _locationFlow.value = mockLocation
    }

    override fun getCurrentLocation(): Flow<Location?> = _locationFlow

    override suspend fun getLatestLocation(): Location? = _locationFlow.value
}
