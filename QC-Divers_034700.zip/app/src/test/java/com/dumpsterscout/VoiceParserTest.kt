package com.dumpsterscout

import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.model.TimeRelevance
import com.dumpsterscout.domain.model.TimingNote
import com.dumpsterscout.util.VoiceParser
import org.junit.Assert.*
import org.junit.Test

class VoiceParserTest {

    @Test
    fun `parse fast phrase - empty today`() {
        val result = VoiceParser.parse("empty today")
        assertEquals(SpotStatus.EMPTY, result.status)
        assertEquals(TimeRelevance.TODAY, result.timeRelevance)
    }

    @Test
    fun `parse fast phrase - locked today`() {
        val result = VoiceParser.parse("locked today")
        assertEquals(SpotStatus.LOCKED, result.status)
    }

    @Test
    fun `parse fast phrase - security came by`() {
        val result = VoiceParser.parse("security came by")
        assertEquals(SpotStatus.SECURITY_ACTIVE, result.status)
        assertTrue(result.securityMentioned)
    }

    @Test
    fun `parse fast phrase - good haul today`() {
        val result = VoiceParser.parse("good haul today")
        assertEquals(SpotStatus.GOOD_HAUL, result.status)
        assertEquals(TimeRelevance.TODAY, result.timeRelevance)
    }

    @Test
    fun `parse fast phrase - nothing there today`() {
        val result = VoiceParser.parse("nothing there today")
        assertEquals(SpotStatus.NOTHING_THERE, result.status)
    }

    @Test
    fun `parse fast phrase - compactor only`() {
        val result = VoiceParser.parse("compactor only, don't bother")
        assertEquals(SpotStatus.COMPACTOR_ONLY, result.status)
    }

    @Test
    fun `parse spot name from brand list`() {
        val result = VoiceParser.parse("The Aldi dumpster is empty today")
        assertNotNull(result.parsedSpotName)
        assertEquals("Aldi", result.parsedSpotName)
        assertEquals(SpotStatus.EMPTY, result.status)
    }

    @Test
    fun `parse spot name and location - Ulta Davenport`() {
        val result = VoiceParser.parse("Ulta in davenport iowa on 53rd street was decent today")
        assertEquals("Ulta Davenport", result.parsedSpotName)
        assertTrue(result.locationHint!!.contains("Davenport"))
        assertTrue(result.locationHint!!.contains("53rd"))
    }

    @Test
    fun `parse rain damage`() {
        val result = VoiceParser.parse("Trader Joe's dumpster was full but rain soaked everything")
        assertTrue(result.weatherIssue)
    }

    @Test
    fun `parse came too early`() {
        val result = VoiceParser.parse("came too early, trash not thrown out yet")
        assertEquals(TimingNote.CAME_TOO_EARLY, result.timingNote)
    }

    @Test
    fun `parse came too late`() {
        val result = VoiceParser.parse("came too late, already picked up")
        assertEquals(TimingNote.CAME_TOO_LATE, result.timingNote)
    }

    @Test
    fun `parse already picked through`() {
        val result = VoiceParser.parse("someone already picked through it")
        assertTrue(result.alreadyPicked)
    }

    @Test
    fun `confidence increases with more signals`() {
        val minimal = VoiceParser.parse("went there")
        val detailed = VoiceParser.parse("Aldi dumpster was empty today")
        assertTrue(detailed.confidence > minimal.confidence)
    }

    @Test
    fun `raw transcript preserved`() {
        val input = "Target had a ton of clothing tonight"
        val result = VoiceParser.parse(input)
        assertEquals(input, result.rawTranscript)
    }

    @Test
    fun `tags extracted for beauty`() {
        val result = VoiceParser.parse("Ulta had lots of makeup and beauty stuff")
        assertTrue(result.tags.contains("beauty"))
    }

    @Test
    fun `tags extracted for food`() {
        val result = VoiceParser.parse("Aldi had bread and groceries")
        assertTrue(result.tags.contains("food"))
    }

    @Test
    fun `parse overflowing`() {
        val result = VoiceParser.parse("dumpster was overflowing tonight")
        assertEquals(SpotStatus.OVERFLOWING, result.status)
        assertEquals(TimeRelevance.TONIGHT, result.timeRelevance)
    }

    @Test
    fun `resolve spot - exact name match`() {
        val spots = listOf(
            com.dumpsterscout.domain.model.DumpsterSpot(id = 1L, name = "Aldi"),
            com.dumpsterscout.domain.model.DumpsterSpot(id = 2L, name = "CVS")
        )
        val result = VoiceParser.parse("Aldi dumpster is empty today")
        val resolved = VoiceParser.resolveSpot(result, spots)
        assertEquals(1L, resolved.matchedSpotId)
    }

    @Test
    fun `toReport creates PersonalReport correctly`() {
        val result = VoiceParser.parse("Aldi dumpster empty today")
        val report = VoiceParser.toReport(result, spotId = 1L, spotName = "Aldi")
        assertEquals(1L, report.spotId)
        assertTrue(report.isFromVoice)
        assertEquals(SpotStatus.EMPTY, report.status)
    }
}
