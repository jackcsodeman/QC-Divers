package com.dumpsterscout

import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.usecase.SaveSpotUseCase
import com.dumpsterscout.fake.FakeLocationRepository
import com.dumpsterscout.fake.FakeSpotRepository
import com.dumpsterscout.ui.spots.AddSpotIntent
import com.dumpsterscout.ui.spots.AddSpotViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class AddSpotViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    private lateinit var spotRepo: FakeSpotRepository
    private lateinit var locationRepo: FakeLocationRepository
    private lateinit var viewModel: AddSpotViewModel

    private val sampleSpot = DumpsterSpot(
        id = 1L,
        name = "Aldi",
        address = "Moline"
    )

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        spotRepo = FakeSpotRepository(listOf(sampleSpot))
        locationRepo = FakeLocationRepository()
        val saveUseCase = SaveSpotUseCase(spotRepo)
        viewModel = AddSpotViewModel(saveUseCase, spotRepo, locationRepo)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `loadSpot with null id resets state`() = runTest(testDispatcher) {
        viewModel.onIntent(AddSpotIntent.LoadSpot(null))
        assertEquals("", viewModel.uiState.value.spot.name)
    }

    @Test
    fun `loadSpot with id loads spot`() = runTest(testDispatcher) {
        viewModel.onIntent(AddSpotIntent.LoadSpot(1L))
        advanceUntilIdle()
        assertEquals("Aldi", viewModel.uiState.value.spot.name)
    }

    @Test
    fun `updateField mutates state`() = runTest(testDispatcher) {
        viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(name = "New Name") })
        assertEquals("New Name", viewModel.uiState.value.spot.name)
    }

    @Test
    fun `prefill sets initial values`() = runTest(testDispatcher) {
        viewModel.onIntent(AddSpotIntent.Prefill("Ulta", "Davenport", SpotStatus.GOOD_HAUL))
        val spot = viewModel.uiState.value.spot
        assertEquals("Ulta", spot.name)
        assertEquals("Davenport", spot.address)
        assertEquals(SpotStatus.GOOD_HAUL, spot.lastStatus)
    }

    @Test
    fun `save success updates state`() = runTest(testDispatcher) {
        viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(name = "Saved Spot") })
        viewModel.onIntent(AddSpotIntent.Save)
        advanceUntilIdle()
        assertTrue(viewModel.uiState.value.isSaved)
        assertNotNull(viewModel.uiState.value.savedId)
    }
}
