package com.dumpsterscout

import com.dumpsterscout.data.remote.GeoBlacklistDataSourceImpl
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotCategory
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.usecase.GetSpotDetailUseCase
import com.dumpsterscout.domain.usecase.SetSpotVisibilityUseCase
import com.dumpsterscout.domain.usecase.ToggleSpotFavoriteUseCase
import com.dumpsterscout.domain.usecase.UpdateSpotStatusUseCase
import com.dumpsterscout.fake.FakeReportRepository
import com.dumpsterscout.fake.FakeSpotRepository
import com.dumpsterscout.fake.FakeUserRepository
import com.dumpsterscout.ui.spots.SpotDetailIntent
import com.dumpsterscout.ui.spots.SpotDetailViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class SpotDetailViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    private lateinit var spotRepo: FakeSpotRepository
    private lateinit var reportRepo: FakeReportRepository
    private lateinit var userRepo: FakeUserRepository
    private lateinit var viewModel: SpotDetailViewModel

    private val sampleSpot = DumpsterSpot(
        id = 1L,
        name = "Trader Joe's",
        category = SpotCategory.GROCERY
    )

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        spotRepo = FakeSpotRepository(listOf(sampleSpot))
        reportRepo = FakeReportRepository()
        userRepo = FakeUserRepository()
        
        val getDetailUseCase = GetSpotDetailUseCase(spotRepo, reportRepo, userRepo)
        val toggleUseCase = ToggleSpotFavoriteUseCase(spotRepo)
        val updateStatusUseCase = UpdateSpotStatusUseCase(spotRepo)
        val setVisibilityUseCase = SetSpotVisibilityUseCase(spotRepo, GeoBlacklistDataSourceImpl())
        
        viewModel = SpotDetailViewModel(
            getDetailUseCase,
            toggleUseCase,
            updateStatusUseCase,
            setVisibilityUseCase,
            spotRepo
        )
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `load loads the spot`() = runTest(testDispatcher) {
        viewModel.onIntent(SpotDetailIntent.Load(1L))
        advanceUntilIdle()
        val state = viewModel.uiState.value
        assertEquals("Trader Joe's", state.spot?.name)
        assertFalse(state.isLoading)
    }

    @Test
    fun `toggleFavorite updates repository`() = runTest(testDispatcher) {
        viewModel.onIntent(SpotDetailIntent.Load(1L))
        advanceUntilIdle()
        viewModel.onIntent(SpotDetailIntent.ToggleFavorite)
        advanceUntilIdle()
        assertTrue(spotRepo.getSpotById(1L)!!.isFavorite)
    }

    @Test
    fun `updateStatus updates repository`() = runTest(testDispatcher) {
        viewModel.onIntent(SpotDetailIntent.Load(1L))
        advanceUntilIdle()
        viewModel.onIntent(SpotDetailIntent.UpdateStatus(SpotStatus.GOOD_HAUL))
        advanceUntilIdle()
        assertEquals(SpotStatus.GOOD_HAUL, spotRepo.getSpotById(1L)!!.lastStatus)
    }

    @Test
    fun `deleteSpot updates state`() = runTest(testDispatcher) {
        viewModel.onIntent(SpotDetailIntent.Load(1L))
        advanceUntilIdle()
        viewModel.onIntent(SpotDetailIntent.DeleteSpot)
        advanceUntilIdle()
        assertTrue(viewModel.uiState.value.isDeleted)
        assertNull(spotRepo.getSpotById(1L))
    }
}
