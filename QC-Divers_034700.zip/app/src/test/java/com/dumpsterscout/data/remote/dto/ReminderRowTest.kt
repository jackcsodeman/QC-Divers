package com.dumpsterscout.data.remote.dto

import com.dumpsterscout.data.local.entity.ReminderEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ReminderRowTest {
    @Test
    fun reminderEntityMapsToRemoteRowWithoutLeakingLocalSpotId() {
        val entity = ReminderEntity(
            id = 42,
            remoteId = null,
            ownerUserId = "owner-1",
            spotId = 99,
            locationRemoteId = "remote-spot",
            label = "Check north side",
            dayOfWeek = 2,
            timeHour = 9,
            timeMinute = 30,
            createdAt = 100,
            updatedAt = 200
        )

        val row = entity.toRow()

        assertEquals("owner-1", row.ownerId)
        assertEquals("remote-spot", row.locationRemoteId)
        assertEquals("Check north side", row.label)
        assertEquals(2, row.dayOfWeek)
        assertEquals(9, row.timeHour)
        assertEquals(30, row.timeMinute)
        assertNull(row.deletedAt)
    }
}
