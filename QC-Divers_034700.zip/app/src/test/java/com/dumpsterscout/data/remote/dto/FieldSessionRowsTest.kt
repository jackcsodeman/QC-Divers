package com.dumpsterscout.data.remote.dto

import com.dumpsterscout.data.local.entity.FieldSessionEntity
import com.dumpsterscout.data.local.entity.FieldSessionVisitEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FieldSessionRowsTest {
    @Test
    fun sessionEntityRoundTripsCoreRemoteFields() {
        val session = FieldSessionEntity(
            id = 9,
            remoteId = "remote-session",
            ownerUserId = "owner-1",
            title = "Saturday checks",
            notes = "Start downtown",
            startedAt = 100,
            endedAt = 200,
            syncStatus = "PENDING_SYNC",
            createdAt = 90,
            updatedAt = 210
        )

        val row = session.toRow()
        val roundTrip = row.toEntity()

        assertEquals("remote-session", row.remoteId)
        assertEquals("owner-1", row.ownerId)
        assertEquals("Saturday checks", roundTrip.title)
        assertEquals(200L, roundTrip.endedAt)
        assertEquals("SYNCED", roundTrip.syncStatus)
    }

    @Test
    fun blankRemoteIdMapsToNullOnSessionEntity() {
        val row = FieldSessionRow(
            remoteId = "",
            ownerId = "owner-1",
            title = "Local session",
            notes = "",
            startedAt = 1,
            endedAt = null,
            createdAt = 1,
            updatedAt = 1,
            deletedAt = null
        )

        assertNull(row.toEntity().remoteId)
    }

    @Test
    fun visitRowUsesParentRemoteId() {
        val visit = FieldSessionVisitEntity(
            id = 4,
            sessionId = 9,
            locationType = "TIRE_SPOT",
            locationId = 12,
            label = "Tire pile",
            notes = "Count looked lower",
            visitedAt = 300,
            createdAt = 300,
            updatedAt = 320
        )

        val row = visit.toRow(sessionRemoteId = "session-remote", ownerId = "owner-1")

        assertEquals("session-remote", row.sessionRemoteId)
        assertEquals("TIRE_SPOT", row.locationType)
        assertEquals("Tire pile", row.label)
    }
}
