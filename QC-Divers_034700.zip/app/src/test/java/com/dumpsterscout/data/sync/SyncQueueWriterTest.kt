package com.dumpsterscout.data.sync

import com.dumpsterscout.data.local.dao.SyncQueueDao
import com.dumpsterscout.data.local.entity.SyncQueueEntity
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.mockk
import io.mockk.slot
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

class SyncQueueWriterTest {
    @Test
    fun enqueuePersistsDurableOutboxItem() = runTest {
        val dao = mockk<SyncQueueDao>()
        val itemSlot = slot<SyncQueueEntity>()
        coEvery { dao.enqueue(capture(itemSlot)) } returns 42L
        val writer = SyncQueueWriter(dao)

        val result = writer.enqueue(
            entityType = SyncEntityType.DUMPSTER_SPOT,
            entityLocalId = 7L,
            entityRemoteId = null,
            operation = SyncQueueOperation.CREATE,
            payload = """{"name":"Test spot"}"""
        )

        assertEquals(42L, result)
        assertEquals("DUMPSTER_SPOT", itemSlot.captured.entityType)
        assertEquals(7L, itemSlot.captured.entityLocalId)
        assertEquals("CREATE", itemSlot.captured.operation)
        assertEquals("PENDING", itemSlot.captured.status)
        assertEquals("""{"name":"Test spot"}""", itemSlot.captured.payload)
        assertEquals("DUMPSTER_SPOT:7:CREATE:", itemSlot.captured.idempotencyKey)
        coVerify(exactly = 1) { dao.enqueue(any()) }
    }
}
