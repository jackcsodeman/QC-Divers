package com.dumpsterscout.data.remote.dto

import com.dumpsterscout.data.local.entity.FieldLocationReportEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FieldLocationReportRowTest {
    @Test
    fun reportEntityMapsToRemoteRowWithParentRemoteId() {
        val report = FieldLocationReportEntity(
            id = 12,
            fieldLocationId = 7,
            locationName = "River cleanup",
            reportType = "VISIT",
            status = "OPEN",
            accessStatus = "MODERATE",
            hazardLevel = "MEDIUM",
            cleanupStatus = "IN_PROGRESS",
            cleanupProgress = 40,
            findings = "Bags and scrap",
            notes = "Bring gloves",
            ownerUserId = "owner-1",
            visibility = "PRIVATE",
            timestamp = 100,
            createdAt = 90,
            updatedAt = 110
        )

        val row = report.toRow(fieldLocationRemoteId = "field-remote")

        assertEquals("field-remote", row.fieldLocationRemoteId)
        assertEquals("owner-1", row.ownerId)
        assertEquals("River cleanup", row.locationName)
        assertEquals("IN_PROGRESS", row.cleanupStatus)
        assertEquals(40, row.cleanupProgress)
    }

    @Test
    fun blankRemoteIdMapsToNullOnEntity() {
        val row = FieldLocationReportRow(
            remoteId = "",
            ownerId = "owner-1",
            fieldLocationRemoteId = "field-remote",
            locationName = "Site",
            reportType = "VISIT",
            status = "OPEN",
            accessStatus = "UNKNOWN",
            hazardLevel = "LOW",
            cleanupStatus = "OPEN",
            cleanupProgress = 0,
            findings = "",
            notes = "",
            photoUris = "",
            voiceTranscript = null,
            isFromVoice = false,
            latitude = null,
            longitude = null,
            visibility = "PRIVATE",
            timestamp = 100,
            createdAt = 90,
            updatedAt = 110,
            deletedAt = null
        )

        val entity = row.toEntity(localFieldLocationId = 77)

        assertEquals(77L, entity.fieldLocationId)
        assertNull(entity.remoteId)
        assertEquals("SYNCED", entity.syncStatus)
    }
}
