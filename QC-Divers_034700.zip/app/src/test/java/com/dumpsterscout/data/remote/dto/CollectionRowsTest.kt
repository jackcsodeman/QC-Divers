package com.dumpsterscout.data.remote.dto

import com.dumpsterscout.data.local.entity.CollectionEntity
import com.dumpsterscout.data.local.entity.CollectionItemEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CollectionRowsTest {
    @Test
    fun collectionEntityRoundTripsCoreRemoteFields() {
        val entity = CollectionEntity(
            id = 7,
            remoteId = "remote-collection",
            ownerUserId = "owner-1",
            name = "Weekend route",
            notes = "Check these first",
            visibility = "PRIVATE",
            syncStatus = "PENDING_SYNC",
            createdAt = 10,
            updatedAt = 20
        )

        val row = entity.toRow()
        val roundTrip = row.toEntity()

        assertEquals("remote-collection", row.remoteId)
        assertEquals("owner-1", row.ownerId)
        assertEquals("Weekend route", roundTrip.name)
        assertEquals("SYNCED", roundTrip.syncStatus)
    }

    @Test
    fun blankRemoteIdMapsToNullOnCollectionEntity() {
        val row = CollectionRow(
            remoteId = "",
            ownerId = "owner-1",
            name = "Local only",
            notes = "",
            visibility = "PRIVATE",
            createdAt = 1,
            updatedAt = 2,
            deletedAt = null
        )

        assertNull(row.toEntity().remoteId)
    }

    @Test
    fun collectionItemRowUsesParentRemoteId() {
        val item = CollectionItemEntity(
            id = 3,
            collectionId = 7,
            locationType = "DUMPSTER_SPOT",
            locationId = 42,
            label = "North alley",
            sortOrder = 2,
            createdAt = 10,
            updatedAt = 20
        )

        val row = item.toRow(collectionRemoteId = "collection-remote", ownerId = "owner-1")

        assertEquals("collection-remote", row.collectionRemoteId)
        assertEquals("DUMPSTER_SPOT", row.locationType)
        assertEquals(2, row.sortOrder)
    }
}
