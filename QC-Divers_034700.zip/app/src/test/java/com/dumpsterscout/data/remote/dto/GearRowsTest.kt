package com.dumpsterscout.data.remote.dto

import com.dumpsterscout.data.local.entity.GearChecklistEntity
import com.dumpsterscout.data.local.entity.GearChecklistItemEntity
import org.junit.Assert.assertEquals
import org.junit.Test

class GearRowsTest {
    @Test
    fun gearChecklistAndItemMapToRemoteRows() {
        val checklist = GearChecklistEntity(
            id = 7,
            remoteId = "remote-checklist",
            ownerUserId = "owner-1",
            name = "Storm Kit",
            isTemplate = true,
            createdAt = 100,
            updatedAt = 200
        )
        val item = GearChecklistItemEntity(
            id = 8,
            checklistId = 7,
            label = "Rain jacket",
            category = "Weather",
            emoji = "🌧",
            isChecked = true,
            sortOrder = 1,
            createdAt = 100,
            updatedAt = 200
        )

        val checklistRow = checklist.toRow()
        val itemRow = item.toRow(checklistRemoteId = "remote-checklist", ownerId = "owner-1")

        assertEquals("remote-checklist", checklistRow.remoteId)
        assertEquals("Storm Kit", checklistRow.name)
        assertEquals("owner-1", itemRow.ownerId)
        assertEquals("remote-checklist", itemRow.checklistRemoteId)
        assertEquals("🌧", itemRow.emoji)
        assertEquals(true, itemRow.isChecked)
    }
}
