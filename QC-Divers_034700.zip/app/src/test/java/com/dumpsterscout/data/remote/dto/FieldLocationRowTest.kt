package com.dumpsterscout.data.remote.dto

import com.dumpsterscout.data.local.entity.FieldLocationEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FieldLocationRowTest {
    @Test
    fun mapsEntityToRemoteRowAndBackWithoutLosingCoreFields() {
        val entity = FieldLocationEntity(
            id = 42,
            remoteId = "remote-42",
            ownerUserId = "owner-1",
            type = "CLEANUP_SITE",
            name = "River cleanup pile",
            description = "Bags and scrap near trail",
            address = "Davenport riverfront",
            latitude = 41.52,
            longitude = -90.57,
            tags = "river,cleanup",
            grade = "B",
            accessStatus = "MODERATE",
            safetyNotes = "Bring gloves",
            hazardNotes = "Glass",
            hazardLevel = "MEDIUM",
            cleanupPriority = "HIGH",
            cleanupStatus = "OPEN",
            resourceType = "",
            resourceAvailability = "UNKNOWN",
            isFavorite = true,
            isArchived = false,
            visibility = "PRIVATE",
            syncStatus = "PENDING_SYNC",
            source = "MANUAL",
            lastVisitedAt = 123L,
            createdAt = 100L,
            updatedAt = 200L,
            deletedAt = null
        )

        val row = entity.toRow()
        val roundTrip = row.toEntity()

        assertEquals("remote-42", row.remoteId)
        assertEquals("owner-1", row.ownerId)
        assertEquals("CLEANUP_SITE", row.type)
        assertEquals("River cleanup pile", row.name)
        assertEquals(41.52, row.latitude, 0.0)
        assertEquals(-90.57, row.longitude, 0.0)
        assertEquals("HIGH", row.cleanupPriority)
        assertEquals("MEDIUM", row.hazardLevel)
        assertEquals("PRIVATE", row.visibility)

        assertEquals("remote-42", roundTrip.remoteId)
        assertEquals("owner-1", roundTrip.ownerUserId)
        assertEquals("CLEANUP_SITE", roundTrip.type)
        assertEquals("River cleanup pile", roundTrip.name)
        assertEquals("SYNCED", roundTrip.syncStatus)
        assertNull(roundTrip.deletedAt)
    }
}
