package com.dumpsterscout.ui.map

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MapClustererTest {
    @Test
    fun `small location lists render as single markers`() {
        val markers = MapClusterer.buildMarkers(
            locations = listOf(sampleLocation(1, 41.0, -90.0), sampleLocation(2, 41.1, -90.1)),
            clusterThreshold = 5
        )

        assertEquals(2, markers.size)
        assertTrue(markers.all { it is MapMarkerUiModel.Single })
    }

    @Test
    fun `large nearby location lists are clustered`() {
        val locations = (1L..12L).map { id ->
            sampleLocation(id, latitude = 41.0 + id * 0.001, longitude = -90.0 - id * 0.001)
        }

        val markers = MapClusterer.buildMarkers(
            locations = locations,
            clusterThreshold = 5,
            cellSizeDegrees = 0.05
        )

        assertTrue(markers.any { it is MapMarkerUiModel.Cluster && it.count > 1 })
        assertTrue(markers.size < locations.size)
    }

    @Test
    fun `zero zero coordinates are excluded`() {
        val markers = MapClusterer.buildMarkers(
            locations = listOf(sampleLocation(1, 0.0, 0.0), sampleLocation(2, 41.0, -90.0))
        )

        assertEquals(1, markers.size)
        assertTrue(markers.single() is MapMarkerUiModel.Single)
    }

    private fun sampleLocation(
        id: Long,
        latitude: Double,
        longitude: Double,
        type: MapLocationType = MapLocationType.FIELD
    ): MapLocationItem = MapLocationItem(
        localId = id,
        type = type,
        name = "Location $id",
        subtitle = "Field Site",
        address = "Test address",
        latitude = latitude,
        longitude = longitude,
        statusLabel = "private",
        isFavorite = false,
        syncStatus = "LOCAL_ONLY",
        visibility = "PRIVATE"
    )
}
