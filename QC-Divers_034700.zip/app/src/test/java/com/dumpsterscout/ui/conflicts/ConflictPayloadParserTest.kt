package com.dumpsterscout.ui.conflicts

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ConflictPayloadParserTest {
    @Test
    fun parsesPlainLocalPayloadAndHidesSensitiveValues() {
        val parsed = ConflictPayloadParser.parse(
            """{"name":"North route","latitude":41.1,"ownerUserId":"private-owner","notes":"Check weekly"}"""
        )

        assertFalse(parsed.hasRemoteSnapshot)
        assertEquals(listOf("latitude", "name", "notes"), parsed.fields.map { it.name })
        assertTrue(parsed.fields.first { it.name == "latitude" }.isSensitive)
        assertFalse(parsed.fields.any { it.name == "ownerUserId" })
    }

    @Test
    fun comparesLocalAndRemoteSnapshots() {
        val parsed = ConflictPayloadParser.parse(
            """{"local":{"name":"Route A","notes":"new"},"remote":{"name":"Route A","notes":"old"}}"""
        )

        assertTrue(parsed.hasRemoteSnapshot)
        val notes = parsed.fields.first { it.name == "notes" }
        assertEquals("new", notes.localValue)
        assertEquals("old", notes.remoteValue)
        assertTrue(notes.isChanged)
        assertFalse(parsed.fields.first { it.name == "name" }.isChanged)
    }

    @Test
    fun comparesSeparateRemotePayload() {
        val parsed = ConflictPayloadParser.parse(
            payload = """{"name":"Route A","notes":"local"}""",
            remotePayload = """{"name":"Route A","notes":"remote"}"""
        )

        assertTrue(parsed.hasRemoteSnapshot)
        val notes = parsed.fields.first { it.name == "notes" }
        assertEquals("local", notes.localValue)
        assertEquals("remote", notes.remoteValue)
        assertTrue(notes.isChanged)
    }

    @Test
    fun extractsRoutePayloadAndRedactsNestedSensitiveFields() {
        val parsed = ConflictPayloadParser.parse(
            payload = """{"route":{"name":"Cleanup loop","notes":"local"},"stops":[{"label":"Private site","latitude":41.1,"longitude":-90.1,"remoteUrl":"secret"}]}""",
            remotePayload = """{"name":"Cleanup loop","notes":"remote"}"""
        )

        assertTrue(parsed.hasRemoteSnapshot)
        assertEquals("local", parsed.fields.first { it.name == "notes" }.localValue)
        assertFalse(parsed.fields.any { it.name == "remoteUrl" })
    }

    @Test
    fun ignoresInvalidPayloadInsteadOfThrowing() {
        val parsed = ConflictPayloadParser.parse("not-json", "also-not-json")

        assertFalse(parsed.hasRemoteSnapshot)
        assertTrue(parsed.fields.isEmpty())
    }
}
