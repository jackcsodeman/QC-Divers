package com.dumpsterscout.notifications

import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar
import java.util.concurrent.TimeUnit

class ReminderSchedulerTest {
    @Test
    fun `one time reminders produce a positive delay within one day`() {
        val now = Calendar.getInstance()
        val delay = ReminderScheduler.nextReminderDelayMillis(
            dayOfWeek = 0,
            hour = now.get(Calendar.HOUR_OF_DAY),
            minute = now.get(Calendar.MINUTE)
        )

        assertTrue(delay >= 1_000L)
        assertTrue(delay <= TimeUnit.DAYS.toMillis(1) + TimeUnit.MINUTES.toMillis(1))
    }

    @Test
    fun `weekly reminders produce a positive delay within one week`() {
        val now = Calendar.getInstance()
        val delay = ReminderScheduler.nextReminderDelayMillis(
            dayOfWeek = now.get(Calendar.DAY_OF_WEEK),
            hour = now.get(Calendar.HOUR_OF_DAY),
            minute = now.get(Calendar.MINUTE)
        )

        assertTrue(delay >= 1_000L)
        assertTrue(delay <= TimeUnit.DAYS.toMillis(7) + TimeUnit.MINUTES.toMillis(1))
    }

    @Test
    fun `invalid clock values are coerced into a valid future delay`() {
        val delay = ReminderScheduler.nextReminderDelayMillis(
            dayOfWeek = Calendar.MONDAY,
            hour = 99,
            minute = -42
        )

        assertTrue(delay >= 1_000L)
        assertTrue(delay <= TimeUnit.DAYS.toMillis(7) + TimeUnit.DAYS.toMillis(1))
    }
}
