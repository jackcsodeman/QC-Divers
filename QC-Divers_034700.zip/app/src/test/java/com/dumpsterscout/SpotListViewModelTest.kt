package com.dumpsterscout

import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotCategory
import com.dumpsterscout.domain.usecase.GetSpotsUseCase
import com.dumpsterscout.domain.usecase.ToggleSpotFavoriteUseCase
import com.dumpsterscout.fake.FakeSpotRepository
import com.dumpsterscout.ui.spots.SpotListIntent
import com.dumpsterscout.ui.spots.SpotListViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class SpotListViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    private lateinit var spotRepo: FakeSpotRepository
    private lateinit var viewModel: SpotListViewModel

    private val grocerySpot = DumpsterSpot(id = 1L, name = "Aldi", category = SpotCategory.GROCERY)
    private val retailSpot = DumpsterSpot(id = 2L, name = "Target", category = SpotCategory.RETAIL, isFavorite = true)

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        spotRepo = FakeSpotRepository(listOf(grocerySpot, retailSpot))
        
        val getSpotsUseCase = GetSpotsUseCase(spotRepo)
        val toggleUseCase = ToggleSpotFavoriteUseCase(spotRepo)
        
        viewModel = SpotListViewModel(getSpotsUseCase, toggleUseCase)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `initial state loads spots`() = runTest(testDispatcher) {
        advanceUntilIdle()
        assertEquals(2, viewModel.uiState.value.spots.size)
        assertFalse(viewModel.uiState.value.isLoading)
    }

    @Test
    fun `search query filters spots`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onIntent(SpotListIntent.Search("Aldi"))
        advanceUntilIdle()
        val filtered = viewModel.uiState.value.spots
        assertEquals(1, filtered.size)
        assertEquals("Aldi", filtered[0].name)
    }

    @Test
    fun `category filter works`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onIntent(SpotListIntent.FilterCategory(SpotCategory.RETAIL))
        advanceUntilIdle()
        assertEquals(1, viewModel.uiState.value.spots.size)
        assertEquals(SpotCategory.RETAIL, viewModel.uiState.value.spots[0].category)
    }

    @Test
    fun `favorites only works`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onIntent(SpotListIntent.ToggleFavorites(true))
        advanceUntilIdle()
        assertEquals(1, viewModel.uiState.value.spots.size)
        assertTrue(viewModel.uiState.value.spots[0].isFavorite)
    }
}
