package com.dumpsterscout.data.local

import androidx.room.migration.Migration
import androidx.room.testing.MigrationTestHelper
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MigrationTest {

    @get:Rule
    val helper = MigrationTestHelper(
        InstrumentationRegistry.getInstrumentation(),
        DumpsterScoutDatabase::class.java.canonicalName,
        FrameworkSQLiteOpenHelperFactory()
    )

    @Test fun migrate1To13_validatesFinalSchema() = validatePath(1, allMigrations())
    @Test fun migrate2To13_validatesFinalSchema() = validatePath(2, migrationsFrom2())
    @Test fun migrate3To13_validatesFinalSchema() = validatePath(3, migrationsFrom3())
    @Test fun migrate4To13_validatesFinalSchema() = validatePath(4, migrationsFrom4())
    @Test fun migrate5To13_validatesFinalSchema() = validatePath(5, migrationsFrom5())
    @Test fun migrate7To13_validatesFinalSchema() = validatePath(7, migrationsFrom7())
    @Test fun migrate8To13_validatesFinalSchema() = validatePath(8, migrationsFrom8())
    @Test fun migrate9To13_validatesFinalSchema() = validatePath(9, migrationsFrom9())
    @Test fun migrate10To13_validatesFinalSchema() = validatePath(10, migrationsFrom10())
    @Test fun migrate11To13_addsChildRemoteMetadata() = validatePath(11, listOf(DumpsterScoutDatabase.MIGRATION_11_12, DumpsterScoutDatabase.MIGRATION_12_13))
    @Test fun migrate12To13_restoresTireVoiceMetadata() = validatePath(12, listOf(DumpsterScoutDatabase.MIGRATION_12_13))

    @Test
    fun migrate6To13_generalizesPhotoOwnershipAndAddsRouteStops() {
        helper.createDatabase(TEST_DB, 6).apply {
            execSQL(
                """
                INSERT INTO spot_photos (
                    spotId, uri, remoteUrl, uploadStatus, caption, mimeType, fileSizeBytes,
                    ownerUserId, takenAt, createdAt, updatedAt, deletedAt
                ) VALUES (42, 'file://legacy.jpg', NULL, 'LOCAL_ONLY', '', 'image/jpeg', 0, NULL, 100, 100, 100, NULL)
                """.trimIndent()
            )
            close()
        }
        val db = helper.runMigrationsAndValidate(TEST_DB, LATEST_VERSION, true, *migrationsFrom6().toTypedArray())
        assertHasColumn(db, "spot_photos", "ownerType")
        assertHasColumn(db, "spot_photos", "ownerId")
        db.query("SELECT ownerType, ownerId FROM spot_photos WHERE uri = 'file://legacy.jpg'").use { cursor ->
            assertTrue(cursor.moveToFirst())
            assertTrue(cursor.getString(0) == "DUMPSTER_SPOT")
            assertTrue(cursor.getLong(1) == 42L)
        }
        db.close()
    }

    @Test
    fun migrateFresh13_hasCoreTables() {
        helper.createDatabase(TEST_DB, LATEST_VERSION).use { db ->
            listOf(
                "dumpster_spots",
                "tire_spots",
                "personal_reports",
                "tire_reports",
                "spot_photos",
                "sync_queue",
                "field_locations",
                "field_location_reports",
                "collections",
                "collection_items",
                "field_sessions",
                "field_session_visits",
                "gear_checklists",
                "gear_checklist_items",
                "route_plans",
                "route_stops"
            ).forEach { table -> assertTableExists(db, table) }
        }
    }

    private fun validatePath(startVersion: Int, migrations: List<Migration>) {
        helper.createDatabase(TEST_DB, startVersion).close()
        val db = helper.runMigrationsAndValidate(TEST_DB, LATEST_VERSION, true, *migrations.toTypedArray())
        assertFinalSchema(db)
        db.close()
    }

    private fun assertFinalSchema(db: SupportSQLiteDatabase) {
        assertTableExists(db, "sync_queue")
        assertTableExists(db, "field_locations")
        assertTableExists(db, "field_location_reports")
        assertTableExists(db, "route_stops")
        assertTableExists(db, "collection_items")
        assertTableExists(db, "field_session_visits")
        assertTableExists(db, "gear_checklist_items")

        assertHasColumn(db, "spot_photos", "ownerType")
        assertHasColumn(db, "spot_photos", "ownerId")
        assertHasColumn(db, "reminders", "remoteId")
        assertHasColumn(db, "reminders", "syncStatus")
        assertHasColumn(db, "reminders", "completedAt")
        assertHasColumn(db, "reminders", "snoozedUntil")
        assertHasColumn(db, "gear_checklists", "remoteId")
        assertHasColumn(db, "gear_checklist_items", "remoteId")
        assertHasColumn(db, "gear_checklist_items", "syncStatus")
        assertHasColumn(db, "sync_queue", "remotePayload")
        assertHasColumn(db, "sync_queue", "resolutionAction")
        assertHasColumn(db, "sync_queue", "resolutionNotes")
        assertHasColumn(db, "sync_queue", "resolvedAt")

        assertHasColumn(db, "route_stops", "remoteId")
        assertHasColumn(db, "route_stops", "ownerUserId")
        assertHasColumn(db, "route_stops", "syncStatus")
        assertHasColumn(db, "collection_items", "remoteId")
        assertHasColumn(db, "collection_items", "ownerUserId")
        assertHasColumn(db, "collection_items", "syncStatus")
        assertHasColumn(db, "field_session_visits", "remoteId")
        assertHasColumn(db, "field_session_visits", "ownerUserId")
        assertHasColumn(db, "field_session_visits", "syncStatus")
        assertHasColumn(db, "field_session_visits", "deletedAt")
        assertHasColumn(db, "tire_reports", "voiceTranscript")
        assertHasColumn(db, "tire_reports", "isFromVoice")
        assertHasColumn(db, "tire_reports", "latitude")
        assertHasColumn(db, "tire_reports", "longitude")
    }

    private fun allMigrations() = listOf(
        DumpsterScoutDatabase.MIGRATION_1_2,
        DumpsterScoutDatabase.MIGRATION_2_3,
        DumpsterScoutDatabase.MIGRATION_3_4,
        DumpsterScoutDatabase.MIGRATION_4_5,
        DumpsterScoutDatabase.MIGRATION_5_6,
        DumpsterScoutDatabase.MIGRATION_6_7,
        DumpsterScoutDatabase.MIGRATION_7_8,
        DumpsterScoutDatabase.MIGRATION_8_9,
        DumpsterScoutDatabase.MIGRATION_9_10,
        DumpsterScoutDatabase.MIGRATION_10_11,
        DumpsterScoutDatabase.MIGRATION_11_12,
        DumpsterScoutDatabase.MIGRATION_12_13
    )

    private fun migrationsFrom2() = allMigrations().drop(1)
    private fun migrationsFrom3() = allMigrations().drop(2)
    private fun migrationsFrom4() = allMigrations().drop(3)
    private fun migrationsFrom5() = allMigrations().drop(4)
    private fun migrationsFrom6() = allMigrations().drop(5)
    private fun migrationsFrom7() = allMigrations().drop(6)
    private fun migrationsFrom8() = allMigrations().drop(7)
    private fun migrationsFrom9() = allMigrations().drop(8)
    private fun migrationsFrom10() = allMigrations().drop(9)

    private fun assertTableExists(db: SupportSQLiteDatabase, tableName: String) {
        db.query("SELECT name FROM sqlite_master WHERE type='table' AND name='$tableName'").use { cursor ->
            assertTrue("Expected table $tableName", cursor.moveToFirst())
        }
    }

    private fun assertHasColumn(db: SupportSQLiteDatabase, tableName: String, columnName: String) {
        db.query("PRAGMA table_info(`$tableName`)").use { cursor ->
            val nameIndex = cursor.getColumnIndexOrThrow("name")
            var found = false
            while (cursor.moveToNext()) {
                if (cursor.getString(nameIndex) == columnName) found = true
            }
            assertTrue("Expected $tableName.$columnName", found)
        }
    }

    private companion object {
        const val TEST_DB = "migration-test"
        const val LATEST_VERSION = 13
    }
}
