package com.dumpsterscout.domain.usecase

import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.repository.SpotRepository
import javax.inject.Inject

/**
 * Persists a dumpster spot to the local and potentially remote layers.
 */
class SaveSpotUseCase @Inject constructor(
    private val spotRepository: SpotRepository
) {
    suspend operator fun invoke(spot: DumpsterSpot): Result<Long> {
        return try {
            if (spot.name.isBlank()) {
                return Result.failure(IllegalArgumentException("Spot name cannot be empty"))
            }
            val id = spotRepository.upsertSpot(spot)
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
