package com.dumpsterscout.domain.usecase

import com.dumpsterscout.domain.repository.SpotRepository
import javax.inject.Inject

/**
 * Toggles the favorite status of a dumpster spot.
 */
class ToggleSpotFavoriteUseCase @Inject constructor(
    private val spotRepository: SpotRepository
) {
    suspend operator fun invoke(spotId: Long): Result<Unit> {
        return try {
            spotRepository.toggleFavorite(spotId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
