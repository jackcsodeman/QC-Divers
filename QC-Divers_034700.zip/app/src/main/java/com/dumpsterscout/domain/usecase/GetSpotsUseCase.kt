package com.dumpsterscout.domain.usecase

import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotCategory
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.repository.SpotRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

/**
 * Aggregates and filters dumpster spots for the list view.
 */
class GetSpotsUseCase @Inject constructor(
    private val spotRepository: SpotRepository,
) {
    /**
     * Executes the use case to get a filtered flow of spots.
     *
     * @param query The search query to filter by name, address, or tags.
     * @param category The category to filter by, or null for all categories.
     * @param status The status to filter by, or null for all statuses.
     * @param favoritesOnly Whether to only include favorite spots.
     */
    operator fun invoke(
        query: String = "",
        category: SpotCategory? = null,
        status: SpotStatus? = null,
        favoritesOnly: Boolean = false,
    ): Flow<List<DumpsterSpot>> {
        return spotRepository.getActiveSpots().map { spots ->
            spots.filter { spot ->
                (query.isBlank() || spot.name.contains(query, ignoreCase = true) ||
                        spot.address.contains(query, ignoreCase = true) ||
                        spot.tags.any { it.contains(query, ignoreCase = true) }) &&
                        (category == null || spot.category == category) &&
                        (status == null || spot.lastStatus == status) &&
                        (!favoritesOnly || spot.isFavorite)
            }.sortedByDescending { it.updatedAt }
        }
    }
}
