package com.dumpsterscout.domain.model

/**
 * Result of the deterministic tire voice/text parser.
 * All fields are optional since input may be partial or ambiguous.
 */
data class TireVoiceParseResult(
    /** Parsed shop/location name, if found */
    val parsedSpotName: String? = null,
    /** Derived spot status */
    val status: TireSpotStatus? = null,
    /** Estimated number of tires mentioned */
    val estimatedCount: Int = 0,
    /** When the visit happened */
    val timeRelevance: TireTimeRelevance = TireTimeRelevance.UNSPECIFIED,
    /** All tires appeared punctured */
    val arePunctured: Boolean = false,
    /** Some punctured, some not */
    val somePunctured: Boolean = false,
    /** Some intact/usable */
    val someUnpunctured: Boolean = false,
    /** Sizes extracted, e.g. "205/55R16, 225/60R17" */
    val commonSizes: String = "",
    /** Tire types e.g. "Car, Truck" */
    val tireTypes: String = "",
    /** Observed tread quality */
    val treadQuality: TreadQuality = TreadQuality.UNKNOWN,
    /** Overall usability condition */
    val condition: TireCondition = TireCondition.UNKNOWN,
    /** Sidewall damage observed */
    val sidewallDamage: Boolean = false,
    /** Dry rot observed */
    val dryRot: Boolean = false,
    /** Repair/patch visible */
    val repairVisible: Boolean = false,
    /** Already picked through on arrival */
    val alreadyPickedThrough: Boolean = false,
    /** Tires appeared freshly put out */
    val lookedFreshOut: Boolean = false,
    /** Weather affected the tires */
    val weatherAffected: Boolean = false,
    /** Free-form notes remainder */
    val notes: String = "",
    /** The raw unchanged transcript */
    val rawTranscript: String = "",
    /** Parser confidence 0.0–1.0 */
    val confidence: Float = 0f,
    /** Best matched tire spot id after resolveSpot() */
    val matchedSpotId: Long? = null,
    /** Up to 3 candidate tire spot ids for low-confidence selection */
    val candidateSpotIds: List<Long> = emptyList(),
    /** Location hint extracted from the transcript (e.g., "53rd St", "Davenport") */
    val locationHint: String? = null
)
