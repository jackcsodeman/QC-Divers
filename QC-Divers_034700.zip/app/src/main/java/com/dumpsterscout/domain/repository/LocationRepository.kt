package com.dumpsterscout.domain.repository

import android.location.Location
import kotlinx.coroutines.flow.Flow

/**
 * Interface for fetching the user's current GPS location.
 */
interface LocationRepository {
    /**
     * Emits the current location. May emit null if location is unavailable.
     */
    fun getCurrentLocation(): Flow<Location?>

    /**
     * Suspends until a single location is retrieved, or null if it fails.
     */
    suspend fun getLatestLocation(): Location?
}
