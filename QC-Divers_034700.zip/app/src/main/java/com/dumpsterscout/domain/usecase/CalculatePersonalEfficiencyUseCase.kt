package com.dumpsterscout.domain.usecase

import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.repository.ReportRepository
import kotlinx.coroutines.flow.first
import javax.inject.Inject

/**
 * Result of efficiency calculation.
 * 
 * @property totalReports Total number of reports submitted.
 * @property successRate Percentage of reports that were "Good Hauls" or had useful content.
 * @property reportsPerWeek Average number of reports logged per week over the last month.
 */
data class PersonalEfficiency(
    val totalReports: Int,
    val successRate: Float,
    val reportsPerWeek: Float
)

/**
 * Use case to calculate a scout's personal productivity metrics.
 * 
 * @property reportRepository The repository providing historical reporting data.
 */
class CalculatePersonalEfficiencyUseCase @Inject constructor(
    private val reportRepository: ReportRepository
) {
    /**
     * Executes the calculation based on the user's historical data.
     * 
     * @return A [PersonalEfficiency] object containing the calculated metrics.
     */
    suspend operator fun invoke(): PersonalEfficiency {
        val allReports = reportRepository.getAllReports().first()
        if (allReports.isEmpty()) return PersonalEfficiency(0, 0f, 0f)

        val successCount = allReports.count { 
            it.status == SpotStatus.GOOD_HAUL || it.status == SpotStatus.HALF_FULL 
        }
        val successRate = successCount.toFloat() / allReports.size

        val thirtyDaysAgo = System.currentTimeMillis() - (30L * 24 * 60 * 60 * 1000)
        val recentReportsCount = allReports.count { it.timestamp >= thirtyDaysAgo }
        val reportsPerWeek = recentReportsCount / 4.28f // 30 days / 7

        return PersonalEfficiency(
            totalReports = allReports.size,
            successRate = successRate,
            reportsPerWeek = reportsPerWeek
        )
    }
}
