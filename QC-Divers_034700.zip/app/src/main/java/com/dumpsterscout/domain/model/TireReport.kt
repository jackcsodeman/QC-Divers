package com.dumpsterscout.domain.model

/**
 * Tread quality observed during a visit.
 */
enum class TreadQuality {
    UNKNOWN,
    VERY_LOW,
    LOW,
    DECENT,
    GOOD,
    EXCELLENT
}

/**
 * Overall condition classification of tires found.
 */
enum class TireCondition {
    UNKNOWN,
    USABLE,
    JUNK,
    MIXED
}

/**
 * A private field report for a tire spot visit.
 * No Android imports — pure Kotlin data class.
 */
data class TireReport(
    val id: Long = 0,
    val tireSpotId: Long,
    val spotName: String = "",

    val status: TireSpotStatus = TireSpotStatus.UNKNOWN,
    val estimatedCount: Int = 0,
    val estimatedUsableCount: Int = 0,
    val estimatedJunkCount: Int = 0,

    // Puncture observations
    val arePunctured: Boolean = false,
    val somePunctured: Boolean = false,
    val someUnpunctured: Boolean = false,

    // Tire characteristics
    val commonSizes: String = "",        // e.g. "205/55R16, 225/60R17"
    val tireTypes: String = "",          // e.g. "All-season, Summer"
    val treadQuality: TreadQuality = TreadQuality.UNKNOWN,
    val condition: TireCondition = TireCondition.UNKNOWN,

    // Damage flags
    val sidewallDamage: Boolean = false,
    val dryRot: Boolean = false,
    val repairVisible: Boolean = false,

    // Notes
    val conditionNotes: String = "",
    val yearNotes: String = "",          // observed year markings
    val alreadyPickedThrough: Boolean = false,
    val lookedFreshOut: Boolean = false,
    val weatherAffected: Boolean = false,
    val notes: String = "",
    val photoUris: List<String> = emptyList(),

    /** Raw voice transcript if from voice report */
    val voiceTranscript: String? = null,
    val isFromVoice: Boolean = false,

    val latitude: Double? = null,
    val longitude: Double? = null,

    val timestamp: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),

    // ── Sync / backend-ready metadata ──────────────────────────────────────────
    /** Stable remote ID from the future backend. Null until first sync. */
    val remoteId: String? = null,
    /** User ID of the owner (device localId in anonymous mode). */
    val ownerUserId: String? = null,
    /** Current sync lifecycle state. */
    val syncStatus: SyncStatus = SyncStatus.LOCAL_ONLY,
    /** Visibility: private, cloud-synced private, or community-shared. */
    val visibility: Visibility = Visibility.PRIVATE,
    /** Soft-delete timestamp. Null = active. */
    val deletedAt: Long? = null
)
