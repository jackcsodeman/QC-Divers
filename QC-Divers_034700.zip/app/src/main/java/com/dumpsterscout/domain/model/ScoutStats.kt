package com.dumpsterscout.domain.model

/**
 * Public statistics for a scout profile.
 * 
 * @property remoteUserId The unique backend ID of the scout.
 * @property spotsVerified Total number of community spots this user has verified or created.
 * @property haulsReported Total number of successful hauls logged by this user.
 * @property trustScore A 0-100 score indicating reliability of reports.
 * @property rankTitle A descriptive title based on activity (e.g., "Novice Scout", "Legendary Diver").
 */
data class ScoutStats(
    val remoteUserId: String,
    val spotsVerified: Int = 0,
    val haulsReported: Int = 0,
    val trustScore: Int = 50,
    val rankTitle: String = "Junior Scout"
)
