package com.dumpsterscout.domain.usecase

import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireSpotCategory
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.domain.repository.TireSpotRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

/**
 * Aggregates and filters tire spots for the list view.
 */
class GetTireSpotsUseCase @Inject constructor(
    private val tireSpotRepository: TireSpotRepository
) {
    operator fun invoke(
        query: String = "",
        category: TireSpotCategory? = null,
        status: TireSpotStatus? = null,
        favoritesOnly: Boolean = false
    ): Flow<List<TireSpot>> {
        return tireSpotRepository.getActiveSpots().map { spots ->
            spots.filter { spot ->
                (query.isBlank() || spot.name.contains(query, ignoreCase = true) ||
                        spot.address.contains(query, ignoreCase = true) ||
                        spot.tags.any { it.contains(query, ignoreCase = true) }) &&
                        (category == null || spot.category == category) &&
                        (status == null || spot.lastStatus == status) &&
                        (!favoritesOnly || spot.isFavorite)
            }.sortedByDescending { it.updatedAt }
        }
    }
}
