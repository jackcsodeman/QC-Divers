package com.dumpsterscout.domain.repository

import com.dumpsterscout.domain.model.PhotoAttachment
import kotlinx.coroutines.flow.Flow

/**
 * Repository for local/private photo attachments.
 *
 * The local Room record is the source of truth. Remote storage is optional and
 * private-by-default through Supabase Storage. Generic owner support lets the
 * same gallery/upload pipeline serve dumpster spots, tire spots, field
 * locations, reports, and future records without public private-photo URLs.
 */
interface PhotoRepository {

    /** Observable list of active (non-deleted) photos for a legacy dumpster spot, newest first. */
    fun getPhotosForSpot(spotId: Long): Flow<List<PhotoAttachment>>

    /** Observable list of active photos for any supported owner, newest first. */
    fun getPhotosForOwner(ownerType: String, ownerId: Long): Flow<List<PhotoAttachment>>

    /** Single photo by ID, or null if not found. */
    suspend fun getPhotoById(id: Long): PhotoAttachment?

    /** Add a new local photo and queue optional private remote upload. */
    suspend fun addPhoto(photo: PhotoAttachment): Long

    /** Update an existing photo record, including caption/metadata changes. */
    suspend fun updatePhoto(photo: PhotoAttachment)

    /** Soft-delete a photo and queue remote deletion if it has a remote reference. */
    suspend fun softDeletePhoto(id: Long)

    /** Hard-delete all photos for a legacy dumpster spot. */
    suspend fun deleteAllForSpot(spotId: Long)

    /** Hard-delete all photos for any owner. */
    suspend fun deleteAllForOwner(ownerType: String, ownerId: Long)

    /** Returns photos that need upload/deletion sync. */
    suspend fun getPendingUploadPhotos(): List<PhotoAttachment>

    /** Mark a photo as successfully uploaded to Supabase Storage. */
    suspend fun markUploaded(id: Long, remoteUrl: String)

    /** Mark a photo upload as failed so it can be retried. */
    suspend fun markUploadFailed(id: Long)
}
