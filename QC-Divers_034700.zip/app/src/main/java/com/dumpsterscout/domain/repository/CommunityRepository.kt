package com.dumpsterscout.domain.repository

import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.TireSpot
import kotlinx.coroutines.flow.Flow

/**
 * Repository for browsing and interacting with shared community data.
 * Unlike other repositories, this primarily deals with remote data from other users
 * that is not stored in the local private Room database unless explicitly imported.
 */
interface CommunityRepository {

    /**
     * Get all dumpster spots shared by the community.
     * Implementation should handle caching/refreshing.
     */
    fun getCommunityDumpsterSpots(): Flow<List<DumpsterSpot>>

    /**
     * Get all tire spots shared by the community.
     */
    fun getCommunityTireSpots(): Flow<List<TireSpot>>

    /**
     * Get a specific community dumpster spot by its remote ID.
     */
    fun getCommunityDumpsterSpot(remoteId: String): Flow<DumpsterSpot?>

    /**
     * Get a specific community tire spot by its remote ID.
     */
    fun getCommunityTireSpot(remoteId: String): Flow<TireSpot?>

    /**
     * Trigger a refresh of community data from the remote backend.
     */
    suspend fun refreshCommunityData()

    /**
     * Report a community spot for moderation.
     */
    suspend fun reportSpot(
        targetTable: String,
        targetRemoteId: String,
        reason: String,
        notes: String
    ): Result<Unit>

    /**
     * Block all content from a specific user.
     */
    suspend fun blockUser(targetRemoteUserId: String): Result<Unit>
}
