package com.dumpsterscout.domain.model

/**
 * Current availability/condition status of a tire spot.
 */
enum class TireSpotStatus {
    UNKNOWN,
    NO_TIRES,
    A_FEW_OUT,
    MANY_OUT,
    GOOD_USABLE,
    MOSTLY_JUNK,
    ALL_PUNCTURED,
    SOME_PUNCTURED,
    UNPUNCTURED,
    ALREADY_PICKED,
    GONE_FAST,
    LOCKED_INACCESSIBLE,
    MOVED_REMOVED,
    WORTH_CHECKING,
    FRESH_DROP,
    NOT_WORTH_IT
}

/**
 * Type of establishment that discards tires.
 */
enum class TireSpotCategory {
    TIRE_SHOP,
    MECHANIC_SHOP,
    DEALERSHIP,
    GARAGE,
    SALVAGE_YARD,
    ROADSIDE_LOT,
    WAREHOUSE,
    OTHER
}

/**
 * Best time of day to visit this tire spot.
 */
enum class TireBestTimeOfDay {
    MORNING,
    AFTERNOON,
    EVENING,
    LATE_NIGHT,
    AROUND_CLOSING,
    VARIES
}

/**
 * Best season for this spot's activity.
 */
enum class TireSeason {
    SPRING,
    SUMMER,
    FALL,
    WINTER,
    YEAR_ROUND
}

/**
 * Observed puncture pattern at this location.
 */
enum class PuncturePattern {
    USUALLY_PUNCTURED,
    SOMETIMES_PUNCTURED,
    USUALLY_UNPUNCTURED,
    UNKNOWN
}

/**
 * Core domain model for a saved tire spot.
 * No Android imports — pure Kotlin data class.
 */
data class TireSpot(
    val id: Long = 0,
    val name: String,
    val category: TireSpotCategory = TireSpotCategory.OTHER,
    val address: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,

    // Access & layout
    val accessNotes: String = "",
    val isFenced: Boolean = false,
    val isGated: Boolean = false,
    val isLocked: Boolean = false,
    val isExposed: Boolean = false,
    val easyAccess: Boolean = true,
    val hasCameras: Boolean = false,
    val securityCommon: Boolean = false,

    // Timing & schedule
    val bestTimeOfDay: TireBestTimeOfDay = TireBestTimeOfDay.VARIES,
    val bestDays: String = "",           // e.g. "Mon,Fri"
    val betterOnWeekends: Boolean? = null,
    val isSeasonal: Boolean = false,
    val season: TireSeason = TireSeason.YEAR_ROUND,
    val putsOutAroundClosing: Boolean = false,

    // Puncture & condition patterns
    val puncturePattern: PuncturePattern = PuncturePattern.UNKNOWN,
    val usableDisappearFast: Boolean = false,
    val othersGetThereFirst: Boolean = false,
    val worthCheckingWhenLight: Boolean = false,
    val usuallyPutsOutMany: Boolean = false,

    // Meta
    val isVerified: Boolean = false,
    val isFavorite: Boolean = false,
    val isRetired: Boolean = false,
    val lastChecked: Long? = null,
    val lastStatus: TireSpotStatus = TireSpotStatus.UNKNOWN,
    val notes: String = "",
    val tags: List<String> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),

    // ── Sync / backend-ready metadata ──────────────────────────────────────────
    /** Stable remote ID from the future backend. Null until first sync. */
    val remoteId: String? = null,
    /** User ID of the owner (device localId in anonymous mode). */
    val ownerUserId: String? = null,
    /** Current sync lifecycle state. */
    val syncStatus: SyncStatus = SyncStatus.LOCAL_ONLY,
    /** Soft-delete timestamp. Null = active. */
    val deletedAt: Long? = null,
    /** Sharing scope for future community features. */
    val visibility: Visibility = Visibility.PRIVATE,
    /** Remote photo URLs shared by the community for this spot. */
    val communityPhotoUrls: List<String> = emptyList()
)
