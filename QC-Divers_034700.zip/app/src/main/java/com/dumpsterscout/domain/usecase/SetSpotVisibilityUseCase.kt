package com.dumpsterscout.domain.usecase

import com.dumpsterscout.data.remote.GeoBlacklistDataSource
import com.dumpsterscout.domain.model.Visibility
import com.dumpsterscout.domain.repository.SpotRepository
import javax.inject.Inject

/**
 * Result of visibility change attempt.
 */
sealed class VisibilityResult {
    /** Change successful. */
    data object Success : VisibilityResult()
    /** Change blocked due to geographical safety restrictions. */
    data class Restricted(val reason: String) : VisibilityResult()
    /** General error during update. */
    data class Error(val message: String) : VisibilityResult()
}

/**
 * Use case to manage community visibility for a spot, with safety checks.
 * 
 * @property spotRepository The repository for spot data.
 * @property geoBlacklist The data source for restricted area lookup.
 */
class SetSpotVisibilityUseCase @Inject constructor(
    private val spotRepository: SpotRepository,
    private val geoBlacklist: GeoBlacklistDataSource
) {
    /**
     * Attempts to set the visibility of the spot with [spotId] to [newVisibility].
     *
     * @param spotId The local ID of the spot.
     * @param newVisibility The desired visibility level.
     * @return A [VisibilityResult] indicating success or the reason for failure.
     */
    suspend operator fun invoke(spotId: Long, newVisibility: Visibility): VisibilityResult {
        if (newVisibility == Visibility.COMMUNITY || newVisibility == Visibility.PUBLIC) {
            val spot = spotRepository.getSpotById(spotId) ?: return VisibilityResult.Error("Spot not found")
            
            if (geoBlacklist.isRestrictedArea(spot.latitude, spot.longitude)) {
                return VisibilityResult.Restricted("This area is restricted. Community sharing is disabled here for safety.")
            }
        }

        return try {
            if (newVisibility == Visibility.COMMUNITY) {
                spotRepository.publishSpot(spotId)
            } else {
                val spot = spotRepository.getSpotById(spotId)
                if (spot != null) {
                    spotRepository.upsertSpot(spot.copy(visibility = newVisibility))
                }
            }
            VisibilityResult.Success
        } catch (e: Exception) {
            VisibilityResult.Error(e.message ?: "Failed to update visibility")
        }
    }
}
