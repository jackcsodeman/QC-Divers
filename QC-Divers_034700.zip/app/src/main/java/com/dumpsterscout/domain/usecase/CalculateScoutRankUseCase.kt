package com.dumpsterscout.domain.usecase

import com.dumpsterscout.domain.model.ScoutStats
import javax.inject.Inject

/**
 * Use case to determine a scout's rank title based on their activity metrics.
 * 
 * @property personalEfficiencyUseCase Use case for performance analysis.
 */
class CalculateScoutRankUseCase @Inject constructor(
    private val personalEfficiencyUseCase: CalculatePersonalEfficiencyUseCase
) {
    /**
     * Calculates the rank title for a scout based on their [stats].
     * 
     * @param stats The base stats for the user.
     * @return A string title representing their community status.
     */
    suspend operator fun invoke(stats: ScoutStats): String {
        val efficiency = personalEfficiencyUseCase()
        
        return when {
            stats.haulsReported >= 100 && efficiency.successRate >= 0.7f -> "Legendary Diver"
            stats.haulsReported >= 50 && efficiency.successRate >= 0.5f -> "Elite Scout"
            stats.haulsReported >= 20 -> "Veteran Scavenger"
            stats.spotsVerified >= 10 -> "Active Contributor"
            stats.haulsReported >= 5 -> "Junior Scout"
            else -> "Novice Scout"
        }
    }
}
