package com.dumpsterscout.domain.usecase

import com.dumpsterscout.data.local.dao.FieldLocationDao
import com.dumpsterscout.data.local.entity.FieldLocationEntity
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.repository.CommunityRepository
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.domain.repository.TireSpotRepository
import com.dumpsterscout.ui.map.MapLocationItem
import com.dumpsterscout.ui.map.MapLocationType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import javax.inject.Inject

/**
 * Use case to aggregate all geographical data for the map view.
 * Handles merging private local data with shared community data,
 * deduplicating records, and mapping to UI models.
 */
class GetMapLocationsUseCase @Inject constructor(
    private val spotRepository: SpotRepository,
    private val tireSpotRepository: TireSpotRepository,
    private val communityRepository: CommunityRepository,
    private val fieldLocationDao: FieldLocationDao // TODO: Refactor to repository
) {

    /**
     * Aggregates active locations from all local and community sources.
     *
     * @param showCommunity Whether to include shared community spots in the result.
     * @return A flow of location items suitable for map markers or lists.
     */
    operator fun invoke(showCommunity: Boolean): Flow<List<MapLocationItem>> {
        return combine(
            spotRepository.getActiveSpots(),
            tireSpotRepository.getActiveSpots(),
            fieldLocationDao.observeActive(),
            communityRepository.getCommunityDumpsterSpots(),
            communityRepository.getCommunityTireSpots()
        ) { dumpsterSpots, tireSpots, fieldLocations, commDumpsters, commTires ->
            buildList {
                // Private spots always included
                addAll(dumpsterSpots.map { it.toMapItem(isCommunity = false) })
                addAll(tireSpots.map { it.toMapItem(isCommunity = false) })
                addAll(fieldLocations.map { it.toMapItem() })

                if (showCommunity) {
                    val myRemoteIds = dumpsterSpots.mapNotNull { it.remoteId }.toSet()
                    val myTireRemoteIds = tireSpots.mapNotNull { it.remoteId }.toSet()

                    // Add community spots not owned by current user
                    addAll(commDumpsters
                        .filter { it.remoteId !in myRemoteIds }
                        .map { it.toMapItem(isCommunity = true) })
                    
                    addAll(commTires
                        .filter { it.remoteId !in myTireRemoteIds }
                        .map { it.toMapItem(isCommunity = true) })
                }
            }.sortedByDescending { it.isFavorite }
        }
    }

    private fun DumpsterSpot.toMapItem(isCommunity: Boolean): MapLocationItem = MapLocationItem(
        localId = id,
        type = MapLocationType.DUMPSTER,
        name = name,
        subtitle = category.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() },
        address = address,
        latitude = latitude,
        longitude = longitude,
        statusLabel = lastStatus.name.lowercase().replace('_', ' '),
        isFavorite = isFavorite,
        syncStatus = syncStatus.name,
        visibility = visibility.name,
        isCommunity = isCommunity,
        remoteId = remoteId,
        lastChecked = lastChecked
    )

    private fun TireSpot.toMapItem(isCommunity: Boolean): MapLocationItem = MapLocationItem(
        localId = id,
        type = MapLocationType.TIRE,
        name = name,
        subtitle = category.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() },
        address = address,
        latitude = latitude,
        longitude = longitude,
        statusLabel = lastStatus.name.lowercase().replace('_', ' '),
        isFavorite = isFavorite,
        syncStatus = syncStatus.name,
        visibility = visibility.name,
        isCommunity = isCommunity,
        remoteId = remoteId,
        lastChecked = lastChecked
    )

    private fun FieldLocationEntity.toMapItem(): MapLocationItem = MapLocationItem(
        localId = id,
        type = MapLocationType.FIELD,
        name = name,
        subtitle = type.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() },
        address = address,
        latitude = latitude,
        longitude = longitude,
        statusLabel = when {
            cleanupPriority != "NONE" -> cleanupPriority.lowercase().replace('_', ' ')
            hazardLevel != "NONE" -> hazardLevel.lowercase().replace('_', ' ')
            else -> syncStatus.lowercase().replace('_', ' ')
        },
        isFavorite = isFavorite,
        syncStatus = syncStatus,
        visibility = visibility,
        isCommunity = false,
        remoteId = remoteId
    )
}
