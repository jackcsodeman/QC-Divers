package com.dumpsterscout.domain.model

/**
 * Spot status indicating current fill / access state.
 */
enum class SpotStatus {
    UNKNOWN,
    EMPTY,
    HALF_FULL,
    FULL,
    OVERFLOWING,
    LOCKED,
    COMPACTOR_ONLY,
    GOOD_HAUL,
    SECURITY_ACTIVE,
    CONSTRUCTION_REMOVED,
    ALREADY_PICKED_THROUGH,
    NOTHING_THERE
}

/**
 * Location type relative to the building.
 */
enum class SpotLocation {
    BEHIND_STORE,
    ALLEY,
    LOADING_DOCK,
    PARKING_LOT,
    STREET_SIDE,
    OTHER
}

/**
 * Categorical type of the dumpster spot.
 */
enum class SpotCategory {
    GROCERY,
    BAKERY,
    PHARMACY,
    RETAIL,
    RESTAURANT,
    APARTMENT_COMPLEX,
    OFFICE,
    WAREHOUSE,
    ELECTRONICS,
    FURNITURE,
    OTHER
}

/**
 * Best time of day to visit.
 */
enum class BestTimeOfDay {
    MORNING,
    AFTERNOON,
    EVENING,
    LATE_NIGHT,
    VARIES
}

/**
 * Season preference.
 */
enum class BestSeason {
    SPRING,
    SUMMER,
    FALL,
    WINTER,
    MOVE_OUT_SEASON,
    HOLIDAY_WEEKS,
    YEAR_ROUND
}

/**
 * Core domain model for a saved dumpster spot.
 * No Android imports — pure Kotlin data class.
 */
data class DumpsterSpot(
    val id: Long = 0,
    val name: String,
    val category: SpotCategory = SpotCategory.OTHER,
    val address: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,

    // Access & layout
    val accessNotes: String = "",
    val spotLocation: SpotLocation = SpotLocation.OTHER,
    val isFenced: Boolean = false,
    val isGated: Boolean = false,
    val isLocked: Boolean = false,
    val isCompactor: Boolean = false,
    val hasMultipleDumpsters: Boolean = false,
    val dumpsterCount: Int = 1,
    val dumpsterLabels: String = "",
    val lidEasyToOpen: Boolean = true,
    val parkingEasy: Boolean = true,
    val distanceFromRoad: String = "",
    val vehicleAccessNotes: String = "",

    // Safety & visibility
    val lightingNotes: String = "",
    val safetyNotes: String = "",
    val securityCommon: Boolean = false,
    val hasCameras: Boolean = false,
    val isWellLit: Boolean = false,
    val isHiddenFromRoad: Boolean = false,

    // Timing & schedule
    val pickupDays: String = "",             // comma-separated days e.g. "Mon,Thu"
    val pickupTimeWindow: String = "",       // e.g. "6:00–8:00 AM"
    val bestTimeOfDay: BestTimeOfDay = BestTimeOfDay.VARIES,
    val betterOnWeekends: Boolean? = null,
    val bestSeason: BestSeason = BestSeason.YEAR_ROUND,
    val worthCheckingAfterPickup: Boolean = false,
    val bestBeforePickupDay: Boolean = false,
    val throwsOutNearClosingTime: Boolean = false,
    val checkMoreThanOncePerWeek: Boolean = false,
    val worstDay: String = "",

    // Findings
    val usualFindings: String = "",          // e.g. "food, electronics, clothes"
    val goodFindsCategories: String = "",
    val avoidReasons: String = "",
    val staffDestroyItems: Boolean = false,
    val worthCheckingWhenEmpty: Boolean = false,
    val usuallyMessy: Boolean = false,
    val hasSharpHazards: Boolean = false,
    val hasSealed: Boolean = false,          // sealed bags
    val checkedByOtherDivers: Boolean = false,
    val betterEarlierInNight: Boolean = true,

    // Condition snapshots
    val conditionSmell: String = "",
    val conditionPests: Boolean = false,
    val conditionMoisture: Boolean = false,

    // Gear
    val recommendedGear: String = "",

    // Grading
    val grade: SpotGrade = SpotGrade(),

    // Meta
    val personalNotes: String = "",
    val tags: List<String> = emptyList(),
    val isFavorite: Boolean = false,
    val isVerified: Boolean = false,
    val isRetired: Boolean = false,
    val lastChecked: Long? = null,           // epoch millis
    val lastStatus: SpotStatus = SpotStatus.UNKNOWN,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),

    // ── Sync / backend-ready metadata ──────────────────────────────────────────
    /** Stable remote ID from the future backend (Supabase row UUID). Null until first sync. */
    val remoteId: String? = null,
    /** User ID of the owner. In local-only mode this is the device's localId. */
    val ownerUserId: String? = null,
    /** Current sync lifecycle state. Defaults to LOCAL_ONLY. */
    val syncStatus: SyncStatus = SyncStatus.LOCAL_ONLY,
    /** Soft-delete timestamp. Null = active. Non-null = pending deletion on next sync. */
    val deletedAt: Long? = null,
    /** Sharing scope for future community features. Defaults to PRIVATE. */
    val visibility: Visibility = Visibility.PRIVATE,
    /** Remote photo URLs shared by the community for this spot. */
    val communityPhotoUrls: List<String> = emptyList()
)
