package com.dumpsterscout.domain.usecase

import android.content.Context
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.VoiceParseResult
import com.dumpsterscout.domain.repository.LocationRepository
import com.dumpsterscout.domain.repository.ReportRepository
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.util.VoiceParser
import com.dumpsterscout.util.geocodeAddress
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

/**
 * Use case to finalize and save a voice report.
 * If no existing spot is selected, it handles geocoding and creation of a new spot.
 */
class SaveVoiceReportUseCase @Inject constructor(
    private val spotRepository: SpotRepository,
    private val reportRepository: ReportRepository,
    private val locationRepository: LocationRepository,
    @ApplicationContext private val context: Context
) {

    suspend operator fun invoke(
        parseResult: VoiceParseResult,
        matchedSpot: DumpsterSpot?,
        editedNotes: String,
        editedTranscript: String
    ): Result<Unit> {
        return try {
            val location = locationRepository.getLatestLocation()
            val spotId = if (matchedSpot != null) {
                matchedSpot.id
            } else {
                // Try to resolve location from hint if present
                var lat = location?.latitude ?: 0.0
                var lng = location?.longitude ?: 0.0
                var address = ""
                
                parseResult.locationHint?.let { hint ->
                    val geoResult = context.geocodeAddress(hint)
                    if (geoResult != null) {
                        lat = geoResult.latitude
                        lng = geoResult.longitude
                        address = geoResult.getAddressLine(0) ?: hint
                    } else {
                        address = hint
                    }
                }

                // Create new spot if none matched
                val newSpot = DumpsterSpot(
                    name = parseResult.parsedSpotName ?: "New Spot",
                    address = address,
                    latitude = lat,
                    longitude = lng,
                    personalNotes = "Auto-created from voice report."
                )
                spotRepository.upsertSpot(newSpot)
            }

            val finalSpotName = matchedSpot?.name ?: parseResult.parsedSpotName ?: "New Spot"

            val report = VoiceParser.toReport(
                result = parseResult.copy(notes = editedNotes, rawTranscript = editedTranscript),
                spotId = spotId,
                spotName = finalSpotName,
                latitude = location?.latitude,
                longitude = location?.longitude
            )
            
            reportRepository.insertReport(report)
            
            parseResult.status?.let { status ->
                spotRepository.updateLastStatus(spotId, status, System.currentTimeMillis())
            }
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
