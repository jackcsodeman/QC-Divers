package com.dumpsterscout.domain.usecase

import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.repository.ReportRepository
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.domain.repository.UserRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import javax.inject.Inject

/**
 * Encapsulates the combined detail data for a dumpster spot.
 *
 * @property spot The core spot data.
 * @property reports The list of reports associated with this spot.
 * @property isOwner Whether the current user owns this spot.
 */
data class SpotDetail(
    val spot: DumpsterSpot,
    val reports: List<PersonalReport>,
    val isOwner: Boolean,
)

/**
 * Fetches a spot's full details including reports and ownership status.
 */
class GetSpotDetailUseCase @Inject constructor(
    private val spotRepository: SpotRepository,
    private val reportRepository: ReportRepository,
    private val userRepository: UserRepository,
) {
    /**
     * Returns a flow of [SpotDetail] for the given [spotId].
     * Emits null if the spot does not exist.
     */
    @OptIn(ExperimentalCoroutinesApi::class)
    operator fun invoke(spotId: Long): Flow<SpotDetail?> {
        return spotRepository.observeSpot(spotId).flatMapLatest { spot ->
            if (spot == null) return@flatMapLatest flowOf(null)
            
            combine(
                reportRepository.getReportsBySpot(spotId),
                userRepository.getCurrentUser(),
            ) { reports, user ->
                val isOwner = (spot.ownerUserId == null || spot.ownerUserId == user.localId)
                SpotDetail(spot, reports, isOwner)
            }
        }
    }
}
