package com.dumpsterscout.domain.usecase

import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.repository.ReportRepository
import kotlinx.coroutines.flow.first
import javax.inject.Inject

/**
 * Result of confidence calculation for a spot.
 */
enum class SpotConfidence {
    /** Multiple good reports recently. */
    TRENDING,
    /** Steady history. */
    HIGH_CONFIDENCE,
    /** No recent data. */
    NEEDS_CHECK,
    /** Multiple empty reports recently. */
    LIKELY_EMPTY,
    /** Conflicting recent data. */
    UNCERTAIN
}

/**
 * Use case to determine the reliability of a community spot based on recent crowd-sourced data.
 * 
 * @property reportRepository The repository providing historical reporting data.
 */
class CalculateSpotConfidenceUseCase @Inject constructor(
    private val reportRepository: ReportRepository
) {
    /**
     * Calculates the current confidence state for a given [spot].
     *
     * Logic:
     * - > 3 "Good Haul" reports in 48h -> TRENDING
     * - > 2 "Nothing There" reports in 48h -> LIKELY_EMPTY
     * - No reports in 7 days -> NEEDS_CHECK
     *
     * @param spot The dumpster spot to evaluate.
     * @return The calculated [SpotConfidence] level.
     */
    suspend operator fun invoke(spot: DumpsterSpot): SpotConfidence {
        val fortyEightHoursAgo = System.currentTimeMillis() - (48 * 60 * 60 * 1000)
        val sevenDaysAgo = System.currentTimeMillis() - (7 * 24 * 60 * 60 * 1000)
        
        val recentReports = reportRepository.getReportsBySpot(spot.id).first()
            .filter { it.timestamp >= sevenDaysAgo }

        if (recentReports.isEmpty()) return SpotConfidence.NEEDS_CHECK

        val veryRecent = recentReports.filter { it.timestamp >= fortyEightHoursAgo }
        
        val goodHauls = veryRecent.count { it.status == SpotStatus.GOOD_HAUL }
        if (goodHauls >= 3) return SpotConfidence.TRENDING

        val emptyReports = veryRecent.count { it.status == SpotStatus.NOTHING_THERE || it.status == SpotStatus.EMPTY }
        if (emptyReports >= 2) return SpotConfidence.LIKELY_EMPTY

        return if (recentReports.size >= 5) SpotConfidence.HIGH_CONFIDENCE else SpotConfidence.UNCERTAIN
    }
}
