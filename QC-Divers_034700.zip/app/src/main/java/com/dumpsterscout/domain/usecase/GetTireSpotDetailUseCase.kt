package com.dumpsterscout.domain.usecase

import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.repository.TireReportRepository
import com.dumpsterscout.domain.repository.TireSpotRepository
import com.dumpsterscout.domain.repository.UserRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import javax.inject.Inject

data class TireSpotDetail(
    val spot: TireSpot,
    val reports: List<TireReport>,
    val isOwner: Boolean
)

/**
 * Fetches a tire spot's full details including reports and ownership status.
 */
class GetTireSpotDetailUseCase @Inject constructor(
    private val tireSpotRepository: TireSpotRepository,
    private val tireReportRepository: TireReportRepository,
    private val userRepository: UserRepository
) {
    @OptIn(ExperimentalCoroutinesApi::class)
    operator fun invoke(spotId: Long): Flow<TireSpotDetail?> {
        return tireSpotRepository.observeSpot(spotId).flatMapLatest { spot ->
            if (spot == null) return@flatMapLatest flowOf(null)

            combine(
                tireReportRepository.getReportsBySpot(spotId),
                userRepository.getCurrentUser()
            ) { reports, user ->
                val isOwner = spot.ownerUserId == null || spot.ownerUserId == user.localId
                TireSpotDetail(spot, reports, isOwner)
            }
        }
    }
}
