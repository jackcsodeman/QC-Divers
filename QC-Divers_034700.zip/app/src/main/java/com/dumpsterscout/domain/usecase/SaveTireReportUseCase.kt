package com.dumpsterscout.domain.usecase

import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.domain.repository.TireReportRepository
import com.dumpsterscout.domain.repository.TireSpotRepository
import javax.inject.Inject

/**
 * Persists a tire report and updates the associated spot's status.
 */
class SaveTireReportUseCase @Inject constructor(
    private val tireReportRepository: TireReportRepository,
    private val tireSpotRepository: TireSpotRepository
) {
    suspend operator fun invoke(report: TireReport): Result<Unit> {
        return try {
            tireReportRepository.insertReport(report)
            if (report.status != TireSpotStatus.UNKNOWN) {
                tireSpotRepository.updateLastStatus(
                    report.tireSpotId, report.status, report.timestamp
                )
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
