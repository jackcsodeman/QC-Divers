package com.dumpsterscout.domain.repository

import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotStatus
import kotlinx.coroutines.flow.Flow

/**
 * Repository interface for dumpster spots.
 * Implementations live in the data layer.
 */
interface SpotRepository {

    fun getAllSpots(): Flow<List<DumpsterSpot>>

    fun getFavoriteSpots(): Flow<List<DumpsterSpot>>

    fun getActiveSpots(): Flow<List<DumpsterSpot>>

    fun searchSpots(query: String): Flow<List<DumpsterSpot>>

    suspend fun getSpotById(id: Long): DumpsterSpot?

    fun observeSpot(id: Long): Flow<DumpsterSpot?>

    suspend fun getNearestSpots(latitude: Double, longitude: Double, radiusMeters: Double = 5000.0): List<DumpsterSpot>

    suspend fun upsertSpot(spot: DumpsterSpot): Long

    suspend fun deleteSpot(spot: DumpsterSpot)

    suspend fun updateLastStatus(spotId: Long, status: SpotStatus, timestamp: Long)

    suspend fun toggleFavorite(spotId: Long)

    suspend fun retireSpot(spotId: Long)

    suspend fun deleteAllSpots()

    suspend fun exportToJson(): String

    suspend fun importFromJson(json: String): Int

    // ── Sync hooks (consumed by future sync WorkManager task) ─────────────────

    /**
     * Returns spots that have local changes not yet pushed to the remote backend.
     * The sync worker calls this to build the next upload batch.
     */
    suspend fun getPendingSyncSpots(): List<DumpsterSpot>

    /**
     * Mark a spot as successfully synced and store the backend-assigned remote ID.
     * @param id       Local Room ID.
     * @param remoteId Supabase row UUID returned after the upsert.
     */
    suspend fun markSpotSynced(id: Long, remoteId: String)

    /** Mark a spot sync as failed so it will be retried on the next pass. */
    suspend fun markSpotSyncFailed(id: Long)

    /**
     * Publish a spot to the community layer.
     * Sets visibility = COMMUNITY and schedules a sync pass.
     */
    suspend fun publishSpot(spotId: Long)

    /** Look up a spot by its backend UUID (used during remote pull to avoid duplicates). */
    suspend fun getSpotByRemoteId(remoteId: String): DumpsterSpot?

    /**
     * Upsert a spot that originated from the remote backend.
     * Does NOT stamp PENDING_SYNC — the record is already synced.
     */
    suspend fun upsertSpotFromRemote(spot: DumpsterSpot): Long
}
