package com.dumpsterscout.domain.model

/**
 * Upload state for a photo that may exist locally, remotely, or both.
 */
enum class UploadStatus {
    /** Photo exists only on-device. */
    LOCAL_ONLY,
    /** Photo is queued for upload to remote storage. */
    PENDING_UPLOAD,
    /** Photo is currently uploading. */
    UPLOADING,
    /** Photo has been uploaded and a private remote reference is available. */
    UPLOADED,
    /** Last upload attempt failed. */
    UPLOAD_FAILED
}

/**
 * A photo or media attachment associated with a spot or report.
 *
 * Designed to work today with local URIs and in the future with remote
 * Supabase Storage references.  Both [localUri] and [remoteUrl] may coexist so
 * the UI can serve the local copy while an upload is in progress.
 *
 * No Android imports — pure Kotlin data class.
 */
data class PhotoAttachment(
    val id: Long = 0,

    /** ID of the owning record (spotId, reportId, etc.). */
    val ownerId: Long,

    /** Discriminator: "spot", "report", "tire_spot", "tire_report". */
    val ownerType: String,

    /** content:// or file:// URI on the local device. Null if only remote. */
    val localUri: String? = null,

    /** Private Supabase Storage reference or short-lived signed URL. Null until uploaded. */
    val remoteUrl: String? = null,

    val uploadStatus: UploadStatus = UploadStatus.LOCAL_ONLY,

    /** User ID who took/added this photo. */
    val ownerUserId: String? = null,

    val caption: String = "",

    /** MIME type, e.g. "image/jpeg". */
    val mimeType: String = "image/jpeg",

    /** File size in bytes. 0 if unknown. */
    val fileSizeBytes: Long = 0,

    val takenAt: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),

    /** Soft-delete timestamp. Null means active. */
    val deletedAt: Long? = null
)
