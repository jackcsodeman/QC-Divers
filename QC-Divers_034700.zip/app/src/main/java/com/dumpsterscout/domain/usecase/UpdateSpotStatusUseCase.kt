package com.dumpsterscout.domain.usecase

import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.repository.SpotRepository
import javax.inject.Inject

/**
 * Updates the current status and last-checked timestamp of a spot.
 */
class UpdateSpotStatusUseCase @Inject constructor(
    private val spotRepository: SpotRepository
) {
    suspend operator fun invoke(spotId: Long, status: SpotStatus): Result<Unit> {
        return try {
            val now = System.currentTimeMillis()
            spotRepository.updateLastStatus(spotId, status, now)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
