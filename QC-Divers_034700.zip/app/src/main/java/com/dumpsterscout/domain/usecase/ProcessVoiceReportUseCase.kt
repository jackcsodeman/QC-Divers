package com.dumpsterscout.domain.usecase

import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.VoiceParseResult
import com.dumpsterscout.domain.repository.LocationRepository
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.util.VoiceParser
import kotlinx.coroutines.flow.first
import javax.inject.Inject

data class VoiceProcessResult(
    val result: VoiceParseResult,
    val matchedSpot: DumpsterSpot?,
    val candidateSpots: List<DumpsterSpot>
)

/**
 * Use case to parse a voice transcript and resolve it against known dumpster spots.
 * Uses both linguistic matching and geographical proximity.
 */
class ProcessVoiceReportUseCase @Inject constructor(
    private val spotRepository: SpotRepository,
    private val locationRepository: LocationRepository
) {

    suspend operator fun invoke(transcript: String): VoiceProcessResult {
        val rawResult = VoiceParser.parse(transcript)
        val allSpots = spotRepository.getActiveSpots().first()
        
        val location = locationRepository.getLatestLocation()
        val nearestSpotId = if (location != null) {
            spotRepository.getNearestSpots(location.latitude, location.longitude, 100.0)
                .firstOrNull()?.id
        } else null

        val resolved = VoiceParser.resolveSpot(rawResult, allSpots, nearestSpotId)

        val matchedSpot = resolved.matchedSpotId?.let { id ->
            allSpots.find { it.id == id }
        }
        val candidates = resolved.candidateSpotIds.mapNotNull { id ->
            allSpots.find { it.id == id }
        }

        return VoiceProcessResult(
            result = resolved,
            matchedSpot = matchedSpot,
            candidateSpots = candidates
        )
    }
}
