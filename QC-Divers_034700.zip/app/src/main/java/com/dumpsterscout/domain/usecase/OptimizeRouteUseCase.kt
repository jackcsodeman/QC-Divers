package com.dumpsterscout.domain.usecase

import com.dumpsterscout.data.local.entity.RouteStopEntity
import javax.inject.Inject

/**
 * Use case to optimize the visiting order of route stops using a nearest-neighbor TSP algorithm.
 */
class OptimizeRouteUseCase @Inject constructor() {
    
    /**
     * Reorders the given [stops] to minimize total travel distance starting from the first stop.
     * 
     * @param stops The list of stops to optimize.
     * @return A reordered list of stops with updated [RouteStopEntity.sortOrder].
     */
    operator fun invoke(stops: List<RouteStopEntity>): List<RouteStopEntity> {
        if (stops.size <= 2) return stops
        
        val unvisited = stops.toMutableList()
        val optimized = mutableListOf<RouteStopEntity>()
        
        // Start with the first stop (keep it as origin)
        var current = unvisited.removeAt(0)
        optimized.add(current)
        
        while (unvisited.isNotEmpty()) {
            val next = unvisited.minBy { stop ->
                calculateDistance(current.latitude, current.longitude, stop.latitude, stop.longitude)
            }
            unvisited.remove(next)
            optimized.add(next)
            current = next
        }
        
        return optimized.mapIndexed { index, stop ->
            stop.copy(sortOrder = index)
        }
    }

    /**
     * Calculates square of Euclidean distance between two points.
     * 
     * @param lat1 Latitude of point 1.
     * @param lon1 Longitude of point 1.
     * @param lat2 Latitude of point 2.
     * @param lon2 Longitude of point 2.
     * @return The squared distance between the points.
     */
    private fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val dLat = lat1 - lat2
        val dLon = lon1 - lon2
        return dLat * dLat + dLon * dLon
    }
}
