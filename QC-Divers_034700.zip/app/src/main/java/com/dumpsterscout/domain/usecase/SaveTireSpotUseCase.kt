package com.dumpsterscout.domain.usecase

import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.repository.TireSpotRepository
import javax.inject.Inject

/**
 * Persists a tire spot to the local and potentially remote layers.
 */
class SaveTireSpotUseCase @Inject constructor(
    private val tireSpotRepository: TireSpotRepository
) {
    suspend operator fun invoke(spot: TireSpot): Result<Long> {
        return try {
            if (spot.name.isBlank()) {
                return Result.failure(IllegalArgumentException("Spot name cannot be empty"))
            }
            val id = tireSpotRepository.upsertSpot(spot)
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
