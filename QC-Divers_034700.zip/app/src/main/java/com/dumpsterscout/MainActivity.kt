package com.dumpsterscout

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.lifecycleScope
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.ui.navigation.DumpsterScoutNavGraph
import com.dumpsterscout.ui.navigation.Screen
import com.dumpsterscout.ui.theme.DumpsterScoutTheme
import com.dumpsterscout.util.DsLogger
import dagger.hilt.android.AndroidEntryPoint
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Single activity host for the Compose UI.
 *
 * Handles deep links for Supabase Auth and pending navigation from notifications.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    /**
     * Injected application preferences for theme and onboarding state.
     */
    @Inject
    lateinit var appPreferences: AppPreferences

    /**
     * Injected Supabase client for handling authentication deep links.
     * This is nullable to support offline/local-only mode when credentials are not configured.
     */
    @Inject
    @JvmField
    var supabaseClient: SupabaseClient? = null

    private val pendingNavigationRoute = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        pendingNavigationRoute.value = intent?.getStringExtra(EXTRA_NAV_ROUTE)
        
        // Handle deep link on cold start
        intent?.data?.let { handleDeepLink(it) }
        
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContent {
            val darkTheme by appPreferences.darkTheme.collectAsState(initial = false)
            val dynamicColor by appPreferences.dynamicColor.collectAsState(initial = true)
            val fieldMode by appPreferences.fieldMode.collectAsState(initial = false)
            val onboardingDone by appPreferences.onboardingDone.collectAsState(initial = false)
            val initialRoute by pendingNavigationRoute
            val scope = rememberCoroutineScope()

            DumpsterScoutTheme(
                darkTheme = darkTheme,
                dynamicColor = dynamicColor,
                fieldMode = fieldMode
            ) {
                DumpsterScoutNavGraph(
                    onboardingComplete = onboardingDone,
                    onOnboardingComplete = { scope.launch { appPreferences.setOnboardingDone(true) } },
                    initialRoute = initialRoute,
                    onInitialRouteConsumed = { pendingNavigationRoute.value = null }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingNavigationRoute.value = intent.getStringExtra(EXTRA_NAV_ROUTE)
        
        // Handle deep link on existing instance
        intent.data?.let { handleDeepLink(it) }
    }

    /**
     * Process incoming deep link URIs to handle authentication redirects.
     *
     * @param data The incoming URI from the intent.
     */
    private fun handleDeepLink(data: Uri) {
        val url = data.toString()
        DsLogger.i("MainActivity", "Handling deep link: $url")
        
        when (data.host) {
            "auth" -> handleAuthDeepLink(data)
            "spot" -> handleSpotDeepLink(data)
        }
    }

    private fun handleAuthDeepLink(data: Uri) {
        val url = data.toString()
        if (url.contains("access_token=")) {
            val client = supabaseClient ?: return
            lifecycleScope.launch {
                try {
                    client.auth.importSessionFromUrl(data)
                    if (data.path?.contains("oauth/consent") == true) {
                        pendingNavigationRoute.value = Screen.OAuthConsent.route
                    } else {
                        pendingNavigationRoute.value = Screen.Home.route
                    }
                } catch (e: Exception) {
                    DsLogger.e("MainActivity", "Auth deep link failed", e)
                }
            }
        }
    }

    private fun handleSpotDeepLink(data: Uri) {
        // Expected: qcdivers://spot/{remoteId}
        val remoteId = data.lastPathSegment ?: return
        pendingNavigationRoute.value = Screen.CommunitySpotDetail.createRoute(remoteId)
    }

    /**
     * Extension to import a session from a URI fragment or query parameters.
     *
     * @param uri The URI containing the authentication parameters.
     */
    private suspend fun io.github.jan.supabase.auth.Auth.importSessionFromUrl(uri: Uri) {
        // This is a helper to extract params from fragment or query and call importAuthToken
        val fragment = uri.fragment ?: uri.query ?: return
        val params = fragment.split("&").associate {
            val parts = it.split("=")
            parts[0] to parts.getOrElse(1) { "" }
        }
        
        val accessToken = params["access_token"]
        val refreshToken = params["refresh_token"]
        
        if (accessToken != null) {
            importAuthToken(accessToken, refreshToken ?: "")
        }
    }

    companion object {
        /** Intent extra key for passing a destination route. */
        const val EXTRA_NAV_ROUTE = "com.dumpsterscout.extra.NAV_ROUTE"
        /** Intent extra key for passing a reminder ID. */
        const val EXTRA_REMINDER_ID = "com.dumpsterscout.extra.REMINDER_ID"
    }
}
