package com.dumpsterscout.notifications

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.dumpsterscout.data.local.entity.ReminderEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Calendar
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReminderScheduler @Inject constructor(
    @ApplicationContext private val context: Context
) {
    fun schedule(reminder: ReminderEntity) {
        if (!reminder.isActive || reminder.id <= 0L) return
        val delayMs = nextReminderDelayMillis(reminder.dayOfWeek, reminder.timeHour, reminder.timeMinute)
        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf(ReminderWorker.KEY_REMINDER_ID to reminder.id))
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            workName(reminder.id),
            ExistingWorkPolicy.REPLACE,
            request
        )
    }

    fun cancel(reminderId: Long) {
        WorkManager.getInstance(context).cancelUniqueWork(workName(reminderId))
    }

    companion object {
        const val CHANNEL_ID = "field_reminders"
        const val CHANNEL_NAME = "Field reminders"

        fun workName(reminderId: Long): String = "field_reminder_$reminderId"

        fun nextReminderDelayMillis(dayOfWeek: Int, hour: Int, minute: Int): Long {
            val now = Calendar.getInstance()
            val next = Calendar.getInstance().apply {
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
                set(Calendar.MINUTE, minute.coerceIn(0, 59))
                if (dayOfWeek in Calendar.SUNDAY..Calendar.SATURDAY) {
                    set(Calendar.DAY_OF_WEEK, dayOfWeek)
                }
                if (!after(now)) {
                    add(Calendar.DAY_OF_YEAR, if (dayOfWeek == 0) 1 else 7)
                }
            }
            return (next.timeInMillis - now.timeInMillis).coerceAtLeast(1_000L)
        }
    }
}
