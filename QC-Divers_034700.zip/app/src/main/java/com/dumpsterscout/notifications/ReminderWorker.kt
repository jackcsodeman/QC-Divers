package com.dumpsterscout.notifications

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.dumpsterscout.MainActivity
import com.dumpsterscout.R
import com.dumpsterscout.ui.navigation.Screen
import com.dumpsterscout.data.local.dao.ReminderDao
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

@HiltWorker
class ReminderWorker @AssistedInject constructor(
    @Assisted private val context: Context,
    @Assisted params: WorkerParameters,
    private val reminderDao: ReminderDao
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val reminderId = inputData.getLong(KEY_REMINDER_ID, 0L)
        val reminder = reminderDao.getReminderById(reminderId) ?: return Result.success()
        if (!reminder.isActive) return Result.success()

        ensureChannel()
        if (Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        ) {
            showNotification(reminderId, reminder.label.ifBlank { context.getString(R.string.reminder_default_label) })
        }

        if (reminder.dayOfWeek == 0) {
            reminderDao.setActive(reminder.id, false, syncStatus = reminder.syncStatus)
        } else {
            val delayMs = ReminderScheduler.nextReminderDelayMillis(reminder.dayOfWeek, reminder.timeHour, reminder.timeMinute)
            val request = OneTimeWorkRequestBuilder<ReminderWorker>()
                .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
                .setInputData(workDataOf(KEY_REMINDER_ID to reminder.id))
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                ReminderScheduler.workName(reminder.id),
                androidx.work.ExistingWorkPolicy.REPLACE,
                request
            )
        }
        return Result.success()
    }

    private fun ensureChannel() {
        val channel = NotificationChannel(
            ReminderScheduler.CHANNEL_ID,
            ReminderScheduler.CHANNEL_NAME,
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = context.getString(R.string.reminder_channel_description)
        }
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    @SuppressLint("MissingPermission")
    private fun showNotification(reminderId: Long, label: String) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(MainActivity.EXTRA_NAV_ROUTE, Screen.Reminders.route)
            putExtra(MainActivity.EXTRA_REMINDER_ID, reminderId)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            reminderId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, ReminderScheduler.CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(context.getString(R.string.reminder_notification_title))
            .setContentText(label)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        NotificationManagerCompat.from(context).notify(reminderId.toInt(), notification)
    }

    companion object {
        const val KEY_REMINDER_ID = "reminder_id"
    }
}
