package com.dumpsterscout.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.dumpsterscout.data.local.entity.RoutePlanEntity
import com.dumpsterscout.data.local.entity.RouteStopEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface RoutePlanDao {

    @Query("SELECT * FROM route_plans WHERE deletedAt IS NULL ORDER BY updatedAt DESC")
    fun getAllRoutePlans(): Flow<List<RoutePlanEntity>>

    @Query("SELECT * FROM route_stops WHERE deletedAt IS NULL ORDER BY routeId ASC, sortOrder ASC")
    fun observeAllStops(): Flow<List<RouteStopEntity>>

    @Query("SELECT * FROM route_stops WHERE routeId = :routeId AND deletedAt IS NULL ORDER BY sortOrder ASC")
    fun observeStopsForRoute(routeId: Long): Flow<List<RouteStopEntity>>

    @Query("SELECT * FROM route_plans WHERE id = :id")
    suspend fun getRoutePlanById(id: Long): RoutePlanEntity?

    @Query("SELECT * FROM route_plans WHERE remoteId = :remoteId LIMIT 1")
    suspend fun getRoutePlanByRemoteId(remoteId: String): RoutePlanEntity?

    @Query("SELECT * FROM route_stops WHERE routeId = :routeId ORDER BY sortOrder ASC")
    suspend fun getStopsForRouteSnapshot(routeId: Long): List<RouteStopEntity>

    @Query("UPDATE route_plans SET syncStatus = 'PENDING_SYNC', updatedAt = :now WHERE id = :id")
    suspend fun markPlanPendingSync(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE route_plans SET syncStatus = 'SYNCED', remoteId = :remoteId, updatedAt = :now WHERE id = :id")
    suspend fun markPlanSynced(id: Long, remoteId: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE route_plans SET syncStatus = 'SYNC_FAILED', updatedAt = :now WHERE id = :id")
    suspend fun markPlanSyncFailed(id: Long, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM route_stops WHERE id = :id")
    suspend fun getStopById(id: Long): RouteStopEntity?

    @Query("SELECT * FROM route_stops WHERE remoteId = :remoteId LIMIT 1")
    suspend fun getStopByRemoteId(remoteId: String): RouteStopEntity?

    @Query("SELECT COALESCE(MAX(sortOrder), -1) + 1 FROM route_stops WHERE routeId = :routeId AND deletedAt IS NULL")
    suspend fun nextSortOrder(routeId: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(plan: RoutePlanEntity): Long

    @Update
    suspend fun update(plan: RoutePlanEntity)

    @Delete
    suspend fun delete(plan: RoutePlanEntity)

    @Query("UPDATE route_plans SET deletedAt = :now, updatedAt = :now WHERE id = :id")
    suspend fun softDeletePlan(id: Long, now: Long = System.currentTimeMillis())

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStop(stop: RouteStopEntity): Long

    @Update
    suspend fun updateStop(stop: RouteStopEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStop(stop: RouteStopEntity): Long

    @Query("UPDATE route_stops SET deletedAt = :now, updatedAt = :now WHERE id = :id")
    suspend fun softDeleteStop(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE route_stops SET sortOrder = :sortOrder, updatedAt = :now WHERE id = :id")
    suspend fun updateStopOrder(id: Long, sortOrder: Int, now: Long = System.currentTimeMillis())

    @Query("DELETE FROM route_stops")
    suspend fun deleteAllStops()

    @Query("DELETE FROM route_plans")
    suspend fun deleteAllPlans()

    @Transaction
    suspend fun deleteAll() {
        deleteAllStops()
        deleteAllPlans()
    }

    @Query("SELECT COUNT(*) FROM route_plans WHERE deletedAt IS NULL")
    fun observeRouteCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM route_stops WHERE deletedAt IS NULL")
    fun observeRouteStopCount(): Flow<Int>

}
