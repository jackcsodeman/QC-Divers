package com.dumpsterscout.data.mapper

import com.dumpsterscout.data.local.entity.SpotPhotoEntity
import com.dumpsterscout.domain.model.PhotoAttachment
import com.dumpsterscout.domain.model.UploadStatus

fun SpotPhotoEntity.toDomain(): PhotoAttachment {
       val resolvedOwnerType = ownerType.ifBlank { "DUMPSTER_SPOT" }
    val resolvedOwnerId = when {
        ownerId > 0L -> ownerId
        spotId != null -> spotId
        else -> 0L
    }
    return PhotoAttachment(
        id = id,
        ownerId = resolvedOwnerId,
        ownerType = resolvedOwnerType,
        localUri = uri.ifBlank { null },
        remoteUrl = remoteUrl,
        uploadStatus = UploadStatus.entries.find { it.name == uploadStatus } ?: UploadStatus.LOCAL_ONLY,
        ownerUserId = ownerUserId,
        caption = caption,
        mimeType = mimeType,
        fileSizeBytes = fileSizeBytes,
        takenAt = takenAt,
        createdAt = createdAt,
        updatedAt = updatedAt,
        deletedAt = deletedAt
    )
}

fun PhotoAttachment.toSpotPhotoEntity(): SpotPhotoEntity {
    val normalizedOwnerType = normalizePhotoOwnerType(ownerType)
    val legacySpotId = if (normalizedOwnerType == "DUMPSTER_SPOT") ownerId else null
    return SpotPhotoEntity(
        id = id,
        spotId = legacySpotId,
        ownerType = normalizedOwnerType,
        ownerId = ownerId,
        uri = localUri ?: "",
        remoteUrl = remoteUrl,
        uploadStatus = uploadStatus.name,
        caption = caption,
        mimeType = mimeType,
        fileSizeBytes = fileSizeBytes,
        ownerUserId = ownerUserId,
        takenAt = takenAt,
        createdAt = createdAt,
        updatedAt = updatedAt,
        deletedAt = deletedAt
    )
}

fun normalizePhotoOwnerType(ownerType: String): String = when (ownerType.uppercase()) {
    "SPOT", "DUMPSTER", "DUMPSTER_SPOT" -> "DUMPSTER_SPOT"
    "TIRE", "TIRE_SPOT" -> "TIRE_SPOT"
    "REPORT", "DUMPSTER_REPORT" -> "DUMPSTER_REPORT"
    "TIRE_REPORT" -> "TIRE_REPORT"
    "FIELD", "FIELD_LOCATION", "CLEANUP_SITE", "SALVAGE_RESOURCE", "CUSTOM" -> "FIELD_LOCATION"
    else -> ownerType.uppercase()
}
