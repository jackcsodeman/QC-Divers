package com.dumpsterscout.data.remote

import com.dumpsterscout.util.DsLogger
import com.dumpsterscout.data.remote.dto.ReportRow
import com.dumpsterscout.data.remote.dto.TireReportRow
import com.dumpsterscout.data.remote.dto.toRow
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.TireReport
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.from

/**
 * Real [RemoteReportDataSource] implementation backed by Supabase Postgrest.
 *
 * Tables: `dumpster_reports`, `tire_reports` — see [ReportRow] / [TireReportRow] for schema.
 */
class SupabaseReportDataSource(
    private val client: SupabaseClient
) : RemoteReportDataSource {

    override suspend fun upsertReports(
        reports: List<PersonalReport>,
        spotRemoteIds: Map<Long, String?>
    ): Map<Long, String> {
        val result = mutableMapOf<Long, String>()
        val currentUserId = client.auth.currentUserOrNull()?.id
        for (report in reports) {
            try {
                val spotRemoteId = spotRemoteIds[report.id]
                val row = report.toRow(ownerId = currentUserId, spotRemoteId = spotRemoteId)
                val returned = if (report.remoteId == null) {
                    client.from(SPOT_REPORTS_TABLE).insert(row) { select() }.decodeSingle<ReportRow>()
                } else {
                    client.from(SPOT_REPORTS_TABLE).upsert(row) { select() }.decodeSingle<ReportRow>()
                }
                result[report.id] = returned.remoteId
            } catch (e: Exception) {
                DsLogger.e(TAG, "Failed to upsert report.", e)
            }
        }
        return result
    }

    override suspend fun upsertTireReports(
        reports: List<TireReport>,
        tireSpotRemoteIds: Map<Long, String?>
    ): Map<Long, String> {
        val result = mutableMapOf<Long, String>()
        val currentUserId = client.auth.currentUserOrNull()?.id
        for (report in reports) {
            try {
                val tireSpotRemoteId = tireSpotRemoteIds[report.id]
                val row = report.toRow(ownerId = currentUserId, tireSpotRemoteId = tireSpotRemoteId)
                val returned = if (report.remoteId == null) {
                    client.from(TIRE_REPORTS_TABLE).insert(row) { select() }.decodeSingle<TireReportRow>()
                } else {
                    client.from(TIRE_REPORTS_TABLE).upsert(row) { select() }.decodeSingle<TireReportRow>()
                }
                result[report.id] = returned.remoteId
            } catch (e: Exception) {
                DsLogger.e(TAG, "Failed to upsert tire report.", e)
            }
        }
        return result
    }


    override suspend fun deleteReports(remoteIds: List<String>): Set<String> =
        softDeleteReports(table = SPOT_REPORTS_TABLE, remoteIds = remoteIds)

    override suspend fun deleteTireReports(remoteIds: List<String>): Set<String> =
        softDeleteReports(table = TIRE_REPORTS_TABLE, remoteIds = remoteIds)

    private suspend fun softDeleteReports(table: String, remoteIds: List<String>): Set<String> {
        val deleted = mutableSetOf<String>()
        val nowMillis = System.currentTimeMillis()
        for (id in remoteIds.filter { it.isNotBlank() }) {
            try {
                client.from(table).update({ set("deleted_at", nowMillis) }) {
                    filter { eq("id", id) }
                }
                deleted.add(id)
            } catch (e: Exception) {
                DsLogger.e(TAG, "Failed to soft-delete report.", e)
            }
        }
        return deleted
    }

    override suspend fun fetchMyReports(ownerUserId: String): List<ReportRow> {
        return try {
            client.from(SPOT_REPORTS_TABLE)
                .select { filter { eq("owner_id", ownerUserId) } }
                .decodeList<ReportRow>()
                .filter { it.deletedAt == null }
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to fetch reports for owner.", e)
            emptyList()
        }
    }

    override suspend fun fetchMyTireReports(ownerUserId: String): List<TireReportRow> {
        return try {
            client.from(TIRE_REPORTS_TABLE)
                .select { filter { eq("owner_id", ownerUserId) } }
                .decodeList<TireReportRow>()
                .filter { it.deletedAt == null }
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to fetch tire reports for owner.", e)
            emptyList()
        }
    }

    private companion object {
        const val TAG = "SupabaseReportDS"
        const val SPOT_REPORTS_TABLE = "dumpster_reports"
        const val TIRE_REPORTS_TABLE = "tire_reports"
    }
}
