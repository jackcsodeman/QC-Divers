package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.RoutePlanEntity
import com.dumpsterscout.data.local.entity.RouteStopEntity

/** Local-only route remote source. */
class NoOpRemoteRouteDataSource : RemoteRouteDataSource {
    override suspend fun upsertRoutePlan(route: RoutePlanEntity, stops: List<RouteStopEntity>): String? = null
    override suspend fun deleteRoutePlans(remoteIds: List<String>): Set<String> = emptySet()
    override suspend fun fetchMyRoutePlans(ownerUserId: String): List<RoutePlanEntity> = emptyList()
    override suspend fun fetchMyRouteStops(ownerUserId: String) = emptyList<com.dumpsterscout.data.remote.dto.RouteStopRow>()

}
