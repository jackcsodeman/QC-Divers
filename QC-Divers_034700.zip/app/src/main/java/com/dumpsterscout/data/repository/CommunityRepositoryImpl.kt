package com.dumpsterscout.data.repository

import com.dumpsterscout.data.remote.RemoteSpotDataSource
import com.dumpsterscout.data.remote.RemoteTireSpotDataSource
import com.dumpsterscout.di.annotations.RemoteSource
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.repository.CommunityRepository
import com.dumpsterscout.util.DsLogger
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.from

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CommunityRepositoryImpl @Inject constructor(
    private val supabaseClient: SupabaseClient?,
    @RemoteSource private val remoteSpotSource: RemoteSpotDataSource,
    @RemoteSource private val remoteTireSource: RemoteTireSpotDataSource
) : CommunityRepository {

    private val _communityDumpsterSpots = MutableStateFlow<List<DumpsterSpot>>(emptyList())
    override fun getCommunityDumpsterSpots(): Flow<List<DumpsterSpot>> = _communityDumpsterSpots.asStateFlow()

    private val _communityTireSpots = MutableStateFlow<List<TireSpot>>(emptyList())
    override fun getCommunityTireSpots(): Flow<List<TireSpot>> = _communityTireSpots.asStateFlow()

    override fun getCommunityDumpsterSpot(remoteId: String): Flow<DumpsterSpot?> =
        _communityDumpsterSpots.map { spots -> spots.find { it.remoteId == remoteId } }

    override fun getCommunityTireSpot(remoteId: String): Flow<TireSpot?> =
        _communityTireSpots.map { spots -> spots.find { it.remoteId == remoteId } }

    override suspend fun refreshCommunityData() {
        try {
            val spots = remoteSpotSource.fetchAllCommunitySpots()
            _communityDumpsterSpots.value = spots

            val tireSpots = remoteTireSource.fetchAllCommunityTireSpots()
            _communityTireSpots.value = tireSpots
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to refresh community data.", e)
        }
    }

    override suspend fun reportSpot(
        targetTable: String,
        targetRemoteId: String,
        reason: String,
        notes: String
    ): Result<Unit> {
        val client = supabaseClient ?: return Result.failure(IllegalStateException("Supabase not configured"))
        return try {
            val reporterId = client.auth.currentUserOrNull()?.id
                ?: return Result.failure(IllegalStateException("User not signed in"))

            client.from("community_reports").insert(
                mapOf(
                    "reporter_id" to reporterId,
                    "target_table" to targetTable,
                    "target_id" to targetRemoteId,
                    "reason" to reason,
                    "notes" to notes
                )
            )
            Result.success(Unit)
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to report spot.", e)
            Result.failure(e)
        }
    }

    override suspend fun blockUser(targetRemoteUserId: String): Result<Unit> {
        val client = supabaseClient ?: return Result.failure(IllegalStateException("Supabase not configured"))
        return try {
            val blockerId = client.auth.currentUserOrNull()?.id
                ?: return Result.failure(IllegalStateException("User not signed in"))

            client.from("blocked_users").insert(
                mapOf(
                    "blocker_id" to blockerId,
                    "blocked_id" to targetRemoteUserId
                )
            )
            Result.success(Unit)
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to block user.", e)
            Result.failure(e)
        }
    }

    companion object {
        private const val TAG = "CommunityRepo"
    }
}
