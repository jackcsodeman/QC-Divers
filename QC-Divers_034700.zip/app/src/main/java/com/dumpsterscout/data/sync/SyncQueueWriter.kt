package com.dumpsterscout.data.sync

import com.dumpsterscout.data.local.dao.SyncQueueDao
import com.dumpsterscout.data.local.entity.SyncQueueEntity
import javax.inject.Inject
import javax.inject.Singleton

enum class SyncEntityType {
    DUMPSTER_SPOT,
    DUMPSTER_REPORT,
    TIRE_SPOT,
    TIRE_REPORT,
    PHOTO,
    FIELD_LOCATION,
    REMINDER,
    ROUTE_PLAN,
    FIELD_SESSION,
    COLLECTION,
    GEAR_CHECKLIST,
    FIELD_LOCATION_REPORT
}

enum class SyncQueueOperation {
    CREATE,
    UPDATE,
    DELETE,
    UPLOAD_PHOTO,
    DELETE_PHOTO
}

/**
 * Small write-only facade for recording durable sync operations.
 *
 * The existing SyncWorker still supports the legacy per-record PENDING_SYNC
 * path. This writer is the production sync foundation that future worker work
 * can consume without losing operations after app restarts or network failures.
 */
@Singleton
class SyncQueueWriter @Inject constructor(
    private val dao: SyncQueueDao
) {
    suspend fun latestQueueId(entityType: SyncEntityType, entityLocalId: Long): Long? =
        dao.latestForEntity(entityType.name, entityLocalId)?.id

    suspend fun enqueue(
        entityType: SyncEntityType,
        entityLocalId: Long,
        entityRemoteId: String?,
        operation: SyncQueueOperation,
        payload: String,
        dependsOnQueueItemId: Long? = null
    ): Long {
        require(entityLocalId > 0L) { "entityLocalId must be persisted before enqueueing sync" }
        val now = System.currentTimeMillis()
        val idempotencyKey = buildIdempotencyKey(entityType, entityLocalId, operation, entityRemoteId)
        return dao.enqueue(
            SyncQueueEntity(
                entityType = entityType.name,
                entityLocalId = entityLocalId,
                entityRemoteId = entityRemoteId,
                operation = operation.name,
                payload = payload.toString(),
                createdAt = now,
                updatedAt = now,
                idempotencyKey = idempotencyKey,
                dependsOnQueueItemId = dependsOnQueueItemId
            )
        )
    }

    private fun buildIdempotencyKey(
        entityType: SyncEntityType,
        entityLocalId: Long,
        operation: SyncQueueOperation,
        entityRemoteId: String?
    ): String = listOf(entityType.name, entityLocalId.toString(), operation.name, entityRemoteId.orEmpty())
        .joinToString(separator = ":")
}
