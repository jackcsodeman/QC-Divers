package com.dumpsterscout.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.dumpsterscout.data.local.dao.DumpsterSpotDao
import com.dumpsterscout.data.local.dao.GearChecklistDao
import com.dumpsterscout.data.local.dao.FieldSessionDao
import com.dumpsterscout.data.local.dao.FieldLocationDao
import com.dumpsterscout.data.local.dao.FieldLocationReportDao
import com.dumpsterscout.data.local.dao.CollectionDao
import com.dumpsterscout.data.local.dao.PersonalReportDao
import com.dumpsterscout.data.local.dao.ReminderDao
import com.dumpsterscout.data.local.dao.RoutePlanDao
import com.dumpsterscout.data.local.dao.SpotPhotoDao
import com.dumpsterscout.data.local.dao.SyncQueueDao
import com.dumpsterscout.data.local.dao.TireReportDao
import com.dumpsterscout.data.local.dao.TireSpotDao
import com.dumpsterscout.data.local.entity.DumpsterSpotEntity
import com.dumpsterscout.data.local.entity.GearChecklistItemEntity
import com.dumpsterscout.data.local.entity.GearChecklistEntity
import com.dumpsterscout.data.local.entity.FieldSessionVisitEntity
import com.dumpsterscout.data.local.entity.FieldSessionEntity
import com.dumpsterscout.data.local.entity.FieldLocationEntity
import com.dumpsterscout.data.local.entity.FieldLocationReportEntity
import com.dumpsterscout.data.local.entity.CollectionItemEntity
import com.dumpsterscout.data.local.entity.CollectionEntity
import com.dumpsterscout.data.local.entity.PersonalReportEntity
import com.dumpsterscout.data.local.entity.ReminderEntity
import com.dumpsterscout.data.local.entity.RoutePlanEntity
import com.dumpsterscout.data.local.entity.RouteStopEntity
import com.dumpsterscout.data.local.entity.SpotPhotoEntity
import com.dumpsterscout.data.local.entity.SyncQueueEntity
import com.dumpsterscout.data.local.entity.TireReportEntity
import com.dumpsterscout.data.local.entity.TireSpotEntity

/**
 * Room database for Dumpster Scout.
 * Room is the local source of truth. Data stays local unless the user opts into Supabase sync.
 *
 * Version history:
 *  1 → 2  Added tire_spots and tire_reports tables.
 *  2 → 3  Added sync/backend-ready metadata columns to all core tables
 *         (syncStatus, ownerUserId, remoteId, deletedAt, visibility where
 *         applicable) and enriched spot_photos with upload-state columns.
 *  3 -> 4  Added visibility to report tables.
 *  4 -> 5  Added durable sync_queue outbox for production-grade sync.
 *  5 -> 6  Added generic field locations, collections, field sessions, and persisted gear checklists.
 *  6 -> 7  Generalized photo ownership for tire/report/field-location parity.
 *  7 -> 8  Added normalized route_stops for mixed route planning and ordering.
 *  8 -> 9  Added sync metadata to reminders and gear checklists/items.
 *  9 -> 10 Added conflict-resolution snapshots and resolution audit metadata to sync_queue.
 * 10 -> 11 Added field-location reports and reminder completion/snooze metadata.
 * 11 -> 12 Added remote sync metadata to normalized child rows for route stops,
 *          collection items, and field-session visits.
 * 12 -> 13 Restored tire voice-report location/transcript metadata from the clean variant.
 */
@Database(
    entities = [
        DumpsterSpotEntity::class,
        PersonalReportEntity::class,
        SpotPhotoEntity::class,
        SyncQueueEntity::class,
        RoutePlanEntity::class,
        RouteStopEntity::class,
        ReminderEntity::class,
        TireSpotEntity::class,
        TireReportEntity::class,
        FieldLocationEntity::class,
        FieldLocationReportEntity::class,
        CollectionEntity::class,
        CollectionItemEntity::class,
        FieldSessionEntity::class,
        FieldSessionVisitEntity::class,
        GearChecklistEntity::class,
        GearChecklistItemEntity::class
    ],
    version = 13,
    exportSchema = true
)
abstract class DumpsterScoutDatabase : RoomDatabase() {

    abstract fun spotDao(): DumpsterSpotDao
    abstract fun reportDao(): PersonalReportDao
    abstract fun photoDao(): SpotPhotoDao
    abstract fun syncQueueDao(): SyncQueueDao
    abstract fun routePlanDao(): RoutePlanDao
    abstract fun reminderDao(): ReminderDao
    abstract fun tireSpotDao(): TireSpotDao
    abstract fun tireReportDao(): TireReportDao
    abstract fun fieldLocationDao(): FieldLocationDao
    abstract fun fieldLocationReportDao(): FieldLocationReportDao
    abstract fun collectionDao(): CollectionDao
    abstract fun fieldSessionDao(): FieldSessionDao
    abstract fun gearChecklistDao(): GearChecklistDao

    companion object {
        const val DATABASE_NAME = "dumpster_scout.db"

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `tire_spots` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `name` TEXT NOT NULL,
                        `category` TEXT NOT NULL DEFAULT 'OTHER',
                        `address` TEXT NOT NULL DEFAULT '',
                        `latitude` REAL NOT NULL DEFAULT 0.0,
                        `longitude` REAL NOT NULL DEFAULT 0.0,
                        `accessNotes` TEXT NOT NULL DEFAULT '',
                        `isFenced` INTEGER NOT NULL DEFAULT 0,
                        `isGated` INTEGER NOT NULL DEFAULT 0,
                        `isLocked` INTEGER NOT NULL DEFAULT 0,
                        `isExposed` INTEGER NOT NULL DEFAULT 0,
                        `easyAccess` INTEGER NOT NULL DEFAULT 1,
                        `hasCameras` INTEGER NOT NULL DEFAULT 0,
                        `securityCommon` INTEGER NOT NULL DEFAULT 0,
                        `bestTimeOfDay` TEXT NOT NULL DEFAULT 'VARIES',
                        `bestDays` TEXT NOT NULL DEFAULT '',
                        `betterOnWeekends` INTEGER,
                        `isSeasonal` INTEGER NOT NULL DEFAULT 0,
                        `season` TEXT NOT NULL DEFAULT 'YEAR_ROUND',
                        `putsOutAroundClosing` INTEGER NOT NULL DEFAULT 0,
                        `puncturePattern` TEXT NOT NULL DEFAULT 'UNKNOWN',
                        `usableDisappearFast` INTEGER NOT NULL DEFAULT 0,
                        `othersGetThereFirst` INTEGER NOT NULL DEFAULT 0,
                        `worthCheckingWhenLight` INTEGER NOT NULL DEFAULT 0,
                        `usuallyPutsOutMany` INTEGER NOT NULL DEFAULT 0,
                        `isVerified` INTEGER NOT NULL DEFAULT 0,
                        `isFavorite` INTEGER NOT NULL DEFAULT 0,
                        `isRetired` INTEGER NOT NULL DEFAULT 0,
                        `lastChecked` INTEGER,
                        `lastStatus` TEXT NOT NULL DEFAULT 'UNKNOWN',
                        `notes` TEXT NOT NULL DEFAULT '',
                        `tags` TEXT NOT NULL DEFAULT '',
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `tire_reports` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `tireSpotId` INTEGER NOT NULL,
                        `spotName` TEXT NOT NULL DEFAULT '',
                        `status` TEXT NOT NULL DEFAULT 'UNKNOWN',
                        `estimatedCount` INTEGER NOT NULL DEFAULT 0,
                        `estimatedUsableCount` INTEGER NOT NULL DEFAULT 0,
                        `estimatedJunkCount` INTEGER NOT NULL DEFAULT 0,
                        `arePunctured` INTEGER NOT NULL DEFAULT 0,
                        `somePunctured` INTEGER NOT NULL DEFAULT 0,
                        `someUnpunctured` INTEGER NOT NULL DEFAULT 0,
                        `commonSizes` TEXT NOT NULL DEFAULT '',
                        `tireTypes` TEXT NOT NULL DEFAULT '',
                        `treadQuality` TEXT NOT NULL DEFAULT 'UNKNOWN',
                        `condition` TEXT NOT NULL DEFAULT 'UNKNOWN',
                        `sidewallDamage` INTEGER NOT NULL DEFAULT 0,
                        `dryRot` INTEGER NOT NULL DEFAULT 0,
                        `repairVisible` INTEGER NOT NULL DEFAULT 0,
                        `conditionNotes` TEXT NOT NULL DEFAULT '',
                        `yearNotes` TEXT NOT NULL DEFAULT '',
                        `alreadyPickedThrough` INTEGER NOT NULL DEFAULT 0,
                        `lookedFreshOut` INTEGER NOT NULL DEFAULT 0,
                        `weatherAffected` INTEGER NOT NULL DEFAULT 0,
                        `notes` TEXT NOT NULL DEFAULT '',
                        `photoUris` TEXT NOT NULL DEFAULT '',
                        `timestamp` INTEGER NOT NULL,
                        FOREIGN KEY(`tireSpotId`) REFERENCES `tire_spots`(`id`) ON DELETE CASCADE
                    )
                """.trimIndent())

                db.execSQL("CREATE INDEX IF NOT EXISTS `index_tire_reports_tireSpotId` ON `tire_reports` (`tireSpotId`)")
            }
        }
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // dumpster_spots: add sync metadata + visibility
                db.execSQL("ALTER TABLE `dumpster_spots` ADD COLUMN `remoteId` TEXT")
                db.execSQL("ALTER TABLE `dumpster_spots` ADD COLUMN `ownerUserId` TEXT")
                db.execSQL("ALTER TABLE `dumpster_spots` ADD COLUMN `syncStatus` TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                db.execSQL("ALTER TABLE `dumpster_spots` ADD COLUMN `deletedAt` INTEGER")
                db.execSQL("ALTER TABLE `dumpster_spots` ADD COLUMN `visibility` TEXT NOT NULL DEFAULT 'PRIVATE'")

                // personal_reports: add sync metadata + createdAt/updatedAt
                db.execSQL("ALTER TABLE `personal_reports` ADD COLUMN `createdAt` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `personal_reports` ADD COLUMN `updatedAt` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `personal_reports` ADD COLUMN `remoteId` TEXT")
                db.execSQL("ALTER TABLE `personal_reports` ADD COLUMN `ownerUserId` TEXT")
                db.execSQL("ALTER TABLE `personal_reports` ADD COLUMN `syncStatus` TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                db.execSQL("ALTER TABLE `personal_reports` ADD COLUMN `deletedAt` INTEGER")
                // Backfill timestamps from existing `timestamp` column so rows don't sit at epoch=0
                db.execSQL("UPDATE `personal_reports` SET createdAt = timestamp, updatedAt = timestamp WHERE createdAt = 0")

                // tire_spots: add sync metadata + visibility
                db.execSQL("ALTER TABLE `tire_spots` ADD COLUMN `remoteId` TEXT")
                db.execSQL("ALTER TABLE `tire_spots` ADD COLUMN `ownerUserId` TEXT")
                db.execSQL("ALTER TABLE `tire_spots` ADD COLUMN `syncStatus` TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                db.execSQL("ALTER TABLE `tire_spots` ADD COLUMN `deletedAt` INTEGER")
                db.execSQL("ALTER TABLE `tire_spots` ADD COLUMN `visibility` TEXT NOT NULL DEFAULT 'PRIVATE'")

                // tire_reports: add sync metadata + createdAt/updatedAt
                db.execSQL("ALTER TABLE `tire_reports` ADD COLUMN `createdAt` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `tire_reports` ADD COLUMN `updatedAt` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `tire_reports` ADD COLUMN `remoteId` TEXT")
                db.execSQL("ALTER TABLE `tire_reports` ADD COLUMN `ownerUserId` TEXT")
                db.execSQL("ALTER TABLE `tire_reports` ADD COLUMN `syncStatus` TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                db.execSQL("ALTER TABLE `tire_reports` ADD COLUMN `deletedAt` INTEGER")
                // Backfill timestamps from existing `timestamp` column
                db.execSQL("UPDATE `tire_reports` SET createdAt = timestamp, updatedAt = timestamp WHERE createdAt = 0")

                // spot_photos: enrich with upload-state, ownership, soft-delete columns
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `remoteUrl` TEXT")
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `uploadStatus` TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `mimeType` TEXT NOT NULL DEFAULT 'image/jpeg'")
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `fileSizeBytes` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `ownerUserId` TEXT")
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `createdAt` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `updatedAt` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `deletedAt` INTEGER")
                // Backfill photo timestamps from `takenAt`
                db.execSQL("UPDATE `spot_photos` SET createdAt = takenAt, updatedAt = takenAt WHERE createdAt = 0")
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Guarded because early schema exports and migration history drifted
                // around report visibility. This keeps both fresh-v3 and migrated-v3
                // databases safe.
                addColumnIfMissing(
                    db = db,
                    tableName = "personal_reports",
                    columnName = "visibility",
                    definition = "TEXT NOT NULL DEFAULT 'PRIVATE'"
                )
                addColumnIfMissing(
                    db = db,
                    tableName = "tire_reports",
                    columnName = "visibility",
                    definition = "TEXT NOT NULL DEFAULT 'PRIVATE'"
                )
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `sync_queue` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `entityType` TEXT NOT NULL,
                        `entityLocalId` INTEGER NOT NULL,
                        `entityRemoteId` TEXT,
                        `operation` TEXT NOT NULL,
                        `payload` TEXT NOT NULL,
                        `retryCount` INTEGER NOT NULL DEFAULT 0,
                        `lastAttemptAt` INTEGER,
                        `lastError` TEXT,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        `idempotencyKey` TEXT NOT NULL,
                        `status` TEXT NOT NULL DEFAULT 'PENDING',
                        `dependsOnQueueItemId` INTEGER
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_sync_queue_status_createdAt` ON `sync_queue` (`status`, `createdAt`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_sync_queue_entityType_entityLocalId` ON `sync_queue` (`entityType`, `entityLocalId`)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_sync_queue_idempotencyKey` ON `sync_queue` (`idempotencyKey`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_sync_queue_dependsOnQueueItemId` ON `sync_queue` (`dependsOnQueueItemId`)")
            }
        }


        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `field_locations` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `remoteId` TEXT,
                        `ownerUserId` TEXT,
                        `type` TEXT NOT NULL DEFAULT 'CUSTOM',
                        `name` TEXT NOT NULL,
                        `description` TEXT NOT NULL DEFAULT '',
                        `address` TEXT NOT NULL DEFAULT '',
                        `latitude` REAL NOT NULL DEFAULT 0.0,
                        `longitude` REAL NOT NULL DEFAULT 0.0,
                        `tags` TEXT NOT NULL DEFAULT '',
                        `grade` TEXT NOT NULL DEFAULT 'UNKNOWN',
                        `accessStatus` TEXT NOT NULL DEFAULT 'UNKNOWN',
                        `safetyNotes` TEXT NOT NULL DEFAULT '',
                        `hazardNotes` TEXT NOT NULL DEFAULT '',
                        `hazardLevel` TEXT NOT NULL DEFAULT 'NONE',
                        `cleanupPriority` TEXT NOT NULL DEFAULT 'NONE',
                        `cleanupStatus` TEXT NOT NULL DEFAULT 'OPEN',
                        `resourceType` TEXT NOT NULL DEFAULT '',
                        `resourceAvailability` TEXT NOT NULL DEFAULT 'UNKNOWN',
                        `isFavorite` INTEGER NOT NULL DEFAULT 0,
                        `isArchived` INTEGER NOT NULL DEFAULT 0,
                        `visibility` TEXT NOT NULL DEFAULT 'PRIVATE',
                        `syncStatus` TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
                        `conflictStatus` TEXT NOT NULL DEFAULT 'NONE',
                        `source` TEXT NOT NULL DEFAULT 'MANUAL',
                        `lastVisitedAt` INTEGER,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        `deletedAt` INTEGER
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_locations_type` ON `field_locations` (`type`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_locations_isFavorite` ON `field_locations` (`isFavorite`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_locations_updatedAt` ON `field_locations` (`updatedAt`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_locations_syncStatus` ON `field_locations` (`syncStatus`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_locations_visibility` ON `field_locations` (`visibility`)")

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `collections` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `remoteId` TEXT,
                        `ownerUserId` TEXT,
                        `name` TEXT NOT NULL,
                        `notes` TEXT NOT NULL DEFAULT '',
                        `visibility` TEXT NOT NULL DEFAULT 'PRIVATE',
                        `syncStatus` TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        `deletedAt` INTEGER
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_collections_updatedAt` ON `collections` (`updatedAt`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_collections_visibility` ON `collections` (`visibility`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_collections_syncStatus` ON `collections` (`syncStatus`)")

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `collection_items` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `collectionId` INTEGER NOT NULL,
                        `locationType` TEXT NOT NULL,
                        `locationId` INTEGER NOT NULL,
                        `label` TEXT NOT NULL DEFAULT '',
                        `sortOrder` INTEGER NOT NULL DEFAULT 0,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        `deletedAt` INTEGER,
                        FOREIGN KEY(`collectionId`) REFERENCES `collections`(`id`) ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_collection_items_collectionId` ON `collection_items` (`collectionId`)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_collection_items_collectionId_locationType_locationId` ON `collection_items` (`collectionId`, `locationType`, `locationId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_collection_items_sortOrder` ON `collection_items` (`sortOrder`)")

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `field_sessions` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `remoteId` TEXT,
                        `ownerUserId` TEXT,
                        `title` TEXT NOT NULL,
                        `notes` TEXT NOT NULL DEFAULT '',
                        `startedAt` INTEGER NOT NULL,
                        `endedAt` INTEGER,
                        `syncStatus` TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        `deletedAt` INTEGER
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_sessions_startedAt` ON `field_sessions` (`startedAt`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_sessions_endedAt` ON `field_sessions` (`endedAt`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_sessions_syncStatus` ON `field_sessions` (`syncStatus`)")

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `field_session_visits` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `sessionId` INTEGER NOT NULL,
                        `locationType` TEXT NOT NULL,
                        `locationId` INTEGER NOT NULL,
                        `label` TEXT NOT NULL DEFAULT '',
                        `notes` TEXT NOT NULL DEFAULT '',
                        `visitedAt` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        FOREIGN KEY(`sessionId`) REFERENCES `field_sessions`(`id`) ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_session_visits_sessionId` ON `field_session_visits` (`sessionId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_session_visits_visitedAt` ON `field_session_visits` (`visitedAt`)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_field_session_visits_sessionId_locationType_locationId` ON `field_session_visits` (`sessionId`, `locationType`, `locationId`)")

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `gear_checklists` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `name` TEXT NOT NULL,
                        `isTemplate` INTEGER NOT NULL DEFAULT 1,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        `deletedAt` INTEGER
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_gear_checklists_updatedAt` ON `gear_checklists` (`updatedAt`)")

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `gear_checklist_items` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `checklistId` INTEGER NOT NULL,
                        `label` TEXT NOT NULL,
                        `category` TEXT NOT NULL DEFAULT 'Essential',
                        `emoji` TEXT NOT NULL DEFAULT '•',
                        `isChecked` INTEGER NOT NULL DEFAULT 0,
                        `sortOrder` INTEGER NOT NULL DEFAULT 0,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        FOREIGN KEY(`checklistId`) REFERENCES `gear_checklists`(`id`) ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_gear_checklist_items_checklistId` ON `gear_checklist_items` (`checklistId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_gear_checklist_items_sortOrder` ON `gear_checklist_items` (`sortOrder`)")
            }
        }

        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `spot_photos_new` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `spotId` INTEGER,
                        `ownerType` TEXT NOT NULL DEFAULT 'DUMPSTER_SPOT',
                        `ownerId` INTEGER NOT NULL DEFAULT 0,
                        `uri` TEXT NOT NULL,
                        `remoteUrl` TEXT,
                        `uploadStatus` TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
                        `caption` TEXT NOT NULL DEFAULT '',
                        `mimeType` TEXT NOT NULL DEFAULT 'image/jpeg',
                        `fileSizeBytes` INTEGER NOT NULL DEFAULT 0,
                        `ownerUserId` TEXT,
                        `takenAt` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        `deletedAt` INTEGER
                    )
                """.trimIndent())
                db.execSQL("""
                    INSERT INTO `spot_photos_new` (
                        id, spotId, ownerType, ownerId, uri, remoteUrl, uploadStatus, caption,
                        mimeType, fileSizeBytes, ownerUserId, takenAt, createdAt, updatedAt, deletedAt
                    )
                    SELECT
                        id, spotId, 'DUMPSTER_SPOT', spotId, uri, remoteUrl, uploadStatus, caption,
                        mimeType, fileSizeBytes, ownerUserId, takenAt, createdAt, updatedAt, deletedAt
                    FROM `spot_photos`
                """.trimIndent())
                db.execSQL("DROP TABLE `spot_photos`")
                db.execSQL("ALTER TABLE `spot_photos_new` RENAME TO `spot_photos`")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_spot_photos_spotId` ON `spot_photos` (`spotId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_spot_photos_ownerType_ownerId` ON `spot_photos` (`ownerType`, `ownerId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_spot_photos_uploadStatus` ON `spot_photos` (`uploadStatus`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_spot_photos_deletedAt` ON `spot_photos` (`deletedAt`)")
            }
        }


        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                addColumnIfMissing(db, "route_plans", "remoteId", "TEXT")
                addColumnIfMissing(db, "route_plans", "ownerUserId", "TEXT")
                addColumnIfMissing(db, "route_plans", "visibility", "TEXT NOT NULL DEFAULT 'PRIVATE'")
                addColumnIfMissing(db, "route_plans", "syncStatus", "TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                addColumnIfMissing(db, "route_plans", "updatedAt", "INTEGER NOT NULL DEFAULT 0")
                addColumnIfMissing(db, "route_plans", "deletedAt", "INTEGER")

                db.execSQL("UPDATE route_plans SET updatedAt = createdAt WHERE updatedAt = 0")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_route_plans_updatedAt` ON `route_plans` (`updatedAt`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_route_plans_syncStatus` ON `route_plans` (`syncStatus`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_route_plans_visibility` ON `route_plans` (`visibility`)")

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `route_stops` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `routeId` INTEGER NOT NULL,
                        `locationType` TEXT NOT NULL,
                        `locationId` INTEGER NOT NULL,
                        `label` TEXT NOT NULL DEFAULT '',
                        `latitude` REAL NOT NULL DEFAULT 0.0,
                        `longitude` REAL NOT NULL DEFAULT 0.0,
                        `sortOrder` INTEGER NOT NULL DEFAULT 0,
                        `notes` TEXT NOT NULL DEFAULT '',
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        `deletedAt` INTEGER,
                        FOREIGN KEY(`routeId`) REFERENCES `route_plans`(`id`) ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_route_stops_routeId_sortOrder` ON `route_stops` (`routeId`, `sortOrder`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_route_stops_locationType_locationId` ON `route_stops` (`locationType`, `locationId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_route_stops_deletedAt` ON `route_stops` (`deletedAt`)")

                db.query("SELECT id, spotIds FROM route_plans WHERE spotIds IS NOT NULL AND spotIds != '' AND spotIds != '[]'").use { cursor ->
                    val idIndex = cursor.getColumnIndex("id")
                    val spotIdsIndex = cursor.getColumnIndex("spotIds")
                    val now = System.currentTimeMillis()
                    while (cursor.moveToNext()) {
                        val routeId = cursor.getLong(idIndex)
                        val rawIds = cursor.getString(spotIdsIndex)
                            .removePrefix("[")
                            .removeSuffix("]")
                            .split(",")
                            .mapNotNull { it.trim().toLongOrNull() }
                        rawIds.forEachIndexed { index, spotId ->
                            db.execSQL(
                                """
                                INSERT INTO route_stops (
                                    routeId, locationType, locationId, label, latitude, longitude,
                                    sortOrder, notes, createdAt, updatedAt, deletedAt
                                ) VALUES (?, 'DUMPSTER_SPOT', ?, '', 0.0, 0.0, ?, '', ?, ?, NULL)
                                """.trimIndent(),
                                arrayOf(routeId, spotId, index, now, now)
                            )
                        }
                    }
                }
            }
        }


        val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                addColumnIfMissing(db, "reminders", "remoteId", "TEXT")
                addColumnIfMissing(db, "reminders", "ownerUserId", "TEXT")
                addColumnIfMissing(db, "reminders", "locationType", "TEXT NOT NULL DEFAULT 'DUMPSTER_SPOT'")
                addColumnIfMissing(db, "reminders", "locationRemoteId", "TEXT")
                addColumnIfMissing(db, "reminders", "syncStatus", "TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                addColumnIfMissing(db, "reminders", "updatedAt", "INTEGER NOT NULL DEFAULT 0")
                addColumnIfMissing(db, "reminders", "deletedAt", "INTEGER")
                db.execSQL("UPDATE reminders SET updatedAt = createdAt WHERE updatedAt = 0")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_reminders_remoteId` ON `reminders` (`remoteId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_reminders_syncStatus` ON `reminders` (`syncStatus`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_reminders_deletedAt` ON `reminders` (`deletedAt`)")

                addColumnIfMissing(db, "gear_checklists", "remoteId", "TEXT")
                addColumnIfMissing(db, "gear_checklists", "ownerUserId", "TEXT")
                addColumnIfMissing(db, "gear_checklists", "syncStatus", "TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_gear_checklists_remoteId` ON `gear_checklists` (`remoteId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_gear_checklists_syncStatus` ON `gear_checklists` (`syncStatus`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_gear_checklists_deletedAt` ON `gear_checklists` (`deletedAt`)")

                addColumnIfMissing(db, "gear_checklist_items", "remoteId", "TEXT")
                addColumnIfMissing(db, "gear_checklist_items", "ownerUserId", "TEXT")
                addColumnIfMissing(db, "gear_checklist_items", "syncStatus", "TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                addColumnIfMissing(db, "gear_checklist_items", "deletedAt", "INTEGER")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_gear_checklist_items_remoteId` ON `gear_checklist_items` (`remoteId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_gear_checklist_items_syncStatus` ON `gear_checklist_items` (`syncStatus`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_gear_checklist_items_deletedAt` ON `gear_checklist_items` (`deletedAt`)")
            }
        }



        val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                addColumnIfMissing(db, "sync_queue", "remotePayload", "TEXT")
                addColumnIfMissing(db, "sync_queue", "resolutionAction", "TEXT")
                addColumnIfMissing(db, "sync_queue", "resolutionNotes", "TEXT")
                addColumnIfMissing(db, "sync_queue", "resolvedAt", "INTEGER")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_sync_queue_resolutionAction` ON `sync_queue` (`resolutionAction`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_sync_queue_resolvedAt` ON `sync_queue` (`resolvedAt`)")
            }
        }

        val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                addColumnIfMissing(db, "reminders", "completedAt", "INTEGER")
                addColumnIfMissing(db, "reminders", "snoozedUntil", "INTEGER")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_reminders_completedAt` ON `reminders` (`completedAt`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_reminders_snoozedUntil` ON `reminders` (`snoozedUntil`)")

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `field_location_reports` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `fieldLocationId` INTEGER NOT NULL,
                        `locationName` TEXT NOT NULL DEFAULT '',
                        `reportType` TEXT NOT NULL DEFAULT 'VISIT',
                        `status` TEXT NOT NULL DEFAULT 'UNKNOWN',
                        `accessStatus` TEXT NOT NULL DEFAULT 'UNKNOWN',
                        `hazardLevel` TEXT NOT NULL DEFAULT 'NONE',
                        `cleanupStatus` TEXT NOT NULL DEFAULT 'OPEN',
                        `cleanupProgress` INTEGER NOT NULL DEFAULT 0,
                        `findings` TEXT NOT NULL DEFAULT '',
                        `notes` TEXT NOT NULL DEFAULT '',
                        `photoUris` TEXT NOT NULL DEFAULT '',
                        `voiceTranscript` TEXT,
                        `isFromVoice` INTEGER NOT NULL DEFAULT 0,
                        `latitude` REAL,
                        `longitude` REAL,
                        `timestamp` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        `remoteId` TEXT,
                        `ownerUserId` TEXT,
                        `syncStatus` TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
                        `visibility` TEXT NOT NULL DEFAULT 'PRIVATE',
                        `deletedAt` INTEGER,
                        FOREIGN KEY(`fieldLocationId`) REFERENCES `field_locations`(`id`) ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_location_reports_fieldLocationId` ON `field_location_reports` (`fieldLocationId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_location_reports_remoteId` ON `field_location_reports` (`remoteId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_location_reports_syncStatus` ON `field_location_reports` (`syncStatus`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_location_reports_visibility` ON `field_location_reports` (`visibility`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_location_reports_deletedAt` ON `field_location_reports` (`deletedAt`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_location_reports_timestamp` ON `field_location_reports` (`timestamp`)")
            }
        }


        val MIGRATION_11_12 = object : Migration(11, 12) {
            override fun migrate(db: SupportSQLiteDatabase) {
                addColumnIfMissing(db, "route_stops", "remoteId", "TEXT")
                addColumnIfMissing(db, "route_stops", "ownerUserId", "TEXT")
                addColumnIfMissing(db, "route_stops", "syncStatus", "TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_route_stops_remoteId` ON `route_stops` (`remoteId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_route_stops_syncStatus` ON `route_stops` (`syncStatus`)")

                addColumnIfMissing(db, "collection_items", "remoteId", "TEXT")
                addColumnIfMissing(db, "collection_items", "ownerUserId", "TEXT")
                addColumnIfMissing(db, "collection_items", "syncStatus", "TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_collection_items_remoteId` ON `collection_items` (`remoteId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_collection_items_syncStatus` ON `collection_items` (`syncStatus`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_collection_items_deletedAt` ON `collection_items` (`deletedAt`)")

                addColumnIfMissing(db, "field_session_visits", "remoteId", "TEXT")
                addColumnIfMissing(db, "field_session_visits", "ownerUserId", "TEXT")
                addColumnIfMissing(db, "field_session_visits", "syncStatus", "TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                addColumnIfMissing(db, "field_session_visits", "deletedAt", "INTEGER")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_session_visits_remoteId` ON `field_session_visits` (`remoteId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_session_visits_syncStatus` ON `field_session_visits` (`syncStatus`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_field_session_visits_deletedAt` ON `field_session_visits` (`deletedAt`)")
            }
        }


        val MIGRATION_12_13 = object : Migration(12, 13) {
            override fun migrate(db: SupportSQLiteDatabase) {
                addColumnIfMissing(db, "tire_reports", "voiceTranscript", "TEXT")
                addColumnIfMissing(db, "tire_reports", "isFromVoice", "INTEGER NOT NULL DEFAULT 0")
                addColumnIfMissing(db, "tire_reports", "latitude", "REAL")
                addColumnIfMissing(db, "tire_reports", "longitude", "REAL")
            }
        }

        private fun addColumnIfMissing(
            db: SupportSQLiteDatabase,
            tableName: String,
            columnName: String,
            definition: String
        ) {
            db.query("PRAGMA table_info(`$tableName`)").use { cursor ->
                val nameIndex = cursor.getColumnIndex("name")
                while (cursor.moveToNext()) {
                    if (cursor.getString(nameIndex) == columnName) return
                }
            }
            db.execSQL("ALTER TABLE `$tableName` ADD COLUMN `$columnName` $definition")
        }
    }
}
