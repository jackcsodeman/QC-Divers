package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.FieldSessionEntity
import com.dumpsterscout.data.local.entity.FieldSessionVisitEntity
import com.dumpsterscout.data.remote.dto.FieldSessionVisitRow

/** Remote contract for field sessions and visit rows. */
interface RemoteFieldSessionDataSource {
    suspend fun upsertFieldSession(session: FieldSessionEntity, visits: List<FieldSessionVisitEntity>): String?
    suspend fun deleteFieldSessions(remoteIds: List<String>): Set<String>
    suspend fun fetchMyFieldSessions(ownerUserId: String): List<FieldSessionEntity>
    suspend fun fetchMyFieldSessionVisits(ownerUserId: String): List<FieldSessionVisitRow>
}
