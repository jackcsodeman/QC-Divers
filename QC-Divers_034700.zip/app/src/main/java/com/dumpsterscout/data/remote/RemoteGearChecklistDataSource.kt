package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.GearChecklistEntity
import com.dumpsterscout.data.local.entity.GearChecklistItemEntity
import com.dumpsterscout.data.remote.dto.GearChecklistItemRow

interface RemoteGearChecklistDataSource {
    suspend fun upsertChecklist(checklist: GearChecklistEntity, items: List<GearChecklistItemEntity>): String?
    suspend fun deleteChecklists(remoteIds: List<String>): Set<String>
    suspend fun fetchMyChecklists(ownerUserId: String): List<GearChecklistEntity>
    suspend fun fetchMyChecklistItems(ownerUserId: String): List<GearChecklistItemRow>
}
