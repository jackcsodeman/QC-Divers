package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.FieldLocationReportEntity
import com.dumpsterscout.data.remote.dto.FieldLocationReportRow

class NoOpRemoteFieldLocationReportDataSource : RemoteFieldLocationReportDataSource {
    override suspend fun upsertReports(
        reports: List<FieldLocationReportEntity>,
        fieldLocationRemoteIds: Map<Long, String?>
    ): Map<Long, String> = emptyMap()

    override suspend fun deleteReports(remoteIds: List<String>): Set<String> = emptySet()

    override suspend fun fetchMyReports(ownerUserId: String): List<FieldLocationReportRow> = emptyList()
}
