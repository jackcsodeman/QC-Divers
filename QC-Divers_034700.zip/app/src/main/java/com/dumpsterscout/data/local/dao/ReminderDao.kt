package com.dumpsterscout.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.dumpsterscout.data.local.entity.ReminderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ReminderDao {

    @Query("SELECT * FROM reminders WHERE isActive = 1 AND deletedAt IS NULL AND completedAt IS NULL ORDER BY dayOfWeek, timeHour, timeMinute")
    fun getActiveReminders(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE spotId = :spotId AND deletedAt IS NULL ORDER BY dayOfWeek, timeHour, timeMinute")
    fun getRemindersForSpot(spotId: Long): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE deletedAt IS NULL ORDER BY createdAt DESC")
    fun getAllReminders(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders ORDER BY createdAt DESC")
    suspend fun getAllRemindersSnapshot(): List<ReminderEntity>

    @Query("SELECT * FROM reminders WHERE id = :id")
    suspend fun getReminderById(id: Long): ReminderEntity?

    @Query("SELECT * FROM reminders WHERE remoteId = :remoteId LIMIT 1")
    suspend fun getReminderByRemoteId(remoteId: String): ReminderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(reminder: ReminderEntity): Long

    @Update
    suspend fun update(reminder: ReminderEntity)

    @Delete
    suspend fun delete(reminder: ReminderEntity)

    @Query("UPDATE reminders SET isActive = :active, syncStatus = :syncStatus, updatedAt = :now WHERE id = :id")
    suspend fun setActive(id: Long, active: Boolean, syncStatus: String = "PENDING_SYNC", now: Long = System.currentTimeMillis())

    @Query("UPDATE reminders SET label = :label, dayOfWeek = :dayOfWeek, timeHour = :hour, timeMinute = :minute, completedAt = NULL, snoozedUntil = NULL, syncStatus = :syncStatus, updatedAt = :now WHERE id = :id")
    suspend fun updateSchedule(id: Long, label: String, dayOfWeek: Int, hour: Int, minute: Int, syncStatus: String = "PENDING_SYNC", now: Long = System.currentTimeMillis())

    @Query("UPDATE reminders SET completedAt = :completedAt, isActive = 0, syncStatus = :syncStatus, updatedAt = :completedAt WHERE id = :id")
    suspend fun markCompleted(id: Long, completedAt: Long = System.currentTimeMillis(), syncStatus: String = "PENDING_SYNC")

    @Query("UPDATE reminders SET snoozedUntil = :snoozedUntil, isActive = 1, syncStatus = :syncStatus, updatedAt = :now WHERE id = :id")
    suspend fun snoozeUntil(id: Long, snoozedUntil: Long, syncStatus: String = "PENDING_SYNC", now: Long = System.currentTimeMillis())

    @Query("UPDATE reminders SET deletedAt = :now, syncStatus = :syncStatus, updatedAt = :now WHERE id = :id")
    suspend fun softDelete(id: Long, syncStatus: String = "PENDING_SYNC", now: Long = System.currentTimeMillis())

    @Query("UPDATE reminders SET syncStatus = 'PENDING_SYNC', updatedAt = :now WHERE id = :id")
    suspend fun markPendingSync(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE reminders SET syncStatus = 'SYNCED', remoteId = :remoteId, updatedAt = :now WHERE id = :id")
    suspend fun markSynced(id: Long, remoteId: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE reminders SET syncStatus = 'SYNC_FAILED', updatedAt = :now WHERE id = :id")
    suspend fun markSyncFailed(id: Long, now: Long = System.currentTimeMillis())

    @Query("DELETE FROM reminders WHERE spotId = :spotId")
    suspend fun deleteRemindersForSpot(spotId: Long)

    @Query("DELETE FROM reminders")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM reminders WHERE deletedAt IS NULL")
    fun observeReminderCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM reminders WHERE deletedAt IS NULL AND isActive = 1")
    fun observeActiveReminderCount(): Flow<Int>

}
