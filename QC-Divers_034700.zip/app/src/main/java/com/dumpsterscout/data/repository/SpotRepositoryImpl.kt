package com.dumpsterscout.data.repository

import com.dumpsterscout.data.local.dao.DumpsterSpotDao
import com.dumpsterscout.data.local.entity.DumpsterSpotEntity
import com.dumpsterscout.data.mapper.toDomain
import com.dumpsterscout.data.mapper.toEntity
import com.dumpsterscout.data.sync.SyncEntityType
import com.dumpsterscout.data.sync.SyncQueueOperation
import com.dumpsterscout.data.sync.SyncQueueWriter
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.di.SupabaseCredentials
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.repository.SpotRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

@Singleton
class SpotRepositoryImpl @Inject constructor(
    private val dao: DumpsterSpotDao,
    private val credentials: SupabaseCredentials,
    private val prefs: AppPreferences,
    private val syncQueue: SyncQueueWriter
) : SpotRepository {

    override fun getAllSpots(): Flow<List<DumpsterSpot>> =
        dao.getAllSpots().map { entities -> entities.map { it.toDomain() } }

    override fun getFavoriteSpots(): Flow<List<DumpsterSpot>> =
        dao.getFavoriteSpots().map { entities -> entities.map { it.toDomain() } }

    override fun getActiveSpots(): Flow<List<DumpsterSpot>> =
        dao.getAllActiveSpots().map { entities -> entities.map { it.toDomain() } }

    override fun searchSpots(query: String): Flow<List<DumpsterSpot>> =
        dao.searchSpots(query).map { entities -> entities.map { it.toDomain() } }

    override suspend fun getSpotById(id: Long): DumpsterSpot? =
        dao.getSpotById(id)?.toDomain()

    override fun observeSpot(id: Long): Flow<DumpsterSpot?> =
        dao.observeSpotById(id).map { it?.toDomain() }

    override suspend fun getNearestSpots(
        latitude: Double,
        longitude: Double,
        radiusMeters: Double
    ): List<DumpsterSpot> {
        val candidates = dao.getNearestSpots(latitude, longitude)
        return candidates
            .map { it.toDomain() }
            .filter { haversineMeters(latitude, longitude, it.latitude, it.longitude) <= radiusMeters }
            .sortedBy { haversineMeters(latitude, longitude, it.latitude, it.longitude) }
    }

    override suspend fun upsertSpot(spot: DumpsterSpot): Long {
        val ownerId = spot.ownerUserId ?: prefs.localUserId.first()
        val isCreate = spot.id == 0L
        val entity = spot.copy(
            ownerUserId = ownerId,
            syncStatus  = if (credentials.isConfigured) SyncStatus.PENDING_SYNC else spot.syncStatus
        ).toEntity()
        val id = dao.upsert(entity)
        if (credentials.isConfigured) {
            val persisted = entity.copy(id = if (id > 0L) id else spot.id)
            syncQueue.enqueue(
                entityType = SyncEntityType.DUMPSTER_SPOT,
                entityLocalId = persisted.id,
                entityRemoteId = persisted.remoteId,
                operation = if (isCreate) SyncQueueOperation.CREATE else SyncQueueOperation.UPDATE,
                payload = Json.encodeToString(persisted)
            )
        }
        return id
    }

    override suspend fun deleteSpot(spot: DumpsterSpot) {
        if (credentials.isConfigured && spot.id > 0L) {
            syncQueue.enqueue(
                entityType = SyncEntityType.DUMPSTER_SPOT,
                entityLocalId = spot.id,
                entityRemoteId = spot.remoteId,
                operation = SyncQueueOperation.DELETE,
                payload = Json.encodeToString(mapOf("id" to spot.id, "remoteId" to spot.remoteId, "deletedAt" to System.currentTimeMillis()))
            )
        }
        dao.delete(spot.toEntity())
    }

    override suspend fun updateLastStatus(spotId: Long, status: SpotStatus, timestamp: Long) {
        dao.updateLastStatus(spotId, status.name, timestamp)
        queueSpotUpdateIfConfigured(spotId)
    }

    override suspend fun toggleFavorite(spotId: Long) {
        dao.toggleFavorite(spotId)
        queueSpotUpdateIfConfigured(spotId)
    }

    override suspend fun retireSpot(spotId: Long) {
        dao.retire(spotId)
        queueSpotUpdateIfConfigured(spotId)
    }

    override suspend fun deleteAllSpots() =
        dao.deleteAll()

    override suspend fun exportToJson(): String {
        val entities = dao.getAllSpotsSnapshot()
        return Json.encodeToString(entities)
    }

    override suspend fun importFromJson(json: String): Int {
        val entities: List<DumpsterSpotEntity> = Json.decodeFromString(json)
        var imported = 0
        for (entity in entities) {
            dao.upsert(entity)
            imported++
        }
        return imported
    }

    override suspend fun getPendingSyncSpots(): List<DumpsterSpot> =
        dao.getPendingSyncSpots().map { it.toDomain() }

    override suspend fun markSpotSynced(id: Long, remoteId: String) =
        dao.markSynced(id, remoteId)

    override suspend fun markSpotSyncFailed(id: Long) =
        dao.markSyncFailed(id)

    override suspend fun publishSpot(spotId: Long) {
        dao.publishSpot(spotId)
        queueSpotUpdateIfConfigured(spotId)
    }

    override suspend fun getSpotByRemoteId(remoteId: String): DumpsterSpot? =
        dao.getByRemoteId(remoteId)?.toDomain()

    override suspend fun upsertSpotFromRemote(spot: DumpsterSpot): Long {
        // Incoming remote spots are already SYNCED — do not stamp PENDING_SYNC.
        return dao.upsert(spot.toEntity())
    }

    private suspend fun queueSpotUpdateIfConfigured(spotId: Long) {
        if (!credentials.isConfigured) return
        dao.markPendingSync(spotId)
        val entity = dao.getSpotById(spotId) ?: return
        syncQueue.enqueue(
            entityType = SyncEntityType.DUMPSTER_SPOT,
            entityLocalId = entity.id,
            entityRemoteId = entity.remoteId,
            operation = SyncQueueOperation.UPDATE,
            payload = Json.encodeToString(entity)
        )
    }

    private fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371000.0
        val phi1 = Math.toRadians(lat1)
        val phi2 = Math.toRadians(lat2)
        val dPhi = Math.toRadians(lat2 - lat1)
        val dLambda = Math.toRadians(lon2 - lon1)
        val a = sin(dPhi / 2) * sin(dPhi / 2) +
                cos(phi1) * cos(phi2) * sin(dLambda / 2) * sin(dLambda / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }
}
