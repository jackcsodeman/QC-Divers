package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * Visit/history report for cleanup, salvage/resource, and custom field locations.
 * Dumpster and tire reports keep their richer specialized tables.
 */
@Entity(
    tableName = "field_location_reports",
    foreignKeys = [
        ForeignKey(
            entity = FieldLocationEntity::class,
            parentColumns = ["id"],
            childColumns = ["fieldLocationId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("fieldLocationId"),
        Index("remoteId"),
        Index("syncStatus"),
        Index("visibility"),
        Index("deletedAt"),
        Index("timestamp")
    ]
)
@Serializable
data class FieldLocationReportEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fieldLocationId: Long,
    val locationName: String = "",
    val reportType: String = "VISIT",
    val status: String = "UNKNOWN",
    val accessStatus: String = "UNKNOWN",
    val hazardLevel: String = "NONE",
    val cleanupStatus: String = "OPEN",
    val cleanupProgress: Int = 0,
    val findings: String = "",
    val notes: String = "",
    val photoUris: String = "",
    val voiceTranscript: String? = null,
    val isFromVoice: Boolean = false,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val remoteId: String? = null,
    val ownerUserId: String? = null,
    val syncStatus: String = "LOCAL_ONLY",
    val visibility: String = "PRIVATE",
    val deletedAt: Long? = null
)
