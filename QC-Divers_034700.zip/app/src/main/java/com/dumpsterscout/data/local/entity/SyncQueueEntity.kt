package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Durable local outbox for offline-first Supabase synchronization.
 *
 * Per-record syncStatus is useful for UI badges, but it is not enough to make
 * sync safe after process death, network loss, sign-out, or parent/child
 * dependency failures. This table records the actual operation that must be
 * pushed later and, when available, a remote snapshot for conflict review.
 */
@Entity(
    tableName = "sync_queue",
    indices = [
        Index(value = ["status", "createdAt"]),
        Index(value = ["entityType", "entityLocalId"]),
        Index(value = ["idempotencyKey"], unique = true),
        Index(value = ["dependsOnQueueItemId"]),
        Index(value = ["resolutionAction"]),
        Index(value = ["resolvedAt"])
    ]
)
data class SyncQueueEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val entityType: String,
    val entityLocalId: Long,
    val entityRemoteId: String? = null,
    val operation: String,
    val payload: String,
    val remotePayload: String? = null,
    val retryCount: Int = 0,
    val lastAttemptAt: Long? = null,
    val lastError: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val idempotencyKey: String,
    val status: String = "PENDING",
    val dependsOnQueueItemId: Long? = null,
    val resolutionAction: String? = null,
    val resolutionNotes: String? = null,
    val resolvedAt: Long? = null
)
