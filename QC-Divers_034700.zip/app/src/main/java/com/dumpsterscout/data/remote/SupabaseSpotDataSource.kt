package com.dumpsterscout.data.remote

import com.dumpsterscout.util.DsLogger
import com.dumpsterscout.data.remote.dto.SpotRow
import com.dumpsterscout.data.remote.dto.toDomain
import com.dumpsterscout.data.remote.dto.toRow
import com.dumpsterscout.domain.model.DumpsterSpot
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.from

/**
 * Real [RemoteSpotDataSource] implementation backed by Supabase Postgrest.
 *
 * Bound via [com.dumpsterscout.di.RemoteModule] when a configured
 * [io.github.jan.supabase.SupabaseClient] is available.
 *
 * Table: `dumpster_spots` — see [SpotRow] for schema details.
 */
class SupabaseSpotDataSource(
    private val client: SupabaseClient
) : RemoteSpotDataSource {

    override suspend fun upsertSpots(spots: List<DumpsterSpot>): Map<Long, String> {
        val result = mutableMapOf<Long, String>()
        val currentUserId = client.auth.currentUserOrNull()?.id
        for (spot in spots) {
            try {
                // Ensure ownerId is the real Supabase UID to satisfy RLS policies
                val row = spot.toRow(ownerId = currentUserId)
                val returned = if (spot.remoteId == null) {
                    client.from(TABLE).insert(row) { select() }.decodeSingle<SpotRow>()
                } else {
                    client.from(TABLE).upsert(row) { select() }.decodeSingle<SpotRow>()
                }
                result[spot.id] = returned.remoteId
            } catch (e: Exception) {
                DsLogger.e(TAG, "Failed to upsert spot.", e)
            }
        }
        return result
    }

    override suspend fun deleteSpots(remoteIds: List<String>): Set<String> {
        val deleted = mutableSetOf<String>()
        val nowMillis = System.currentTimeMillis()
        for (id in remoteIds) {
            try {
                client.from(TABLE).update({ set("deleted_at", nowMillis) }) {
                    filter { eq("id", id) }
                }
                deleted.add(id)
            } catch (e: Exception) {
                DsLogger.e(TAG, "Failed to soft-delete spot.", e)
            }
        }
        return deleted
    }

    override suspend fun fetchMySpots(ownerUserId: String): List<DumpsterSpot> {
        return try {
            client.from(TABLE)
                .select { filter { eq("owner_id", ownerUserId) } }
                .decodeList<SpotRow>()
                .filter { it.deletedAt == null }
                .map { it.toDomain() }
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to fetch spots for owner.", e)
            emptyList()
        }
    }

    override suspend fun fetchAllCommunitySpots(): List<DumpsterSpot> {
        val currentUserId = client.auth.currentUserOrNull()?.id
        return try {
            client.from(TABLE)
                .select {
                    filter {
                        or {
                            eq("visibility", "COMMUNITY")
                            eq("visibility", "PUBLIC")
                            eq("visibility", "COMMUNITY_PUBLIC")
                        }
                    }
                }
                .decodeList<SpotRow>()
                .filter { it.deletedAt == null }
                .map { row ->
                    val domain = row.toDomain()
                    // Fuzz coordinates if not owned by current user to protect privacy
                    if (row.ownerId != currentUserId) {
                        domain.copy(
                            latitude = applyJitter(domain.latitude, row.remoteId),
                            longitude = applyJitter(domain.longitude, row.remoteId + "_lon")
                        )
                    } else {
                        domain
                    }
                }
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to fetch community spots.", e)
            emptyList()
        }
    }

    /**
     * Applies a stable +/- 0.0005 jitter to a coordinate value based on a seed.
     * This ensures public discovery doesn't leak the exact GPS coordinate of private property.
     */
    private fun applyJitter(value: Double, seed: String): Double {
        val random = java.util.Random(seed.hashCode().toLong())
        // nextDouble is 0.0 to 1.0. (val - 0.5) * 2 is -1.0 to 1.0.
        // * 0.0005 makes it +/- 0.0005.
        val offset = (random.nextDouble() - 0.5) * 2 * 0.0005
        return value + offset
    }

    private companion object {

        const val TAG = "SupabaseSpotDS"
        const val TABLE = "dumpster_spots"
    }
}
