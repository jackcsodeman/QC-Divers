package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(
    tableName = "collection_items",
    foreignKeys = [
        ForeignKey(
            entity = CollectionEntity::class,
            parentColumns = ["id"],
            childColumns = ["collectionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("collectionId"),
        Index(value = ["collectionId", "locationType", "locationId"], unique = true),
        Index("sortOrder"),
        Index("remoteId"),
        Index("syncStatus"),
        Index("deletedAt")
    ]
)
@Serializable
data class CollectionItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val remoteId: String? = null,
    val ownerUserId: String? = null,
    val collectionId: Long,
    val locationType: String,
    val locationId: Long,
    val label: String = "",
    val sortOrder: Int = 0,
    val syncStatus: String = "LOCAL_ONLY",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)
