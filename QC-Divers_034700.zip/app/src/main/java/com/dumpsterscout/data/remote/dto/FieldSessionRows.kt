package com.dumpsterscout.data.remote.dto

import com.dumpsterscout.data.local.entity.FieldSessionEntity
import com.dumpsterscout.data.local.entity.FieldSessionVisitEntity
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class FieldSessionRow(
    @SerialName("id") val remoteId: String = "",
    @SerialName("owner_id") val ownerId: String? = null,
    @SerialName("title") val title: String,
    @SerialName("notes") val notes: String,
    @SerialName("started_at") val startedAt: Long,
    @SerialName("ended_at") val endedAt: Long?,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: Long,
    @SerialName("deleted_at") val deletedAt: Long?
)

@Serializable
data class FieldSessionVisitRow(
    @SerialName("id") val remoteId: String = "",
    @SerialName("owner_id") val ownerId: String? = null,
    @SerialName("session_id") val sessionRemoteId: String,
    @SerialName("location_type") val locationType: String,
    @SerialName("location_remote_id") val locationRemoteId: String? = null,
    @SerialName("label") val label: String,
    @SerialName("notes") val notes: String,
    @SerialName("visited_at") val visitedAt: Long,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: Long,
    @SerialName("deleted_at") val deletedAt: Long? = null
)

fun FieldSessionEntity.toRow(ownerId: String? = null): FieldSessionRow = FieldSessionRow(
    remoteId = remoteId.orEmpty(),
    ownerId = ownerId ?: ownerUserId,
    title = title,
    notes = notes,
    startedAt = startedAt,
    endedAt = endedAt,
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)

fun FieldSessionRow.toEntity(): FieldSessionEntity = FieldSessionEntity(
    remoteId = remoteId.ifBlank { null },
    ownerUserId = ownerId,
    title = title,
    notes = notes,
    startedAt = startedAt,
    endedAt = endedAt,
    syncStatus = "SYNCED",
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)

fun FieldSessionVisitEntity.toRow(sessionRemoteId: String, ownerId: String? = null, locationRemoteId: String? = null): FieldSessionVisitRow = FieldSessionVisitRow(
    remoteId = remoteId.orEmpty(),
    ownerId = ownerId ?: ownerUserId,
    sessionRemoteId = sessionRemoteId,
    locationType = locationType,
    locationRemoteId = locationRemoteId,
    label = label,
    notes = notes,
    visitedAt = visitedAt,
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)


fun FieldSessionVisitRow.toEntity(sessionId: Long, locationId: Long): FieldSessionVisitEntity = FieldSessionVisitEntity(
    remoteId = remoteId.ifBlank { null },
    ownerUserId = ownerId,
    sessionId = sessionId,
    locationType = locationType,
    locationId = locationId,
    label = label,
    notes = notes,
    visitedAt = visitedAt,
    syncStatus = "SYNCED",
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)
