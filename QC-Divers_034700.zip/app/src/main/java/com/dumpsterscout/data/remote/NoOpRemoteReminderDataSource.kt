package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.ReminderEntity

class NoOpRemoteReminderDataSource : RemoteReminderDataSource {
    override suspend fun upsertReminders(reminders: List<ReminderEntity>, locationRemoteIds: Map<Long, String>): Map<Long, String> = emptyMap()
    override suspend fun deleteReminders(remoteIds: List<String>): Set<String> = emptySet()
    override suspend fun fetchMyReminders(ownerUserId: String): List<ReminderEntity> = emptyList()
}
