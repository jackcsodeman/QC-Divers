package com.dumpsterscout.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.dumpsterscout.data.local.entity.SpotPhotoEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SpotPhotoDao {

    /** Active (non-deleted) photos for a legacy dumpster spot, newest first. */
    @Query("""
        SELECT * FROM spot_photos
        WHERE deletedAt IS NULL
          AND ((ownerType IN ('DUMPSTER_SPOT', 'spot') AND ownerId = :spotId) OR spotId = :spotId)
        ORDER BY takenAt DESC
    """)
    fun getPhotosForSpot(spotId: Long): Flow<List<SpotPhotoEntity>>

    /** Active photos for any supported owner, newest first. */
    @Query("""
        SELECT * FROM spot_photos
        WHERE deletedAt IS NULL AND ownerType = :ownerType AND ownerId = :ownerId
        ORDER BY takenAt DESC
    """)
    fun getPhotosForOwner(ownerType: String, ownerId: Long): Flow<List<SpotPhotoEntity>>

    /** All photos including soft-deleted, for a legacy dumpster spot. */
    @Query("""
        SELECT * FROM spot_photos
        WHERE ((ownerType IN ('DUMPSTER_SPOT', 'spot') AND ownerId = :spotId) OR spotId = :spotId)
        ORDER BY takenAt DESC
    """)
    fun getAllPhotosForSpot(spotId: Long): Flow<List<SpotPhotoEntity>>

    @Query("SELECT * FROM spot_photos WHERE id = :id")
    suspend fun getById(id: Long): SpotPhotoEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(photo: SpotPhotoEntity): Long

    @Update
    suspend fun update(photo: SpotPhotoEntity)

    @Delete
    suspend fun delete(photo: SpotPhotoEntity)

    /** Soft-delete: stamps deletedAt and marks pending sync so the deletion is pushed on next sync. */
    @Query("UPDATE spot_photos SET deletedAt = :now, updatedAt = :now, uploadStatus = 'PENDING_UPLOAD' WHERE id = :id")
    suspend fun softDelete(id: Long, now: Long = System.currentTimeMillis())

    /** Hard-delete all photos for a legacy dumpster spot (used when spot itself is deleted). */
    @Query("DELETE FROM spot_photos WHERE ((ownerType IN ('DUMPSTER_SPOT', 'spot') AND ownerId = :spotId) OR spotId = :spotId)")
    suspend fun deleteAllForSpot(spotId: Long)

    @Query("DELETE FROM spot_photos WHERE ownerType = :ownerType AND ownerId = :ownerId")
    suspend fun deleteAllForOwner(ownerType: String, ownerId: Long)

    @Query("SELECT COUNT(*) FROM spot_photos WHERE deletedAt IS NULL")
    fun observePhotoCount(): Flow<Int>

    /** Photos queued for upload/deletion — includes soft-deleted records so the worker can push remote deletions. */
    @Query("SELECT * FROM spot_photos WHERE uploadStatus = 'PENDING_UPLOAD' ORDER BY createdAt ASC")
    suspend fun getPendingUploadPhotos(): List<SpotPhotoEntity>

    /** Mark a photo as uploaded and store the remote reference. */
    @Query("UPDATE spot_photos SET uploadStatus = 'UPLOADED', remoteUrl = :remoteUrl, updatedAt = :now WHERE id = :id")
    suspend fun markUploaded(id: Long, remoteUrl: String, now: Long = System.currentTimeMillis())

    @Query("DELETE FROM spot_photos")
    suspend fun deleteAll()

    /** Mark a photo upload as failed. */
    @Query("UPDATE spot_photos SET uploadStatus = 'UPLOAD_FAILED', updatedAt = :now WHERE id = :id")
    suspend fun markUploadFailed(id: Long, now: Long = System.currentTimeMillis())
}
