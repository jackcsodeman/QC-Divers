package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.CollectionEntity
import com.dumpsterscout.data.local.entity.CollectionItemEntity
import com.dumpsterscout.data.remote.dto.CollectionRow
import com.dumpsterscout.data.remote.dto.CollectionItemRow
import com.dumpsterscout.data.remote.dto.toEntity
import com.dumpsterscout.data.remote.dto.toRow
import com.dumpsterscout.util.DsLogger
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.from

/** Supabase PostgREST implementation for collections and collection_items. */
class SupabaseCollectionDataSource(
    private val client: SupabaseClient,
    private val locationIdResolver: RemoteLocationIdResolver
) : RemoteCollectionDataSource {
    override suspend fun upsertCollection(collection: CollectionEntity, items: List<CollectionItemEntity>): String? {
        return try {
            val currentUserId = client.auth.currentUserOrNull()?.id
            val row = collection.toRow(ownerId = currentUserId)
            val returned = if (collection.remoteId.isNullOrBlank()) {
                client.from(COLLECTIONS_TABLE).insert(row) { select() }.decodeSingle<CollectionRow>()
            } else {
                client.from(COLLECTIONS_TABLE).upsert(row) { select() }.decodeSingle<CollectionRow>()
            }
            replaceItems(returned.remoteId, currentUserId ?: collection.ownerUserId, items)
            returned.remoteId
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to upsert collection.", e)
            null
        }
    }

    override suspend fun deleteCollections(remoteIds: List<String>): Set<String> {
        val deleted = mutableSetOf<String>()
        val nowMillis = System.currentTimeMillis()
        for (id in remoteIds) {
            try {
                client.from(COLLECTIONS_TABLE).update({ set("deleted_at", nowMillis) }) {
                    filter { eq("id", id) }
                }
                client.from(ITEMS_TABLE).update({ set("deleted_at", nowMillis) }) {
                    filter { eq("collection_id", id) }
                }
                deleted.add(id)
            } catch (e: Exception) {
                DsLogger.e(TAG, "Failed to soft-delete collection.", e)
            }
        }
        return deleted
    }

    override suspend fun fetchMyCollections(ownerUserId: String): List<CollectionEntity> {
        return try {
            client.from(COLLECTIONS_TABLE)
                .select { filter { eq("owner_id", ownerUserId) } }
                .decodeList<CollectionRow>()
                .filter { it.deletedAt == null }
                .map { it.toEntity() }
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to fetch collections for owner.", e)
            emptyList()
        }
    }


    override suspend fun fetchMyCollectionItems(ownerUserId: String): List<CollectionItemRow> {
        return try {
            client.from(ITEMS_TABLE)
                .select { filter { eq("owner_id", ownerUserId) } }
                .decodeList<CollectionItemRow>()
                .filter { it.deletedAt == null }
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to fetch collection items for owner.", e)
            emptyList()
        }
    }

    private suspend fun replaceItems(collectionRemoteId: String, ownerUserId: String?, items: List<CollectionItemEntity>) {
        val nowMillis = System.currentTimeMillis()
        client.from(ITEMS_TABLE).update({ set("deleted_at", nowMillis) }) {
            filter { eq("collection_id", collectionRemoteId) }
        }
        val activeItems = items.filter { it.deletedAt == null }
        if (activeItems.isEmpty()) return
        client.from(ITEMS_TABLE).insert(activeItems.map { item ->
            item.toRow(
                collectionRemoteId = collectionRemoteId,
                ownerId = ownerUserId,
                locationRemoteId = locationIdResolver.resolve(item.locationType, item.locationId)
            )
        })
    }

    private companion object {
        const val TAG = "SupabaseCollectionDS"
        const val COLLECTIONS_TABLE = "collections"
        const val ITEMS_TABLE = "collection_items"
    }
}
