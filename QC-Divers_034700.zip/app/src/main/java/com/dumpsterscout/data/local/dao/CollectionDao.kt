package com.dumpsterscout.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.dumpsterscout.data.local.entity.CollectionEntity
import com.dumpsterscout.data.local.entity.CollectionItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CollectionDao {
    @Query("SELECT * FROM collections WHERE deletedAt IS NULL ORDER BY updatedAt DESC")
    fun observeCollections(): Flow<List<CollectionEntity>>

    @Query("SELECT * FROM collection_items WHERE deletedAt IS NULL ORDER BY collectionId ASC, sortOrder ASC")
    fun observeItems(): Flow<List<CollectionItemEntity>>

    @Query("SELECT * FROM collection_items WHERE collectionId = :collectionId AND deletedAt IS NULL ORDER BY sortOrder ASC")
    fun observeItemsForCollection(collectionId: Long): Flow<List<CollectionItemEntity>>

    @Query("SELECT * FROM collections WHERE id = :id LIMIT 1")
    suspend fun getCollectionById(id: Long): CollectionEntity?

    @Query("SELECT * FROM collections WHERE remoteId = :remoteId LIMIT 1")
    suspend fun getCollectionByRemoteId(remoteId: String): CollectionEntity?

    @Query("SELECT * FROM collection_items WHERE id = :id LIMIT 1")
    suspend fun getItemById(id: Long): CollectionItemEntity?

    @Query("SELECT * FROM collection_items WHERE remoteId = :remoteId LIMIT 1")
    suspend fun getItemByRemoteId(remoteId: String): CollectionItemEntity?

    @Query("SELECT * FROM collection_items WHERE collectionId = :collectionId ORDER BY sortOrder ASC")
    suspend fun getItemsForCollectionSnapshot(collectionId: Long): List<CollectionItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCollection(collection: CollectionEntity): Long

    @Update
    suspend fun updateCollection(collection: CollectionEntity)

    @Query("UPDATE collections SET deletedAt = :now, updatedAt = :now, syncStatus = 'PENDING_SYNC' WHERE id = :id")
    suspend fun softDeleteCollection(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE collections SET syncStatus = 'PENDING_SYNC', updatedAt = :now WHERE id = :id")
    suspend fun markPendingSync(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE collections SET syncStatus = 'SYNCED', remoteId = :remoteId, updatedAt = :now WHERE id = :id")
    suspend fun markSynced(id: Long, remoteId: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE collections SET syncStatus = 'SYNC_FAILED', updatedAt = :now WHERE id = :id")
    suspend fun markSyncFailed(id: Long, now: Long = System.currentTimeMillis())

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertItem(item: CollectionItemEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertItem(item: CollectionItemEntity): Long

    @Query("UPDATE collection_items SET deletedAt = :now, updatedAt = :now WHERE id = :id")
    suspend fun softDeleteItem(id: Long, now: Long = System.currentTimeMillis())

    @Query("DELETE FROM collection_items WHERE id = :id")
    suspend fun deleteItem(id: Long)

    @Query("DELETE FROM collection_items WHERE collectionId = :collectionId AND locationType = :locationType AND locationId = :locationId")
    suspend fun removeLocation(collectionId: Long, locationType: String, locationId: Long)

    @Query("SELECT * FROM collections ORDER BY updatedAt DESC")
    suspend fun getCollectionsSnapshot(): List<CollectionEntity>

    @Query("SELECT * FROM collection_items ORDER BY collectionId ASC, sortOrder ASC")
    suspend fun getItemsSnapshot(): List<CollectionItemEntity>

    @Query("DELETE FROM collection_items")
    suspend fun deleteAllItems()

    @Query("DELETE FROM collections")
    suspend fun deleteAllCollections()

    @Transaction
    suspend fun deleteAll() {
        deleteAllItems()
        deleteAllCollections()
    }

    @Query("SELECT COUNT(*) FROM collections WHERE deletedAt IS NULL")
    fun observeCollectionCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM collection_items WHERE deletedAt IS NULL")
    fun observeCollectionItemCount(): Flow<Int>

}
