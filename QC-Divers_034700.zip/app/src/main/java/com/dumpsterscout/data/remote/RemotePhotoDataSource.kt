package com.dumpsterscout.data.remote

import com.dumpsterscout.domain.model.PhotoAttachment

/**
 * Contract for the remote (Supabase Storage) photo data source.
 *
 * Remote photo storage must be private by default. Implementations should return
 * an internal storage reference or a short-lived signed URL, never a permanent
 * public URL for private user media.
 */
interface RemotePhotoDataSource {

    /**
     * Upload a photo to remote storage.
     *
     * @param photo  The local photo record. [PhotoAttachment.localUri] must be non-null.
     * @return       A private storage reference or short-lived signed URL, or null on failure.
     */
    suspend fun uploadPhoto(photo: PhotoAttachment): String?

    /**
     * Delete a photo from remote storage.
     *
     * @param remoteUrl  The storage reference previously returned by [uploadPhoto].
     */
    suspend fun deletePhoto(remoteUrl: String)
}
