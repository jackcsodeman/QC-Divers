package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(
    tableName = "field_session_visits",
    foreignKeys = [
        ForeignKey(
            entity = FieldSessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("sessionId"),
        Index("visitedAt"),
        Index(value = ["sessionId", "locationType", "locationId"], unique = true),
        Index("remoteId"),
        Index("syncStatus"),
        Index("deletedAt")
    ]
)
@Serializable
data class FieldSessionVisitEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val remoteId: String? = null,
    val ownerUserId: String? = null,
    val sessionId: Long,
    val locationType: String,
    val locationId: Long,
    val label: String = "",
    val notes: String = "",
    val visitedAt: Long = System.currentTimeMillis(),
    val syncStatus: String = "LOCAL_ONLY",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)
