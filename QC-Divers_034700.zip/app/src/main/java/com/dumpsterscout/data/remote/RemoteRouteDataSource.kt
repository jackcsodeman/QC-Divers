package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.RoutePlanEntity
import com.dumpsterscout.data.local.entity.RouteStopEntity
import com.dumpsterscout.data.remote.dto.RouteStopRow

/** Remote contract for saved route plans and normalized route stops. */
interface RemoteRouteDataSource {
    suspend fun upsertRoutePlan(route: RoutePlanEntity, stops: List<RouteStopEntity>): String?
    suspend fun deleteRoutePlans(remoteIds: List<String>): Set<String>
    suspend fun fetchMyRoutePlans(ownerUserId: String): List<RoutePlanEntity>
    suspend fun fetchMyRouteStops(ownerUserId: String): List<RouteStopRow>
}
