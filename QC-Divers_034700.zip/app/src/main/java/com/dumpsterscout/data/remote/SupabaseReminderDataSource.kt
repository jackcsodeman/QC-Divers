package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.ReminderEntity
import com.dumpsterscout.data.remote.dto.ReminderRow
import com.dumpsterscout.data.remote.dto.toEntity
import com.dumpsterscout.data.remote.dto.toRow
import com.dumpsterscout.util.DsLogger
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.from

/** Supabase PostgREST implementation for synced reminders. */
class SupabaseReminderDataSource(
    private val client: SupabaseClient
) : RemoteReminderDataSource {
    override suspend fun upsertReminders(reminders: List<ReminderEntity>, locationRemoteIds: Map<Long, String>): Map<Long, String> {
        val synced = mutableMapOf<Long, String>()
        val currentUserId = client.auth.currentUserOrNull()?.id
        for (reminder in reminders) {
            try {
                val row = reminder.toRow(
                    ownerId = currentUserId,
                    locationRemoteIdOverride = locationRemoteIds[reminder.id] ?: reminder.locationRemoteId
                )
                val returned = if (reminder.remoteId.isNullOrBlank()) {
                    client.from(TABLE).insert(row) { select() }.decodeSingle<ReminderRow>()
                } else {
                    client.from(TABLE).upsert(row) { select() }.decodeSingle<ReminderRow>()
                }
                synced[reminder.id] = returned.remoteId
            } catch (e: Exception) {
                DsLogger.e(TAG, "Failed to upsert reminder.", e)
            }
        }
        return synced
    }

    override suspend fun deleteReminders(remoteIds: List<String>): Set<String> {
        val deleted = mutableSetOf<String>()
        val now = System.currentTimeMillis()
        for (id in remoteIds.filter { it.isNotBlank() }) {
            try {
                client.from(TABLE).update({ set("deleted_at", now) }) {
                    filter { eq("id", id) }
                }
                deleted.add(id)
            } catch (e: Exception) {
                DsLogger.e(TAG, "Failed to soft-delete reminder.", e)
            }
        }
        return deleted
    }

    override suspend fun fetchMyReminders(ownerUserId: String): List<ReminderEntity> = try {
        client.from(TABLE)
            .select { filter { eq("owner_id", ownerUserId) } }
            .decodeList<ReminderRow>()
            .filter { it.deletedAt == null }
            .map { it.toEntity() }
    } catch (e: Exception) {
        DsLogger.e(TAG, "Failed to fetch reminders for owner.", e)
        emptyList()
    }

    private companion object {
        const val TAG = "SupabaseReminderDS"
        const val TABLE = "reminders"
    }
}
