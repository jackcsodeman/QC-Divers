package com.dumpsterscout.data.sync

import com.dumpsterscout.data.local.dao.CollectionDao
import com.dumpsterscout.data.local.dao.FieldLocationDao
import com.dumpsterscout.data.local.dao.FieldLocationReportDao
import com.dumpsterscout.data.local.dao.FieldSessionDao
import com.dumpsterscout.data.local.dao.RoutePlanDao
import com.dumpsterscout.data.local.dao.ReminderDao
import com.dumpsterscout.data.local.dao.GearChecklistDao
import com.dumpsterscout.data.local.dao.SyncQueueDao
import com.dumpsterscout.data.local.entity.SyncQueueEntity
import com.dumpsterscout.data.remote.RemoteCollectionDataSource
import com.dumpsterscout.data.remote.RemoteFieldLocationDataSource
import com.dumpsterscout.data.remote.RemoteFieldLocationReportDataSource
import com.dumpsterscout.data.remote.RemoteFieldSessionDataSource
import com.dumpsterscout.data.remote.RemotePhotoDataSource
import com.dumpsterscout.data.remote.RemoteReportDataSource
import com.dumpsterscout.data.remote.RemoteRouteDataSource
import com.dumpsterscout.data.remote.RemoteReminderDataSource
import com.dumpsterscout.data.remote.RemoteGearChecklistDataSource
import com.dumpsterscout.data.remote.RemoteSpotDataSource
import com.dumpsterscout.data.remote.RemoteTireSpotDataSource
import com.dumpsterscout.di.annotations.RemoteSource
import com.dumpsterscout.domain.repository.PhotoRepository
import com.dumpsterscout.domain.repository.ReportRepository
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.domain.repository.TireReportRepository
import com.dumpsterscout.domain.repository.TireSpotRepository
import com.dumpsterscout.util.DsLogger
import javax.inject.Inject
import javax.inject.Singleton

/** 
 * Summary of one sync-queue processing pass. 
 * 
 * @property attempted Number of items picked up for processing.
 * @property succeeded Number of items successfully synced.
 * @property failed Number of items that encountered an error.
 */
data class SyncQueueProcessResult(
    val attempted: Int,
    val succeeded: Int,
    val failed: Int
) {
    /** True if any failures occurred during this pass. */
    val hasFailures: Boolean get() = failed > 0
}

/**
 * Processes the durable local sync outbox.
 *
 * The old per-record PENDING_SYNC hooks remain as a compatibility fallback, but
 * this processor is the production path for new mutations. It handles retries,
 * parent/child delays, stale queued updates, and remote confirmation before
 * marking records synced.
 */
@Singleton
class SyncQueueProcessor @Inject constructor(
    private val queueDao: SyncQueueDao,
    private val collectionDao: CollectionDao,
    private val fieldLocationDao: FieldLocationDao,
    private val fieldLocationReportDao: FieldLocationReportDao,
    private val fieldSessionDao: FieldSessionDao,
    private val routeDao: RoutePlanDao,
    private val reminderDao: ReminderDao,
    private val gearChecklistDao: GearChecklistDao,
    private val spotRepository: SpotRepository,
    private val reportRepository: ReportRepository,
    private val tireSpotRepository: TireSpotRepository,
    private val tireReportRepository: TireReportRepository,
    private val photoRepository: PhotoRepository,
    @RemoteSource private val remoteSpotSource: RemoteSpotDataSource,
    @RemoteSource private val remoteReportSource: RemoteReportDataSource,
    @RemoteSource private val remoteTireSpotSource: RemoteTireSpotDataSource,
    @RemoteSource private val remotePhotoSource: RemotePhotoDataSource,
    @RemoteSource private val remoteCollectionSource: RemoteCollectionDataSource,
    @RemoteSource private val remoteFieldLocationSource: RemoteFieldLocationDataSource,
    @RemoteSource private val remoteFieldLocationReportSource: RemoteFieldLocationReportDataSource,
    @RemoteSource private val remoteFieldSessionSource: RemoteFieldSessionDataSource,
    @RemoteSource private val remoteRouteSource: RemoteRouteDataSource,
    @RemoteSource private val remoteReminderSource: RemoteReminderDataSource,
    @RemoteSource private val remoteGearChecklistSource: RemoteGearChecklistDataSource
) {
    /**
     * Processes up to [limit] runnable items from the sync queue.
     * 
     * @param limit Maximum items to process in this pass.
     * @return A [SyncQueueProcessResult] summarizing the outcome.
     */
    suspend fun processNextBatch(limit: Int = 50): SyncQueueProcessResult {
        queueDao.resetStaleInProgress(System.currentTimeMillis() - STALE_IN_PROGRESS_MS)
        val items = queueDao.getRunnable(limit)
        if (items.isEmpty()) return SyncQueueProcessResult(0, 0, 0)

        var succeeded = 0
        var failed = 0
        for (item in items) {
            queueDao.markInProgress(item.id)
            try {
                processOne(item)
                queueDao.markSucceeded(item.id)
                succeeded++
            } catch (e: Exception) {
                DsLogger.e(TAG, "Sync queue item failed: ${item.entityType}/${item.operation}", e)
                queueDao.markFailed(item.id, e.message ?: e::class.java.simpleName)
                failed++
            }
        }
        return SyncQueueProcessResult(attempted = items.size, succeeded = succeeded, failed = failed)
    }

    /**
     * Resets all items marked as failed so they can be retried in the next batch.
     */
    suspend fun retryFailed() {
        queueDao.retryFailed()
    }

    /**
     * Dispatches a sync item to the appropriate entity processor.
     */
    private suspend fun processOne(item: SyncQueueEntity) {
        when (item.entityType) {
            SyncEntityType.DUMPSTER_SPOT.name -> processDumpsterSpot(item)
            SyncEntityType.DUMPSTER_REPORT.name -> processDumpsterReport(item)
            SyncEntityType.TIRE_SPOT.name -> processTireSpot(item)
            SyncEntityType.TIRE_REPORT.name -> processTireReport(item)
            SyncEntityType.PHOTO.name -> processPhoto(item)
            SyncEntityType.FIELD_LOCATION.name -> processFieldLocation(item)
            SyncEntityType.FIELD_LOCATION_REPORT.name -> processFieldLocationReport(item)
            SyncEntityType.COLLECTION.name -> processCollection(item)
            SyncEntityType.FIELD_SESSION.name -> processFieldSession(item)
            SyncEntityType.ROUTE_PLAN.name -> processRoutePlan(item)
            SyncEntityType.REMINDER.name -> processReminder(item)
            SyncEntityType.GEAR_CHECKLIST.name -> processGearChecklist(item)
            else -> throw IllegalArgumentException("Unsupported sync entity type: ${item.entityType}")
        }
    }

    private suspend fun processDumpsterSpot(item: SyncQueueEntity) {
        when (item.operation) {
            SyncQueueOperation.DELETE.name -> {
                val remoteId = item.entityRemoteId
                if (remoteId.isNullOrBlank()) return
                val deleted = remoteSpotSource.deleteSpots(listOf(remoteId))
                if (remoteId !in deleted) throw IllegalStateException("Remote spot delete was not confirmed")
            }
            SyncQueueOperation.CREATE.name, SyncQueueOperation.UPDATE.name -> {
                val spot = spotRepository.getSpotById(item.entityLocalId) ?: return
                val synced = remoteSpotSource.upsertSpots(listOf(spot))
                val remoteId = synced[spot.id] ?: throw IllegalStateException("Remote spot upsert was not confirmed")
                spotRepository.markSpotSynced(spot.id, remoteId)
            }
            else -> throw IllegalArgumentException("Unsupported spot operation: ${item.operation}")
        }
    }

    private suspend fun processDumpsterReport(item: SyncQueueEntity) {
        when (item.operation) {
            SyncQueueOperation.DELETE.name -> {
                val remoteId = item.entityRemoteId
                if (remoteId.isNullOrBlank()) return
                val deleted = remoteReportSource.deleteReports(listOf(remoteId))
                if (remoteId !in deleted) throw IllegalStateException("Remote report delete was not confirmed")
            }
            SyncQueueOperation.CREATE.name, SyncQueueOperation.UPDATE.name -> {
                val report = reportRepository.getReportById(item.entityLocalId) ?: return
                val parentRemoteId = spotRepository.getSpotById(report.spotId)?.remoteId
                    ?: throw IllegalStateException("Parent dumpster spot is not synced yet")
                val synced = remoteReportSource.upsertReports(
                    reports = listOf(report),
                    spotRemoteIds = mapOf(report.id to parentRemoteId)
                )
                val remoteId = synced[report.id] ?: throw IllegalStateException("Remote report upsert was not confirmed")
                reportRepository.markReportSynced(report.id, remoteId)
            }
            else -> throw IllegalArgumentException("Unsupported report operation: ${item.operation}")
        }
    }

    private suspend fun processTireSpot(item: SyncQueueEntity) {
        when (item.operation) {
            SyncQueueOperation.DELETE.name -> {
                val remoteId = item.entityRemoteId
                if (remoteId.isNullOrBlank()) return
                val deleted = remoteTireSpotSource.deleteTireSpots(listOf(remoteId))
                if (remoteId !in deleted) throw IllegalStateException("Remote tire spot delete was not confirmed")
            }
            SyncQueueOperation.CREATE.name, SyncQueueOperation.UPDATE.name -> {
                val spot = tireSpotRepository.getSpotById(item.entityLocalId) ?: return
                val synced = remoteTireSpotSource.upsertTireSpots(listOf(spot))
                val remoteId = synced[spot.id] ?: throw IllegalStateException("Remote tire spot upsert was not confirmed")
                tireSpotRepository.markSpotSynced(spot.id, remoteId)
            }
            else -> throw IllegalArgumentException("Unsupported tire spot operation: ${item.operation}")
        }
    }

    private suspend fun processTireReport(item: SyncQueueEntity) {
        when (item.operation) {
            SyncQueueOperation.DELETE.name -> {
                val remoteId = item.entityRemoteId
                if (remoteId.isNullOrBlank()) return
                val deleted = remoteReportSource.deleteTireReports(listOf(remoteId))
                if (remoteId !in deleted) throw IllegalStateException("Remote tire report delete was not confirmed")
            }
            SyncQueueOperation.CREATE.name, SyncQueueOperation.UPDATE.name -> {
                val report = tireReportRepository.getReportById(item.entityLocalId) ?: return
                val parentRemoteId = tireSpotRepository.getSpotById(report.tireSpotId)?.remoteId
                    ?: throw IllegalStateException("Parent tire spot is not synced yet")
                val synced = remoteReportSource.upsertTireReports(
                    reports = listOf(report),
                    tireSpotRemoteIds = mapOf(report.id to parentRemoteId)
                )
                val remoteId = synced[report.id] ?: throw IllegalStateException("Remote tire report upsert was not confirmed")
                tireReportRepository.markReportSynced(report.id, remoteId)
            }
            else -> throw IllegalArgumentException("Unsupported tire report operation: ${item.operation}")
        }
    }


    private suspend fun processFieldLocation(item: SyncQueueEntity) {
        when (item.operation) {
            SyncQueueOperation.DELETE.name -> {
                val remoteId = item.entityRemoteId
                if (remoteId.isNullOrBlank()) return
                val deleted = remoteFieldLocationSource.deleteFieldLocations(listOf(remoteId))
                if (remoteId !in deleted) throw IllegalStateException("Remote field location delete was not confirmed")
            }
            SyncQueueOperation.CREATE.name, SyncQueueOperation.UPDATE.name -> {
                val location = fieldLocationDao.getById(item.entityLocalId) ?: return
                if (location.deletedAt != null) return
                val synced = remoteFieldLocationSource.upsertFieldLocations(listOf(location))
                val remoteId = synced[location.id] ?: throw IllegalStateException("Remote field location upsert was not confirmed")
                fieldLocationDao.markSynced(location.id, remoteId)
            }
            else -> throw IllegalArgumentException("Unsupported field location operation: ${item.operation}")
        }
    }


    private suspend fun processFieldLocationReport(item: SyncQueueEntity) {
        when (item.operation) {
            SyncQueueOperation.DELETE.name -> {
                val remoteId = item.entityRemoteId
                if (remoteId.isNullOrBlank()) return
                val deleted = remoteFieldLocationReportSource.deleteReports(listOf(remoteId))
                if (remoteId !in deleted) throw IllegalStateException("Remote field-location report delete was not confirmed")
            }
            SyncQueueOperation.CREATE.name, SyncQueueOperation.UPDATE.name -> {
                val report = fieldLocationReportDao.getById(item.entityLocalId) ?: return
                if (report.deletedAt != null) return
                val parentRemoteId = fieldLocationDao.getById(report.fieldLocationId)?.remoteId
                    ?: throw IllegalStateException("Parent field location is not synced yet")
                val synced = remoteFieldLocationReportSource.upsertReports(
                    reports = listOf(report),
                    fieldLocationRemoteIds = mapOf(report.id to parentRemoteId)
                )
                val remoteId = synced[report.id] ?: throw IllegalStateException("Remote field-location report upsert was not confirmed")
                fieldLocationReportDao.markSynced(report.id, remoteId)
            }
            else -> throw IllegalArgumentException("Unsupported field-location report operation: ${item.operation}")
        }
    }

    private suspend fun processCollection(item: SyncQueueEntity) {
        when (item.operation) {
            SyncQueueOperation.DELETE.name -> {
                val remoteId = item.entityRemoteId
                if (remoteId.isNullOrBlank()) return
                val deleted = remoteCollectionSource.deleteCollections(listOf(remoteId))
                if (remoteId !in deleted) throw IllegalStateException("Remote collection delete was not confirmed")
            }
            SyncQueueOperation.CREATE.name, SyncQueueOperation.UPDATE.name -> {
                val collection = collectionDao.getCollectionById(item.entityLocalId) ?: return
                if (collection.deletedAt != null) return
                val items = collectionDao.getItemsForCollectionSnapshot(collection.id)
                val remoteId = remoteCollectionSource.upsertCollection(collection, items)
                    ?: throw IllegalStateException("Remote collection upsert was not confirmed")
                collectionDao.markSynced(collection.id, remoteId)
            }
            else -> throw IllegalArgumentException("Unsupported collection operation: ${item.operation}")
        }
    }

    private suspend fun processFieldSession(item: SyncQueueEntity) {
        when (item.operation) {
            SyncQueueOperation.DELETE.name -> {
                val remoteId = item.entityRemoteId
                if (remoteId.isNullOrBlank()) return
                val deleted = remoteFieldSessionSource.deleteFieldSessions(listOf(remoteId))
                if (remoteId !in deleted) throw IllegalStateException("Remote field session delete was not confirmed")
            }
            SyncQueueOperation.CREATE.name, SyncQueueOperation.UPDATE.name -> {
                val session = fieldSessionDao.getSessionById(item.entityLocalId) ?: return
                if (session.deletedAt != null) return
                val visits = fieldSessionDao.getVisitsForSessionSnapshot(session.id)
                val remoteId = remoteFieldSessionSource.upsertFieldSession(session, visits)
                    ?: throw IllegalStateException("Remote field session upsert was not confirmed")
                fieldSessionDao.markSynced(session.id, remoteId)
            }
            else -> throw IllegalArgumentException("Unsupported field session operation: ${item.operation}")
        }
    }


    private suspend fun processRoutePlan(item: SyncQueueEntity) {
        when (item.operation) {
            SyncQueueOperation.DELETE.name -> {
                val remoteId = item.entityRemoteId
                if (remoteId.isNullOrBlank()) return
                val deleted = remoteRouteSource.deleteRoutePlans(listOf(remoteId))
                if (remoteId !in deleted) throw IllegalStateException("Remote route delete was not confirmed")
            }
            SyncQueueOperation.CREATE.name, SyncQueueOperation.UPDATE.name -> {
                val route = routeDao.getRoutePlanById(item.entityLocalId) ?: return
                if (route.deletedAt != null) return
                val stops = routeDao.getStopsForRouteSnapshot(route.id)
                val remoteId = remoteRouteSource.upsertRoutePlan(route, stops)
                    ?: throw IllegalStateException("Remote route upsert was not confirmed")
                routeDao.markPlanSynced(route.id, remoteId)
            }
            else -> throw IllegalArgumentException("Unsupported route operation: ${item.operation}")
        }
    }


    private suspend fun processReminder(item: SyncQueueEntity) {
        when (item.operation) {
            SyncQueueOperation.DELETE.name -> {
                val remoteId = item.entityRemoteId
                if (remoteId.isNullOrBlank()) return
                val deleted = remoteReminderSource.deleteReminders(listOf(remoteId))
                if (remoteId !in deleted) throw IllegalStateException("Remote reminder delete was not confirmed")
            }
            SyncQueueOperation.CREATE.name, SyncQueueOperation.UPDATE.name -> {
                val reminder = reminderDao.getReminderById(item.entityLocalId) ?: return
                if (reminder.deletedAt != null) return
                val parentRemoteId = spotRepository.getSpotById(reminder.spotId)?.remoteId
                    ?: reminder.locationRemoteId
                    ?: throw IllegalStateException("Parent reminder location is not synced yet")
                val synced = remoteReminderSource.upsertReminders(
                    reminders = listOf(reminder.copy(locationRemoteId = parentRemoteId)),
                    locationRemoteIds = mapOf(reminder.id to parentRemoteId)
                )
                val remoteId = synced[reminder.id] ?: throw IllegalStateException("Remote reminder upsert was not confirmed")
                reminderDao.markSynced(reminder.id, remoteId)
            }
            else -> throw IllegalArgumentException("Unsupported reminder operation: ${item.operation}")
        }
    }

    private suspend fun processGearChecklist(item: SyncQueueEntity) {
        when (item.operation) {
            SyncQueueOperation.DELETE.name -> {
                val remoteId = item.entityRemoteId
                if (remoteId.isNullOrBlank()) return
                val deleted = remoteGearChecklistSource.deleteChecklists(listOf(remoteId))
                if (remoteId !in deleted) throw IllegalStateException("Remote gear checklist delete was not confirmed")
            }
            SyncQueueOperation.CREATE.name, SyncQueueOperation.UPDATE.name -> {
                val checklist = gearChecklistDao.getChecklistById(item.entityLocalId) ?: return
                if (checklist.deletedAt != null) return
                val items = gearChecklistDao.getItemsForChecklistSnapshot(checklist.id)
                val remoteId = remoteGearChecklistSource.upsertChecklist(checklist, items)
                    ?: throw IllegalStateException("Remote gear checklist upsert was not confirmed")
                gearChecklistDao.markChecklistSynced(checklist.id, remoteId)
            }
            else -> throw IllegalArgumentException("Unsupported gear checklist operation: ${item.operation}")
        }
    }

    private suspend fun processPhoto(item: SyncQueueEntity) {
        when (item.operation) {
            SyncQueueOperation.UPLOAD_PHOTO.name -> {
                val photo = photoRepository.getPhotoById(item.entityLocalId) ?: return
                if (photo.deletedAt != null) return
                val remoteRef = try {
                    remotePhotoSource.uploadPhoto(photo)
                } catch (e: Exception) {
                    photoRepository.markUploadFailed(photo.id)
                    throw e
                } ?: run {
                    photoRepository.markUploadFailed(photo.id)
                    throw IllegalStateException("Remote photo upload was not confirmed")
                }
                photoRepository.markUploaded(photo.id, remoteRef)
            }
            SyncQueueOperation.DELETE_PHOTO.name -> {
                val remoteRef = item.entityRemoteId
                if (!remoteRef.isNullOrBlank()) remotePhotoSource.deletePhoto(remoteRef)
            }
            else -> throw IllegalArgumentException("Unsupported photo operation: ${item.operation}")
        }
    }

    private companion object {
        const val TAG = "SyncQueueProcessor"
        const val STALE_IN_PROGRESS_MS = 30 * 60 * 1000L
    }
}
