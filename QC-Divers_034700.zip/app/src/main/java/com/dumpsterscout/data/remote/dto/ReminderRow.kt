package com.dumpsterscout.data.remote.dto

import com.dumpsterscout.data.local.entity.ReminderEntity
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ReminderRow(
    @SerialName("id") val remoteId: String = "",
    @SerialName("owner_id") val ownerId: String? = null,
    @SerialName("location_type") val locationType: String = "DUMPSTER_SPOT",
    @SerialName("location_remote_id") val locationRemoteId: String? = null,
    @SerialName("label") val label: String = "",
    @SerialName("day_of_week") val dayOfWeek: Int = 0,
    @SerialName("time_hour") val timeHour: Int = 20,
    @SerialName("time_minute") val timeMinute: Int = 0,
    @SerialName("is_active") val isActive: Boolean = true,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: Long,
    @SerialName("deleted_at") val deletedAt: Long?
)

fun ReminderEntity.toRow(locationRemoteIdOverride: String? = null, ownerId: String? = null): ReminderRow = ReminderRow(
    remoteId = remoteId.orEmpty(),
    ownerId = ownerId ?: ownerUserId,
    locationType = locationType,
    locationRemoteId = locationRemoteIdOverride ?: locationRemoteId,
    label = label,
    dayOfWeek = dayOfWeek,
    timeHour = timeHour,
    timeMinute = timeMinute,
    isActive = isActive,
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)

fun ReminderRow.toEntity(): ReminderEntity = ReminderEntity(
    remoteId = remoteId.ifBlank { null },
    ownerUserId = ownerId,
    spotId = 0L,
    locationType = locationType,
    locationRemoteId = locationRemoteId,
    label = label,
    dayOfWeek = dayOfWeek,
    timeHour = timeHour,
    timeMinute = timeMinute,
    isActive = isActive,
    syncStatus = "SYNCED",
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)
