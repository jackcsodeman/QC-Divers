package com.dumpsterscout.data.remote.dto

import com.dumpsterscout.data.local.entity.FieldLocationEntity
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** Remote DTO for the `field_locations` Supabase table. */
@Serializable
data class FieldLocationRow(
    @SerialName("id") val remoteId: String = "",
    @SerialName("owner_id") val ownerId: String? = null,
    @SerialName("location_type") val type: String,
    @SerialName("name") val name: String,
    @SerialName("description") val description: String,
    @SerialName("address") val address: String,
    @SerialName("latitude") val latitude: Double,
    @SerialName("longitude") val longitude: Double,
    @SerialName("tags") val tags: String,
    @SerialName("grade") val grade: String,
    @SerialName("access_status") val accessStatus: String,
    @SerialName("safety_notes") val safetyNotes: String,
    @SerialName("hazard_notes") val hazardNotes: String,
    @SerialName("hazard_level") val hazardLevel: String,
    @SerialName("cleanup_priority") val cleanupPriority: String,
    @SerialName("cleanup_status") val cleanupStatus: String,
    @SerialName("resource_type") val resourceType: String,
    @SerialName("resource_availability") val resourceAvailability: String,
    @SerialName("is_favorite") val isFavorite: Boolean,
    @SerialName("is_archived") val isArchived: Boolean,
    @SerialName("visibility") val visibility: String,
    @SerialName("source") val source: String,
    @SerialName("last_visited_at") val lastVisitedAt: Long?,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: Long,
    @SerialName("deleted_at") val deletedAt: Long?
)

fun FieldLocationEntity.toRow(ownerId: String? = null): FieldLocationRow = FieldLocationRow(
    remoteId = remoteId ?: "",
    ownerId = ownerId ?: ownerUserId,
    type = type,
    name = name,
    description = description,
    address = address,
    latitude = latitude,
    longitude = longitude,
    tags = tags,
    grade = grade,
    accessStatus = accessStatus,
    safetyNotes = safetyNotes,
    hazardNotes = hazardNotes,
    hazardLevel = hazardLevel,
    cleanupPriority = cleanupPriority,
    cleanupStatus = cleanupStatus,
    resourceType = resourceType,
    resourceAvailability = resourceAvailability,
    isFavorite = isFavorite,
    isArchived = isArchived,
    visibility = visibility,
    source = source,
    lastVisitedAt = lastVisitedAt,
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)

fun FieldLocationRow.toEntity(): FieldLocationEntity = FieldLocationEntity(
    remoteId = remoteId.ifBlank { null },
    ownerUserId = ownerId,
    type = type,
    name = name,
    description = description,
    address = address,
    latitude = latitude,
    longitude = longitude,
    tags = tags,
    grade = grade,
    accessStatus = accessStatus,
    safetyNotes = safetyNotes,
    hazardNotes = hazardNotes,
    hazardLevel = hazardLevel,
    cleanupPriority = cleanupPriority,
    cleanupStatus = cleanupStatus,
    resourceType = resourceType,
    resourceAvailability = resourceAvailability,
    isFavorite = isFavorite,
    isArchived = isArchived,
    visibility = visibility,
    syncStatus = "SYNCED",
    conflictStatus = "NONE",
    source = source,
    lastVisitedAt = lastVisitedAt,
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)
