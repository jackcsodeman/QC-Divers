package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * Room entity for tire spot visit reports.
 */
@Entity(
    tableName = "tire_reports",
    foreignKeys = [
        ForeignKey(
            entity = TireSpotEntity::class,
            parentColumns = ["id"],
            childColumns = ["tireSpotId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("tireSpotId")]
)
@Serializable
data class TireReportEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tireSpotId: Long,
    val spotName: String = "",
    val status: String = "UNKNOWN",
    val estimatedCount: Int = 0,
    val estimatedUsableCount: Int = 0,
    val estimatedJunkCount: Int = 0,
    val arePunctured: Boolean = false,
    val somePunctured: Boolean = false,
    val someUnpunctured: Boolean = false,
    val commonSizes: String = "",
    val tireTypes: String = "",
    val treadQuality: String = "UNKNOWN",
    val condition: String = "UNKNOWN",
    val sidewallDamage: Boolean = false,
    val dryRot: Boolean = false,
    val repairVisible: Boolean = false,
    val conditionNotes: String = "",
    val yearNotes: String = "",
    val alreadyPickedThrough: Boolean = false,
    val lookedFreshOut: Boolean = false,
    val weatherAffected: Boolean = false,
    val notes: String = "",
    val photoUris: String = "",         // JSON array string
    val voiceTranscript: String? = null,
    val isFromVoice: Boolean = false,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),

    // Sync / backend-ready metadata
    val remoteId: String? = null,
    val ownerUserId: String? = null,
    val syncStatus: String = "LOCAL_ONLY",
    val visibility: String = "PRIVATE",
    val deletedAt: Long? = null
)
