package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * Normalized stop row for saved routes.
 *
 * RoutePlanEntity keeps the high-level route metadata. Stops live here so the
 * app can support mixed dumpster/tire/field-location routes, stable ordering,
 * backup/restore, sync queue payloads, and future remote route_stops parity.
 */
@Entity(
    tableName = "route_stops",
    foreignKeys = [
        ForeignKey(
            entity = RoutePlanEntity::class,
            parentColumns = ["id"],
            childColumns = ["routeId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["routeId", "sortOrder"]),
        Index(value = ["locationType", "locationId"]),
        Index(value = ["remoteId"]),
        Index(value = ["syncStatus"]),
        Index(value = ["deletedAt"])
    ]
)
@Serializable
data class RouteStopEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val remoteId: String? = null,
    val ownerUserId: String? = null,
    val routeId: Long,
    val locationType: String,
    val locationId: Long,
    val label: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val sortOrder: Int = 0,
    val notes: String = "",
    val syncStatus: String = "LOCAL_ONLY",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)
