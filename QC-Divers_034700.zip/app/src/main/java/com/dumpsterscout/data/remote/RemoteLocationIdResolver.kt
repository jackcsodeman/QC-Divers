package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.dao.DumpsterSpotDao
import com.dumpsterscout.data.local.dao.FieldLocationDao
import com.dumpsterscout.data.local.dao.TireSpotDao
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Resolves local location references into remote Supabase IDs for parent/child
 * sync rows such as route_stops, collection_items, and field_session_visits.
 */
@Singleton
class RemoteLocationIdResolver @Inject constructor(
    private val dumpsterSpotDao: DumpsterSpotDao,
    private val tireSpotDao: TireSpotDao,
    private val fieldLocationDao: FieldLocationDao
) {
    suspend fun resolve(locationType: String, localId: Long): String? {
        if (localId <= 0L) return null
        return when (locationType.uppercase()) {
            "DUMPSTER", "DUMPSTER_SPOT" -> dumpsterSpotDao.getSpotById(localId)?.remoteId
            "TIRE", "TIRE_SPOT" -> tireSpotDao.getSpotById(localId)?.remoteId
            "FIELD_LOCATION", "CLEANUP_SITE", "SALVAGE_RESOURCE", "CUSTOM" -> fieldLocationDao.getById(localId)?.remoteId
            else -> fieldLocationDao.getById(localId)?.remoteId
        }
    }
}
