package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(
    tableName = "gear_checklists",
    indices = [
        Index("updatedAt"),
        Index("remoteId"),
        Index("syncStatus"),
        Index("deletedAt")
    ]
)
@Serializable
data class GearChecklistEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val remoteId: String? = null,
    val ownerUserId: String? = null,
    val name: String,
    val isTemplate: Boolean = true,
    val syncStatus: String = "LOCAL_ONLY",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)
