package com.dumpsterscout.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.dumpsterscout.data.local.entity.GearChecklistEntity
import com.dumpsterscout.data.local.entity.GearChecklistItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface GearChecklistDao {
    @Query("SELECT * FROM gear_checklists WHERE deletedAt IS NULL ORDER BY createdAt ASC")
    fun observeChecklists(): Flow<List<GearChecklistEntity>>

    @Query("SELECT * FROM gear_checklist_items WHERE deletedAt IS NULL ORDER BY sortOrder ASC, id ASC")
    fun observeItems(): Flow<List<GearChecklistItemEntity>>

    @Query("SELECT * FROM gear_checklist_items WHERE checklistId = :checklistId AND deletedAt IS NULL ORDER BY sortOrder ASC, id ASC")
    fun observeItemsForChecklist(checklistId: Long): Flow<List<GearChecklistItemEntity>>

    @Query("SELECT * FROM gear_checklists WHERE id = :id")
    suspend fun getChecklistById(id: Long): GearChecklistEntity?

    @Query("SELECT * FROM gear_checklists WHERE remoteId = :remoteId LIMIT 1")
    suspend fun getChecklistByRemoteId(remoteId: String): GearChecklistEntity?

    @Query("SELECT * FROM gear_checklist_items WHERE id = :id")
    suspend fun getItemById(id: Long): GearChecklistItemEntity?

    @Query("SELECT * FROM gear_checklist_items WHERE remoteId = :remoteId LIMIT 1")
    suspend fun getItemByRemoteId(remoteId: String): GearChecklistItemEntity?

    @Query("SELECT * FROM gear_checklist_items WHERE checklistId = :checklistId ORDER BY sortOrder ASC, id ASC")
    suspend fun getItemsForChecklistSnapshot(checklistId: Long): List<GearChecklistItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChecklist(checklist: GearChecklistEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: GearChecklistItemEntity): Long

    @Update
    suspend fun updateItem(item: GearChecklistItemEntity)

    @Query("UPDATE gear_checklist_items SET isChecked = :checked, syncStatus = :syncStatus, updatedAt = :now WHERE id = :id")
    suspend fun setChecked(id: Long, checked: Boolean, syncStatus: String = "PENDING_SYNC", now: Long = System.currentTimeMillis())

    @Query("UPDATE gear_checklist_items SET isChecked = :checked, syncStatus = :syncStatus, updatedAt = :now WHERE checklistId = :checklistId")
    suspend fun setAllChecked(checklistId: Long, checked: Boolean, syncStatus: String = "PENDING_SYNC", now: Long = System.currentTimeMillis())

    @Query("UPDATE gear_checklists SET syncStatus = 'PENDING_SYNC', updatedAt = :now WHERE id = :id")
    suspend fun markChecklistPendingSync(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE gear_checklists SET syncStatus = 'SYNCED', remoteId = :remoteId, updatedAt = :now WHERE id = :id")
    suspend fun markChecklistSynced(id: Long, remoteId: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE gear_checklists SET syncStatus = 'SYNC_FAILED', updatedAt = :now WHERE id = :id")
    suspend fun markChecklistSyncFailed(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE gear_checklists SET deletedAt = :now, syncStatus = :syncStatus, updatedAt = :now WHERE id = :id")
    suspend fun softDeleteChecklist(id: Long, syncStatus: String = "PENDING_SYNC", now: Long = System.currentTimeMillis())

    @Query("SELECT COUNT(*) FROM gear_checklists")
    suspend fun countChecklists(): Int

    @Query("SELECT * FROM gear_checklists ORDER BY createdAt ASC")
    suspend fun getChecklistsSnapshot(): List<GearChecklistEntity>

    @Query("SELECT * FROM gear_checklist_items ORDER BY checklistId ASC, sortOrder ASC")
    suspend fun getItemsSnapshot(): List<GearChecklistItemEntity>

    @Query("DELETE FROM gear_checklist_items")
    suspend fun deleteAllItems()

    @Query("DELETE FROM gear_checklists")
    suspend fun deleteAllChecklists()

    @Transaction
    suspend fun deleteAll() {
        deleteAllItems()
        deleteAllChecklists()
    }

    @Query("SELECT COUNT(*) FROM gear_checklist_items WHERE deletedAt IS NULL")
    fun observeItemCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM gear_checklist_items WHERE deletedAt IS NULL AND isChecked = 1")
    fun observeCheckedItemCount(): Flow<Int>

}
