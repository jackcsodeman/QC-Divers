package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * Generic first-class field location for cleanup sites, salvage/resource spots,
 * and custom scout locations. Dumpster and tire modules keep their richer legacy
 * entities, while this table covers new location types without a risky rewrite.
 */
@Entity(
    tableName = "field_locations",
    indices = [
        Index("type"),
        Index("isFavorite"),
        Index("updatedAt"),
        Index("syncStatus"),
        Index("visibility")
    ]
)
@Serializable
data class FieldLocationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val remoteId: String? = null,
    val ownerUserId: String? = null,
    val type: String = "CUSTOM",
    val name: String,
    val description: String = "",
    val address: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val tags: String = "",
    val grade: String = "UNKNOWN",
    val accessStatus: String = "UNKNOWN",
    val safetyNotes: String = "",
    val hazardNotes: String = "",
    val hazardLevel: String = "NONE",
    val cleanupPriority: String = "NONE",
    val cleanupStatus: String = "OPEN",
    val resourceType: String = "",
    val resourceAvailability: String = "UNKNOWN",
    val isFavorite: Boolean = false,
    val isArchived: Boolean = false,
    val visibility: String = "PRIVATE",
    val syncStatus: String = "LOCAL_ONLY",
    val conflictStatus: String = "NONE",
    val source: String = "MANUAL",
    val lastVisitedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)
