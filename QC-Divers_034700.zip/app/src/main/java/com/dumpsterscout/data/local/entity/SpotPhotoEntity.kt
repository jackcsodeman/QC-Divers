package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * Room entity for photos attached to any syncable field object.
 *
 * Legacy dumpster-spot photos still carry [spotId] for backward-compatible
 * queries and migrations. New code should use [ownerType] + [ownerId] so tire
 * spots, reports, cleanup/salvage locations, collections, and future entities
 * can share one private-photo pipeline.
 */
@Entity(
    tableName = "spot_photos",
    indices = [
        Index("spotId"),
        Index(value = ["ownerType", "ownerId"]),
        Index("uploadStatus"),
        Index("deletedAt")
    ]
)
@Serializable
data class SpotPhotoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    /** Legacy dumpster spot foreign key retained for v1-v6 compatibility. */
    val spotId: Long? = null,

    /** Stable discriminator, e.g. DUMPSTER_SPOT, TIRE_SPOT, REPORT, FIELD_LOCATION. */
    val ownerType: String = "DUMPSTER_SPOT",

    /** Local ID of the owning record for [ownerType]. */
    val ownerId: Long = 0,

    /** content:// or file:// URI on the local device. */
    val uri: String,

    /** Private Supabase Storage reference or short-lived signed URL. Null until uploaded. */
    val remoteUrl: String? = null,

    /** UploadStatus enum name. Default LOCAL_ONLY. */
    val uploadStatus: String = "LOCAL_ONLY",

    val caption: String = "",
    val mimeType: String = "image/jpeg",
    val fileSizeBytes: Long = 0,

    /** User ID of the contributor (device localId in anonymous mode). */
    val ownerUserId: String? = null,

    val takenAt: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),

    /** Soft-delete timestamp. Null = active. */
    val deletedAt: Long? = null
)
