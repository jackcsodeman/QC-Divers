package com.dumpsterscout.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class TodoItem(val id: Int, val name: String)
