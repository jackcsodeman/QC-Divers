package com.dumpsterscout.data.remote.dto

import com.dumpsterscout.data.local.entity.CollectionEntity
import com.dumpsterscout.data.local.entity.CollectionItemEntity
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class CollectionRow(
    @SerialName("id") val remoteId: String = "",
    @SerialName("owner_id") val ownerId: String? = null,
    @SerialName("name") val name: String,
    @SerialName("notes") val notes: String,
    @SerialName("visibility") val visibility: String,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: Long,
    @SerialName("deleted_at") val deletedAt: Long?
)

@Serializable
data class CollectionItemRow(
    @SerialName("id") val remoteId: String = "",
    @SerialName("owner_id") val ownerId: String? = null,
    @SerialName("collection_id") val collectionRemoteId: String,
    @SerialName("location_type") val locationType: String,
    @SerialName("location_remote_id") val locationRemoteId: String? = null,
    @SerialName("sort_order") val sortOrder: Int,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: Long,
    @SerialName("deleted_at") val deletedAt: Long?
)

fun CollectionEntity.toRow(ownerId: String? = null): CollectionRow = CollectionRow(
    remoteId = remoteId.orEmpty(),
    ownerId = ownerId ?: ownerUserId,
    name = name,
    notes = notes,
    visibility = visibility,
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)

fun CollectionRow.toEntity(): CollectionEntity = CollectionEntity(
    remoteId = remoteId.ifBlank { null },
    ownerUserId = ownerId,
    name = name,
    notes = notes,
    visibility = visibility,
    syncStatus = "SYNCED",
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)

fun CollectionItemEntity.toRow(collectionRemoteId: String, ownerId: String? = null, locationRemoteId: String? = null): CollectionItemRow = CollectionItemRow(
    remoteId = remoteId.orEmpty(),
    ownerId = ownerId ?: ownerUserId,
    collectionRemoteId = collectionRemoteId,
    locationType = locationType,
    locationRemoteId = locationRemoteId,
    sortOrder = sortOrder,
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)


fun CollectionItemRow.toEntity(collectionId: Long, locationId: Long): CollectionItemEntity = CollectionItemEntity(
    remoteId = remoteId.ifBlank { null },
    ownerUserId = ownerId,
    collectionId = collectionId,
    locationType = locationType,
    locationId = locationId,
    sortOrder = sortOrder,
    syncStatus = "SYNCED",
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)
