package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.FieldSessionEntity
import com.dumpsterscout.data.local.entity.FieldSessionVisitEntity
import com.dumpsterscout.data.remote.dto.FieldSessionRow
import com.dumpsterscout.data.remote.dto.FieldSessionVisitRow
import com.dumpsterscout.data.remote.dto.toEntity
import com.dumpsterscout.data.remote.dto.toRow
import com.dumpsterscout.util.DsLogger
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.from

/** Supabase PostgREST implementation for field_sessions and field_session_visits. */
class SupabaseFieldSessionDataSource(
    private val client: SupabaseClient,
    private val locationIdResolver: RemoteLocationIdResolver
) : RemoteFieldSessionDataSource {
    override suspend fun upsertFieldSession(session: FieldSessionEntity, visits: List<FieldSessionVisitEntity>): String? {
        return try {
            val currentUserId = client.auth.currentUserOrNull()?.id
            val row = session.toRow(ownerId = currentUserId)
            val returned = if (session.remoteId.isNullOrBlank()) {
                client.from(SESSIONS_TABLE).insert(row) { select() }.decodeSingle<FieldSessionRow>()
            } else {
                client.from(SESSIONS_TABLE).upsert(row) { select() }.decodeSingle<FieldSessionRow>()
            }
            replaceVisits(returned.remoteId, currentUserId ?: session.ownerUserId, visits)
            returned.remoteId
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to upsert field session.", e)
            null
        }
    }

    override suspend fun deleteFieldSessions(remoteIds: List<String>): Set<String> {
        val deleted = mutableSetOf<String>()
        val nowMillis = System.currentTimeMillis()
        for (id in remoteIds) {
            try {
                client.from(SESSIONS_TABLE).update({ set("deleted_at", nowMillis) }) {
                    filter { eq("id", id) }
                }
                client.from(VISITS_TABLE).update({ set("deleted_at", nowMillis) }) {
                    filter { eq("session_id", id) }
                }
                deleted.add(id)
            } catch (e: Exception) {
                DsLogger.e(TAG, "Failed to soft-delete field session.", e)
            }
        }
        return deleted
    }

    override suspend fun fetchMyFieldSessions(ownerUserId: String): List<FieldSessionEntity> {
        return try {
            client.from(SESSIONS_TABLE)
                .select { filter { eq("owner_id", ownerUserId) } }
                .decodeList<FieldSessionRow>()
                .filter { it.deletedAt == null }
                .map { it.toEntity() }
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to fetch field sessions for owner.", e)
            emptyList()
        }
    }


    override suspend fun fetchMyFieldSessionVisits(ownerUserId: String): List<FieldSessionVisitRow> {
        return try {
            client.from(VISITS_TABLE)
                .select { filter { eq("owner_id", ownerUserId) } }
                .decodeList<FieldSessionVisitRow>()
                .filter { it.deletedAt == null }
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to fetch field-session visits for owner.", e)
            emptyList()
        }
    }

    private suspend fun replaceVisits(sessionRemoteId: String, ownerUserId: String?, visits: List<FieldSessionVisitEntity>) {
        val nowMillis = System.currentTimeMillis()
        client.from(VISITS_TABLE).update({ set("deleted_at", nowMillis) }) {
            filter { eq("session_id", sessionRemoteId) }
        }
        if (visits.isEmpty()) return
        client.from(VISITS_TABLE).insert(visits.map { visit ->
            visit.toRow(
                sessionRemoteId = sessionRemoteId,
                ownerId = ownerUserId,
                locationRemoteId = locationIdResolver.resolve(visit.locationType, visit.locationId)
            )
        })
    }

    private companion object {
        const val TAG = "SupabaseFieldSessionDS"
        const val SESSIONS_TABLE = "field_sessions"
        const val VISITS_TABLE = "field_session_visits"
    }
}
