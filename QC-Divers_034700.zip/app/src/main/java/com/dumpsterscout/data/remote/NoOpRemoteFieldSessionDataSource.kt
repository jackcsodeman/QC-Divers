package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.FieldSessionEntity
import com.dumpsterscout.data.local.entity.FieldSessionVisitEntity

/** Local-only remote stub for field-session sync. */
class NoOpRemoteFieldSessionDataSource : RemoteFieldSessionDataSource {
    override suspend fun upsertFieldSession(session: FieldSessionEntity, visits: List<FieldSessionVisitEntity>): String? =
        session.remoteId ?: "local-field-session-${session.id}"

    override suspend fun deleteFieldSessions(remoteIds: List<String>): Set<String> = remoteIds.toSet()

    override suspend fun fetchMyFieldSessions(ownerUserId: String): List<FieldSessionEntity> = emptyList()
    override suspend fun fetchMyFieldSessionVisits(ownerUserId: String) = emptyList<com.dumpsterscout.data.remote.dto.FieldSessionVisitRow>()

}
