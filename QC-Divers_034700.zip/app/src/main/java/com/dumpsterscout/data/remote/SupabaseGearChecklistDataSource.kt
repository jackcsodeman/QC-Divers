package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.GearChecklistEntity
import com.dumpsterscout.data.local.entity.GearChecklistItemEntity
import com.dumpsterscout.data.remote.dto.GearChecklistRow
import com.dumpsterscout.data.remote.dto.GearChecklistItemRow
import com.dumpsterscout.data.remote.dto.toEntity
import com.dumpsterscout.data.remote.dto.toRow
import com.dumpsterscout.util.DsLogger
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.from

/** Supabase PostgREST implementation for gear_checklists and gear_checklist_items. */
class SupabaseGearChecklistDataSource(
    private val client: SupabaseClient
) : RemoteGearChecklistDataSource {
    override suspend fun upsertChecklist(checklist: GearChecklistEntity, items: List<GearChecklistItemEntity>): String? {
        return try {
            val currentUserId = client.auth.currentUserOrNull()?.id
            val returned = if (checklist.remoteId.isNullOrBlank()) {
                client.from(CHECKLISTS_TABLE).insert(checklist.toRow(ownerId = currentUserId)) { select() }.decodeSingle<GearChecklistRow>()
            } else {
                client.from(CHECKLISTS_TABLE).upsert(checklist.toRow(ownerId = currentUserId)) { select() }.decodeSingle<GearChecklistRow>()
            }
            replaceItems(returned.remoteId, currentUserId ?: checklist.ownerUserId, items)
            returned.remoteId
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to upsert gear checklist.", e)
            null
        }
    }

    override suspend fun deleteChecklists(remoteIds: List<String>): Set<String> {
        val deleted = mutableSetOf<String>()
        val now = System.currentTimeMillis()
        for (id in remoteIds.filter { it.isNotBlank() }) {
            try {
                client.from(CHECKLISTS_TABLE).update({ set("deleted_at", now) }) {
                    filter { eq("id", id) }
                }
                client.from(ITEMS_TABLE).update({ set("deleted_at", now) }) {
                    filter { eq("checklist_id", id) }
                }
                deleted.add(id)
            } catch (e: Exception) {
                DsLogger.e(TAG, "Failed to soft-delete gear checklist.", e)
            }
        }
        return deleted
    }

    override suspend fun fetchMyChecklists(ownerUserId: String): List<GearChecklistEntity> = try {
        client.from(CHECKLISTS_TABLE)
            .select { filter { eq("owner_id", ownerUserId) } }
            .decodeList<GearChecklistRow>()
            .filter { it.deletedAt == null }
            .map { it.toEntity() }
    } catch (e: Exception) {
        DsLogger.e(TAG, "Failed to fetch gear checklists for owner.", e)
        emptyList()
    }


    override suspend fun fetchMyChecklistItems(ownerUserId: String): List<GearChecklistItemRow> = try {
        client.from(ITEMS_TABLE)
            .select { filter { eq("owner_id", ownerUserId) } }
            .decodeList<GearChecklistItemRow>()
            .filter { it.deletedAt == null }
    } catch (e: Exception) {
        DsLogger.e(TAG, "Failed to fetch gear checklist items for owner.", e)
        emptyList()
    }

    private suspend fun replaceItems(checklistRemoteId: String, ownerUserId: String?, items: List<GearChecklistItemEntity>) {
        val now = System.currentTimeMillis()
        client.from(ITEMS_TABLE).update({ set("deleted_at", now) }) {
            filter { eq("checklist_id", checklistRemoteId) }
        }
        val activeItems = items.filter { it.deletedAt == null }
        if (activeItems.isEmpty()) return
        client.from(ITEMS_TABLE).insert(activeItems.map { it.toRow(checklistRemoteId = checklistRemoteId, ownerId = ownerUserId) })
    }

    private companion object {
        const val TAG = "SupabaseGearChecklistDS"
        const val CHECKLISTS_TABLE = "gear_checklists"
        const val ITEMS_TABLE = "gear_checklist_items"
    }
}
