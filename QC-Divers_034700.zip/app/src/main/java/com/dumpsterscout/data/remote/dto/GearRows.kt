package com.dumpsterscout.data.remote.dto

import com.dumpsterscout.data.local.entity.GearChecklistEntity
import com.dumpsterscout.data.local.entity.GearChecklistItemEntity
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class GearChecklistRow(
    @SerialName("id") val remoteId: String = "",
    @SerialName("owner_id") val ownerId: String? = null,
    @SerialName("name") val name: String,
    @SerialName("is_template") val isTemplate: Boolean,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: Long,
    @SerialName("deleted_at") val deletedAt: Long?
)

@Serializable
data class GearChecklistItemRow(
    @SerialName("id") val remoteId: String = "",
    @SerialName("owner_id") val ownerId: String? = null,
    @SerialName("checklist_id") val checklistRemoteId: String,
    @SerialName("label") val label: String,
    @SerialName("category") val category: String,
    @SerialName("emoji") val emoji: String = "•",
    @SerialName("is_checked") val isChecked: Boolean,
    @SerialName("sort_order") val sortOrder: Int,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: Long,
    @SerialName("deleted_at") val deletedAt: Long?
)

fun GearChecklistEntity.toRow(ownerId: String? = null): GearChecklistRow = GearChecklistRow(
    remoteId = remoteId.orEmpty(),
    ownerId = ownerId ?: ownerUserId,
    name = name,
    isTemplate = isTemplate,
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)

fun GearChecklistRow.toEntity(): GearChecklistEntity = GearChecklistEntity(
    remoteId = remoteId.ifBlank { null },
    ownerUserId = ownerId,
    name = name,
    isTemplate = isTemplate,
    syncStatus = "SYNCED",
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)

fun GearChecklistItemEntity.toRow(checklistRemoteId: String, ownerId: String? = null): GearChecklistItemRow = GearChecklistItemRow(
    remoteId = remoteId.orEmpty(),
    ownerId = ownerId,
    checklistRemoteId = checklistRemoteId,
    label = label,
    category = category,
    emoji = emoji,
    isChecked = isChecked,
    sortOrder = sortOrder,
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)


fun GearChecklistItemRow.toEntity(checklistId: Long): GearChecklistItemEntity = GearChecklistItemEntity(
    remoteId = remoteId.ifBlank { null },
    ownerUserId = ownerId,
    checklistId = checklistId,
    label = label,
    category = category,
    emoji = emoji,
    isChecked = isChecked,
    sortOrder = sortOrder,
    syncStatus = "SYNCED",
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)
