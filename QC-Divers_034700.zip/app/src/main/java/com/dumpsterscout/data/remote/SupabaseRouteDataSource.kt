package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.RoutePlanEntity
import com.dumpsterscout.data.local.entity.RouteStopEntity
import com.dumpsterscout.data.remote.dto.RoutePlanRow
import com.dumpsterscout.data.remote.dto.RouteStopRow
import com.dumpsterscout.data.remote.dto.toEntity
import com.dumpsterscout.data.remote.dto.toRow
import com.dumpsterscout.util.DsLogger
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.from

/** Supabase PostgREST implementation for saved routes and normalized stops. */
class SupabaseRouteDataSource(
    private val client: SupabaseClient,
    private val locationIdResolver: RemoteLocationIdResolver
) : RemoteRouteDataSource {

    override suspend fun upsertRoutePlan(route: RoutePlanEntity, stops: List<RouteStopEntity>): String? {
        return try {
            val currentUserId = client.auth.currentUserOrNull()?.id
            val routeRow = route.toRow(ownerId = currentUserId)
            val returned = if (route.remoteId.isNullOrBlank()) {
                client.from(ROUTES_TABLE).insert(routeRow) { select() }.decodeSingle<RoutePlanRow>()
            } else {
                client.from(ROUTES_TABLE).upsert(routeRow) { select() }.decodeSingle<RoutePlanRow>()
            }
            replaceRouteStops(returned.remoteId, currentUserId ?: route.ownerUserId, stops)
            returned.remoteId
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to upsert route plan.", e)
            null
        }
    }

    override suspend fun deleteRoutePlans(remoteIds: List<String>): Set<String> {
        val deleted = mutableSetOf<String>()
        val nowMillis = System.currentTimeMillis()
        for (id in remoteIds) {
            try {
                client.from(ROUTES_TABLE).update({ set("deleted_at", nowMillis) }) {
                    filter { eq("id", id) }
                }
                client.from(STOPS_TABLE).update({ set("deleted_at", nowMillis) }) {
                    filter { eq("route_id", id) }
                }
                deleted.add(id)
            } catch (e: Exception) {
                DsLogger.e(TAG, "Failed to soft-delete route plan.", e)
            }
        }
        return deleted
    }

    override suspend fun fetchMyRoutePlans(ownerUserId: String): List<RoutePlanEntity> {
        return try {
            client.from(ROUTES_TABLE)
                .select { filter { eq("owner_id", ownerUserId) } }
                .decodeList<RoutePlanRow>()
                .filter { it.deletedAt == null }
                .map { it.toEntity() }
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to fetch route plans for owner.", e)
            emptyList()
        }
    }


    override suspend fun fetchMyRouteStops(ownerUserId: String): List<RouteStopRow> {
        return try {
            client.from(STOPS_TABLE)
                .select { filter { eq("owner_id", ownerUserId) } }
                .decodeList<RouteStopRow>()
                .filter { it.deletedAt == null }
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to fetch route stops for owner.", e)
            emptyList()
        }
    }

    private suspend fun replaceRouteStops(routeRemoteId: String, ownerUserId: String?, stops: List<RouteStopEntity>) {
        val nowMillis = System.currentTimeMillis()
        client.from(STOPS_TABLE).update({ set("deleted_at", nowMillis) }) {
            filter { eq("route_id", routeRemoteId) }
        }
        val activeStops = stops.filter { it.deletedAt == null }
        if (activeStops.isEmpty()) return
        client.from(STOPS_TABLE).insert(activeStops.map { stop ->
            stop.toRow(
                routeRemoteId = routeRemoteId,
                ownerId = ownerUserId,
                locationRemoteId = locationIdResolver.resolve(stop.locationType, stop.locationId)
            )
        })
    }

    private companion object {
        const val TAG = "SupabaseRouteDS"
        const val ROUTES_TABLE = "route_plans"
        const val STOPS_TABLE = "route_stops"
    }
}
