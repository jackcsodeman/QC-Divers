package com.dumpsterscout.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.dumpsterscout.data.local.entity.FieldLocationReportEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FieldLocationReportDao {
    @Query("SELECT * FROM field_location_reports WHERE deletedAt IS NULL ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<FieldLocationReportEntity>>

    @Query("SELECT * FROM field_location_reports WHERE fieldLocationId = :locationId AND deletedAt IS NULL ORDER BY timestamp DESC")
    fun observeForLocation(locationId: Long): Flow<List<FieldLocationReportEntity>>

    @Query("SELECT * FROM field_location_reports WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): FieldLocationReportEntity?

    @Query("SELECT * FROM field_location_reports WHERE remoteId = :remoteId LIMIT 1")
    suspend fun getByRemoteId(remoteId: String): FieldLocationReportEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(report: FieldLocationReportEntity): Long

    @Update
    suspend fun update(report: FieldLocationReportEntity)

    @Query("UPDATE field_location_reports SET deletedAt = :now, syncStatus = :syncStatus, updatedAt = :now WHERE id = :id")
    suspend fun softDelete(id: Long, syncStatus: String = "PENDING_SYNC", now: Long = System.currentTimeMillis())

    @Query("UPDATE field_location_reports SET syncStatus = 'PENDING_SYNC', updatedAt = :now WHERE id = :id")
    suspend fun markPendingSync(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE field_location_reports SET syncStatus = 'SYNCED', remoteId = :remoteId, updatedAt = :now WHERE id = :id")
    suspend fun markSynced(id: Long, remoteId: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE field_location_reports SET syncStatus = 'SYNC_FAILED', updatedAt = :now WHERE id = :id")
    suspend fun markSyncFailed(id: Long, now: Long = System.currentTimeMillis())

    @Query("SELECT COUNT(*) FROM field_location_reports WHERE deletedAt IS NULL")
    fun observeReportCount(): Flow<Int>

    @Query("SELECT * FROM field_location_reports ORDER BY timestamp DESC")
    suspend fun getAllSnapshot(): List<FieldLocationReportEntity>

    @Query("DELETE FROM field_location_reports")
    suspend fun deleteAll()
}
