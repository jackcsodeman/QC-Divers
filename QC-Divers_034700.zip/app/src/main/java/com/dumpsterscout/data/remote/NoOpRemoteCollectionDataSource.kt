package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.CollectionEntity
import com.dumpsterscout.data.local.entity.CollectionItemEntity

/** Local-only remote stub for collection sync. */
class NoOpRemoteCollectionDataSource : RemoteCollectionDataSource {
    override suspend fun upsertCollection(collection: CollectionEntity, items: List<CollectionItemEntity>): String? =
        collection.remoteId ?: "local-collection-${collection.id}"

    override suspend fun deleteCollections(remoteIds: List<String>): Set<String> = remoteIds.toSet()

    override suspend fun fetchMyCollections(ownerUserId: String): List<CollectionEntity> = emptyList()
    override suspend fun fetchMyCollectionItems(ownerUserId: String) = emptyList<com.dumpsterscout.data.remote.dto.CollectionItemRow>()

}
