package com.dumpsterscout.data.remote

import com.dumpsterscout.domain.model.TireSpot

/**
 * Contract for the remote (Supabase) tire spot data source.
 *
 * Follows the same pattern as [RemoteSpotDataSource].
 * Bind [SupabaseTireSpotDataSource] via [com.dumpsterscout.di.RemoteModule] when live.
 */
interface RemoteTireSpotDataSource {

    /**
     * Push one or more locally-modified tire spots to the remote backend.
     * @return Map of localId → remoteId for successfully upserted spots.
     */
    suspend fun upsertTireSpots(spots: List<TireSpot>): Map<Long, String>

    /**
     * Soft-delete tire spots on the remote backend (set `deleted_at`).
     * @return Set of remoteIds that were successfully marked.
     */
    suspend fun deleteTireSpots(remoteIds: List<String>): Set<String>

    /**
     * Fetch all tire spots owned by [ownerUserId] from the backend.
     * @return List of domain spots with [com.dumpsterscout.domain.model.SyncStatus.SYNCED] set.
     */
    suspend fun fetchMyTireSpots(ownerUserId: String): List<TireSpot>

    /**
     * Fetch all tire spots with COMMUNITY or PUBLIC visibility from all users.
     */
    suspend fun fetchAllCommunityTireSpots(): List<TireSpot>
}

