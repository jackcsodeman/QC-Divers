package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.FieldLocationReportEntity
import com.dumpsterscout.data.remote.dto.FieldLocationReportRow
import com.dumpsterscout.data.remote.dto.toRow
import com.dumpsterscout.util.DsLogger
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.from

/** Supabase PostgREST implementation for generic field-location reports. */
class SupabaseFieldLocationReportDataSource(
    private val client: SupabaseClient
) : RemoteFieldLocationReportDataSource {

    override suspend fun upsertReports(
        reports: List<FieldLocationReportEntity>,
        fieldLocationRemoteIds: Map<Long, String?>
    ): Map<Long, String> {
        val result = mutableMapOf<Long, String>()
        val currentUserId = client.auth.currentUserOrNull()?.id
        for (report in reports) {
            try {
                val parentRemoteId = fieldLocationRemoteIds[report.id]
                val row = report.toRow(ownerId = currentUserId, fieldLocationRemoteId = parentRemoteId)
                val returned = if (report.remoteId.isNullOrBlank()) {
                    client.from(TABLE).insert(row) { select() }.decodeSingle<FieldLocationReportRow>()
                } else {
                    client.from(TABLE).upsert(row) { select() }.decodeSingle<FieldLocationReportRow>()
                }
                result[report.id] = returned.remoteId
            } catch (e: Exception) {
                DsLogger.e(TAG, "Failed to upsert field-location report.", e)
            }
        }
        return result
    }

    override suspend fun deleteReports(remoteIds: List<String>): Set<String> {
        val deleted = mutableSetOf<String>()
        val nowMillis = System.currentTimeMillis()
        for (id in remoteIds.filter { it.isNotBlank() }) {
            try {
                client.from(TABLE).update({ set("deleted_at", nowMillis) }) {
                    filter { eq("id", id) }
                }
                deleted.add(id)
            } catch (e: Exception) {
                DsLogger.e(TAG, "Failed to soft-delete field-location report.", e)
            }
        }
        return deleted
    }

    override suspend fun fetchMyReports(ownerUserId: String): List<FieldLocationReportRow> = try {
        client.from(TABLE)
            .select { filter { eq("owner_id", ownerUserId) } }
            .decodeList<FieldLocationReportRow>()
            .filter { it.deletedAt == null }
    } catch (e: Exception) {
        DsLogger.e(TAG, "Failed to fetch field-location reports for owner.", e)
        emptyList()
    }

    private companion object {
        const val TAG = "SupabaseFieldLocReportDS"
        const val TABLE = "field_location_reports"
    }
}
