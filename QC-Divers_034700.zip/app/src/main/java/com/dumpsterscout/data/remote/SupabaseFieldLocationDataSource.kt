package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.FieldLocationEntity
import com.dumpsterscout.data.remote.dto.FieldLocationRow
import com.dumpsterscout.data.remote.dto.toEntity
import com.dumpsterscout.data.remote.dto.toRow
import com.dumpsterscout.util.DsLogger
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.from

/** Supabase PostgREST implementation for generic cleanup/salvage/custom field locations. */
class SupabaseFieldLocationDataSource(
    private val client: SupabaseClient
) : RemoteFieldLocationDataSource {

    override suspend fun upsertFieldLocations(locations: List<FieldLocationEntity>): Map<Long, String> {
        val result = mutableMapOf<Long, String>()
        val currentUserId = client.auth.currentUserOrNull()?.id
        for (location in locations) {
            try {
                val row = location.toRow(ownerId = currentUserId)
                val returned = if (location.remoteId.isNullOrBlank()) {
                    client.from(TABLE).insert(row) { select() }.decodeSingle<FieldLocationRow>()
                } else {
                    client.from(TABLE).upsert(row) { select() }.decodeSingle<FieldLocationRow>()
                }
                result[location.id] = returned.remoteId
            } catch (e: Exception) {
                DsLogger.e(TAG, "Failed to upsert field location.", e)
            }
        }
        return result
    }

    override suspend fun deleteFieldLocations(remoteIds: List<String>): Set<String> {
        val deleted = mutableSetOf<String>()
        val nowMillis = System.currentTimeMillis()
        for (id in remoteIds) {
            try {
                client.from(TABLE).update({ set("deleted_at", nowMillis) }) {
                    filter { eq("id", id) }
                }
                deleted.add(id)
            } catch (e: Exception) {
                DsLogger.e(TAG, "Failed to soft-delete field location.", e)
            }
        }
        return deleted
    }

    override suspend fun fetchMyFieldLocations(ownerUserId: String): List<FieldLocationEntity> {
        return try {
            client.from(TABLE)
                .select { filter { eq("owner_id", ownerUserId) } }
                .decodeList<FieldLocationRow>()
                .filter { it.deletedAt == null }
                .map { it.toEntity() }
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to fetch field locations for owner.", e)
            emptyList()
        }
    }

    private companion object {
        const val TAG = "SupabaseFieldLocationDS"
        const val TABLE = "field_locations"
    }
}
