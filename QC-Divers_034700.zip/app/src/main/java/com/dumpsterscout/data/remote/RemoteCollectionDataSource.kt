package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.CollectionEntity
import com.dumpsterscout.data.local.entity.CollectionItemEntity
import com.dumpsterscout.data.remote.dto.CollectionItemRow

/** Remote contract for saved collections and their membership rows. */
interface RemoteCollectionDataSource {
    suspend fun upsertCollection(collection: CollectionEntity, items: List<CollectionItemEntity>): String?
    suspend fun deleteCollections(remoteIds: List<String>): Set<String>
    suspend fun fetchMyCollections(ownerUserId: String): List<CollectionEntity>
    suspend fun fetchMyCollectionItems(ownerUserId: String): List<CollectionItemRow>
}
