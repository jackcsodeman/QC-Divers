package com.dumpsterscout.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RewriteQueriesToDropUnusedColumns
import androidx.room.Update
import androidx.room.Upsert
import com.dumpsterscout.data.local.entity.DumpsterSpotEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DumpsterSpotDao {

    @Query("SELECT * FROM dumpster_spots WHERE isRetired = 0 ORDER BY updatedAt DESC")
    fun getAllActiveSpots(): Flow<List<DumpsterSpotEntity>>

    @Query("SELECT * FROM dumpster_spots ORDER BY updatedAt DESC")
    fun getAllSpots(): Flow<List<DumpsterSpotEntity>>

    @Query("SELECT * FROM dumpster_spots WHERE isFavorite = 1 AND isRetired = 0 ORDER BY updatedAt DESC")
    fun getFavoriteSpots(): Flow<List<DumpsterSpotEntity>>

    @Query("""
        SELECT * FROM dumpster_spots 
        WHERE isRetired = 0 AND (
            name LIKE '%' || :query || '%' OR 
            address LIKE '%' || :query || '%' OR 
            personalNotes LIKE '%' || :query || '%' OR 
            tags LIKE '%' || :query || '%' OR
            usualFindings LIKE '%' || :query || '%'
        )
        ORDER BY updatedAt DESC
    """)
    fun searchSpots(query: String): Flow<List<DumpsterSpotEntity>>

    @Query("SELECT * FROM dumpster_spots WHERE id = :id")
    suspend fun getSpotById(id: Long): DumpsterSpotEntity?

    @Query("SELECT * FROM dumpster_spots WHERE id = :id")
    fun observeSpotById(id: Long): Flow<DumpsterSpotEntity?>

    @RewriteQueriesToDropUnusedColumns
    @Query("""
        SELECT *, (
            (latitude - :lat) * (latitude - :lat) + 
            (longitude - :lng) * (longitude - :lng)
        ) AS distanceSq 
        FROM dumpster_spots 
        WHERE isRetired = 0
        ORDER BY distanceSq ASC
        LIMIT :limit
    """)
    suspend fun getNearestSpots(lat: Double, lng: Double, limit: Int = 20): List<DumpsterSpotEntity>

    @Upsert
    suspend fun upsert(spot: DumpsterSpotEntity): Long

    @Delete
    suspend fun delete(spot: DumpsterSpotEntity)

    @Query("UPDATE dumpster_spots SET lastStatus = :status, lastChecked = :timestamp, updatedAt = :timestamp WHERE id = :id")
    suspend fun updateLastStatus(id: Long, status: String, timestamp: Long)

    @Query("UPDATE dumpster_spots SET isFavorite = NOT isFavorite WHERE id = :id")
    suspend fun toggleFavorite(id: Long)

    @Query("UPDATE dumpster_spots SET isRetired = 1, updatedAt = :now WHERE id = :id")
    suspend fun retire(id: Long, now: Long = System.currentTimeMillis())

    @Query("SELECT COUNT(*) FROM dumpster_spots WHERE isRetired = 0")
    suspend fun countActiveSpots(): Int

    @Query("SELECT * FROM dumpster_spots ORDER BY updatedAt DESC")
    suspend fun getAllSpotsSnapshot(): List<DumpsterSpotEntity>

    @Query("SELECT * FROM dumpster_spots WHERE syncStatus = 'PENDING_SYNC' AND deletedAt IS NULL ORDER BY updatedAt ASC")
    suspend fun getPendingSyncSpots(): List<DumpsterSpotEntity>

    @Query("UPDATE dumpster_spots SET syncStatus = 'SYNCED', remoteId = :remoteId, updatedAt = :now WHERE id = :id")
    suspend fun markSynced(id: Long, remoteId: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE dumpster_spots SET syncStatus = 'SYNC_FAILED', updatedAt = :now WHERE id = :id")
    suspend fun markSyncFailed(id: Long, now: Long = System.currentTimeMillis())

    @Query("""
        UPDATE dumpster_spots
        SET visibility = 'COMMUNITY', syncStatus = 'PENDING_SYNC', updatedAt = :now
        WHERE id = :id
    """)
    suspend fun publishSpot(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE dumpster_spots SET syncStatus = 'PENDING_SYNC', updatedAt = :now WHERE id = :id")
    suspend fun markPendingSync(id: Long, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM dumpster_spots WHERE remoteId = :remoteId LIMIT 1")
    suspend fun getByRemoteId(remoteId: String): DumpsterSpotEntity?

    @Query("DELETE FROM dumpster_spots")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM dumpster_spots WHERE isRetired = 0")
    fun observeActiveSpotCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM dumpster_spots WHERE isRetired = 0 AND isFavorite = 1")
    fun observeFavoriteCount(): Flow<Int>

}
