package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.GearChecklistEntity
import com.dumpsterscout.data.local.entity.GearChecklistItemEntity

class NoOpRemoteGearChecklistDataSource : RemoteGearChecklistDataSource {
    override suspend fun upsertChecklist(checklist: GearChecklistEntity, items: List<GearChecklistItemEntity>): String? = null
    override suspend fun deleteChecklists(remoteIds: List<String>): Set<String> = emptySet()
    override suspend fun fetchMyChecklists(ownerUserId: String): List<GearChecklistEntity> = emptyList()
    override suspend fun fetchMyChecklistItems(ownerUserId: String) = emptyList<com.dumpsterscout.data.remote.dto.GearChecklistItemRow>()

}
