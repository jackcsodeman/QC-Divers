package com.dumpsterscout.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.dumpsterscout.data.local.entity.FieldLocationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FieldLocationDao {
    @Query("SELECT * FROM field_locations WHERE deletedAt IS NULL AND isArchived = 0 ORDER BY updatedAt DESC")
    fun observeActive(): Flow<List<FieldLocationEntity>>

    @Query("SELECT * FROM field_locations WHERE deletedAt IS NULL ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<FieldLocationEntity>>

    @Query("SELECT * FROM field_locations WHERE deletedAt IS NULL AND isFavorite = 1 ORDER BY updatedAt DESC")
    fun observeFavorites(): Flow<List<FieldLocationEntity>>

    @Query("SELECT * FROM field_locations WHERE deletedAt IS NULL AND id = :id LIMIT 1")
    suspend fun getById(id: Long): FieldLocationEntity?

    @Query("""
        SELECT * FROM field_locations
        WHERE deletedAt IS NULL AND (
            name LIKE '%' || :query || '%' OR
            description LIKE '%' || :query || '%' OR
            address LIKE '%' || :query || '%' OR
            tags LIKE '%' || :query || '%' OR
            safetyNotes LIKE '%' || :query || '%' OR
            hazardNotes LIKE '%' || :query || '%'
        )
        ORDER BY updatedAt DESC
    """)
    fun search(query: String): Flow<List<FieldLocationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(location: FieldLocationEntity): Long

    @Update
    suspend fun update(location: FieldLocationEntity)

    @Query("UPDATE field_locations SET isFavorite = NOT isFavorite, updatedAt = :now WHERE id = :id")
    suspend fun toggleFavorite(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE field_locations SET deletedAt = :now, updatedAt = :now WHERE id = :id")
    suspend fun softDelete(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE field_locations SET isArchived = 1, updatedAt = :now WHERE id = :id")
    suspend fun archive(id: Long, now: Long = System.currentTimeMillis())


    @Query("UPDATE field_locations SET syncStatus = 'PENDING_SYNC', updatedAt = :now WHERE id = :id")
    suspend fun markPendingSync(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE field_locations SET syncStatus = 'SYNCED', remoteId = :remoteId, updatedAt = :now WHERE id = :id")
    suspend fun markSynced(id: Long, remoteId: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE field_locations SET syncStatus = 'SYNC_FAILED', updatedAt = :now WHERE id = :id")
    suspend fun markSyncFailed(id: Long, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM field_locations WHERE remoteId = :remoteId LIMIT 1")
    suspend fun getByRemoteId(remoteId: String): FieldLocationEntity?

    @Query("SELECT COUNT(*) FROM field_locations WHERE deletedAt IS NULL")
    suspend fun countActive(): Int

    @Query("SELECT * FROM field_locations ORDER BY updatedAt DESC")
    suspend fun getAllSnapshot(): List<FieldLocationEntity>

    @Query("DELETE FROM field_locations")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM field_locations WHERE deletedAt IS NULL AND isArchived = 0")
    fun observeActiveCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM field_locations WHERE deletedAt IS NULL AND isFavorite = 1")
    fun observeFavoriteCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM field_locations WHERE deletedAt IS NULL AND cleanupPriority IN ('HIGH', 'URGENT')")
    fun observeHighPriorityCount(): Flow<Int>

}
