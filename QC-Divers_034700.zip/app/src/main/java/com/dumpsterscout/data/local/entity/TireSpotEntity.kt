package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * Room entity for tire spots.
 */
@Entity(tableName = "tire_spots")
@Serializable
data class TireSpotEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String = "OTHER",
    val address: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,

    // Access
    val accessNotes: String = "",
    val isFenced: Boolean = false,
    val isGated: Boolean = false,
    val isLocked: Boolean = false,
    val isExposed: Boolean = false,
    val easyAccess: Boolean = true,
    val hasCameras: Boolean = false,
    val securityCommon: Boolean = false,

    // Schedule
    val bestTimeOfDay: String = "VARIES",
    val bestDays: String = "",
    val betterOnWeekends: Boolean? = null,
    val isSeasonal: Boolean = false,
    val season: String = "YEAR_ROUND",
    val putsOutAroundClosing: Boolean = false,

    // Patterns
    val puncturePattern: String = "UNKNOWN",
    val usableDisappearFast: Boolean = false,
    val othersGetThereFirst: Boolean = false,
    val worthCheckingWhenLight: Boolean = false,
    val usuallyPutsOutMany: Boolean = false,

    // Meta
    val isVerified: Boolean = false,
    val isFavorite: Boolean = false,
    val isRetired: Boolean = false,
    val lastChecked: Long? = null,
    val lastStatus: String = "UNKNOWN",
    val notes: String = "",
    val tags: String = "",              // JSON array string
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),

    // Sync / backend-ready metadata
    val remoteId: String? = null,
    val ownerUserId: String? = null,
    val syncStatus: String = "LOCAL_ONLY",
    val deletedAt: Long? = null,
    val visibility: String = "PRIVATE"
)
