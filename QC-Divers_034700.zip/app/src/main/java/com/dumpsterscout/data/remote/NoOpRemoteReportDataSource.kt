package com.dumpsterscout.data.remote

import com.dumpsterscout.util.DsLogger
import com.dumpsterscout.data.remote.dto.ReportRow
import com.dumpsterscout.data.remote.dto.TireReportRow
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.TireReport
import javax.inject.Inject

/**
 * No-op [RemoteReportDataSource] used while the Supabase backend is not yet live.
 */
class NoOpRemoteReportDataSource @Inject constructor() : RemoteReportDataSource {

    override suspend fun upsertReports(
        reports: List<PersonalReport>,
        spotRemoteIds: Map<Long, String?>
    ): Map<Long, String> {
        DsLogger.d(TAG, "upsertReports: no-op (${reports.size}). Wire up Supabase to activate.")
        return emptyMap()
    }

    override suspend fun upsertTireReports(
        reports: List<TireReport>,
        tireSpotRemoteIds: Map<Long, String?>
    ): Map<Long, String> {
        DsLogger.d(TAG, "upsertTireReports: no-op (${reports.size}). Wire up Supabase to activate.")
        return emptyMap()
    }


    override suspend fun deleteReports(remoteIds: List<String>): Set<String> {
        DsLogger.d(TAG, "deleteReports: no-op (${remoteIds.size}). Wire up Supabase to activate.")
        return emptySet()
    }

    override suspend fun deleteTireReports(remoteIds: List<String>): Set<String> {
        DsLogger.d(TAG, "deleteTireReports: no-op (${remoteIds.size}). Wire up Supabase to activate.")
        return emptySet()
    }

    override suspend fun fetchMyReports(ownerUserId: String): List<ReportRow> {
        DsLogger.d(TAG, "fetchMyReports: no-op. Wire up Supabase to activate.")
        return emptyList()
    }

    override suspend fun fetchMyTireReports(ownerUserId: String): List<TireReportRow> {
        DsLogger.d(TAG, "fetchMyTireReports: no-op. Wire up Supabase to activate.")
        return emptyList()
    }

    private companion object {
        const val TAG = "NoOpRemoteReportDS"
    }
}
