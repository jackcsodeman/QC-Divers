package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.ReminderEntity

interface RemoteReminderDataSource {
    suspend fun upsertReminders(reminders: List<ReminderEntity>, locationRemoteIds: Map<Long, String>): Map<Long, String>
    suspend fun deleteReminders(remoteIds: List<String>): Set<String>
    suspend fun fetchMyReminders(ownerUserId: String): List<ReminderEntity>
}
