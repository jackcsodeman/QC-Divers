package com.dumpsterscout.data.repository

import com.dumpsterscout.data.local.dao.DumpsterSpotDao
import com.dumpsterscout.data.local.dao.GearChecklistDao
import com.dumpsterscout.data.local.dao.FieldSessionDao
import com.dumpsterscout.data.local.dao.FieldLocationDao
import com.dumpsterscout.data.local.dao.FieldLocationReportDao
import com.dumpsterscout.data.local.dao.CollectionDao
import com.dumpsterscout.data.local.dao.PersonalReportDao
import com.dumpsterscout.data.local.dao.ReminderDao
import com.dumpsterscout.data.local.dao.RoutePlanDao
import com.dumpsterscout.data.local.dao.SpotPhotoDao
import com.dumpsterscout.data.local.dao.SyncQueueDao
import com.dumpsterscout.data.local.dao.TireReportDao
import com.dumpsterscout.data.local.dao.TireSpotDao
import com.dumpsterscout.notifications.ReminderScheduler
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Destructive local maintenance operations used by Settings.
 *
 * Kept separate from feature repositories so the UI can offer an honest
 * "clear local data" action that covers all currently persisted tables.
 */
@Singleton
class LocalDataMaintenance @Inject constructor(
    private val spotDao: DumpsterSpotDao,
    private val reportDao: PersonalReportDao,
    private val photoDao: SpotPhotoDao,
    private val routePlanDao: RoutePlanDao,
    private val reminderDao: ReminderDao,
    private val tireSpotDao: TireSpotDao,
    private val tireReportDao: TireReportDao,
    private val fieldLocationDao: FieldLocationDao,
    private val fieldLocationReportDao: FieldLocationReportDao,
    private val collectionDao: CollectionDao,
    private val fieldSessionDao: FieldSessionDao,
    private val gearChecklistDao: GearChecklistDao,
    private val syncQueueDao: SyncQueueDao,
    private val reminderScheduler: ReminderScheduler
) {
    suspend fun clearAllLocalData() {
        reminderDao.getAllRemindersSnapshot().forEach { reminderScheduler.cancel(it.id) }
        syncQueueDao.deleteAll()
        photoDao.deleteAll()
        reminderDao.deleteAll()
        gearChecklistDao.deleteAll()
        fieldSessionDao.deleteAll()
        collectionDao.deleteAll()
        routePlanDao.deleteAll()
        fieldLocationReportDao.deleteAll()
        fieldLocationDao.deleteAll()
        tireReportDao.deleteAll()
        reportDao.deleteAll()
        tireSpotDao.deleteAll()
        spotDao.deleteAll()
    }
}
