package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * Room entity for reminders tied to a spot.
 *
 * Dumpster reminders still keep the legacy spotId foreign key for local UX, but
 * sync metadata is generic enough for future tire/field-location reminders.
 */
@Entity(
    tableName = "reminders",
    foreignKeys = [
        ForeignKey(
            entity = DumpsterSpotEntity::class,
            parentColumns = ["id"],
            childColumns = ["spotId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("spotId"),
        Index("remoteId"),
        Index("syncStatus"),
        Index("deletedAt"),
        Index("completedAt"),
        Index("snoozedUntil")
    ]
)
@Serializable
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val remoteId: String? = null,
    val ownerUserId: String? = null,
    val spotId: Long,
    val locationType: String = "DUMPSTER_SPOT",
    val locationRemoteId: String? = null,
    val label: String = "",
    /** Weekday: 1=Sun … 7=Sat, or 0 for one-time */
    val dayOfWeek: Int = 0,
    val timeHour: Int = 20,
    val timeMinute: Int = 0,
    val isActive: Boolean = true,
    val syncStatus: String = "LOCAL_ONLY",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null,
    val completedAt: Long? = null,
    val snoozedUntil: Long? = null
)
