package com.dumpsterscout.data.remote

import com.dumpsterscout.domain.model.DumpsterSpot

/**
 * Contract for the remote (Supabase) spot data source.
 *
 * All methods are suspend functions that talk directly to the network layer.
 * Repositories use this interface via the [@RemoteSource] Hilt qualifier so the
 * local-only stub can be swapped for a real implementation without touching
 * the repository code.
 *
 * When Supabase is activated:
 * 1. Add `implementation(platform(libs.supabase.bom))` etc. in build.gradle.kts.
 * 2. Create `SupabaseSpotDataSource` that injects the `SupabaseClient` and calls
 *    `supabase.from("spots").upsert(...)`, etc.
 * 3. Rebind `@RemoteSource RemoteSpotDataSource` → `SupabaseSpotDataSource` in
 *    `RemoteModule`.
 */
interface RemoteSpotDataSource {

    /**
     * Push one or more locally-modified spots to the remote backend.
     * @return Map of localId → remoteId for successfully upserted spots.
     */
    suspend fun upsertSpots(spots: List<DumpsterSpot>): Map<Long, String>

    /**
     * Mark spots as deleted on the remote backend (soft-delete via `deleted_at`).
     * @return Set of remoteIds that were successfully deleted.
     */
    suspend fun deleteSpots(remoteIds: List<String>): Set<String>

    /**
     * Fetch all spots owned by [ownerUserId] from the backend.
     * Used to pull the user's private/public synced spots back to a new install.
     * @return List of domain spots with [SyncStatus.SYNCED] set.
     */
    suspend fun fetchMySpots(ownerUserId: String): List<DumpsterSpot>

    /**
     * Fetch all spots with COMMUNITY or PUBLIC visibility from all users.
     * Used for the Community Explorer map and list.
     */
    suspend fun fetchAllCommunitySpots(): List<DumpsterSpot>
}

