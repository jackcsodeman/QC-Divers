package com.dumpsterscout.data.remote.dto

import com.dumpsterscout.data.local.entity.FieldLocationReportEntity
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** Remote DTO for the `field_location_reports` Supabase table. */
@Serializable
data class FieldLocationReportRow(
    @SerialName("id") val remoteId: String = "",
    @SerialName("owner_id") val ownerId: String? = null,
    @SerialName("field_location_id") val fieldLocationRemoteId: String?,
    @SerialName("location_name") val locationName: String,
    @SerialName("report_type") val reportType: String,
    @SerialName("status") val status: String,
    @SerialName("access_status") val accessStatus: String,
    @SerialName("hazard_level") val hazardLevel: String,
    @SerialName("cleanup_status") val cleanupStatus: String,
    @SerialName("cleanup_progress") val cleanupProgress: Int,
    @SerialName("findings") val findings: String,
    @SerialName("notes") val notes: String,
    @SerialName("photo_uris") val photoUris: String,
    @SerialName("voice_transcript") val voiceTranscript: String?,
    @SerialName("is_from_voice") val isFromVoice: Boolean,
    @SerialName("latitude") val latitude: Double?,
    @SerialName("longitude") val longitude: Double?,
    @SerialName("visibility") val visibility: String,
    @SerialName("timestamp") val timestamp: Long,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: Long,
    @SerialName("deleted_at") val deletedAt: Long?
)

fun FieldLocationReportEntity.toRow(
    ownerId: String? = null,
    fieldLocationRemoteId: String? = null
): FieldLocationReportRow = FieldLocationReportRow(
    remoteId = remoteId.orEmpty(),
    ownerId = ownerId ?: ownerUserId,
    fieldLocationRemoteId = fieldLocationRemoteId,
    locationName = locationName,
    reportType = reportType,
    status = status,
    accessStatus = accessStatus,
    hazardLevel = hazardLevel,
    cleanupStatus = cleanupStatus,
    cleanupProgress = cleanupProgress,
    findings = findings,
    notes = notes,
    photoUris = photoUris,
    voiceTranscript = voiceTranscript,
    isFromVoice = isFromVoice,
    latitude = latitude,
    longitude = longitude,
    visibility = visibility,
    timestamp = timestamp,
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)

fun FieldLocationReportRow.toEntity(localFieldLocationId: Long): FieldLocationReportEntity = FieldLocationReportEntity(
    fieldLocationId = localFieldLocationId,
    locationName = locationName,
    reportType = reportType,
    status = status,
    accessStatus = accessStatus,
    hazardLevel = hazardLevel,
    cleanupStatus = cleanupStatus,
    cleanupProgress = cleanupProgress,
    findings = findings,
    notes = notes,
    photoUris = photoUris,
    voiceTranscript = voiceTranscript,
    isFromVoice = isFromVoice,
    latitude = latitude,
    longitude = longitude,
    timestamp = timestamp,
    createdAt = createdAt,
    updatedAt = updatedAt,
    remoteId = remoteId.ifBlank { null },
    ownerUserId = ownerId,
    syncStatus = "SYNCED",
    visibility = visibility,
    deletedAt = deletedAt
)
