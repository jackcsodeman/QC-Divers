package com.dumpsterscout.data.repository

import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import androidx.room.withTransaction
import com.dumpsterscout.data.local.DumpsterScoutDatabase
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

data class BackupImportResult(
    val restoredTables: Int,
    val restoredRows: Int
)

data class BackupTablePreview(
    val tableName: String,
    val rowCount: Int,
    val isKnownTable: Boolean
)

data class BackupImportPreview(
    val format: String,
    val schemaVersion: Int,
    val exportedAt: Long,
    val tablePreviews: List<BackupTablePreview>,
    val unknownTables: List<String>,
    val missingTables: List<String>
) {
    val totalRows: Int = tablePreviews.sumOf { it.rowCount }
    val knownTablesWithRows: Int = tablePreviews.count { it.isKnownTable && it.rowCount > 0 }
}

/**
 * Full local backup/restore for every Room table currently owned by the app.
 *
 * This intentionally exports the local source-of-truth database, including
 * pending sync queue items. Cloud data is not fetched here; signed-in users can
 * sync separately before exporting if they want a cloud-complete backup.
 */
@Singleton
class LocalBackupRepository @Inject constructor(
    private val database: DumpsterScoutDatabase,
    private val dataMaintenance: LocalDataMaintenance
) {
    suspend fun exportBackup(): String {
        val db = database.openHelper.readableDatabase
        val root = JSONObject()
            .put("format", BACKUP_FORMAT)
            .put("schemaVersion", BACKUP_SCHEMA_VERSION)
            .put("exportedAt", System.currentTimeMillis())
            .put("tables", JSONObject())

        val tables = root.getJSONObject("tables")
        for (table in TABLES) {
            val rows = JSONArray()
            db.query("SELECT * FROM `$table`").use { cursor ->
                while (cursor.moveToNext()) rows.put(cursor.toJsonObject())
            }
            tables.put(table, rows)
        }
        return root.toString(2)
    }

    fun previewImport(json: String): BackupImportPreview {
        val root = JSONObject(json)
        require(root.optString("format") == BACKUP_FORMAT) {
            "Unsupported backup format. Expected $BACKUP_FORMAT."
        }
        val schemaVersion = root.optInt("schemaVersion", 0)
        require(schemaVersion in 1..BACKUP_SCHEMA_VERSION) {
            "Unsupported backup schema version $schemaVersion. This app supports up to $BACKUP_SCHEMA_VERSION."
        }
        val tables = root.getJSONObject("tables")
        val names = tables.keys().asSequence().toSet()
        val known = TABLES.toSet()
        val previews = names.sorted().map { table ->
            BackupTablePreview(
                tableName = table,
                rowCount = tables.optJSONArray(table)?.length() ?: 0,
                isKnownTable = table in known
            )
        }
        return BackupImportPreview(
            format = root.optString("format"),
            schemaVersion = schemaVersion,
            exportedAt = root.optLong("exportedAt", 0L),
            tablePreviews = previews,
            unknownTables = (names - known).sorted(),
            missingTables = (known - names).sorted()
        )
    }

    suspend fun importBackup(json: String): BackupImportResult {
        val preview = previewImport(json)
        require(preview.unknownTables.isEmpty()) {
            "Backup includes unsupported tables: ${preview.unknownTables.joinToString()}"
        }
        val root = JSONObject(json)
        val tables = root.getJSONObject("tables")
        var restoredTables = 0
        var restoredRows = 0

        database.withTransaction {
            dataMaintenance.clearAllLocalData()
            val db = database.openHelper.writableDatabase
            for (table in TABLES) {
                val rows = tables.optJSONArray(table) ?: continue
                for (i in 0 until rows.length()) {
                    db.insert(table, SQLiteDatabase.CONFLICT_REPLACE, rows.getJSONObject(i).toContentValues())
                    restoredRows++
                }
                restoredTables++
            }
        }

        return BackupImportResult(restoredTables = restoredTables, restoredRows = restoredRows)
    }

    private fun Cursor.toJsonObject(): JSONObject {
        val row = JSONObject()
        for (index in 0 until columnCount) {
            val name = getColumnName(index)
            when (getType(index)) {
                Cursor.FIELD_TYPE_NULL -> row.put(name, JSONObject.NULL)
                Cursor.FIELD_TYPE_INTEGER -> row.put(name, getLong(index))
                Cursor.FIELD_TYPE_FLOAT -> row.put(name, getDouble(index))
                Cursor.FIELD_TYPE_STRING -> row.put(name, getString(index))
                Cursor.FIELD_TYPE_BLOB -> row.put(name, getBlob(index).joinToString(separator = ","))
            }
        }
        return row
    }

    private fun JSONObject.toContentValues(): ContentValues {
        val values = ContentValues()
        val keys = keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val value = get(key)
            when {
                value === JSONObject.NULL -> values.putNull(key)
                value is String -> values.put(key, value)
                value is Boolean -> values.put(key, value)
                value is Number && value.toString().contains('.') -> values.put(key, value.toDouble())
                value is Number -> values.put(key, value.toLong())
                else -> values.put(key, value.toString())
            }
        }
        return values
    }

    private companion object {
        const val BACKUP_FORMAT = "dumpster-scout-local-backup"
        const val BACKUP_SCHEMA_VERSION = 1
        val TABLES = listOf(
            "dumpster_spots",
            "tire_spots",
            "personal_reports",
            "tire_reports",
            "spot_photos",
            "route_plans",
            "route_stops",
            "reminders",
            "field_locations",
            "field_location_reports",
            "collections",
            "collection_items",
            "field_sessions",
            "field_session_visits",
            "gear_checklists",
            "gear_checklist_items",
            "sync_queue"
        )
    }
}
