package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * Room entity for dumpster spots.
 */
@Entity(tableName = "dumpster_spots")
@Serializable
data class DumpsterSpotEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String = "OTHER",
    val address: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,

    // Access
    val accessNotes: String = "",
    val spotLocation: String = "OTHER",
    val isFenced: Boolean = false,
    val isGated: Boolean = false,
    val isLocked: Boolean = false,
    val isCompactor: Boolean = false,
    val hasMultipleDumpsters: Boolean = false,
    val dumpsterCount: Int = 1,
    val dumpsterLabels: String = "",
    val lidEasyToOpen: Boolean = true,
    val parkingEasy: Boolean = true,
    val distanceFromRoad: String = "",
    val vehicleAccessNotes: String = "",

    // Safety
    val lightingNotes: String = "",
    val safetyNotes: String = "",
    val securityCommon: Boolean = false,
    val hasCameras: Boolean = false,
    val isWellLit: Boolean = false,
    val isHiddenFromRoad: Boolean = false,

    // Schedule
    val pickupDays: String = "",
    val pickupTimeWindow: String = "",
    val bestTimeOfDay: String = "VARIES",
    val betterOnWeekends: Boolean? = null,
    val bestSeason: String = "YEAR_ROUND",
    val worthCheckingAfterPickup: Boolean = false,
    val bestBeforePickupDay: Boolean = false,
    val throwsOutNearClosingTime: Boolean = false,
    val checkMoreThanOncePerWeek: Boolean = false,
    val worstDay: String = "",

    // Findings
    val usualFindings: String = "",
    val goodFindsCategories: String = "",
    val avoidReasons: String = "",
    val staffDestroyItems: Boolean = false,
    val worthCheckingWhenEmpty: Boolean = false,
    val usuallyMessy: Boolean = false,
    val hasSharpHazards: Boolean = false,
    val hasSealed: Boolean = false,
    val checkedByOtherDivers: Boolean = false,
    val betterEarlierInNight: Boolean = true,

    // Condition
    val conditionSmell: String = "",
    val conditionPests: Boolean = false,
    val conditionMoisture: Boolean = false,

    // Gear
    val recommendedGear: String = "",

    // Grade — stored as flat columns
    val gradeOverall: Float = 0f,
    val gradeConsistency: Float = 0f,
    val gradeQuality: Float = 0f,
    val gradeQuantity: Float = 0f,
    val gradeCleanliness: Float = 0f,
    val gradeRisk: Float = 0f,
    val gradeAccessDifficulty: Float = 0f,
    val gradeLegalSensitivity: Float = 0f,

    // Meta
    val personalNotes: String = "",
    val tags: String = "",               // JSON array string
    val isFavorite: Boolean = false,
    val isVerified: Boolean = false,
    val isRetired: Boolean = false,
    val lastChecked: Long? = null,
    val lastStatus: String = "UNKNOWN",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),

    // Sync / backend-ready metadata
    val remoteId: String? = null,
    val ownerUserId: String? = null,
    val syncStatus: String = "LOCAL_ONLY",
    val deletedAt: Long? = null,
    val visibility: String = "PRIVATE"
)
