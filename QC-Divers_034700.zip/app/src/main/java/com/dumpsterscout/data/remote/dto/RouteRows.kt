package com.dumpsterscout.data.remote.dto

import com.dumpsterscout.data.local.entity.RoutePlanEntity
import com.dumpsterscout.data.local.entity.RouteStopEntity
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** Remote DTO for the `route_plans` Supabase table. */
@Serializable
data class RoutePlanRow(
    @SerialName("id") val remoteId: String = "",
    @SerialName("owner_id") val ownerId: String? = null,
    @SerialName("name") val name: String,
    @SerialName("notes") val notes: String,
    @SerialName("visibility") val visibility: String,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: Long,
    @SerialName("deleted_at") val deletedAt: Long?
)

/** Remote DTO for the `route_stops` Supabase table. */
@Serializable
data class RouteStopRow(
    @SerialName("id") val remoteId: String = "",
    @SerialName("owner_id") val ownerId: String? = null,
    @SerialName("route_id") val routeRemoteId: String,
    @SerialName("location_type") val locationType: String,
    @SerialName("location_remote_id") val locationRemoteId: String? = null,
    @SerialName("label") val label: String = "",
    @SerialName("latitude") val latitude: Double = 0.0,
    @SerialName("longitude") val longitude: Double = 0.0,
    @SerialName("sort_order") val sortOrder: Int,
    @SerialName("notes") val notes: String,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: Long,
    @SerialName("deleted_at") val deletedAt: Long?
)

fun RoutePlanEntity.toRow(ownerId: String? = null): RoutePlanRow = RoutePlanRow(
    remoteId = remoteId.orEmpty(),
    ownerId = ownerId ?: ownerUserId,
    name = name,
    notes = notes,
    visibility = visibility,
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)

fun RoutePlanRow.toEntity(): RoutePlanEntity = RoutePlanEntity(
    remoteId = remoteId.ifBlank { null },
    ownerUserId = ownerId,
    name = name,
    notes = notes,
    visibility = visibility,
    syncStatus = "SYNCED",
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)

fun RouteStopEntity.toRow(routeRemoteId: String, ownerId: String? = null, locationRemoteId: String? = null): RouteStopRow = RouteStopRow(
    remoteId = remoteId.orEmpty(),
    ownerId = ownerId ?: ownerUserId,
    routeRemoteId = routeRemoteId,
    locationType = locationType,
    locationRemoteId = locationRemoteId,
    label = label,
    latitude = latitude,
    longitude = longitude,
    sortOrder = sortOrder,
    notes = notes,
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)


fun RouteStopRow.toEntity(routeId: Long, locationId: Long): RouteStopEntity = RouteStopEntity(
    remoteId = remoteId.ifBlank { null },
    ownerUserId = ownerId,
    routeId = routeId,
    locationType = locationType,
    locationId = locationId,
    label = label,
    latitude = latitude,
    longitude = longitude,
    sortOrder = sortOrder,
    notes = notes,
    syncStatus = "SYNCED",
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)
