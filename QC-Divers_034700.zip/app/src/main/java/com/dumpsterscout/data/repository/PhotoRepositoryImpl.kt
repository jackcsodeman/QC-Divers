package com.dumpsterscout.data.repository

import com.dumpsterscout.data.local.dao.SpotPhotoDao
import com.dumpsterscout.data.mapper.toDomain
import com.dumpsterscout.data.mapper.toSpotPhotoEntity
import com.dumpsterscout.data.sync.SyncEntityType
import com.dumpsterscout.data.sync.SyncQueueOperation
import com.dumpsterscout.data.sync.SyncQueueWriter
import com.dumpsterscout.domain.model.PhotoAttachment
import com.dumpsterscout.domain.repository.PhotoRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PhotoRepositoryImpl @Inject constructor(
    private val dao: SpotPhotoDao,
    private val syncQueue: SyncQueueWriter
) : PhotoRepository {

    override fun getPhotosForSpot(spotId: Long): Flow<List<PhotoAttachment>> =
        dao.getPhotosForSpot(spotId).map { entities -> entities.map { it.toDomain() } }

    override fun getPhotosForOwner(ownerType: String, ownerId: Long): Flow<List<PhotoAttachment>> =
        dao.getPhotosForOwner(ownerType, ownerId).map { entities -> entities.map { it.toDomain() } }

    override suspend fun getPhotoById(id: Long): PhotoAttachment? =
        dao.getById(id)?.toDomain()

    override suspend fun addPhoto(photo: PhotoAttachment): Long {
        val entity = photo.toSpotPhotoEntity()
        val id = dao.insert(entity)
        syncQueue.enqueue(
            entityType = SyncEntityType.PHOTO,
            entityLocalId = id,
            entityRemoteId = entity.remoteUrl,
            operation = SyncQueueOperation.UPLOAD_PHOTO,
            payload = Json.encodeToString(entity.copy(id = id))
        )
        return id
    }

    override suspend fun updatePhoto(photo: PhotoAttachment) {
        val entity = photo.toSpotPhotoEntity()
        dao.update(entity)
        if (photo.id > 0L) {
            syncQueue.enqueue(
                entityType = SyncEntityType.PHOTO,
                entityLocalId = photo.id,
                entityRemoteId = entity.remoteUrl,
                operation = SyncQueueOperation.UPLOAD_PHOTO,
                payload = Json.encodeToString(entity)
            )
        }
    }

    override suspend fun softDeletePhoto(id: Long) {
        val beforeDelete = dao.getById(id)
        dao.softDelete(id)
        syncQueue.enqueue(
            entityType = SyncEntityType.PHOTO,
            entityLocalId = id,
            entityRemoteId = beforeDelete?.remoteUrl,
            operation = SyncQueueOperation.DELETE_PHOTO,
            payload = Json.encodeToString(mapOf("id" to id, "remoteUrl" to beforeDelete?.remoteUrl, "deletedAt" to System.currentTimeMillis()))
        )
    }

    override suspend fun deleteAllForSpot(spotId: Long) =
        dao.deleteAllForSpot(spotId)

    override suspend fun deleteAllForOwner(ownerType: String, ownerId: Long) =
        dao.deleteAllForOwner(ownerType, ownerId)

    override suspend fun getPendingUploadPhotos(): List<PhotoAttachment> =
        dao.getPendingUploadPhotos().map { it.toDomain() }

    override suspend fun markUploaded(id: Long, remoteUrl: String) =
        dao.markUploaded(id, remoteUrl)

    override suspend fun markUploadFailed(id: Long) =
        dao.markUploadFailed(id)
}
