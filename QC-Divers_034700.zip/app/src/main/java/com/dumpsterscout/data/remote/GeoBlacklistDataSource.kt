package com.dumpsterscout.data.remote

/**
 * Data source for identifying sensitive areas where community sharing is restricted.
 */
interface GeoBlacklistDataSource {
    /**
     * Returns true if the given coordinates fall within a restricted zone.
     *
     * @param latitude The decimal latitude.
     * @param longitude The decimal longitude.
     * @return True if the area is blacklisted for public content.
     */
    suspend fun isRestrictedArea(latitude: Double, longitude: Double): Boolean
}

/**
 * Production implementation of [GeoBlacklistDataSource] using spatial logic.
 */
class GeoBlacklistDataSourceImpl : GeoBlacklistDataSource {
    /**
     * Checks if the given [latitude] and [longitude] are in a restricted zone.
     *
     * @param latitude The decimal latitude.
     * @param longitude The decimal longitude.
     * @return True if the location is blacklisted.
     */
    override suspend fun isRestrictedArea(latitude: Double, longitude: Double): Boolean {
        // Production: Query a spatial database or local Geo-JSON set.
        // For now, simple bounding box mock for a hypothetical school zone.
        val restrictedZones = listOf(
            RestrictedZone(41.524, -90.575, 0.002) 
        )
        
        return restrictedZones.any { zone ->
            Math.abs(latitude - zone.lat) < zone.radius && 
            Math.abs(longitude - zone.lon) < zone.radius
        }
    }

    /**
     * Internal representation of a restricted circular or box-like zone.
     * 
     * @property lat Decimal latitude of the zone center.
     * @property lon Decimal longitude of the zone center.
     * @property radius The approximate radius of the restricted zone in degrees.
     */
    private data class RestrictedZone(
        val lat: Double, 
        val lon: Double, 
        val radius: Double
    )
}
