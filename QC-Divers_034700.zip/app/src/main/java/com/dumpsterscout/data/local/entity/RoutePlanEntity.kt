package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * Room entity for saved route plans.
 *
 * Stops are normalized into route_stops. The legacy spotIds JSON field remains
 * for backup compatibility with earlier app versions, but new UI reads stops.
 */
@Entity(
    tableName = "route_plans",
    indices = [
        Index("updatedAt"),
        Index("syncStatus"),
        Index("visibility")
    ]
)
@Serializable
data class RoutePlanEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val remoteId: String? = null,
    val ownerUserId: String? = null,
    val name: String,
    val spotIds: String = "",
    val notes: String = "",
    val visibility: String = "PRIVATE",
    val syncStatus: String = "LOCAL_ONLY",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)
