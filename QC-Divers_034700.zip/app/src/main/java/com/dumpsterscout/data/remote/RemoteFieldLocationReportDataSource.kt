package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.FieldLocationReportEntity
import com.dumpsterscout.data.remote.dto.FieldLocationReportRow

/** Remote data source for cleanup/salvage/custom field-location reports. */
interface RemoteFieldLocationReportDataSource {
    suspend fun upsertReports(
        reports: List<FieldLocationReportEntity>,
        fieldLocationRemoteIds: Map<Long, String?> = emptyMap()
    ): Map<Long, String>

    suspend fun deleteReports(remoteIds: List<String>): Set<String>

    /** Returns raw rows so the worker can resolve each parent field_location_id locally before insert. */
    suspend fun fetchMyReports(ownerUserId: String): List<FieldLocationReportRow>
}
