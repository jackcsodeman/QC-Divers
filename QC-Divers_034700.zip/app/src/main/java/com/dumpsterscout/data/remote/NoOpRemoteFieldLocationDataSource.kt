package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.FieldLocationEntity

/** Local-only field-location remote source. */
class NoOpRemoteFieldLocationDataSource : RemoteFieldLocationDataSource {
    override suspend fun upsertFieldLocations(locations: List<FieldLocationEntity>): Map<Long, String> = emptyMap()
    override suspend fun deleteFieldLocations(remoteIds: List<String>): Set<String> = emptySet()
    override suspend fun fetchMyFieldLocations(ownerUserId: String): List<FieldLocationEntity> = emptyList()
}
