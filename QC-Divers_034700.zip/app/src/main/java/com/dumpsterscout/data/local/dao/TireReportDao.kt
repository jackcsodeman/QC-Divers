package com.dumpsterscout.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.dumpsterscout.data.local.entity.TireReportEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TireReportDao {

    @Query("SELECT * FROM tire_reports ORDER BY timestamp DESC")
    fun getAllReports(): Flow<List<TireReportEntity>>

    @Query("SELECT * FROM tire_reports WHERE tireSpotId = :spotId ORDER BY timestamp DESC")
    fun getReportsBySpot(spotId: Long): Flow<List<TireReportEntity>>

    @Query("SELECT * FROM tire_reports ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentReports(limit: Int): Flow<List<TireReportEntity>>

    @Query("SELECT * FROM tire_reports WHERE id = :id")
    suspend fun getReportById(id: Long): TireReportEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(report: TireReportEntity): Long

    @Update
    suspend fun update(report: TireReportEntity)

    @Delete
    suspend fun delete(report: TireReportEntity)

    @Query("DELETE FROM tire_reports")
    suspend fun deleteAll()

    @Query("SELECT * FROM tire_reports WHERE syncStatus = 'PENDING_SYNC' AND deletedAt IS NULL ORDER BY updatedAt ASC")
    suspend fun getPendingSyncReports(): List<TireReportEntity>

    @Query("UPDATE tire_reports SET syncStatus = 'SYNCED', remoteId = :remoteId, updatedAt = :now WHERE id = :id")
    suspend fun markSynced(id: Long, remoteId: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE tire_reports SET syncStatus = 'SYNC_FAILED', updatedAt = :now WHERE id = :id")
    suspend fun markSyncFailed(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE tire_reports SET visibility = 'COMMUNITY', syncStatus = 'PENDING_SYNC', updatedAt = :now WHERE id = :id")
    suspend fun publishReport(id: Long, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM tire_reports WHERE remoteId = :remoteId LIMIT 1")
    suspend fun getByRemoteId(remoteId: String): TireReportEntity?

    @Query("SELECT COUNT(*) FROM tire_reports WHERE deletedAt IS NULL")
    fun getReportCount(): Flow<Int>

}
