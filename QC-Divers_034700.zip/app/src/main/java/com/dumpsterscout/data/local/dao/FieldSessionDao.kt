package com.dumpsterscout.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.dumpsterscout.data.local.entity.FieldSessionEntity
import com.dumpsterscout.data.local.entity.FieldSessionVisitEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FieldSessionDao {
    @Query("SELECT * FROM field_sessions WHERE deletedAt IS NULL ORDER BY startedAt DESC")
    fun observeSessions(): Flow<List<FieldSessionEntity>>

    @Query("SELECT * FROM field_sessions WHERE deletedAt IS NULL AND endedAt IS NULL ORDER BY startedAt DESC LIMIT 1")
    fun observeActiveSession(): Flow<FieldSessionEntity?>

    @Query("SELECT * FROM field_session_visits ORDER BY visitedAt DESC")
    fun observeVisits(): Flow<List<FieldSessionVisitEntity>>

    @Query("SELECT * FROM field_session_visits WHERE sessionId = :sessionId ORDER BY visitedAt DESC")
    fun observeVisitsForSession(sessionId: Long): Flow<List<FieldSessionVisitEntity>>

    @Query("SELECT * FROM field_sessions WHERE id = :id LIMIT 1")
    suspend fun getSessionById(id: Long): FieldSessionEntity?

    @Query("SELECT * FROM field_sessions WHERE remoteId = :remoteId LIMIT 1")
    suspend fun getSessionByRemoteId(remoteId: String): FieldSessionEntity?

    @Query("SELECT * FROM field_session_visits WHERE id = :id LIMIT 1")
    suspend fun getVisitById(id: Long): FieldSessionVisitEntity?

    @Query("SELECT * FROM field_session_visits WHERE remoteId = :remoteId LIMIT 1")
    suspend fun getVisitByRemoteId(remoteId: String): FieldSessionVisitEntity?

    @Query("SELECT * FROM field_session_visits WHERE sessionId = :sessionId ORDER BY visitedAt DESC")
    suspend fun getVisitsForSessionSnapshot(sessionId: Long): List<FieldSessionVisitEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: FieldSessionEntity): Long

    @Update
    suspend fun updateSession(session: FieldSessionEntity)

    @Query("UPDATE field_sessions SET endedAt = :endedAt, updatedAt = :endedAt, syncStatus = 'PENDING_SYNC' WHERE id = :id")
    suspend fun endSession(id: Long, endedAt: Long = System.currentTimeMillis())

    @Query("UPDATE field_sessions SET syncStatus = 'PENDING_SYNC', updatedAt = :now WHERE id = :id")
    suspend fun markPendingSync(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE field_sessions SET syncStatus = 'SYNCED', remoteId = :remoteId, updatedAt = :now WHERE id = :id")
    suspend fun markSynced(id: Long, remoteId: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE field_sessions SET syncStatus = 'SYNC_FAILED', updatedAt = :now WHERE id = :id")
    suspend fun markSyncFailed(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE field_sessions SET deletedAt = :now, updatedAt = :now WHERE id = :id")
    suspend fun softDeleteSession(id: Long, now: Long = System.currentTimeMillis())

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertVisit(visit: FieldSessionVisitEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertVisit(visit: FieldSessionVisitEntity): Long

    @Query("DELETE FROM field_session_visits WHERE id = :id")
    suspend fun deleteVisit(id: Long)

    @Query("SELECT * FROM field_sessions ORDER BY startedAt DESC")
    suspend fun getSessionsSnapshot(): List<FieldSessionEntity>

    @Query("SELECT * FROM field_session_visits ORDER BY visitedAt DESC")
    suspend fun getVisitsSnapshot(): List<FieldSessionVisitEntity>

    @Query("DELETE FROM field_session_visits")
    suspend fun deleteAllVisits()

    @Query("DELETE FROM field_sessions")
    suspend fun deleteAllSessions()

    @Transaction
    suspend fun deleteAll() {
        deleteAllVisits()
        deleteAllSessions()
    }

    @Query("SELECT COUNT(*) FROM field_sessions WHERE deletedAt IS NULL")
    fun observeSessionCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM field_session_visits")
    fun observeVisitCount(): Flow<Int>

}
