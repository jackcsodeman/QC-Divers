package com.dumpsterscout.data.remote

import com.dumpsterscout.util.DsLogger
import com.dumpsterscout.domain.model.PhotoAttachment
import javax.inject.Inject

/**
 * No-op [RemotePhotoDataSource] used while Supabase Storage is not yet live.
 */
class NoOpRemotePhotoDataSource @Inject constructor() : RemotePhotoDataSource {

    override suspend fun uploadPhoto(photo: PhotoAttachment): String? {
        DsLogger.d(TAG, "uploadPhoto: no-op (id=${photo.id}). Wire up Supabase Storage to activate.")
        return null
    }

    override suspend fun deletePhoto(remoteUrl: String) {
        DsLogger.d(TAG, "deletePhoto: no-op. Wire up Supabase Storage to activate.")
    }

    private companion object {
        const val TAG = "NoOpRemotePhotoDS"
    }
}
