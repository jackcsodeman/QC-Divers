package com.dumpsterscout.data.remote

import com.dumpsterscout.data.local.entity.FieldLocationEntity

/** Remote contract for cleanup/salvage/custom field locations. */
interface RemoteFieldLocationDataSource {
    suspend fun upsertFieldLocations(locations: List<FieldLocationEntity>): Map<Long, String>
    suspend fun deleteFieldLocations(remoteIds: List<String>): Set<String>
    suspend fun fetchMyFieldLocations(ownerUserId: String): List<FieldLocationEntity>
}
