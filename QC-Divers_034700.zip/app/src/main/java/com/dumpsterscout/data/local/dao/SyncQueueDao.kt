package com.dumpsterscout.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.dumpsterscout.data.local.entity.SyncQueueEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SyncQueueDao {
    @Query("SELECT * FROM sync_queue ORDER BY createdAt ASC")
    fun observeAll(): Flow<List<SyncQueueEntity>>

    @Query(
        """
        SELECT * FROM sync_queue
        WHERE status IN ('PENDING', 'FAILED')
          AND (dependsOnQueueItemId IS NULL OR dependsOnQueueItemId IN (SELECT id FROM sync_queue WHERE status = 'SUCCEEDED'))
        ORDER BY createdAt ASC
        LIMIT :limit
        """
    )
    suspend fun getRunnable(limit: Int = 50): List<SyncQueueEntity>

    @Query("SELECT COUNT(*) FROM sync_queue WHERE status IN ('PENDING', 'FAILED', 'IN_PROGRESS', 'CONFLICT')")
    fun observeUnfinishedCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sync_queue WHERE status IN ('FAILED', 'CONFLICT')")
    fun observeFailedCount(): Flow<Int>

    @Query(
        """
        UPDATE sync_queue
        SET status = 'PENDING',
            resolutionAction = NULL,
            resolutionNotes = NULL,
            resolvedAt = NULL,
            updatedAt = :now
        WHERE status IN ('FAILED', 'CONFLICT')
        """
    )
    suspend fun retryFailed(now: Long = System.currentTimeMillis())

    @Query(
        """
        UPDATE sync_queue
        SET status = 'PENDING',
            lastError = NULL,
            resolutionAction = 'KEEP_LOCAL',
            resolutionNotes = 'Retrying local payload after user review',
            resolvedAt = :now,
            updatedAt = :now
        WHERE id = :id
        """
    )
    suspend fun retryOne(id: Long, now: Long = System.currentTimeMillis())

    @Query("DELETE FROM sync_queue WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE sync_queue SET status = 'PENDING', updatedAt = :now WHERE status = 'IN_PROGRESS' AND lastAttemptAt IS NOT NULL AND lastAttemptAt < :olderThan")
    suspend fun resetStaleInProgress(olderThan: Long, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM sync_queue WHERE entityType = :entityType AND entityLocalId = :entityLocalId ORDER BY createdAt DESC LIMIT 1")
    suspend fun latestForEntity(entityType: String, entityLocalId: Long): SyncQueueEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIfAbsent(item: SyncQueueEntity): Long

    @Query("SELECT * FROM sync_queue WHERE idempotencyKey = :idempotencyKey LIMIT 1")
    suspend fun getByIdempotencyKey(idempotencyKey: String): SyncQueueEntity?

    @Query("SELECT * FROM sync_queue WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): SyncQueueEntity?

    @Query(
        """
        UPDATE sync_queue
        SET entityRemoteId = :entityRemoteId,
            payload = :payload,
            status = 'PENDING',
            lastError = NULL,
            resolutionAction = NULL,
            resolutionNotes = NULL,
            resolvedAt = NULL,
            updatedAt = :updatedAt,
            dependsOnQueueItemId = :dependsOnQueueItemId
        WHERE idempotencyKey = :idempotencyKey
        """
    )
    suspend fun refreshExisting(
        idempotencyKey: String,
        entityRemoteId: String?,
        payload: String,
        updatedAt: Long,
        dependsOnQueueItemId: Long?
    )

    @Transaction
    suspend fun enqueue(item: SyncQueueEntity): Long {
        val insertedId = insertIfAbsent(item)
        if (insertedId > 0L) return insertedId
        refreshExisting(
            idempotencyKey = item.idempotencyKey,
            entityRemoteId = item.entityRemoteId,
            payload = item.payload,
            updatedAt = item.updatedAt,
            dependsOnQueueItemId = item.dependsOnQueueItemId
        )
        return getByIdempotencyKey(item.idempotencyKey)?.id ?: 0L
    }

    @Query("UPDATE sync_queue SET status = 'IN_PROGRESS', lastAttemptAt = :now, updatedAt = :now WHERE id = :id")
    suspend fun markInProgress(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE sync_queue SET status = 'SUCCEEDED', lastError = NULL, updatedAt = :now WHERE id = :id")
    suspend fun markSucceeded(id: Long, now: Long = System.currentTimeMillis())

    @Query(
        """
        UPDATE sync_queue
        SET status = 'FAILED',
            retryCount = retryCount + 1,
            lastError = :error,
            lastAttemptAt = :now,
            updatedAt = :now
        WHERE id = :id
        """
    )
    suspend fun markFailed(id: Long, error: String, now: Long = System.currentTimeMillis())

    @Query(
        """
        UPDATE sync_queue
        SET status = 'CONFLICT',
            remotePayload = :remotePayload,
            lastError = :error,
            lastAttemptAt = :now,
            updatedAt = :now
        WHERE id = :id
        """
    )
    suspend fun markConflict(id: Long, remotePayload: String, error: String, now: Long = System.currentTimeMillis())

    @Query(
        """
        UPDATE sync_queue
        SET status = 'RESOLVED_REMOTE',
            resolutionAction = 'KEEP_REMOTE',
            resolutionNotes = :notes,
            resolvedAt = :now,
            updatedAt = :now
        WHERE id = :id
        """
    )
    suspend fun markResolvedRemote(
        id: Long,
        notes: String = "Accepted remote state and dropped local queued mutation",
        now: Long = System.currentTimeMillis()
    )

    @Query(
        """
        UPDATE sync_queue
        SET status = 'RESOLVED_DUPLICATE',
            resolutionAction = 'DUPLICATE_LOCAL',
            resolutionNotes = :notes,
            resolvedAt = :now,
            updatedAt = :now
        WHERE id = :id
        """
    )
    suspend fun markResolvedDuplicate(
        id: Long,
        notes: String = "Marked for duplicate local copy after user review",
        now: Long = System.currentTimeMillis()
    )

    @Query("DELETE FROM sync_queue WHERE status = 'SUCCEEDED' AND updatedAt < :olderThan")
    suspend fun pruneSucceeded(olderThan: Long)

    @Query("DELETE FROM sync_queue")
    suspend fun deleteAll()
}
