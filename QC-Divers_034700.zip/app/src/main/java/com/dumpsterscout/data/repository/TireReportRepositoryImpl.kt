package com.dumpsterscout.data.repository

import com.dumpsterscout.data.local.dao.TireReportDao
import com.dumpsterscout.data.local.dao.TireSpotDao
import com.dumpsterscout.data.mapper.toDomain
import com.dumpsterscout.data.mapper.toEntity
import com.dumpsterscout.data.sync.SyncEntityType
import com.dumpsterscout.data.sync.SyncQueueOperation
import com.dumpsterscout.data.sync.SyncQueueWriter
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.di.SupabaseCredentials
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.model.Visibility
import com.dumpsterscout.domain.repository.TireReportRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TireReportRepositoryImpl @Inject constructor(
    private val dao: TireReportDao,
    private val tireSpotDao: TireSpotDao,
    private val credentials: SupabaseCredentials,
    private val prefs: AppPreferences,
    private val syncQueue: SyncQueueWriter
) : TireReportRepository {

    override fun getAllReports(): Flow<List<TireReport>> =
        dao.getAllReports().map { entities -> entities.map { it.toDomain() } }

    override fun getReportsBySpot(spotId: Long): Flow<List<TireReport>> =
        dao.getReportsBySpot(spotId).map { entities -> entities.map { it.toDomain() } }

    override fun getRecentReports(limit: Int): Flow<List<TireReport>> =
        dao.getRecentReports(limit).map { entities -> entities.map { it.toDomain() } }

    override suspend fun getReportById(id: Long): TireReport? =
        dao.getReportById(id)?.toDomain()

    override suspend fun insertReport(report: TireReport): Long {
        val ownerId = report.ownerUserId ?: prefs.localUserId.first()
        val stamped = if (credentials.isConfigured) {
            report.copy(
                ownerUserId = ownerId,
                syncStatus  = SyncStatus.PENDING_SYNC
            )
        } else {
            report.copy(ownerUserId = ownerId)
        }
        val entity = stamped.toEntity()
        val id = dao.insert(entity)
        if (credentials.isConfigured) {
            enqueueReport(id, entity.remoteId, SyncQueueOperation.CREATE, Json.encodeToString(entity.copy(id = id)))
        }
        return id
    }

    override suspend fun updateReport(report: TireReport) {
        val current = dao.getReportById(report.id)
        val ownerId = report.ownerUserId
            ?: current?.ownerUserId
            ?: prefs.localUserId.first()
        val stamped = if (credentials.isConfigured) {
            report.copy(
                ownerUserId = ownerId,
                syncStatus  = SyncStatus.PENDING_SYNC
            )
        } else {
            report.copy(ownerUserId = ownerId)
        }
        val entity = stamped.toEntity()
        dao.update(entity)
        if (credentials.isConfigured) {
            enqueueReport(report.id, entity.remoteId, SyncQueueOperation.UPDATE, Json.encodeToString(entity))
        }
    }

    override suspend fun deleteReport(report: TireReport) {
        if (credentials.isConfigured && report.id > 0L) {
            enqueueReport(
                report.id,
                report.remoteId,
                SyncQueueOperation.DELETE,
                Json.encodeToString(mapOf("id" to report.id, "remoteId" to report.remoteId, "deletedAt" to System.currentTimeMillis()))
            )
        }
        dao.delete(report.toEntity())
    }

    override suspend fun deleteAllReports() =
        dao.deleteAll()

    override suspend fun getPendingSyncReports(): List<TireReport> =
        dao.getPendingSyncReports().map { it.toDomain() }

    override suspend fun markReportSynced(id: Long, remoteId: String) =
        dao.markSynced(id, remoteId)

    override suspend fun markReportSyncFailed(id: Long) =
        dao.markSyncFailed(id)

    override suspend fun publishReport(reportId: Long) {
        dao.publishReport(reportId)
        if (credentials.isConfigured) {
            dao.getReportById(reportId)?.let { entity ->
                enqueueReport(reportId, entity.remoteId, SyncQueueOperation.UPDATE, Json.encodeToString(entity))
            }
        }
    }

    private suspend fun enqueueReport(
        id: Long,
        remoteId: String?,
        operation: SyncQueueOperation,
        payload: String
    ) {
        val parent = dao.getReportById(id)?.let { tireSpotDao.getSpotById(it.tireSpotId) }
        val dependency = if (parent?.remoteId.isNullOrBlank() && parent != null) {
            syncQueue.latestQueueId(SyncEntityType.TIRE_SPOT, parent.id)
        } else {
            null
        }
        syncQueue.enqueue(
            entityType = SyncEntityType.TIRE_REPORT,
            entityLocalId = id,
            entityRemoteId = remoteId,
            operation = operation,
            payload = payload,
            dependsOnQueueItemId = dependency
        )
    }

    override suspend fun getReportByRemoteId(remoteId: String): TireReport? =
        dao.getByRemoteId(remoteId)?.toDomain()

    override suspend fun insertReportFromRemote(report: TireReport): Long =
        dao.insert(report.toEntity().copy(syncStatus = SyncStatus.SYNCED.name))
}
