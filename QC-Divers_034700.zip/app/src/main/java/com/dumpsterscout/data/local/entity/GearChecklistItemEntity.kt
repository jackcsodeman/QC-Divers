package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(
    tableName = "gear_checklist_items",
    foreignKeys = [
        ForeignKey(
            entity = GearChecklistEntity::class,
            parentColumns = ["id"],
            childColumns = ["checklistId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("checklistId"),
        Index("sortOrder"),
        Index("remoteId"),
        Index("syncStatus"),
        Index("deletedAt")
    ]
)
@Serializable
data class GearChecklistItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val remoteId: String? = null,
    val ownerUserId: String? = null,
    val checklistId: Long,
    val label: String,
    val category: String = "Essential",
    val emoji: String = "•",
    val isChecked: Boolean = false,
    val sortOrder: Int = 0,
    val syncStatus: String = "LOCAL_ONLY",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)
