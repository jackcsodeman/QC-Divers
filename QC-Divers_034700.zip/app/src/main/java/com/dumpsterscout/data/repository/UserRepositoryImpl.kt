package com.dumpsterscout.data.repository

import com.dumpsterscout.util.DsLogger
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.di.SupabaseCredentials
import com.dumpsterscout.domain.model.AuthState
import com.dumpsterscout.domain.model.LocalUser
import com.dumpsterscout.domain.model.ScoutStats
import com.dumpsterscout.domain.repository.UserRepository
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.OtpType
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.OTP
import io.github.jan.supabase.auth.status.SessionStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Implementation of [UserRepository] backed by DataStore for local identity and
 * Supabase Auth for remote authentication.
 *
 * When [supabaseClient] is null (credentials not configured), the app runs in
 * local-only mode: all auth methods return graceful failures, and [getAuthState]
 * permanently emits [AuthState.SIGNED_OUT].
 *
 * On successful OTP verification, the Supabase auth UID is persisted to
 * DataStore via [linkRemoteAccount] so the user identity is stable across
 * sessions even if the backend is temporarily unreachable.
 */
@Singleton
class UserRepositoryImpl @Inject constructor(
    private val prefs: AppPreferences,
    private val supabaseClient: SupabaseClient?,
    private val credentials: SupabaseCredentials
) : UserRepository {

    override fun getCurrentUser(): Flow<LocalUser> =
        combine(
            prefs.localUserId,
            prefs.displayName,
            prefs.remoteUserId,
            prefs.firstSeenAt
        ) { localId, displayName, remoteUserId, firstSeenAt ->
            LocalUser(
                localId = localId ?: generateAndPersistLocalId(),
                displayName = displayName,
                remoteUserId = remoteUserId,
                isAnonymous = remoteUserId == null,
                firstSeenAt = firstSeenAt ?: System.currentTimeMillis()
            )
        }

    override suspend fun getOrCreateUser(): LocalUser {
        val localId = prefs.localUserId.first() ?: generateAndPersistLocalId()
        val now = System.currentTimeMillis()
        if (prefs.firstSeenAt.first() == null) prefs.setFirstSeenAt(now)
        return LocalUser(
            localId = localId,
            displayName = prefs.displayName.first(),
            remoteUserId = prefs.remoteUserId.first(),
            isAnonymous = prefs.remoteUserId.first() == null,
            firstSeenAt = prefs.firstSeenAt.first() ?: now
        )
    }

    override suspend fun updateDisplayName(name: String) {
        prefs.setDisplayName(name)
    }

    override suspend fun linkRemoteAccount(remoteUserId: String) {
        prefs.setRemoteUserId(remoteUserId)
    }

    override suspend fun clearUser() {
        prefs.clearUserIdentity()
    }

    // ── Auth ──────────────────────────────────────────────────────────────────

    override suspend fun signInWithOtp(email: String): Result<Unit> {
        val client = supabaseClient ?: return Result.failure(
            IllegalStateException("Supabase not configured — running in local-only mode.")
        )
        return try {
            // Explicitly set the redirect URL to the app's deep link scheme.
            // This ensures that if Supabase sends a Magic Link (instead of a code),
            // clicking it will redirect back into the app instead of localhost.
            client.auth.signInWith(OTP, "qcdivers://auth") { 
                this.email = email
                this.createUser = true 
            }
            Result.success(Unit)
        } catch (e: Exception) {
            DsLogger.e(TAG, "signInWithOtp failed.", e)
            Result.failure(e)
        }
    }

    override suspend fun verifyOtp(email: String, token: String): Result<Unit> {
        val client = supabaseClient ?: return Result.failure(
            IllegalStateException("Supabase not configured — running in local-only mode.")
        )
        return try {
            client.auth.verifyEmailOtp(OtpType.Email.EMAIL, email, token)
            val uid = client.auth.currentUserOrNull()?.id
            if (uid != null) linkRemoteAccount(uid)
            Result.success(Unit)
        } catch (e: Exception) {
            DsLogger.e(TAG, "verifyOtp failed.", e)
            Result.failure(e)
        }
    }

    override suspend fun signOut() {
        val client = supabaseClient ?: return
        try {
            client.auth.signOut()
            prefs.clearUserIdentity()
        } catch (e: Exception) {
            DsLogger.e(TAG, "signOut failed.", e)
        }
    }


    override suspend fun deleteAccountAndCloudData(): Result<Unit> {
        val client = supabaseClient ?: return Result.failure(
            IllegalStateException("Supabase not configured — account deletion is unavailable in local-only mode.")
        )
        if (!credentials.isConfigured) {
            return Result.failure(IllegalStateException("Supabase credentials are missing."))
        }
        return try {
            val accessToken = client.auth.currentSessionOrNull()?.accessToken
                ?: return Result.failure(IllegalStateException("No active Supabase session. Please sign in again."))
            val endpoint = credentials.url.trimEnd('/') + "/functions/v1/delete-account"
            withContext(Dispatchers.IO) {
                val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15_000
                    readTimeout = 30_000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $accessToken")
                    setRequestProperty("apikey", credentials.anonKey)
                    setRequestProperty("Content-Type", "application/json")
                }
                connection.outputStream.use { it.write("{}".toByteArray()) }
                val code = connection.responseCode
                connection.disconnect()
                if (code !in 200..299) {
                    throw IllegalStateException("Delete account Edge Function returned HTTP $code")
                }
            }
            prefs.clearUserIdentity()
            Result.success(Unit)
        } catch (e: Exception) {
            DsLogger.e(TAG, "deleteAccountAndCloudData failed.", e)
            Result.failure(e)
        }
    }

    override fun getAuthState(): Flow<AuthState> {
        val client = supabaseClient ?: return flowOf(AuthState.SIGNED_OUT)
        return client.auth.sessionStatus.map { status ->
            when (status) {
                is SessionStatus.Authenticated    -> AuthState.SIGNED_IN
                is SessionStatus.NotAuthenticated -> AuthState.SIGNED_OUT
                else                              -> AuthState.LOADING
            }
        }
    }

    override suspend fun getUserPublicStats(remoteUserId: String): Result<ScoutStats> {
        // Implementation for production: Fetch from a 'scout_stats' public view/table
        // For now, return a default/mocked result
        return Result.success(
            ScoutStats(
                remoteUserId = remoteUserId,
                spotsVerified = 12,
                haulsReported = 45,
                trustScore = 88,
                rankTitle = "Veteran Diver"
            )
        )
    }

    private suspend fun generateAndPersistLocalId(): String {
        val id = UUID.randomUUID().toString()
        prefs.setLocalUserId(id)
        return id
    }

    private companion object {
        const val TAG = "UserRepositoryImpl"
    }
}
