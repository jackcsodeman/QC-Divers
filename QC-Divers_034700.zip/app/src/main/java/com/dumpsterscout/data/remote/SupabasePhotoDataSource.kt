package com.dumpsterscout.data.remote

import android.content.Context
import androidx.core.net.toUri
import com.dumpsterscout.util.DsLogger
import com.dumpsterscout.domain.model.PhotoAttachment
import dagger.hilt.android.qualifiers.ApplicationContext
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.storage.storage

/**
 * Real [RemotePhotoDataSource] implementation backed by Supabase Storage.
 *
 * Bucket: `spot-photos` must be private. The returned remote reference is
 * a storage pointer (`supabase://spot-photos/path`) rather than a public URL.
 * UI code should request signed/authenticated access before displaying remote
 * media.
 *
 * Storage path convention: `{ownerUserId}/{ownerType}_{ownerId}/{photoId}.jpg`
 * This groups photos by user and owning record, making ownership queries
 * and moderation efficient.
 */
class SupabasePhotoDataSource(
    private val client: SupabaseClient,
    private val context: Context
) : RemotePhotoDataSource {

    override suspend fun uploadPhoto(photo: PhotoAttachment): String? {
        val uri = photo.localUri ?: run {
            DsLogger.e(TAG, "Cannot upload photo because local URI is missing.")
            return null
        }
        return try {
            val bytes = readUriBytes(uri) ?: return null
            val path = buildPath(photo)
            client.storage.from(BUCKET).upload(path, bytes) { upsert = true }
            storageReference(path)
        } catch (e: Exception) {
            DsLogger.e(TAG, "Photo upload failed.", e)
            null
        }
    }

    override suspend fun deletePhoto(remoteUrl: String) {
        try {
            val path = pathFromStorageReference(remoteUrl)
            if (path != null) client.storage.from(BUCKET).delete(path)
        } catch (e: Exception) {
            DsLogger.e(TAG, "Photo delete failed.", e)
        }
    }

    private fun storageReference(path: String): String = "$STORAGE_SCHEME://$BUCKET/$path"

    private fun pathFromStorageReference(remoteReference: String): String? {
        val prefix = "$STORAGE_SCHEME://$BUCKET/"
        return remoteReference.takeIf { it.startsWith(prefix) }?.removePrefix(prefix)
    }

    private fun buildPath(photo: PhotoAttachment): String {
        val uid = photo.ownerUserId ?: "anonymous"
        return "$uid/${photo.ownerType}_${photo.ownerId}/${photo.id}.jpg"
    }

    private fun readUriBytes(uri: String): ByteArray? =
        try {
            context.contentResolver.openInputStream(uri.toUri())?.use { it.readBytes() }
        } catch (e: Exception) {
            DsLogger.e(TAG, "Failed to read local photo bytes.", e)
            null
        }

    private companion object {
        const val TAG = "SupabasePhotoDS"
        const val BUCKET = "spot-photos"
        const val STORAGE_SCHEME = "supabase"
    }
}
