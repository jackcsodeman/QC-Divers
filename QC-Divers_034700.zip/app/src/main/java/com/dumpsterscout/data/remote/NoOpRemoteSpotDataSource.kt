package com.dumpsterscout.data.remote

import com.dumpsterscout.util.DsLogger
import com.dumpsterscout.domain.model.DumpsterSpot
import javax.inject.Inject

/**
 * No-op [RemoteSpotDataSource] used while the Supabase backend is not yet live.
 *
 * All methods succeed silently (returning empty results) so the sync worker can
 * run without errors.  Replace this binding in [RemoteModule] once the real
 * [SupabaseSpotDataSource] is implemented.
 */
class NoOpRemoteSpotDataSource @Inject constructor() : RemoteSpotDataSource {

    override suspend fun upsertSpots(spots: List<DumpsterSpot>): Map<Long, String> {
        DsLogger.d(TAG, "upsertSpots: no-op (${spots.size} spots). Wire up Supabase to activate.")
        return emptyMap()
    }

    override suspend fun deleteSpots(remoteIds: List<String>): Set<String> {
        DsLogger.d(TAG, "deleteSpots: no-op (${remoteIds.size} ids). Wire up Supabase to activate.")
        return emptySet()
    }

    override suspend fun fetchMySpots(ownerUserId: String): List<DumpsterSpot> {
        DsLogger.d(TAG, "fetchMySpots: no-op. Wire up Supabase to activate.")
        return emptyList()
    }

    override suspend fun fetchAllCommunitySpots(): List<DumpsterSpot> {
        DsLogger.d(TAG, "fetchAllCommunitySpots: no-op. Wire up Supabase to activate.")
        return emptyList()
    }

    private companion object {

        const val TAG = "NoOpRemoteSpotDS"
    }
}
