package com.dumpsterscout.ui.reminders

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.data.local.dao.ReminderDao
import com.dumpsterscout.data.local.entity.ReminderEntity
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.data.sync.SyncEntityType
import com.dumpsterscout.data.sync.SyncQueueOperation
import com.dumpsterscout.data.sync.SyncQueueWriter
import com.dumpsterscout.di.SupabaseCredentials
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.notifications.ReminderScheduler
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject

data class RemindersUiState(
    val reminders: List<ReminderEntity> = emptyList(),
    val spots: List<DumpsterSpot> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null
)

@HiltViewModel
class RemindersViewModel @Inject constructor(
    private val reminderDao: ReminderDao,
    private val spotRepository: SpotRepository,
    private val scheduler: ReminderScheduler,
    private val credentials: SupabaseCredentials,
    private val prefs: AppPreferences,
    private val syncQueue: SyncQueueWriter
) : ViewModel() {

    private val errors = MutableStateFlow<String?>(null)

    val uiState: StateFlow<RemindersUiState> = combine(
        reminderDao.getAllReminders(),
        spotRepository.getActiveSpots(),
        errors
    ) { reminders, spots, error ->
        RemindersUiState(
            reminders = reminders,
            spots = spots,
            isLoading = false,
            error = error
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = RemindersUiState()
    )

    fun addReminder(
        spotId: Long,
        label: String,
        dayOfWeek: Int,
        hour: Int,
        minute: Int
    ) {
        if (spotId <= 0L) {
            errors.value = "Choose a spot first."
            return
        }
        viewModelScope.launch {
            try {
                val ownerId = prefs.localUserId.first()
                val syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else "LOCAL_ONLY"
                val reminder = ReminderEntity(
                    ownerUserId = ownerId,
                    spotId = spotId,
                    label = label.trim(),
                    dayOfWeek = dayOfWeek,
                    timeHour = hour.coerceIn(0, 23),
                    timeMinute = minute.coerceIn(0, 59),
                    isActive = true,
                    syncStatus = syncStatus
                )
                val id = reminderDao.insert(reminder)
                val saved = reminder.copy(id = id)
                scheduler.schedule(saved)
                queueReminderIfConfigured(saved, SyncQueueOperation.CREATE)
                errors.value = null
            } catch (e: Exception) {
                errors.value = e.message ?: "Failed to save reminder."
            }
        }
    }


    fun updateReminder(
        reminder: ReminderEntity,
        label: String,
        dayOfWeek: Int,
        hour: Int,
        minute: Int
    ) {
        viewModelScope.launch {
            try {
                val syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else reminder.syncStatus
                reminderDao.updateSchedule(
                    id = reminder.id,
                    label = label.trim(),
                    dayOfWeek = dayOfWeek,
                    hour = hour.coerceIn(0, 23),
                    minute = minute.coerceIn(0, 59),
                    syncStatus = syncStatus
                )
                val updated = reminder.copy(
                    label = label.trim(),
                    dayOfWeek = dayOfWeek,
                    timeHour = hour.coerceIn(0, 23),
                    timeMinute = minute.coerceIn(0, 59),
                    completedAt = null,
                    snoozedUntil = null,
                    isActive = true,
                    syncStatus = syncStatus,
                    updatedAt = System.currentTimeMillis()
                )
                scheduler.schedule(updated)
                queueReminderIfConfigured(updated, SyncQueueOperation.UPDATE)
                errors.value = null
            } catch (e: Exception) {
                errors.value = e.message ?: "Failed to update reminder."
            }
        }
    }

    fun complete(reminder: ReminderEntity) {
        viewModelScope.launch {
            try {
                scheduler.cancel(reminder.id)
                val syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else reminder.syncStatus
                val completedAt = System.currentTimeMillis()
                reminderDao.markCompleted(reminder.id, completedAt = completedAt, syncStatus = syncStatus)
                queueReminderIfConfigured(reminder.copy(completedAt = completedAt, isActive = false, syncStatus = syncStatus), SyncQueueOperation.UPDATE)
                errors.value = null
            } catch (e: Exception) {
                errors.value = e.message ?: "Failed to complete reminder."
            }
        }
    }

    fun snooze(reminder: ReminderEntity, minutes: Long = 60L) {
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                val snoozedUntil = now + minutes.coerceAtLeast(5L) * 60_000L
                val syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else reminder.syncStatus
                reminderDao.snoozeUntil(reminder.id, snoozedUntil = snoozedUntil, syncStatus = syncStatus, now = now)
                val updated = reminder.copy(snoozedUntil = snoozedUntil, isActive = true, syncStatus = syncStatus, updatedAt = now)
                scheduler.schedule(updated)
                queueReminderIfConfigured(updated, SyncQueueOperation.UPDATE)
                errors.value = null
            } catch (e: Exception) {
                errors.value = e.message ?: "Failed to snooze reminder."
            }
        }
    }

    fun setActive(reminder: ReminderEntity, active: Boolean) {
        viewModelScope.launch {
            try {
                val syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else reminder.syncStatus
                reminderDao.setActive(reminder.id, active, syncStatus = syncStatus)
                val updated = reminder.copy(isActive = active, syncStatus = syncStatus, updatedAt = System.currentTimeMillis())
                if (active) scheduler.schedule(updated) else scheduler.cancel(reminder.id)
                queueReminderIfConfigured(updated, SyncQueueOperation.UPDATE)
                errors.value = null
            } catch (e: Exception) {
                errors.value = e.message ?: "Failed to update reminder."
            }
        }
    }

    fun delete(reminder: ReminderEntity) {
        viewModelScope.launch {
            try {
                scheduler.cancel(reminder.id)
                if (credentials.isConfigured) {
                    reminderDao.softDelete(reminder.id)
                    queueReminderIfConfigured(reminder, SyncQueueOperation.DELETE, explicitRemoteId = reminder.remoteId)
                } else {
                    reminderDao.delete(reminder)
                }
                errors.value = null
            } catch (e: Exception) {
                errors.value = e.message ?: "Failed to delete reminder."
            }
        }
    }

    fun clearError() {
        errors.value = null
    }

    private suspend fun queueReminderIfConfigured(
        reminder: ReminderEntity,
        operation: SyncQueueOperation,
        explicitRemoteId: String? = null
    ) {
        if (!credentials.isConfigured) return
        val persisted = reminderDao.getReminderById(reminder.id) ?: reminder
        if (operation != SyncQueueOperation.DELETE) reminderDao.markPendingSync(reminder.id)
        syncQueue.enqueue(
            entityType = SyncEntityType.REMINDER,
            entityLocalId = reminder.id,
            entityRemoteId = explicitRemoteId ?: persisted.remoteId,
            operation = operation,
            payload = Json.encodeToString(persisted)
        )
    }
}
