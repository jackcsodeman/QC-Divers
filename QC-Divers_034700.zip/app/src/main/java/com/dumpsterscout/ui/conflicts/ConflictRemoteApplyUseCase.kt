package com.dumpsterscout.ui.conflicts

import com.dumpsterscout.data.local.dao.CollectionDao
import com.dumpsterscout.data.local.dao.DumpsterSpotDao
import com.dumpsterscout.data.local.dao.PersonalReportDao
import com.dumpsterscout.data.local.dao.FieldLocationDao
import com.dumpsterscout.data.local.dao.FieldSessionDao
import com.dumpsterscout.data.local.dao.GearChecklistDao
import com.dumpsterscout.data.local.dao.ReminderDao
import com.dumpsterscout.data.local.dao.RoutePlanDao
import com.dumpsterscout.data.local.dao.TireReportDao
import com.dumpsterscout.data.local.dao.TireSpotDao
import com.dumpsterscout.data.local.entity.CollectionEntity
import com.dumpsterscout.data.local.entity.DumpsterSpotEntity
import com.dumpsterscout.data.local.entity.FieldLocationEntity
import com.dumpsterscout.data.local.entity.FieldSessionEntity
import com.dumpsterscout.data.local.entity.GearChecklistEntity
import com.dumpsterscout.data.local.entity.PersonalReportEntity
import com.dumpsterscout.data.local.entity.ReminderEntity
import com.dumpsterscout.data.local.entity.RoutePlanEntity
import com.dumpsterscout.data.local.entity.SyncQueueEntity
import com.dumpsterscout.data.local.entity.TireReportEntity
import com.dumpsterscout.data.local.entity.TireSpotEntity
import com.dumpsterscout.data.sync.SyncEntityType
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.longOrNull
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Applies safe conflict-resolution choices to local rows.
 *
 * Remote snapshots are deliberately applied field-by-field with conservative
 * defaults. Missing fields never overwrite local values. Sensitive fields remain
 * redacted in the UI by [ConflictPayloadParser], but the local apply step can
 * still honor persisted snapshots when the user explicitly chooses Accept remote.
 */
@Singleton
class ConflictRemoteApplyUseCase @Inject constructor(
    private val dumpsterSpotDao: DumpsterSpotDao,
    private val personalReportDao: PersonalReportDao,
    private val tireSpotDao: TireSpotDao,
    private val tireReportDao: TireReportDao,
    private val fieldLocationDao: FieldLocationDao,
    private val collectionDao: CollectionDao,
    private val fieldSessionDao: FieldSessionDao,
    private val reminderDao: ReminderDao,
    private val routePlanDao: RoutePlanDao,
    private val gearChecklistDao: GearChecklistDao
) {
    suspend fun acceptRemote(item: SyncQueueEntity): ConflictApplyResult {
        val remote = remoteObjectFor(item)
            ?: return ConflictApplyResult.unsupported("No remote snapshot is available for ${item.entityType}.")
        val now = System.currentTimeMillis()
        return when (item.entityType) {
            SyncEntityType.DUMPSTER_SPOT.name -> acceptDumpsterSpot(item.entityLocalId, remote, now)
            SyncEntityType.DUMPSTER_REPORT.name -> acceptDumpsterReport(item.entityLocalId, remote, now)
            SyncEntityType.TIRE_SPOT.name -> acceptTireSpot(item.entityLocalId, remote, now)
            SyncEntityType.TIRE_REPORT.name -> acceptTireReport(item.entityLocalId, remote, now)
            SyncEntityType.FIELD_LOCATION.name -> acceptFieldLocation(item.entityLocalId, remote, now)
            SyncEntityType.COLLECTION.name -> acceptCollection(item.entityLocalId, remote, now)
            SyncEntityType.FIELD_SESSION.name -> acceptFieldSession(item.entityLocalId, remote, now)
            SyncEntityType.REMINDER.name -> acceptReminder(item.entityLocalId, remote, now)
            SyncEntityType.ROUTE_PLAN.name -> acceptRoutePlan(item.entityLocalId, remote, now)
            SyncEntityType.GEAR_CHECKLIST.name -> acceptGearChecklist(item.entityLocalId, remote, now)
            else -> ConflictApplyResult.unsupported("Remote apply is not automated for ${item.entityType}; payload was preserved for audit.")
        }
    }

    suspend fun duplicateLocal(item: SyncQueueEntity): ConflictApplyResult {
        val now = System.currentTimeMillis()
        return when (item.entityType) {
            SyncEntityType.DUMPSTER_SPOT.name -> duplicateDumpsterSpot(item.entityLocalId, now)
            SyncEntityType.DUMPSTER_REPORT.name -> duplicateDumpsterReport(item.entityLocalId, now)
            SyncEntityType.TIRE_SPOT.name -> duplicateTireSpot(item.entityLocalId, now)
            SyncEntityType.TIRE_REPORT.name -> duplicateTireReport(item.entityLocalId, now)
            SyncEntityType.FIELD_LOCATION.name -> duplicateFieldLocation(item.entityLocalId, now)
            SyncEntityType.COLLECTION.name -> duplicateCollection(item.entityLocalId, now)
            SyncEntityType.FIELD_SESSION.name -> duplicateFieldSession(item.entityLocalId, now)
            SyncEntityType.REMINDER.name -> duplicateReminder(item.entityLocalId, now)
            SyncEntityType.ROUTE_PLAN.name -> duplicateRoutePlan(item.entityLocalId, now)
            SyncEntityType.GEAR_CHECKLIST.name -> duplicateGearChecklist(item.entityLocalId, now)
            else -> ConflictApplyResult.unsupported("Duplicate copy is not automated for ${item.entityType}; payload was preserved for audit.")
        }
    }


    private suspend fun acceptDumpsterSpot(id: Long, remote: JsonObject, now: Long): ConflictApplyResult {
        val current = dumpsterSpotDao.getSpotById(id) ?: return ConflictApplyResult.missing("Dumpster spot $id no longer exists.")
        dumpsterSpotDao.upsert(
            current.copy(
                remoteId = remote.stringValue("id", "remoteId") ?: current.remoteId,
                ownerUserId = remote.stringValue("owner_id", "ownerId", "ownerUserId") ?: current.ownerUserId,
                name = remote.stringValue("name") ?: current.name,
                category = remote.stringValue("category") ?: current.category,
                address = remote.stringValue("address") ?: current.address,
                latitude = remote.doubleValue("latitude") ?: current.latitude,
                longitude = remote.doubleValue("longitude") ?: current.longitude,
                visibility = remote.stringValue("visibility") ?: current.visibility,
                personalNotes = remote.stringValue("personal_notes", "personalNotes") ?: current.personalNotes,
                tags = remote.stringValue("tags") ?: current.tags,
                isFavorite = remote.booleanValue("is_favorite", "isFavorite") ?: current.isFavorite,
                isVerified = remote.booleanValue("is_verified", "isVerified") ?: current.isVerified,
                isRetired = remote.booleanValue("is_retired", "isRetired") ?: current.isRetired,
                lastStatus = remote.stringValue("last_status", "lastStatus") ?: current.lastStatus,
                lastChecked = remote.longValue("last_checked", "lastChecked") ?: current.lastChecked,
                syncStatus = "SYNCED",
                updatedAt = now,
                deletedAt = remote.longValue("deleted_at", "deletedAt") ?: current.deletedAt
            )
        )
        return ConflictApplyResult.applied("Applied remote dumpster spot values to local row $id.")
    }

    private suspend fun acceptDumpsterReport(id: Long, remote: JsonObject, now: Long): ConflictApplyResult {
        val current = personalReportDao.getReportById(id) ?: return ConflictApplyResult.missing("Dumpster report $id no longer exists.")
        personalReportDao.update(
            current.copy(
                remoteId = remote.stringValue("id", "remoteId") ?: current.remoteId,
                ownerUserId = remote.stringValue("owner_id", "ownerId", "ownerUserId") ?: current.ownerUserId,
                status = remote.stringValue("status") ?: current.status,
                fillLevel = remote.stringValue("fill_level", "fillLevel") ?: current.fillLevel,
                notes = remote.stringValue("notes") ?: current.notes,
                tags = remote.stringValue("tags") ?: current.tags,
                visibility = remote.stringValue("visibility") ?: current.visibility,
                isFromVoice = remote.booleanValue("is_from_voice", "isFromVoice") ?: current.isFromVoice,
                timestamp = remote.longValue("timestamp") ?: current.timestamp,
                syncStatus = "SYNCED",
                updatedAt = now,
                deletedAt = remote.longValue("deleted_at", "deletedAt") ?: current.deletedAt
            )
        )
        return ConflictApplyResult.applied("Applied remote dumpster report values to local row $id.")
    }

    private suspend fun acceptTireSpot(id: Long, remote: JsonObject, now: Long): ConflictApplyResult {
        val current = tireSpotDao.getSpotById(id) ?: return ConflictApplyResult.missing("Tire spot $id no longer exists.")
        tireSpotDao.upsert(
            current.copy(
                remoteId = remote.stringValue("id", "remoteId") ?: current.remoteId,
                ownerUserId = remote.stringValue("owner_id", "ownerId", "ownerUserId") ?: current.ownerUserId,
                name = remote.stringValue("name") ?: current.name,
                category = remote.stringValue("category") ?: current.category,
                address = remote.stringValue("address") ?: current.address,
                latitude = remote.doubleValue("latitude") ?: current.latitude,
                longitude = remote.doubleValue("longitude") ?: current.longitude,
                visibility = remote.stringValue("visibility") ?: current.visibility,
                accessNotes = remote.stringValue("access_notes", "accessNotes") ?: current.accessNotes,
                isFenced = remote.booleanValue("is_fenced", "isFenced") ?: current.isFenced,
                isGated = remote.booleanValue("is_gated", "isGated") ?: current.isGated,
                isLocked = remote.booleanValue("is_locked", "isLocked") ?: current.isLocked,
                isExposed = remote.booleanValue("is_exposed", "isExposed") ?: current.isExposed,
                easyAccess = remote.booleanValue("easy_access", "easyAccess") ?: current.easyAccess,
                hasCameras = remote.booleanValue("has_cameras", "hasCameras") ?: current.hasCameras,
                securityCommon = remote.booleanValue("security_common", "securityCommon") ?: current.securityCommon,
                bestTimeOfDay = remote.stringValue("best_time_of_day", "bestTimeOfDay") ?: current.bestTimeOfDay,
                bestDays = remote.stringValue("best_days", "bestDays") ?: current.bestDays,
                betterOnWeekends = remote.booleanValue("better_on_weekends", "betterOnWeekends") ?: current.betterOnWeekends,
                isSeasonal = remote.booleanValue("is_seasonal", "isSeasonal") ?: current.isSeasonal,
                season = remote.stringValue("season") ?: current.season,
                putsOutAroundClosing = remote.booleanValue("puts_out_around_closing", "putsOutAroundClosing") ?: current.putsOutAroundClosing,
                puncturePattern = remote.stringValue("puncture_pattern", "puncturePattern") ?: current.puncturePattern,
                usableDisappearFast = remote.booleanValue("usable_disappear_fast", "usableDisappearFast") ?: current.usableDisappearFast,
                othersGetThereFirst = remote.booleanValue("others_get_there_first", "othersGetThereFirst") ?: current.othersGetThereFirst,
                worthCheckingWhenLight = remote.booleanValue("worth_checking_when_light", "worthCheckingWhenLight") ?: current.worthCheckingWhenLight,
                usuallyPutsOutMany = remote.booleanValue("usually_puts_out_many", "usuallyPutsOutMany") ?: current.usuallyPutsOutMany,
                isVerified = remote.booleanValue("is_verified", "isVerified") ?: current.isVerified,
                isFavorite = remote.booleanValue("is_favorite", "isFavorite") ?: current.isFavorite,
                isRetired = remote.booleanValue("is_retired", "isRetired") ?: current.isRetired,
                lastStatus = remote.stringValue("last_status", "lastStatus") ?: current.lastStatus,
                lastChecked = remote.longValue("last_checked", "lastChecked") ?: current.lastChecked,
                notes = remote.stringValue("notes") ?: current.notes,
                tags = remote.stringValue("tags") ?: current.tags,
                syncStatus = "SYNCED",
                updatedAt = now,
                deletedAt = remote.longValue("deleted_at", "deletedAt") ?: current.deletedAt
            )
        )
        return ConflictApplyResult.applied("Applied remote tire spot values to local row $id.")
    }

    private suspend fun acceptTireReport(id: Long, remote: JsonObject, now: Long): ConflictApplyResult {
        val current = tireReportDao.getReportById(id) ?: return ConflictApplyResult.missing("Tire report $id no longer exists.")
        tireReportDao.update(
            current.copy(
                remoteId = remote.stringValue("id", "remoteId") ?: current.remoteId,
                ownerUserId = remote.stringValue("owner_id", "ownerId", "ownerUserId") ?: current.ownerUserId,
                status = remote.stringValue("status") ?: current.status,
                estimatedCount = remote.intValue("estimated_count", "estimatedCount") ?: current.estimatedCount,
                estimatedUsableCount = remote.intValue("estimated_usable_count", "estimatedUsableCount") ?: current.estimatedUsableCount,
                notes = remote.stringValue("notes") ?: current.notes,
                visibility = remote.stringValue("visibility") ?: current.visibility,
                timestamp = remote.longValue("timestamp") ?: current.timestamp,
                syncStatus = "SYNCED",
                updatedAt = now,
                deletedAt = remote.longValue("deleted_at", "deletedAt") ?: current.deletedAt
            )
        )
        return ConflictApplyResult.applied("Applied remote tire report values to local row $id.")
    }

    private suspend fun acceptFieldLocation(id: Long, remote: JsonObject, now: Long): ConflictApplyResult {
        val current = fieldLocationDao.getById(id) ?: return ConflictApplyResult.missing("Field location $id no longer exists.")
        fieldLocationDao.update(
            current.copy(
                remoteId = remote.stringValue("id", "remoteId") ?: current.remoteId,
                ownerUserId = remote.stringValue("owner_id", "ownerUserId") ?: current.ownerUserId,
                type = remote.stringValue("type") ?: current.type,
                name = remote.stringValue("name") ?: current.name,
                description = remote.stringValue("description") ?: current.description,
                address = remote.stringValue("address") ?: current.address,
                latitude = remote.doubleValue("latitude") ?: current.latitude,
                longitude = remote.doubleValue("longitude") ?: current.longitude,
                tags = remote.stringValue("tags") ?: current.tags,
                grade = remote.stringValue("grade") ?: current.grade,
                accessStatus = remote.stringValue("access_status", "accessStatus") ?: current.accessStatus,
                safetyNotes = remote.stringValue("safety_notes", "safetyNotes") ?: current.safetyNotes,
                hazardNotes = remote.stringValue("hazard_notes", "hazardNotes") ?: current.hazardNotes,
                hazardLevel = remote.stringValue("hazard_level", "hazardLevel") ?: current.hazardLevel,
                cleanupPriority = remote.stringValue("cleanup_priority", "cleanupPriority") ?: current.cleanupPriority,
                cleanupStatus = remote.stringValue("cleanup_status", "cleanupStatus") ?: current.cleanupStatus,
                resourceType = remote.stringValue("resource_type", "resourceType") ?: current.resourceType,
                resourceAvailability = remote.stringValue("resource_availability", "resourceAvailability") ?: current.resourceAvailability,
                isFavorite = remote.booleanValue("is_favorite", "isFavorite") ?: current.isFavorite,
                isArchived = remote.booleanValue("is_archived", "isArchived") ?: current.isArchived,
                visibility = remote.stringValue("visibility") ?: current.visibility,
                syncStatus = "SYNCED",
                conflictStatus = "RESOLVED_REMOTE",
                updatedAt = now,
                deletedAt = remote.longValue("deleted_at", "deletedAt") ?: current.deletedAt
            )
        )
        return ConflictApplyResult.applied("Applied remote field location values to local row $id.")
    }

    private suspend fun acceptCollection(id: Long, remote: JsonObject, now: Long): ConflictApplyResult {
        val current = collectionDao.getCollectionById(id) ?: return ConflictApplyResult.missing("Collection $id no longer exists.")
        collectionDao.updateCollection(
            current.copy(
                remoteId = remote.stringValue("id", "remoteId") ?: current.remoteId,
                ownerUserId = remote.stringValue("owner_id", "ownerUserId") ?: current.ownerUserId,
                name = remote.stringValue("name") ?: current.name,
                notes = remote.stringValue("notes") ?: current.notes,
                visibility = remote.stringValue("visibility") ?: current.visibility,
                syncStatus = "SYNCED",
                updatedAt = now,
                deletedAt = remote.longValue("deleted_at", "deletedAt") ?: current.deletedAt
            )
        )
        return ConflictApplyResult.applied("Applied remote collection values to local row $id.")
    }

    private suspend fun acceptFieldSession(id: Long, remote: JsonObject, now: Long): ConflictApplyResult {
        val current = fieldSessionDao.getSessionById(id) ?: return ConflictApplyResult.missing("Field session $id no longer exists.")
        fieldSessionDao.updateSession(
            current.copy(
                remoteId = remote.stringValue("id", "remoteId") ?: current.remoteId,
                ownerUserId = remote.stringValue("owner_id", "ownerUserId") ?: current.ownerUserId,
                title = remote.stringValue("title") ?: current.title,
                notes = remote.stringValue("notes") ?: current.notes,
                startedAt = remote.longValue("started_at", "startedAt") ?: current.startedAt,
                endedAt = remote.longValue("ended_at", "endedAt") ?: current.endedAt,
                syncStatus = "SYNCED",
                updatedAt = now,
                deletedAt = remote.longValue("deleted_at", "deletedAt") ?: current.deletedAt
            )
        )
        return ConflictApplyResult.applied("Applied remote field session values to local row $id.")
    }

    private suspend fun acceptReminder(id: Long, remote: JsonObject, now: Long): ConflictApplyResult {
        val current = reminderDao.getReminderById(id) ?: return ConflictApplyResult.missing("Reminder $id no longer exists.")
        reminderDao.update(
            current.copy(
                remoteId = remote.stringValue("id", "remoteId") ?: current.remoteId,
                ownerUserId = remote.stringValue("owner_id", "ownerUserId") ?: current.ownerUserId,
                locationType = remote.stringValue("location_type", "locationType") ?: current.locationType,
                locationRemoteId = remote.stringValue("location_remote_id", "locationRemoteId") ?: current.locationRemoteId,
                label = remote.stringValue("label") ?: current.label,
                dayOfWeek = remote.intValue("day_of_week", "dayOfWeek") ?: current.dayOfWeek,
                timeHour = remote.intValue("time_hour", "timeHour") ?: current.timeHour,
                timeMinute = remote.intValue("time_minute", "timeMinute") ?: current.timeMinute,
                isActive = remote.booleanValue("is_active", "isActive") ?: current.isActive,
                syncStatus = "SYNCED",
                updatedAt = now,
                deletedAt = remote.longValue("deleted_at", "deletedAt") ?: current.deletedAt
            )
        )
        return ConflictApplyResult.applied("Applied remote reminder values to local row $id.")
    }

    private suspend fun acceptRoutePlan(id: Long, remote: JsonObject, now: Long): ConflictApplyResult {
        val current = routePlanDao.getRoutePlanById(id) ?: return ConflictApplyResult.missing("Route plan $id no longer exists.")
        routePlanDao.update(
            current.copy(
                remoteId = remote.stringValue("id", "remoteId") ?: current.remoteId,
                ownerUserId = remote.stringValue("owner_id", "ownerUserId") ?: current.ownerUserId,
                name = remote.stringValue("name") ?: current.name,
                notes = remote.stringValue("notes") ?: current.notes,
                visibility = remote.stringValue("visibility") ?: current.visibility,
                syncStatus = "SYNCED",
                updatedAt = now,
                deletedAt = remote.longValue("deleted_at", "deletedAt") ?: current.deletedAt
            )
        )
        return ConflictApplyResult.applied("Applied remote route values to local row $id.")
    }

    private suspend fun acceptGearChecklist(id: Long, remote: JsonObject, now: Long): ConflictApplyResult {
        val current = gearChecklistDao.getChecklistById(id) ?: return ConflictApplyResult.missing("Gear checklist $id no longer exists.")
        gearChecklistDao.insertChecklist(
            current.copy(
                remoteId = remote.stringValue("id", "remoteId") ?: current.remoteId,
                ownerUserId = remote.stringValue("owner_id", "ownerUserId") ?: current.ownerUserId,
                name = remote.stringValue("name") ?: current.name,
                isTemplate = remote.booleanValue("is_template", "isTemplate") ?: current.isTemplate,
                syncStatus = "SYNCED",
                updatedAt = now,
                deletedAt = remote.longValue("deleted_at", "deletedAt") ?: current.deletedAt
            )
        )
        return ConflictApplyResult.applied("Applied remote gear checklist values to local row $id.")
    }


    private suspend fun duplicateDumpsterSpot(id: Long, now: Long): ConflictApplyResult {
        val current = dumpsterSpotDao.getSpotById(id) ?: return ConflictApplyResult.missing("Dumpster spot $id no longer exists.")
        val newId = dumpsterSpotDao.upsert(current.copyForDuplicate(now))
        return ConflictApplyResult.applied("Created duplicate dumpster spot $newId from local row $id.")
    }

    private suspend fun duplicateDumpsterReport(id: Long, now: Long): ConflictApplyResult {
        val current = personalReportDao.getReportById(id) ?: return ConflictApplyResult.missing("Dumpster report $id no longer exists.")
        val newId = personalReportDao.insert(current.copyForDuplicate(now))
        return ConflictApplyResult.applied("Created duplicate dumpster report $newId from local row $id.")
    }

    private suspend fun duplicateTireSpot(id: Long, now: Long): ConflictApplyResult {
        val current = tireSpotDao.getSpotById(id) ?: return ConflictApplyResult.missing("Tire spot $id no longer exists.")
        val newId = tireSpotDao.upsert(current.copyForDuplicate(now))
        return ConflictApplyResult.applied("Created duplicate tire spot $newId from local row $id.")
    }

    private suspend fun duplicateTireReport(id: Long, now: Long): ConflictApplyResult {
        val current = tireReportDao.getReportById(id) ?: return ConflictApplyResult.missing("Tire report $id no longer exists.")
        val newId = tireReportDao.insert(current.copyForDuplicate(now))
        return ConflictApplyResult.applied("Created duplicate tire report $newId from local row $id.")
    }

    private suspend fun duplicateFieldLocation(id: Long, now: Long): ConflictApplyResult {
        val current = fieldLocationDao.getById(id) ?: return ConflictApplyResult.missing("Field location $id no longer exists.")
        val newId = fieldLocationDao.upsert(current.copyForDuplicate(now))
        return ConflictApplyResult.applied("Created duplicate field location $newId from local row $id.")
    }

    private suspend fun duplicateCollection(id: Long, now: Long): ConflictApplyResult {
        val current = collectionDao.getCollectionById(id) ?: return ConflictApplyResult.missing("Collection $id no longer exists.")
        val newId = collectionDao.insertCollection(current.copyForDuplicate(now))
        return ConflictApplyResult.applied("Created duplicate collection $newId from local row $id.")
    }

    private suspend fun duplicateFieldSession(id: Long, now: Long): ConflictApplyResult {
        val current = fieldSessionDao.getSessionById(id) ?: return ConflictApplyResult.missing("Field session $id no longer exists.")
        val newId = fieldSessionDao.insertSession(current.copyForDuplicate(now))
        return ConflictApplyResult.applied("Created duplicate field session $newId from local row $id.")
    }

    private suspend fun duplicateReminder(id: Long, now: Long): ConflictApplyResult {
        val current = reminderDao.getReminderById(id) ?: return ConflictApplyResult.missing("Reminder $id no longer exists.")
        val newId = reminderDao.insert(current.copyForDuplicate(now))
        return ConflictApplyResult.applied("Created duplicate reminder $newId from local row $id.")
    }

    private suspend fun duplicateRoutePlan(id: Long, now: Long): ConflictApplyResult {
        val current = routePlanDao.getRoutePlanById(id) ?: return ConflictApplyResult.missing("Route plan $id no longer exists.")
        val newId = routePlanDao.insert(current.copyForDuplicate(now))
        return ConflictApplyResult.applied("Created duplicate route plan $newId from local row $id.")
    }

    private suspend fun duplicateGearChecklist(id: Long, now: Long): ConflictApplyResult {
        val current = gearChecklistDao.getChecklistById(id) ?: return ConflictApplyResult.missing("Gear checklist $id no longer exists.")
        val newId = gearChecklistDao.insertChecklist(current.copyForDuplicate(now))
        return ConflictApplyResult.applied("Created duplicate gear checklist $newId from local row $id.")
    }

    private fun remoteObjectFor(item: SyncQueueEntity): JsonObject? {
        item.remotePayload?.parseJsonObject()?.let { return it }
        val payload = item.payload.parseJsonObject() ?: return null
        payload["remote"]?.asObject()?.let { return it }
        return null
    }

    private fun String?.parseJsonObject(): JsonObject? = this
        ?.takeIf { it.isNotBlank() }
        ?.let { runCatching { Json.parseToJsonElement(it).jsonObject }.getOrNull() }

    private fun JsonElement.asObject(): JsonObject? = this as? JsonObject

    private fun JsonObject.stringValue(vararg keys: String): String? = firstPrimitive(keys)?.contentOrNull
    private fun JsonObject.longValue(vararg keys: String): Long? = firstPrimitive(keys)?.longOrNull
    private fun JsonObject.intValue(vararg keys: String): Int? = firstPrimitive(keys)?.intOrNull
    private fun JsonObject.doubleValue(vararg keys: String): Double? = firstPrimitive(keys)?.doubleOrNull
    private fun JsonObject.booleanValue(vararg keys: String): Boolean? = firstPrimitive(keys)?.booleanOrNull
    private fun JsonObject.firstPrimitive(keys: Array<out String>): JsonPrimitive? = keys
        .asSequence()
        .mapNotNull { get(it) as? JsonPrimitive }
        .firstOrNull()


    private fun DumpsterSpotEntity.copyForDuplicate(now: Long): DumpsterSpotEntity = copy(
        id = 0,
        remoteId = null,
        ownerUserId = null,
        name = "$name (local copy)",
        syncStatus = "LOCAL_ONLY",
        createdAt = now,
        updatedAt = now,
        deletedAt = null
    )

    private fun PersonalReportEntity.copyForDuplicate(now: Long): PersonalReportEntity = copy(
        id = 0,
        remoteId = null,
        ownerUserId = null,
        spotName = if (spotName.isBlank()) "Local copy" else "$spotName (local copy)",
        syncStatus = "LOCAL_ONLY",
        createdAt = now,
        updatedAt = now,
        deletedAt = null
    )

    private fun TireSpotEntity.copyForDuplicate(now: Long): TireSpotEntity = copy(
        id = 0,
        remoteId = null,
        ownerUserId = null,
        name = "$name (local copy)",
        syncStatus = "LOCAL_ONLY",
        createdAt = now,
        updatedAt = now,
        deletedAt = null
    )

    private fun TireReportEntity.copyForDuplicate(now: Long): TireReportEntity = copy(
        id = 0,
        remoteId = null,
        ownerUserId = null,
        spotName = if (spotName.isBlank()) "Local copy" else "$spotName (local copy)",
        syncStatus = "LOCAL_ONLY",
        createdAt = now,
        updatedAt = now,
        deletedAt = null
    )

    private fun FieldLocationEntity.copyForDuplicate(now: Long): FieldLocationEntity = copy(
        id = 0,
        remoteId = null,
        ownerUserId = null,
        name = "$name (local copy)",
        syncStatus = "LOCAL_ONLY",
        conflictStatus = "NONE",
        createdAt = now,
        updatedAt = now,
        deletedAt = null
    )

    private fun CollectionEntity.copyForDuplicate(now: Long): CollectionEntity = copy(
        id = 0,
        remoteId = null,
        ownerUserId = null,
        name = "$name (local copy)",
        syncStatus = "LOCAL_ONLY",
        createdAt = now,
        updatedAt = now,
        deletedAt = null
    )

    private fun FieldSessionEntity.copyForDuplicate(now: Long): FieldSessionEntity = copy(
        id = 0,
        remoteId = null,
        ownerUserId = null,
        title = "$title (local copy)",
        syncStatus = "LOCAL_ONLY",
        createdAt = now,
        updatedAt = now,
        deletedAt = null
    )

    private fun ReminderEntity.copyForDuplicate(now: Long): ReminderEntity = copy(
        id = 0,
        remoteId = null,
        ownerUserId = null,
        label = if (label.isBlank()) "Local copy" else "$label (local copy)",
        syncStatus = "LOCAL_ONLY",
        createdAt = now,
        updatedAt = now,
        deletedAt = null
    )

    private fun RoutePlanEntity.copyForDuplicate(now: Long): RoutePlanEntity = copy(
        id = 0,
        remoteId = null,
        ownerUserId = null,
        name = "$name (local copy)",
        syncStatus = "LOCAL_ONLY",
        createdAt = now,
        updatedAt = now,
        deletedAt = null
    )

    private fun GearChecklistEntity.copyForDuplicate(now: Long): GearChecklistEntity = copy(
        id = 0,
        remoteId = null,
        ownerUserId = null,
        name = "$name (local copy)",
        syncStatus = "LOCAL_ONLY",
        createdAt = now,
        updatedAt = now,
        deletedAt = null
    )
}

data class ConflictApplyResult(
    val applied: Boolean,
    val message: String
) {
    companion object {
        fun applied(message: String) = ConflictApplyResult(applied = true, message = message)
        fun missing(message: String) = ConflictApplyResult(applied = false, message = message)
        fun unsupported(message: String) = ConflictApplyResult(applied = false, message = message)
    }
}
