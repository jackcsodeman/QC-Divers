package com.dumpsterscout.ui.sync

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.theme.DsElevation
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.DumpsterScoutTheme
import com.dumpsterscout.ui.theme.ScoutSurface0
import com.dumpsterscout.ui.theme.ScoutSurface2
import java.text.DateFormat
import java.util.Date

@Composable
fun SyncStatusScreen(
    onNavigateBack: () -> Unit,
    viewModel: SyncStatusViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    SyncStatusScreenContent(
        uiState = uiState,
        onNavigateBack = onNavigateBack,
        onEvent = viewModel::onEvent
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SyncStatusScreenContent(
    uiState: SyncStatusUiState,
    onNavigateBack: () -> Unit,
    onEvent: (SyncStatusEvent) -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(uiState.message) {
        uiState.message?.let {
            snackbarHostState.showSnackbar(it)
            onEvent(SyncStatusEvent.ClearMessage)
        }
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = "Sync Status",
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Navigate back")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = ScoutSurface0
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            item {
                SyncSummaryCard(uiState)
            }
            item {
                SyncActionsCard(uiState, onEvent)
            }
            if (uiState.items.isEmpty()) {
                item { EmptySyncCard() }
            } else {
                items(uiState.items, key = { it.id }) { item ->
                    SyncQueueItemCard(item)
                }
            }
            item { Spacer(Modifier.height(DsSpacing.xl)) }
        }
    }
}

@Composable
private fun SyncSummaryCard(uiState: SyncStatusUiState) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card)
    ) {
        Column(
            modifier = Modifier.padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                Icon(Icons.Default.CloudSync, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text("Local sync queue", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            Text(
                "Room remains the source of truth. This queue shows local changes waiting for optional Supabase sync.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                AssistChip(onClick = {}, label = { Text("${uiState.pendingCount} pending") })
                AssistChip(onClick = {}, label = { Text("${uiState.failedCount} failed") })
                AssistChip(onClick = {}, label = { Text("${uiState.succeededCount} done") })
            }
        }
    }
}

@Composable
private fun SyncActionsCard(
    uiState: SyncStatusUiState,
    onEvent: (SyncStatusEvent) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card)
    ) {
        Column(
            modifier = Modifier.padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            Button(
                onClick = { onEvent(SyncStatusEvent.ProcessNow) },
                enabled = !uiState.isProcessing,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (uiState.isProcessing) {
                    CircularProgressIndicator(modifier = Modifier.height(18.dp), strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Default.Sync, contentDescription = null)
                }
                Text(if (uiState.isProcessing) " Processing" else " Process queue now")
            }
            OutlinedButton(
                onClick = { onEvent(SyncStatusEvent.RetryFailed) },
                enabled = uiState.failedCount > 0 && !uiState.isProcessing,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Text(" Retry failed")
            }
            OutlinedButton(
                onClick = { onEvent(SyncStatusEvent.PruneSucceeded) },
                enabled = uiState.succeededCount > 0 && !uiState.isProcessing,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null)
                Text(" Clear completed")
            }
        }
    }
}

@Composable
private fun EmptySyncCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2)
    ) {
        Column(modifier = Modifier.padding(DsSpacing.l), verticalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
            Icon(Icons.Default.CloudDone, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text("Nothing waiting to sync", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(
                "Local-only changes stay on this device. Signed-in users can process queued changes when Supabase is configured.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun SyncQueueItemCard(item: SyncQueueItemUi) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2)
    ) {
        Column(modifier = Modifier.padding(DsSpacing.m), verticalArrangement = Arrangement.spacedBy(DsSpacing.xs)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (item.status == "FAILED") Icons.Default.Error else Icons.Default.CloudSync,
                    contentDescription = null,
                    tint = if (item.status == "FAILED") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
                Column(modifier = Modifier.weight(1f).padding(start = DsSpacing.s)) {
                    Text("${item.operation} ${item.entityType}", style = MaterialTheme.typography.titleSmall)
                    Text("Status: ${item.status} · retries: ${item.retryCount}", style = MaterialTheme.typography.bodySmall)
                }
            }
            item.lastError?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
            Text(
                "Updated ${DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(item.updatedAt))}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun SyncStatusPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        SyncStatusScreenContent(
            uiState = SyncStatusUiState(
                items = listOf(
                    SyncQueueItemUi(1, "DUMPSTER_SPOT", "CREATE", "PENDING", 0, null, 0, System.currentTimeMillis()),
                    SyncQueueItemUi(2, "PHOTO", "UPLOAD_PHOTO", "FAILED", 2, "Network unavailable", 0, System.currentTimeMillis())
                )
            ),
            onNavigateBack = {},
            onEvent = {}
        )
    }
}
