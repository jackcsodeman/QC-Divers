package com.dumpsterscout.ui.tire

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.usecase.SaveTireReportUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Intents for the Tire Report screen.
 */
sealed class TireReportIntent {
    data class Init(val spotId: Long, val spotName: String) : TireReportIntent()
    data class UpdateField(val update: (TireReport) -> TireReport) : TireReportIntent()
    data object Save : TireReportIntent()
    data object ClearSaved : TireReportIntent()
    data object ClearError : TireReportIntent()
}

/**
 * UI State for the Tire Report screen.
 */
data class TireReportUiState(
    val report: TireReport = TireReport(tireSpotId = 0),
    val spotName: String = "",
    val isLoading: Boolean = false,
    val isSaved: Boolean = false,
    val error: String? = null
)

/**
 * MVI ViewModel for creating and saving a new tire spot report.
 */
@HiltViewModel
class TireReportViewModel @Inject constructor(
    private val saveTireReportUseCase: SaveTireReportUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(TireReportUiState())
    val uiState: StateFlow<TireReportUiState> = _uiState.asStateFlow()

    /**
     * Handle incoming UI intents.
     */
    fun onIntent(intent: TireReportIntent) {
        when (intent) {
            is TireReportIntent.Init -> _uiState.update { it.copy(report = TireReport(tireSpotId = intent.spotId), spotName = intent.spotName) }
            is TireReportIntent.UpdateField -> _uiState.update { it.copy(report = intent.update(it.report)) }
            TireReportIntent.Save -> saveReport()
            TireReportIntent.ClearSaved -> _uiState.update { it.copy(isSaved = false) }
            TireReportIntent.ClearError -> _uiState.update { it.copy(error = null) }
        }
    }

    private fun saveReport() {
        viewModelScope.launch {
            try {
                _uiState.update { it.copy(isLoading = true) }
                saveTireReportUseCase(_uiState.value.report)
                    .onSuccess {
                        _uiState.update { it.copy(isLoading = false, isSaved = true) }
                    }
                    .onFailure { e ->
                        _uiState.update { it.copy(error = e.message ?: "Failed to save report", isLoading = false) }
                    }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
    }
}
