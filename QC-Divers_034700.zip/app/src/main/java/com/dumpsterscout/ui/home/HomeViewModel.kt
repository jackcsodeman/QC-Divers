package com.dumpsterscout.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.data.local.dao.RoutePlanDao
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.repository.ReportRepository
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.domain.repository.TireReportRepository
import com.dumpsterscout.domain.repository.TireSpotRepository
import com.dumpsterscout.util.DsLogger
import com.dumpsterscout.util.HapticFeedback
import com.dumpsterscout.util.SampleData
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Intents for the Home dashboard.
 */
sealed class HomeIntent {
    /** Toggle the favorite status of a dumpster spot. */
    data class ToggleFavorite(val spotId: Long) : HomeIntent()
    /** Clear the current error state. */
    data object ClearError : HomeIntent()
    /** Manually trigger a data refresh. */
    data object RefreshData : HomeIntent()
}

/**
 * Side effects for the Home dashboard.
 */
sealed class HomeEffect {
    /** Show a transient message to the user. */
    data class ShowSnackbar(val message: String) : HomeEffect()
    /** Trigger a haptic pulse. */
    data object TriggerHaptic : HomeEffect()
}

/**
 * UI State for the Home dashboard.
 */
data class HomeUiState(
    val spots: List<DumpsterSpot> = emptyList(),
    val recentReports: List<PersonalReport> = emptyList(),
    val favoriteSpots: List<DumpsterSpot> = emptyList(),
    val isLoading: Boolean = true,
    val totalSpots: Int = 0,
    val totalReports: Int = 0,
    val activeTireSpots: Int = 0,
    val recentTireReports: List<TireReport> = emptyList(),
    val error: String? = null
)

/**
 * MVI ViewModel for the Home dashboard, managing stats and recent activity.
 */
@HiltViewModel
class HomeViewModel @Inject constructor(
    private val spotRepository: SpotRepository,
    private val reportRepository: ReportRepository,
    private val tireSpotRepository: TireSpotRepository,
    private val tireReportRepository: TireReportRepository,
    private val appPreferences: AppPreferences,
    private val routePlanDao: RoutePlanDao,
    private val haptic: HapticFeedback
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private val _effect = Channel<HomeEffect>(Channel.BUFFERED)
    /** Stream of side effects emitted by the ViewModel. */
    val effect: Flow<HomeEffect> = _effect.receiveAsFlow()

    init {
        seedDemoDataIfNeeded()
        observeData()
    }

    private fun observeData() {
        viewModelScope.launch {
            try {
                combine(
                    combine(
                        spotRepository.getActiveSpots(),
                        spotRepository.getFavoriteSpots(),
                        reportRepository.getRecentReports(10),
                        reportRepository.getReportCount(),
                        tireSpotRepository.getActiveSpots()
                    ) { spots, favorites, recentReports, totalReports, tireSpots ->
                        HomeUiState(
                            spots             = spots,
                            recentReports     = recentReports,
                            favoriteSpots     = favorites,
                            isLoading         = false,
                            totalSpots        = spots.size,
                            totalReports      = totalReports,
                            activeTireSpots   = tireSpots.size
                        )
                    },
                    tireReportRepository.getRecentReports(3)
                ) { state, tireReports ->
                    state.copy(recentTireReports = tireReports)
                }.collect { state ->
                    _uiState.value = state
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
    }

    /**
     * Handle incoming UI intents.
     *
     * @param intent The intent to process.
     */
    fun onIntent(intent: HomeIntent) {
        when (intent) {
            is HomeIntent.ToggleFavorite -> toggleFavorite(intent.spotId)
            HomeIntent.ClearError -> _uiState.update { it.copy(error = null) }
            HomeIntent.RefreshData -> observeData()
        }
    }

    private fun seedDemoDataIfNeeded() {
        viewModelScope.launch {
            try {
                val seeded = appPreferences.demoDataSeeded.first()
                if (!seeded) {
                    SampleData.spots.forEach { spot -> spotRepository.upsertSpot(spot) }
                    SampleData.reports.forEach { report -> reportRepository.insertReport(report) }
                    SampleData.tireSpots.forEach { spot -> tireSpotRepository.upsertSpot(spot) }
                    SampleData.tireReports.forEach { report -> tireReportRepository.insertReport(report) }
                    SampleData.routes.forEach { route -> routePlanDao.insert(route) }
                    appPreferences.setDemoDataSeeded(true)
                }
            } catch (e: Exception) {
                DsLogger.e("HomeViewModel", "Demo seeding failed.", e)
            }
        }
    }

    private fun toggleFavorite(spotId: Long) {
        viewModelScope.launch {
            try {
                spotRepository.toggleFavorite(spotId)
                haptic.tick()
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "An unexpected error occurred") }
            }
        }
    }
}
