package com.dumpsterscout.ui.photos

import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun createFieldPhotoUri(context: Context): Uri {
    val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    val directory = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "field_photos")
    directory.mkdirs()
    val photoFile = File(directory, "qc_divers_$timestamp.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", photoFile)
}
