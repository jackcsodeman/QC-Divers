package com.dumpsterscout.ui.community

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.Visibility
import com.dumpsterscout.domain.repository.CommunityRepository
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.domain.repository.TireSpotRepository
import com.dumpsterscout.domain.usecase.CalculateSpotConfidenceUseCase
import com.dumpsterscout.domain.usecase.SpotConfidence
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * UI State for the community discovery features.
 * 
 * @property dumpsterSpots Shared dumpster spots from the community.
 * @property tireSpots Shared tire spots from the community.
 * @property selectedDumpsterSpot The dumpster spot currently being viewed in detail.
 * @property selectedTireSpot The tire spot currently being viewed in detail.
 * @property selectedSpotConfidence The calculated confidence level for the selected spot.
 * @property isLoading Whether community data is being fetched.
 * @property error An optional error message.
 * @property reportSuccess Whether a content report was submitted successfully.
 */
data class CommunityUiState(
    val dumpsterSpots: List<DumpsterSpot> = emptyList(),
    val tireSpots: List<TireSpot> = emptyList(),
    val selectedDumpsterSpot: DumpsterSpot? = null,
    val selectedTireSpot: TireSpot? = null,
    val selectedSpotConfidence: SpotConfidence? = null,
    val isLoading: Boolean = false,
    val error: String? = null,
    val reportSuccess: Boolean = false
)

/**
 * MVI ViewModel for browsing community-shared dumpster and tire spots.
 * 
 * @property communityRepository The repository for shared community data.
 * @property privateSpotRepository Repository for the user's private dumpster spots.
 * @property privateTireSpotRepository Repository for the user's private tire spots.
 * @property calculateSpotConfidenceUseCase Use case for spot reliability analysis.
 */
@HiltViewModel
class CommunityViewModel @Inject constructor(
    private val communityRepository: CommunityRepository,
    private val privateSpotRepository: SpotRepository,
    private val privateTireSpotRepository: TireSpotRepository,
    private val calculateSpotConfidenceUseCase: CalculateSpotConfidenceUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(CommunityUiState())
    /** The current UI state. */
    val uiState: StateFlow<CommunityUiState> = _uiState.asStateFlow()

    init {
        observeCommunityData()
        refresh()
    }

    private fun observeCommunityData() {
        communityRepository.getCommunityDumpsterSpots()
            .onEach { spots -> _uiState.update { it.copy(dumpsterSpots = spots) } }
            .launchIn(viewModelScope)

        communityRepository.getCommunityTireSpots()
            .onEach { spots -> _uiState.update { it.copy(tireSpots = spots) } }
            .launchIn(viewModelScope)
    }

    /**
     * Loads a specific dumpster spot and calculates its community confidence level.
     * 
     * @param remoteId The backend ID of the spot.
     */
    fun loadDumpsterSpot(remoteId: String) {
        communityRepository.getCommunityDumpsterSpot(remoteId)
            .onEach { spot ->
                _uiState.update { it.copy(selectedDumpsterSpot = spot) }
                if (spot != null) {
                    val confidence = calculateSpotConfidenceUseCase(spot)
                    _uiState.update { it.copy(selectedSpotConfidence = confidence) }
                }
            }
            .launchIn(viewModelScope)
    }

    /**
     * Loads a specific tire spot.
     * 
     * @param remoteId The backend ID of the spot.
     */
    fun loadTireSpot(remoteId: String) {
        communityRepository.getCommunityTireSpot(remoteId)
            .onEach { spot -> _uiState.update { it.copy(selectedTireSpot = spot) } }
            .launchIn(viewModelScope)
    }

    /**
     * Refreshes the community feed from the remote backend.
     */
    fun refresh() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            try {
                communityRepository.refreshCommunityData()
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "Failed to refresh community data") }
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    /**
     * Clones a community dumpster spot into the user's private local collection.
     * 
     * @param spot The shared spot to import.
     */
    fun importDumpsterSpot(spot: DumpsterSpot) {
        viewModelScope.launch {
            try {
                val localCopy = spot.copy(
                    id = 0L,
                    remoteId = null,
                    ownerUserId = null,
                    syncStatus = SyncStatus.LOCAL_ONLY,
                    visibility = Visibility.PRIVATE,
                    isFavorite = false
                )
                privateSpotRepository.upsertSpot(localCopy)
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "Failed to import spot: ${e.message}") }
            }
        }
    }

    /**
     * Clones a community tire spot into the user's private local collection.
     * 
     * @param spot The shared spot to import.
     */
    fun importTireSpot(spot: TireSpot) {
        viewModelScope.launch {
            try {
                val localCopy = spot.copy(
                    id = 0L,
                    remoteId = null,
                    ownerUserId = null,
                    syncStatus = SyncStatus.LOCAL_ONLY,
                    visibility = Visibility.PRIVATE,
                    isFavorite = false
                )
                privateTireSpotRepository.upsertSpot(localCopy)
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "Failed to import tire spot: ${e.message}") }
            }
        }
    }

    /**
     * Submits a report for moderation.
     * 
     * @param targetTable The entity type being reported.
     * @param targetRemoteId The backend ID of the content.
     * @param reason The report category.
     * @param notes Additional context from the reporting user.
     */
    fun reportContent(
        targetTable: String,
        targetRemoteId: String,
        reason: String,
        notes: String
    ) {
        viewModelScope.launch {
            val result = communityRepository.reportSpot(targetTable, targetRemoteId, reason, notes)
            if (result.isSuccess) {
                _uiState.update { it.copy(reportSuccess = true) }
            } else {
                _uiState.update { it.copy(error = result.exceptionOrNull()?.message ?: "Report failed") }
            }
        }
    }

    /**
     * Blocks all content from a specific user.
     * 
     * @param targetRemoteUserId The backend ID of the user to block.
     */
    fun blockUser(targetRemoteUserId: String) {
        viewModelScope.launch {
            val result = communityRepository.blockUser(targetRemoteUserId)
            if (result.isSuccess) {
                refresh()
            } else {
                _uiState.update { it.copy(error = result.exceptionOrNull()?.message ?: "Block failed") }
            }
        }
    }

    /**
     * Clears the report success flag.
     */
    fun clearReportSuccess() {
        _uiState.update { it.copy(reportSuccess = false) }
    }

    /**
     * Clears the current error message.
     */
    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }
}
