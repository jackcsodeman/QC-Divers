package com.dumpsterscout.ui.account

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import com.dumpsterscout.ui.theme.DsSpacing
import kotlinx.coroutines.delay

/**
 * A landing screen for OAuth/Magic Link redirects.
 * 
 * Satisfies the "Authorization Path" requirement from Supabase while
 * providing feedback to the user that they are being signed in.
 *
 * @param onAuthFinished Callback to execute when the consent/redirection period ends.
 */
@Composable
fun AuthConsentScreen(
    onAuthFinished: () -> Unit
) {
    // Usually, the MainActivity handles the actual token processing.
    // This screen just shows a status message and then navigates home.
    LaunchedEffect(Unit) {
        delay(2000) // Brief delay to show the status
        onAuthFinished()
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            CircularProgressIndicator()
            Text(
                text = "Completing sign-in...",
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center
            )
            Text(
                text = "You'll be redirected in a moment.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}
