package com.dumpsterscout.ui.settings

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.BuildConfig
import com.dumpsterscout.R
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.DumpsterScoutTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    onNavigateToAbout: () -> Unit = {},
    onNavigateToAccount: () -> Unit = {},
    onNavigateToSyncStatus: () -> Unit = {},
    onNavigateToConflicts: () -> Unit = {},
    onNavigateToReminders: () -> Unit = {},
    onNavigateToFieldLocations: () -> Unit = {},
    onNavigateToCollections: () -> Unit = {},
    onNavigateToFieldSessions: () -> Unit = {},
    onNavigateToGearChecklist: () -> Unit = {},
    onNavigateToAnalytics: () -> Unit = {},
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val exportFileName = stringResource(R.string.backup_export_file_name)
    var pendingExportJson by remember { mutableStateOf<String?>(null) }

    fun readTextFromUri(uri: Uri): String = context.contentResolver.openInputStream(uri)
        ?.bufferedReader()
        ?.use { it.readText() }
        ?: error(context.getString(R.string.import_file_open_failed))

    fun writeTextToUri(uri: Uri, json: String) {
        context.contentResolver.openOutputStream(uri)
            ?.bufferedWriter()
            ?.use { it.write(json) }
            ?: error(context.getString(R.string.export_file_open_failed))
    }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        val json = pendingExportJson
        pendingExportJson = null
        if (uri == null || json == null) {
            Toast.makeText(context, context.getString(R.string.export_cancelled), Toast.LENGTH_SHORT).show()
            viewModel.clearExportResult()
            return@rememberLauncherForActivityResult
        }
        runCatching { writeTextToUri(uri, json) }
            .onSuccess { Toast.makeText(context, context.getString(R.string.exported_to_file), Toast.LENGTH_SHORT).show() }
            .onFailure { Toast.makeText(context, context.getString(R.string.export_failed_with_reason, it.message ?: "Unknown error"), Toast.LENGTH_LONG).show() }
        viewModel.clearExportResult()
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching { readTextFromUri(uri) }
            .onSuccess(viewModel::previewImportData)
            .onFailure { Toast.makeText(context, context.getString(R.string.import_preview_failed_with_reason, it.message ?: "Unknown error"), Toast.LENGTH_LONG).show() }
    }

    // Handle exported JSON — save through Android Storage Access Framework.
    LaunchedEffect(uiState.exportedJson) {
        uiState.exportedJson?.let { json ->
            pendingExportJson = json
            exportLauncher.launch(exportFileName)
        }
    }

    // Handle import result
    LaunchedEffect(uiState.importResult) {
        uiState.importResult?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearImportResult()
        }
    }

    // Handle preference save errors
    LaunchedEffect(uiState.prefError) {
        uiState.prefError?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearPrefError()
        }
    }

    // Clear data confirmation dialog
    if (uiState.showClearConfirm) {
        AlertDialog(
            onDismissRequest = viewModel::dismissClearConfirm,
            title    = { Text(stringResource(R.string.clear_all_data_title)) },
            text     = { Text(stringResource(R.string.clear_all_data_message)) },
            confirmButton = {
                TextButton(
                    onClick = viewModel::confirmClearData,
                    colors  = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.delete_everything)) }
            },
            dismissButton = {
                TextButton(onClick = viewModel::dismissClearConfirm) { Text(stringResource(R.string.cancel)) }
            }
        )
    }

    uiState.importPreview?.let { preview ->
        AlertDialog(
            onDismissRequest = viewModel::dismissImportPreview,
            title = { Text(stringResource(R.string.import_preview_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                    Text(
                        stringResource(
                            R.string.import_preview_summary,
                            preview.totalRows,
                            preview.knownTablesWithRows,
                            preview.schemaVersion
                        ),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (preview.unknownTables.isNotEmpty()) {
                        Text(
                            stringResource(R.string.import_preview_unknown_tables, preview.unknownTables.joinToString()),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    Text(
                        stringResource(R.string.import_preview_replace_warning),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = preview.unknownTables.isEmpty(),
                    onClick = viewModel::confirmImportPreview
                ) { Text(stringResource(R.string.import_preview_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = viewModel::dismissImportPreview) { Text(stringResource(R.string.cancel)) }
            }
        )
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.settings_title),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            SettingsGroup(stringResource(R.string.settings_group_appearance)) {
                ToggleSettingItem(
                    title         = stringResource(R.string.dark_theme),
                    icon          = Icons.Default.DarkMode,
                    checked       = uiState.darkTheme,
                    onCheckedChange = viewModel::setDarkTheme
                )
                ToggleSettingItem(
                    title         = stringResource(R.string.dynamic_color),
                    icon          = Icons.Default.Palette,
                    subtitle      = stringResource(R.string.dynamic_color_desc),
                    checked       = uiState.dynamicColor,
                    onCheckedChange = viewModel::setDynamicColor
                )
                ToggleSettingItem(
                    title         = stringResource(R.string.field_mode),
                    icon          = Icons.Default.FlashlightOn,
                    subtitle      = stringResource(R.string.field_mode_desc),
                    checked       = uiState.fieldMode,
                    onCheckedChange = viewModel::setFieldMode
                )
            }

            SettingsGroup(stringResource(R.string.settings_group_data)) {
                SettingsItem(
                    title   = stringResource(R.string.export_data),
                    icon    = Icons.Default.FileUpload,
                    subtitle = stringResource(R.string.export_data_subtitle),
                    onClick = viewModel::exportData
                )
                SettingsItem(
                    title   = stringResource(R.string.import_data),
                    icon    = Icons.Default.FileDownload,
                    subtitle = stringResource(R.string.import_data_subtitle),
                    onClick = { importLauncher.launch(arrayOf("application/json", "text/*", "*/*")) }
                )
                SettingsItem(
                    title      = stringResource(R.string.clear_data),
                    icon       = Icons.Default.DeleteForever,
                    tintColor  = MaterialTheme.colorScheme.error,
                    onClick    = viewModel::requestClearData
                )
            }

            SettingsGroup(stringResource(R.string.settings_group_field_tools)) {
                SettingsItem(
                    title    = stringResource(R.string.field_locations_title),
                    icon     = Icons.Default.Place,
                    subtitle = stringResource(R.string.field_locations_subtitle),
                    onClick  = onNavigateToFieldLocations
                )
                SettingsItem(
                    title    = stringResource(R.string.collections_title),
                    icon     = Icons.Default.Folder,
                    subtitle = stringResource(R.string.collections_subtitle),
                    onClick  = onNavigateToCollections
                )
                SettingsItem(
                    title    = stringResource(R.string.field_sessions_title),
                    icon     = Icons.Default.History,
                    subtitle = stringResource(R.string.field_sessions_subtitle),
                    onClick  = onNavigateToFieldSessions
                )
                SettingsItem(
                    title    = stringResource(R.string.gear_checklist_title),
                    icon     = Icons.Default.Checklist,
                    subtitle = stringResource(R.string.gear_checklist_subtitle),
                    onClick  = onNavigateToGearChecklist
                )
                SettingsItem(
                    title    = stringResource(R.string.reminders_title),
                    icon     = Icons.Default.Notifications,
                    subtitle = stringResource(R.string.reminders_subtitle),
                    onClick  = onNavigateToReminders
                )
            }

            SettingsGroup(stringResource(R.string.settings_group_insights)) {
                SettingsItem(
                    title    = stringResource(R.string.analytics_title),
                    icon     = Icons.Default.Insights,
                    subtitle = stringResource(R.string.analytics_subtitle),
                    onClick  = onNavigateToAnalytics
                )
            }

            SettingsGroup(stringResource(R.string.settings_group_sync)) {
                SettingsItem(
                    title    = stringResource(R.string.sync_status_title),
                    icon     = Icons.Default.Sync,
                    subtitle = stringResource(R.string.sync_status_subtitle),
                    onClick  = onNavigateToSyncStatus
                )
                SettingsItem(
                    title    = stringResource(R.string.conflicts_title),
                    icon     = Icons.Default.ReportProblem,
                    subtitle = stringResource(R.string.conflicts_subtitle),
                    onClick  = onNavigateToConflicts
                )
            }

            SettingsGroup(stringResource(R.string.about)) {
                SettingsItem(
                    title    = stringResource(R.string.settings_account_title),
                    icon     = Icons.Default.AccountCircle,
                    subtitle = stringResource(R.string.settings_account_subtitle),
                    onClick  = onNavigateToAccount
                )
                SettingsItem(
                    title    = stringResource(R.string.about_dumpster_scout),
                    icon     = Icons.Default.Info,
                    subtitle = stringResource(R.string.app_version_credit, BuildConfig.VERSION_NAME),
                    onClick  = onNavigateToAbout
                )
            }

            // Safety note
            Surface(
                color    = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f),
                shape    = MaterialTheme.shapes.medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(DsSpacing.l)
            ) {
                Row(
                    modifier  = Modifier.padding(DsSpacing.m),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                ) {
                    Icon(
                        Icons.Default.Warning, stringResource(R.string.cd_safety_warning),
                        tint     = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        stringResource(R.string.safety_disclaimer),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }

            Spacer(Modifier.height(DsSpacing.xxxl))
        }
    }
}

@Composable
private fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(
        title,
        style    = MaterialTheme.typography.labelSmall,
        color    = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(horizontal = DsSpacing.l, vertical = DsSpacing.s)
    )
    Column(content = content)
    HorizontalDivider(modifier = Modifier.padding(vertical = DsSpacing.xs))
}

@Composable
private fun ToggleSettingItem(
    title: String,
    icon: ImageVector,
    subtitle: String? = null,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier  = Modifier
            .fillMaxWidth()
            .padding(horizontal = DsSpacing.l, vertical = DsSpacing.m),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(DsSpacing.l)
    ) {
        Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            subtitle?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SettingsItem(
    title: String,
    icon: ImageVector,
    subtitle: String? = null,
    tintColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    onClick: () -> Unit
) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier  = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.l)
        ) {
            Icon(icon, contentDescription = title, tint = tintColor)
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyLarge, color = tintColor)
                subtitle?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Icon(Icons.Default.ChevronRight, contentDescription = stringResource(R.string.cd_open_setting, title), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ── Previews ──────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "Settings dark")
@Composable
private fun SettingsDarkPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title = "Settings",
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Navigate back")
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                SettingsGroup("Appearance") {
                    ToggleSettingItem(title = "Dark Theme", icon = Icons.Default.DarkMode, checked = true, onCheckedChange = {})
                    ToggleSettingItem(title = "Dynamic Color", icon = Icons.Default.Palette, subtitle = "Material You color from wallpaper (Android 12+)", checked = false, onCheckedChange = {})
                    ToggleSettingItem(title = "Field Mode", icon = Icons.Default.FlashlightOn, subtitle = "Larger controls, night-friendly display", checked = false, onCheckedChange = {})
                }
                SettingsGroup("Data") {
                    SettingsItem(title = "Export Data", icon = Icons.Default.FileUpload, onClick = {})
                    SettingsItem(title = "Import Data", icon = Icons.Default.FileDownload, onClick = {})
                    SettingsItem(title = "Clear All Data", icon = Icons.Default.DeleteForever, tintColor = MaterialTheme.colorScheme.error, onClick = {})
                }
                SettingsGroup("About") {
                    SettingsItem(title = "About Dumpster Scout", icon = Icons.Default.Info, subtitle = "v1.1.1b · Jack Sodeman-Dickey", onClick = {})
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, name = "Settings light")
@Composable
private fun SettingsLightPreview() {
    DumpsterScoutTheme(darkTheme = false) {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title = "Settings",
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Navigate back")
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                SettingsGroup("Appearance") {
                    ToggleSettingItem(title = "Dark Theme", icon = Icons.Default.DarkMode, checked = false, onCheckedChange = {})
                    ToggleSettingItem(title = "Field Mode", icon = Icons.Default.FlashlightOn, subtitle = "Larger controls, night-friendly display", checked = false, onCheckedChange = {})
                }
                SettingsGroup("Data") {
                    SettingsItem(title = "Export Data", icon = Icons.Default.FileUpload, onClick = {})
                }
            }
        }
    }
}