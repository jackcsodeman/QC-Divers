package com.dumpsterscout.ui.tire

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

/**
 * Legacy ViewModel being phased out in favor of specific MVI ViewModels.
 */
@HiltViewModel
class TireSpotViewModel @Inject constructor() : ViewModel() {
    // Phasing out in favor of TireSpotListViewModel, TireSpotDetailViewModel, etc.
}
