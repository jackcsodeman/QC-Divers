package com.dumpsterscout.ui.history

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.ui.components.*
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.DumpsterScoutTheme
import com.dumpsterscout.util.SampleData
import com.dumpsterscout.util.timeAgoString

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    onNavigateBack: () -> Unit,
    onNavigateToSpotDetail: (Long) -> Unit,
    viewModel: HistoryViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.error) {
        uiState.error?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.onIntent(HistoryIntent.ClearError)
        }
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.history_title),
                subtitle = pluralStringResource(R.plurals.history_entries, uiState.filteredReports.size, uiState.filteredReports.size),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            // Search
            DsSearchField(
                value         = uiState.searchQuery,
                onValueChange = { viewModel.onIntent(HistoryIntent.Search(it)) },
                placeholder   = stringResource(R.string.search_logs),
                modifier      = Modifier.padding(horizontal = DsSpacing.l, vertical = DsSpacing.s)
            )

            // Period filter chips
            val periodOptions = listOf(
                stringResource(R.string.filter_all)      to (uiState.filterPeriod == FilterPeriod.ALL),
                stringResource(R.string.filter_today)    to (uiState.filterPeriod == FilterPeriod.TODAY),
                stringResource(R.string.filter_this_week) to (uiState.filterPeriod == FilterPeriod.THIS_WEEK)
            )
            FilterChipGroup(
                options  = periodOptions,
                onSelect = { idx -> viewModel.onIntent(HistoryIntent.ChangePeriod(FilterPeriod.entries[idx])) },
                modifier = Modifier.padding(horizontal = DsSpacing.l)
            )
            Spacer(Modifier.height(DsSpacing.s))

            when {
                uiState.isLoading -> {
                    Column(
                        modifier  = Modifier.padding(DsSpacing.l),
                        verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) { repeat(5) { LoadingShimmerCard() } }
                }
                uiState.filteredReports.isEmpty() -> {
                    EmptyStatePanel(
                        message  = if (uiState.reports.isEmpty())
                            stringResource(R.string.no_activity_yet)
                        else
                            stringResource(R.string.no_reports_match),
                        icon     = if (uiState.reports.isEmpty())
                            Icons.Default.HistoryEdu
                        else
                            Icons.Default.SearchOff,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                else -> {
                    LazyColumn(
                        contentPadding      = PaddingValues(horizontal = DsSpacing.l, vertical = DsSpacing.s),
                        verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) {
                        items(uiState.filteredReports, key = { it.id }) { report ->
                            HistoryReportCardWrapper(
                                report  = report,
                                onClick = { onNavigateToSpotDetail(report.spotId) },
                                onDelete = { viewModel.onIntent(HistoryIntent.DeleteReport(report)) }
                            )
                        }
                        item { Spacer(Modifier.height(DsSpacing.xxxl)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryReportCardWrapper(
    report: PersonalReport,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteDialog by remember { mutableStateOf(false) }

    if (showDeleteDialog) {
        DeleteConfirmDialog(
            title     = stringResource(R.string.confirm_delete_report_title),
            message   = stringResource(R.string.confirm_delete_report_message),
            onConfirm = { onDelete(); showDeleteDialog = false },
            onDismiss = { showDeleteDialog = false }
        )
    }

    val flags = buildList {
        if (report.bagsFresh == true)       add("Fresh bags")
        if (report.alreadyPickedThrough)    add("Picked through")
        if (report.rainDamage)              add("Rain damage")
        if (report.securitySeen)            add("Security")
        if (report.cameTooEarly)            add("Too early")
        if (report.cameTooLate)             add("Too late")
    }

    HistoryEventCard(
        spotName  = report.spotName,
        status    = report.status,
        isVoice   = report.isFromVoice,
        timestamp = timeAgoString(report.timestamp),
        notes     = report.notes,
        flags     = flags,
        onClick   = onClick,
        onDelete  = { showDeleteDialog = true }
    )
}

// ── Previews ──────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "History – filled (dark)")
@Composable
private fun HistoryFilledPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title    = "Activity Log",
                    subtitle = "${SampleData.reports.size} entries",
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                contentPadding      = PaddingValues(horizontal = DsSpacing.l, vertical = DsSpacing.s),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.s),
                modifier            = Modifier.padding(padding)
            ) {
                items(SampleData.reports, key = { it.id }) { report ->
                    val flags = buildList {
                        if (report.bagsFresh == true)    add("Fresh bags")
                        if (report.alreadyPickedThrough) add("Picked through")
                        if (report.rainDamage)           add("Rain damage")
                        if (report.securitySeen)         add("Security")
                        if (report.cameTooEarly)         add("Too early")
                        if (report.cameTooLate)          add("Too late")
                    }
                    HistoryEventCard(
                        spotName  = report.spotName,
                        status    = report.status,
                        isVoice   = report.isFromVoice,
                        timestamp = timeAgoString(report.timestamp),
                        notes     = report.notes,
                        flags     = flags,
                        onClick   = {},
                        onDelete  = {}
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, name = "History – empty")
@Composable
private fun HistoryEmptyPreview() {
    DumpsterScoutTheme {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title    = "Activity Log",
                    subtitle = "0 entries",
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                        }
                    }
                )
            }
        ) { padding ->
            EmptyStatePanel(
                message  = "No reports yet. Start logging to see history here.",
                icon     = Icons.Default.HistoryEdu,
                modifier = Modifier.fillMaxSize().padding(padding)
            )
        }
    }
}
