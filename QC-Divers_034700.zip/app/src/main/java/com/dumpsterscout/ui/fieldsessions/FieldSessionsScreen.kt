package com.dumpsterscout.ui.fieldsessions

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.data.local.entity.FieldSessionVisitEntity
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.EmptyStatePanel
import com.dumpsterscout.ui.theme.DsElevation
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.GradeHigh
import com.dumpsterscout.ui.theme.ScoutSurface2
import com.dumpsterscout.util.toShortDateString

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FieldSessionsScreen(
    onNavigateBack: () -> Unit,
    viewModel: FieldSessionsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var showStartDialog by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.message) { uiState.message?.let { snackbarHostState.showSnackbar(it); viewModel.clearMessage() } }
    LaunchedEffect(uiState.error) { uiState.error?.let { snackbarHostState.showSnackbar(it); viewModel.clearError() } }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.field_sessions_title),
                subtitle = stringResource(R.string.field_sessions_subtitle),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            if (uiState.activeSession == null) {
                FloatingActionButton(onClick = { showStartDialog = true }) { Icon(Icons.Default.PlayArrow, contentDescription = stringResource(R.string.field_session_start)) }
            }
        }
    ) { padding ->
        if (uiState.sessions.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                EmptyStatePanel(message = stringResource(R.string.field_sessions_empty), icon = Icons.Default.Timeline)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(DsSpacing.l),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                items(uiState.sessions, key = { it.session.id }) { session ->
                    FieldSessionCard(
                        sessionUi = session,
                        active = session.session.endedAt == null,
                        candidates = uiState.candidates,
                        onEnd = { viewModel.endSession(session.session.id) },
                        onAddVisit = { viewModel.addVisit(session.session.id, it) },
                        onDeleteVisit = viewModel::deleteVisit
                    )
                }
                item { Spacer(Modifier.height(DsSpacing.giant)) }
            }
        }
    }

    if (showStartDialog) {
        StartSessionDialog(
            onDismiss = { showStartDialog = false },
            onStart = { title, notes -> viewModel.startSession(title, notes); showStartDialog = false }
        )
    }
}

@Composable
private fun FieldSessionCard(
    sessionUi: SessionUi,
    active: Boolean,
    candidates: List<SessionLocationCandidate>,
    onEnd: () -> Unit,
    onAddVisit: (SessionLocationCandidate) -> Unit,
    onDeleteVisit: (Long) -> Unit
) {
    var addExpanded by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card)
    ) {
        Column(Modifier.padding(DsSpacing.l), verticalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)) {
                Icon(Icons.Default.Timeline, contentDescription = stringResource(R.string.cd_field_session_icon), tint = if (active) GradeHigh else MaterialTheme.colorScheme.primary)
                Column(Modifier.weight(1f)) {
                    Text(sessionUi.session.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(sessionUi.session.startedAt.toShortDateString(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (active) {
                    AssistChip(onClick = {}, label = { Text(stringResource(R.string.field_session_active)) })
                    IconButton(onClick = onEnd) { Icon(Icons.Default.Stop, contentDescription = stringResource(R.string.cd_end_field_session_named, sessionUi.session.title), tint = MaterialTheme.colorScheme.error) }
                }
            }
            Text(pluralStringResource(R.plurals.field_session_visits, sessionUi.visits.size, sessionUi.visits.size), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (sessionUi.session.notes.isNotBlank()) Text(sessionUi.session.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            sessionUi.visits.forEach { visit -> VisitRow(visit, onDelete = { onDeleteVisit(visit.id) }) }
            if (active) {
                TextButton(onClick = { addExpanded = !addExpanded }) { Icon(Icons.Default.Add, contentDescription = stringResource(R.string.field_session_add_visit)); Text(stringResource(R.string.field_session_add_visit)) }
                if (addExpanded) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                        items(candidates.take(24), key = { it.type + it.id }) { candidate ->
                            AssistChip(onClick = { onAddVisit(candidate) }, label = { Text(candidate.label, maxLines = 1) }, leadingIcon = { Icon(Icons.Default.Add, contentDescription = stringResource(R.string.cd_add_visit_named, candidate.label)) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VisitRow(visit: FieldSessionVisitEntity, onDelete: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
        Text(visit.label.ifBlank { "${visit.locationType} #${visit.locationId}" }, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Text(visit.locationType.lowercase().replace('_', ' '), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.cd_delete_visit_named, visit.label.ifBlank { visit.locationType }), tint = MaterialTheme.colorScheme.error) }
    }
}

@Composable
private fun StartSessionDialog(onDismiss: () -> Unit, onStart: (String, String) -> Unit) {
    var title by remember { mutableStateOf("Field Run") }
    var notes by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.field_session_start)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text(stringResource(R.string.field_session_title_label)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text(stringResource(R.string.field_session_notes_label)) }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            }
        },
        confirmButton = { Button(onClick = { onStart(title, notes) }, enabled = title.isNotBlank()) { Text(stringResource(R.string.field_session_start)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}
