package com.dumpsterscout.ui.photos

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.PhotoAttachment
import com.dumpsterscout.domain.model.UploadStatus
import com.dumpsterscout.domain.repository.PhotoRepository
import com.dumpsterscout.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SpotPhotoUiState(
    val ownerType: String = "DUMPSTER_SPOT",
    val ownerId: Long = 0L,
    val photos: List<PhotoAttachment> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val lastAddedPhotoId: Long? = null
)

@HiltViewModel
class SpotPhotoViewModel @Inject constructor(
    private val photoRepository: PhotoRepository,
    private val userRepository: UserRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SpotPhotoUiState())
    val uiState: StateFlow<SpotPhotoUiState> = _uiState.asStateFlow()
    private var loadJob: Job? = null

    /** Backward-compatible dumpster-spot loader. */
    fun load(spotId: Long) = loadOwner(ownerType = "DUMPSTER_SPOT", ownerId = spotId)

    fun loadOwner(ownerType: String, ownerId: Long) {
        if (_uiState.value.ownerType == ownerType && _uiState.value.ownerId == ownerId && _uiState.value.photos.isNotEmpty()) return
        loadJob?.cancel()
        _uiState.update { it.copy(ownerType = ownerType, ownerId = ownerId, isLoading = true, error = null) }
        loadJob = viewModelScope.launch {
            try {
                photoRepository.getPhotosForOwner(ownerType, ownerId).collect { photos ->
                    _uiState.update { it.copy(photos = photos, isLoading = false) }
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message ?: "Failed to load photos.") }
            }
        }
    }

    fun addPhoto(localUri: String) {
        val state = _uiState.value
        if (state.ownerId <= 0L || state.ownerType.isBlank() || localUri.isBlank()) return
        viewModelScope.launch {
            try {
                val user = userRepository.getOrCreateUser()
                val now = System.currentTimeMillis()
                val id = photoRepository.addPhoto(
                    PhotoAttachment(
                        ownerId = state.ownerId,
                        ownerType = state.ownerType,
                        localUri = localUri,
                        uploadStatus = UploadStatus.PENDING_UPLOAD,
                        ownerUserId = user.remoteUserId ?: user.localId,
                        takenAt = now,
                        createdAt = now,
                        updatedAt = now
                    )
                )
                _uiState.update { it.copy(lastAddedPhotoId = id, error = null) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "Failed to add photo.") }
            }
        }
    }

    fun deletePhoto(photoId: Long) {
        viewModelScope.launch {
            try {
                photoRepository.softDeletePhoto(photoId)
                _uiState.update { it.copy(error = null) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "Failed to delete photo.") }
            }
        }
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }

    fun clearLastAdded() {
        _uiState.update { it.copy(lastAddedPhotoId = null) }
    }
}
