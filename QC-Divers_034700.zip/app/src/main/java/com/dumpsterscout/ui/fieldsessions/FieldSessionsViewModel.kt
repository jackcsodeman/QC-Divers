package com.dumpsterscout.ui.fieldsessions

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.data.local.dao.DumpsterSpotDao
import com.dumpsterscout.data.local.dao.FieldLocationDao
import com.dumpsterscout.data.local.dao.FieldSessionDao
import com.dumpsterscout.data.local.dao.TireSpotDao
import com.dumpsterscout.data.local.entity.FieldSessionEntity
import com.dumpsterscout.data.local.entity.FieldSessionVisitEntity
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.data.sync.SyncEntityType
import com.dumpsterscout.data.sync.SyncQueueOperation
import com.dumpsterscout.data.sync.SyncQueueWriter
import com.dumpsterscout.di.SupabaseCredentials
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject

@Serializable
data class FieldSessionSyncPayload(
    val session: FieldSessionEntity,
    val visits: List<FieldSessionVisitEntity>
)

data class SessionLocationCandidate(
    val type: String,
    val id: Long,
    val label: String
)

data class SessionUi(
    val session: FieldSessionEntity,
    val visits: List<FieldSessionVisitEntity>,
    val syncStatusLabel: String = session.syncStatus.replace('_', ' ')
)

data class FieldSessionsUiState(
    val sessions: List<SessionUi> = emptyList(),
    val activeSession: FieldSessionEntity? = null,
    val candidates: List<SessionLocationCandidate> = emptyList(),
    val isLoading: Boolean = true,
    val message: String? = null,
    val error: String? = null
)

@HiltViewModel
class FieldSessionsViewModel @Inject constructor(
    private val sessionDao: FieldSessionDao,
    private val credentials: SupabaseCredentials,
    private val prefs: AppPreferences,
    private val syncQueue: SyncQueueWriter,
    spotDao: DumpsterSpotDao,
    tireSpotDao: TireSpotDao,
    fieldLocationDao: FieldLocationDao
) : ViewModel() {
    private val message = MutableStateFlow<String?>(null)
    private val error = MutableStateFlow<String?>(null)

    @Suppress("UNCHECKED_CAST")
    val uiState: StateFlow<FieldSessionsUiState> = combine(
        listOf(
            sessionDao.observeSessions().map { it as Any },
            sessionDao.observeActiveSession().map { it as Any? },
            sessionDao.observeVisits().map { it as Any },
            spotDao.getAllActiveSpots().map { list -> list.map { SessionLocationCandidate("DUMPSTER_SPOT", it.id, it.name) } as Any },
            tireSpotDao.getAllActiveSpots().map { list -> list.map { SessionLocationCandidate("TIRE_SPOT", it.id, it.name) } as Any },
            fieldLocationDao.observeActive().map { list -> list.map { SessionLocationCandidate(it.type, it.id, it.name) } as Any },
            message.map { it as Any? },
            error.map { it as Any? }
        )
    ) { values ->
        val sessions = values[0] as List<FieldSessionEntity>
        val active = values[1] as FieldSessionEntity?
        val visits = values[2] as List<FieldSessionVisitEntity>
        val candidates = (values[3] as List<SessionLocationCandidate>) +
            (values[4] as List<SessionLocationCandidate>) +
            (values[5] as List<SessionLocationCandidate>)
        FieldSessionsUiState(
            sessions = sessions.map { session -> SessionUi(session, visits.filter { it.sessionId == session.id }) },
            activeSession = active,
            candidates = candidates.sortedBy { it.label.lowercase() },
            isLoading = false,
            message = values[6] as String?,
            error = values[7] as String?
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), FieldSessionsUiState())

    fun clearMessage() { message.value = null }
    fun clearError() { error.value = null }

    fun startSession(title: String, notes: String) {
        if (title.isBlank()) {
            error.value = "Session title is required."
            return
        }
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                val ownerId = prefs.localUserId.first()
                val id = sessionDao.insertSession(
                    FieldSessionEntity(
                        ownerUserId = ownerId,
                        title = title.trim(),
                        notes = notes.trim(),
                        startedAt = now,
                        syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else "LOCAL_ONLY",
                        createdAt = now,
                        updatedAt = now
                    )
                )
                queueSessionIfConfigured(id, SyncQueueOperation.CREATE)
                message.value = "Session started."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to start session."
            }
        }
    }

    fun endSession(sessionId: Long) {
        viewModelScope.launch {
            try {
                sessionDao.endSession(sessionId)
                queueSessionIfConfigured(sessionId, SyncQueueOperation.UPDATE)
                message.value = "Session ended."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to end session."
            }
        }
    }

    fun addVisit(sessionId: Long, candidate: SessionLocationCandidate) {
        viewModelScope.launch {
            try {
                sessionDao.insertVisit(FieldSessionVisitEntity(sessionId = sessionId, locationType = candidate.type, locationId = candidate.id, label = candidate.label))
                queueSessionIfConfigured(sessionId, SyncQueueOperation.UPDATE)
                message.value = "Visit added."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to add visit."
            }
        }
    }

    fun deleteVisit(visitId: Long) {
        viewModelScope.launch {
            try {
                val visit = sessionDao.getVisitById(visitId)
                sessionDao.deleteVisit(visitId)
                if (visit != null) queueSessionIfConfigured(visit.sessionId, SyncQueueOperation.UPDATE)
                message.value = "Visit removed."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to remove visit."
            }
        }
    }

    private suspend fun queueSessionIfConfigured(
        sessionId: Long,
        operation: SyncQueueOperation,
        explicitRemoteId: String? = null
    ) {
        if (!credentials.isConfigured) return
        val session = sessionDao.getSessionById(sessionId) ?: return
        sessionDao.markPendingSync(sessionId)
        val visits = sessionDao.getVisitsForSessionSnapshot(sessionId)
        syncQueue.enqueue(
            entityType = SyncEntityType.FIELD_SESSION,
            entityLocalId = sessionId,
            entityRemoteId = explicitRemoteId ?: session.remoteId,
            operation = operation,
            payload = Json.encodeToString(FieldSessionSyncPayload(session, visits))
        )
    }
}
