package com.dumpsterscout.ui.community

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Notes
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.usecase.SpotConfidence
import com.dumpsterscout.ui.components.*
import com.dumpsterscout.ui.theme.*
import com.dumpsterscout.util.timeAgoString

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommunitySpotDetailScreen(
    remoteId: String,
    onNavigateBack: () -> Unit,
    viewModel: CommunityViewModel = hiltViewModel()
) {
    LaunchedEffect(remoteId) {
        viewModel.loadDumpsterSpot(remoteId)
    }

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val spot = uiState.selectedDumpsterSpot
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val reportSuccessMsg = stringResource(R.string.report_success_message)
    var showReportDialog by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.error) {
        uiState.error?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearError()
        }
    }

    LaunchedEffect(uiState.reportSuccess) {
        if (uiState.reportSuccess) {
            snackbarHostState.showSnackbar(reportSuccessMsg)
            viewModel.clearReportSuccess()
        }
    }

    if (showReportDialog && spot != null) {
        ReportDialog(
            onDismiss = { showReportDialog = false },
            onSubmit = { reason, notes ->
                showReportDialog = false
                viewModel.reportContent(
                    targetTable = "DUMPSTER_SPOT",
                    targetRemoteId = spot.remoteId ?: "",
                    reason = reason,
                    notes = notes
                )
            }
        )
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = spot?.name ?: stringResource(R.string.spot_detail_title),
                subtitle = spot?.let {
                    it.category.name.lowercase().replaceFirstChar { c -> c.uppercaseChar() }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                },
                actions = {
                    if (spot != null) {
                        IconButton(onClick = {
                            val sendIntent: Intent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, "Check out this spot on QC Divers: qcdivers://spot/${spot.remoteId}")
                                type = "text/plain"
                            }
                            val shareIntent = Intent.createChooser(sendIntent, null)
                            context.startActivity(shareIntent)
                        }) {
                            Icon(Icons.Default.Share, stringResource(R.string.cd_share_spot))
                        }
                        IconButton(onClick = { viewModel.importDumpsterSpot(spot) }) {
                            Icon(Icons.Default.ContentCopy, stringResource(R.string.import_to_my_spots))
                        }
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Default.MoreVert, stringResource(R.string.cd_more_options))
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.report_content)) },
                                onClick = {
                                    showMenu = false
                                    showReportDialog = true
                                },
                                leadingIcon = { Icon(Icons.Default.Report, null, tint = MaterialTheme.colorScheme.error) }
                            )
                            spot.ownerUserId?.let { ownerId ->
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.block_user)) },
                                    onClick = {
                                        showMenu = false
                                        viewModel.blockUser(ownerId)
                                        onNavigateBack()
                                    },
                                    leadingIcon = { Icon(Icons.Default.Block, null) }
                                )
                            }
                        }
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        if (uiState.isLoading) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(DsSpacing.l),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                repeat(4) { LoadingShimmerCard() }
            }
            return@Scaffold
        }

        if (spot == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                EmptyStatePanel(message = stringResource(R.string.spot_not_found))
            }
            return@Scaffold
        }

        CommunitySpotDetailContent(
            spot = spot,
            confidence = uiState.selectedSpotConfidence,
            onImport = { viewModel.importDumpsterSpot(spot) },
            modifier = Modifier.padding(padding)
        )
    }
}

@Composable
private fun CommunitySpotDetailContent(
    spot: DumpsterSpot,
    confidence: SpotConfidence?,
    onImport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = categoryColor(spot.category)

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            horizontal = DsSpacing.l,
            vertical = DsSpacing.m
        ),
        verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
    ) {
        // ── Remote Image Gallery ──────────────────────────────────────────
        if (spot.communityPhotoUrls.isNotEmpty()) {
            item {
                CommunityPhotoGallery(urls = spot.communityPhotoUrls)
            }
        }

        // ── Community Badge ────────────────────────────────────────────────
        item {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = MaterialTheme.shapes.small,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(DsSpacing.s),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.People, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(DsSpacing.s))
                    Text(
                        stringResource(R.string.community_badge),
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }

        // ── Confidence Engine ──────────────────────────────────────────────
        confidence?.let { conf ->
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = when(conf) {
                            SpotConfidence.TRENDING -> ScoutAmberWarm.copy(alpha = 0.15f)
                            SpotConfidence.LIKELY_EMPTY -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
                            else -> ScoutSurface2
                        }
                    ),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Row(
                        modifier = Modifier.padding(DsSpacing.m),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) {
                        Icon(
                            imageVector = when(conf) {
                                SpotConfidence.TRENDING -> Icons.Default.Whatshot
                                SpotConfidence.LIKELY_EMPTY -> Icons.Default.Info
                                else -> Icons.Default.Analytics
                            },
                            contentDescription = null,
                            tint = when(conf) {
                                SpotConfidence.TRENDING -> ScoutAmberWarm
                                SpotConfidence.LIKELY_EMPTY -> MaterialTheme.colorScheme.error
                                else -> MaterialTheme.colorScheme.primary
                            }
                        )
                        Column {
                            Text(
                                text = when(conf) {
                                    SpotConfidence.TRENDING -> "🔥 Trending Spot"
                                    SpotConfidence.HIGH_CONFIDENCE -> "Verified History"
                                    SpotConfidence.NEEDS_CHECK -> "Needs New Intel"
                                    SpotConfidence.LIKELY_EMPTY -> "Likely Empty"
                                    SpotConfidence.UNCERTAIN -> "Limited Data"
                                },
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = when(conf) {
                                    SpotConfidence.TRENDING -> "Multiple scouts reported hauls here recently."
                                    SpotConfidence.LIKELY_EMPTY -> "Recent reports suggest this spot is empty."
                                    else -> "Community consensus based on recent activity."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // ── Risk banner ────────────────────────────────────────────────────
        item {
            val risks = buildList {
                if (spot.securityCommon) add(stringResource(R.string.risk_security_patrols))
                if (spot.hasCameras)     add(stringResource(R.string.risk_cameras_present))
                if (spot.isLocked)       add(stringResource(R.string.risk_dumpster_locked))
                if (spot.staffDestroyItems) add(stringResource(R.string.risk_staff_destroys))
                if (spot.isCompactor)    add(stringResource(R.string.risk_compactor_only))
            }
            RiskBanner(risks = risks)
        }

        // ── Rich header card ───────────────────────────────────────────────
        item { CommunitySpotHeaderCard(spot = spot, accent = accent) }

        // ── Access information ─────────────────────────────────────────────
        if (spot.accessNotes.isNotBlank() || spot.isFenced || spot.isGated || spot.isLocked || spot.isCompactor) {
            item {
                CollapsibleSection(
                    title     = stringResource(R.string.section_access),
                    icon      = Icons.Default.Key,
                    accent    = accent,
                    startOpen = true
                ) {
                    if (spot.accessNotes.isNotBlank()) {
                        Text(spot.accessNotes, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(DsSpacing.s))
                    }
                    CommunityAccessBadgesRow(spot)
                }
            }
        }

        // ── Pickup schedule ────────────────────────────────────────────────
        if (spot.pickupDays.isNotBlank() || spot.pickupTimeWindow.isNotBlank()) {
            item {
                CollapsibleSection(
                    title = stringResource(R.string.section_pickup_schedule),
                    icon  = Icons.Default.Schedule
                ) {
                    if (spot.pickupDays.isNotBlank())       InfoRow(stringResource(R.string.label_days), spot.pickupDays)
                    if (spot.pickupTimeWindow.isNotBlank()) InfoRow(stringResource(R.string.label_time), spot.pickupTimeWindow)
                    InfoRow(
                        stringResource(R.string.label_best_time),
                        spot.bestTimeOfDay.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }
                    )
                }
            }
        }

        // ── Typical finds ──────────────────────────────────────────────────
        if (spot.usualFindings.isNotBlank() || spot.avoidReasons.isNotBlank()) {
            item {
                CollapsibleSection(
                    title = stringResource(R.string.section_typical_finds),
                    icon  = Icons.Default.Inventory2
                ) {
                    if (spot.usualFindings.isNotBlank()) {
                        Text(spot.usualFindings, style = MaterialTheme.typography.bodyMedium)
                    }
                    if (spot.avoidReasons.isNotBlank()) {
                        Spacer(Modifier.height(DsSpacing.xs))
                        InfoRow(
                            label      = stringResource(R.string.label_avoid),
                            value      = spot.avoidReasons,
                            valueColor = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }

        // ── Grade card ─────────────────────────────────────
        if (spot.grade.isGraded()) {
            item { GradeCard(grade = spot.grade) }
        }

        // ── Tags ───────────────────────────────────────────────────────────
        if (spot.tags.isNotEmpty()) {
            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    spot.tags.forEach { tag ->
                        SuggestionChip(
                            onClick = {},
                            label   = { Text(tag, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }
        }

        // ── Import Button ──────────────────────────────────────────────────
        item {
            Button(
                onClick = onImport,
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium
            ) {
                Icon(Icons.Default.ContentCopy, null)
                Spacer(Modifier.width(DsSpacing.s))
                Text(stringResource(R.string.import_to_my_spots))
            }
        }

        item { Spacer(Modifier.height(DsSpacing.xxxl)) }
    }
}

@Composable
private fun CollapsibleSection(
    title: String,
    icon: ImageVector = Icons.Default.ChevronRight,
    accent: Color? = null,
    startOpen: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    var expanded by remember { mutableStateOf(startOpen) }
    val chevronRotation by animateFloatAsState(
        targetValue = if (expanded) 90f else 0f,
        animationSpec = tween(DsMotion.fast, easing = DsEasing.emphasizedDecelerate),
        label = "chevron_rotation"
    )

    Card(
        modifier  = Modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = tween(DsMotion.medium, easing = DsEasing.emphasizedDecelerate)),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.medium
    ) {
        Column {
            if (accent != null) {
                Box(Modifier.fillMaxWidth().height(3.dp).background(accent))
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(DsSpacing.l),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                Icon(icon, null, tint = accent ?: MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Text(title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                Icon(
                    Icons.Default.ChevronRight,
                    stringResource(R.string.cd_toggle_section),
                    modifier = Modifier.size(20.dp).rotate(chevronRotation),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter   = fadeIn(tween(DsMotion.fast)) + expandVertically(tween(DsMotion.medium, easing = DsEasing.emphasizedDecelerate)),
                exit    = fadeOut(tween(DsMotion.fast)) + shrinkVertically(tween(DsMotion.fast, easing = DsEasing.emphasizedAccelerate))
            ) {
                Column(modifier = Modifier.padding(start = DsSpacing.l, end = DsSpacing.l, bottom = DsSpacing.l)) {
                    content()
                }
            }
        }
    }
}

@Composable
private fun CommunitySpotHeaderCard(spot: DumpsterSpot, accent: Color) {
    Card(
        modifier  = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(listOf(accent.copy(alpha = 0.45f), accent.copy(alpha = 0.10f))),
                shape = MaterialTheme.shapes.large
            ),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.raised),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.large
    ) {
        Box {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .clip(MaterialTheme.shapes.large)
                    .background(accentHeaderBrush(accent))
            )
            Column(modifier = Modifier.padding(DsSpacing.l)) {
                Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                    StatusChip(status = spot.lastStatus)
                    if (spot.isVerified) ConditionTag(label = stringResource(R.string.condition_verified))
                }
                Spacer(Modifier.height(DsSpacing.m))

                Text(
                    spot.category.name.lowercase().replaceFirstChar { it.uppercaseChar() },
                    style = MaterialTheme.typography.labelMedium,
                    color = accent
                )
                if (spot.address.isNotBlank()) {
                    Text(
                        spot.address,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                spot.lastChecked?.let {
                    Text(
                        stringResource(R.string.checked_time_ago, timeAgoString(it)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(Modifier.height(DsSpacing.m))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(DsSpacing.s),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (spot.grade.isGraded()) {
                        SpotStatChip(
                            icon  = Icons.Default.Star,
                            value = "%.1f".format(spot.grade.overall),
                            label = stringResource(R.string.stat_score),
                            color = gradeColor(spot.grade.overall, inverted = false),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (spot.pickupDays.isNotBlank()) {
                        SpotStatChip(
                            icon  = Icons.Default.CalendarToday,
                            value = spot.pickupDays.split(",").firstOrNull() ?: spot.pickupDays,
                            label = stringResource(R.string.stat_pickup),
                            color = ScoutAmberWarm,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    SpotStatChip(
                        icon  = Icons.Default.Place,
                        value = spot.spotLocation.name.lowercase().replace('_', ' ')
                            .replaceFirstChar { it.uppercaseChar() }
                            .take(8),
                        label = stringResource(R.string.stat_location),
                        color = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun CommunityPhotoGallery(urls: List<String>) {
    val pagerState = rememberPagerState(pageCount = { urls.size })
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp)
            .clip(MaterialTheme.shapes.large)
            .background(ScoutSurface2)
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            AsyncImage(
                model = urls[page].optimizeSupabaseImage(width = 800),
                contentDescription = "Community photo ${page + 1}",
                modifier = Modifier.fillMaxSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop
            )
        }
        
        // Page indicator
        if (urls.size > 1) {
            Surface(
                color = Color.Black.copy(alpha = 0.5f),
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(DsSpacing.m)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = DsSpacing.s, vertical = DsSpacing.xs),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    repeat(urls.size) { iteration ->
                        val color = if (pagerState.currentPage == iteration) Color.White else Color.White.copy(alpha = 0.5f)
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(color)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Extension to append Supabase optimization parameters to image URLs.
 */
fun String.optimizeSupabaseImage(width: Int, quality: Int = 80): String {
    return if (contains("storage/v1/object/public")) {
        val separator = if (contains("?")) "&" else "?"
        "$this${separator}width=$width&quality=$quality"
    } else this
}

@Composable
private fun CommunityAccessBadgesRow(spot: DumpsterSpot) {
    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs), modifier = Modifier.fillMaxWidth()) {
        if (spot.isFenced)       ConditionTag(stringResource(R.string.condition_fenced))
        if (spot.isGated)        ConditionTag(stringResource(R.string.condition_gated))
        if (spot.isLocked)       ConditionTag(stringResource(R.string.condition_locked),    isWarning = true)
        if (spot.isCompactor)    ConditionTag(stringResource(R.string.condition_compactor), isWarning = true)
        if (spot.hasCameras)     ConditionTag(stringResource(R.string.condition_cameras))
        if (spot.securityCommon) ConditionTag(stringResource(R.string.condition_security),  isWarning = true)
    }
}
