package com.dumpsterscout.ui.map

enum class MapLocationType { DUMPSTER, TIRE, FIELD }

data class MapLocationItem(
    val localId: Long,
    val type: MapLocationType,
    val name: String,
    val subtitle: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val statusLabel: String,
    val isFavorite: Boolean,
    val syncStatus: String,
    val visibility: String,
    val isCommunity: Boolean = false,
    val remoteId: String? = null,
    val lastChecked: Long? = null
) {
    val hasCoordinates: Boolean get() = latitude != 0.0 || longitude != 0.0
}
