package com.dumpsterscout.ui.favorites

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.domain.usecase.ToggleSpotFavoriteUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for managing the favorites screen state.
 */
@HiltViewModel
class FavoritesViewModel @Inject constructor(
    private val spotRepository: SpotRepository,
    private val toggleSpotFavoriteUseCase: ToggleSpotFavoriteUseCase
) : ViewModel() {

    /**
     * Observable stream of favorite spots.
     */
    val favoriteSpots: StateFlow<List<DumpsterSpot>> = spotRepository.getFavoriteSpots()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    /**
     * Toggle the favorite status of a spot.
     */
    fun toggleFavorite(spotId: Long) {
        viewModelScope.launch {
            toggleSpotFavoriteUseCase(spotId)
        }
    }
}
