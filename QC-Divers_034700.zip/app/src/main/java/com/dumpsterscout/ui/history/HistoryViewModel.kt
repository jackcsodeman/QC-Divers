package com.dumpsterscout.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.repository.ReportRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Intents for the history screen.
 */
sealed class HistoryIntent {
    /** Change the time period for filtering reports. */
    data class ChangePeriod(val period: FilterPeriod) : HistoryIntent()
    /** Update the search query for filtering reports. */
    data class Search(val query: String) : HistoryIntent()
    /** Delete a specific report from history. */
    data class DeleteReport(val report: PersonalReport) : HistoryIntent()
    /** Clear any active error message. */
    data object ClearError : HistoryIntent()
}

/**
 * Time periods for filtering history.
 */
enum class FilterPeriod { 
    /** Show all history. */
    ALL, 
    /** Show only reports from today. */
    TODAY, 
    /** Show reports from the last 7 days. */
    THIS_WEEK 
}

/**
 * UI State for the history screen.
 * 
 * @property reports The full list of reports.
 * @property filteredReports The subset of reports matching current filters.
 * @property isLoading Whether the history is being loaded.
 * @property filterPeriod The currently active time filter.
 * @property searchQuery The current search text.
 * @property error An optional error message.
 */
data class HistoryUiState(
    val reports: List<PersonalReport> = emptyList(),
    val filteredReports: List<PersonalReport> = emptyList(),
    val isLoading: Boolean = true,
    val filterPeriod: FilterPeriod = FilterPeriod.ALL,
    val searchQuery: String = "",
    val error: String? = null
)

/**
 * MVI ViewModel for managing the activity history/log screen.
 * 
 * @property reportRepository The repository providing historical reporting data.
 */
@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val reportRepository: ReportRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HistoryUiState())
    /** The current UI state. */
    val uiState: StateFlow<HistoryUiState> = _uiState.asStateFlow()

    init {
        observeReports()
    }

    private fun observeReports() {
        reportRepository.getAllReports()
            .onEach { reports ->
                _uiState.update { state ->
                    val filtered = applyFilter(reports, state.filterPeriod, state.searchQuery)
                    state.copy(reports = reports, filteredReports = filtered, isLoading = false)
                }
            }
            .catch { e ->
                _uiState.update { it.copy(error = e.message ?: "Failed to load history", isLoading = false) }
            }
            .launchIn(viewModelScope)
    }

    /**
     * Handle incoming UI intents.
     *
     * @param intent The intent to process.
     */
    fun onIntent(intent: HistoryIntent) {
        when (intent) {
            is HistoryIntent.ChangePeriod -> {
                _uiState.update { state ->
                    val filtered = applyFilter(state.reports, intent.period, state.searchQuery)
                    state.copy(filterPeriod = intent.period, filteredReports = filtered)
                }
            }
            is HistoryIntent.Search -> {
                _uiState.update { state ->
                    val filtered = applyFilter(state.reports, state.filterPeriod, intent.query)
                    state.copy(searchQuery = intent.query, filteredReports = filtered)
                }
            }
            is HistoryIntent.DeleteReport -> {
                viewModelScope.launch {
                    try {
                        reportRepository.deleteReport(intent.report)
                    } catch (e: Exception) {
                        _uiState.update { it.copy(error = e.message ?: "Failed to delete report") }
                    }
                }
            }
            HistoryIntent.ClearError -> _uiState.update { it.copy(error = null) }
        }
    }

    /**
     * Applies current filters and search query to the raw report list.
     */
    private fun applyFilter(
        reports: List<PersonalReport>,
        period: FilterPeriod,
        query: String
    ): List<PersonalReport> {
        val now = System.currentTimeMillis()
        val oneDayMs = 86_400_000L
        val oneWeekMs = 7 * oneDayMs
        return reports.filter { report ->
            val withinPeriod = when (period) {
                FilterPeriod.ALL -> true
                FilterPeriod.TODAY -> (now - report.timestamp) < oneDayMs
                FilterPeriod.THIS_WEEK -> (now - report.timestamp) < oneWeekMs
            }
            val matchesQuery = query.isBlank() ||
                    report.spotName.contains(query, ignoreCase = true) ||
                    report.notes.contains(query, ignoreCase = true) ||
                    report.tags.any { it.contains(query, ignoreCase = true) }
            withinPeriod && matchesQuery
        }
    }
}
