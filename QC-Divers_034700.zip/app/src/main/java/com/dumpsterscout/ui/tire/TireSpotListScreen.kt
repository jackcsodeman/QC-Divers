package com.dumpsterscout.ui.tire

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.FilterListOff
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.TireSpotCategory
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.EmptyStatePanel
import com.dumpsterscout.ui.components.LoadingShimmerCard
import com.dumpsterscout.ui.theme.DsSpacing

/**
 * Screen displaying the list of all tire spots with search and filtering.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TireSpotListScreen(
    onNavigateBack: () -> Unit,
    onNavigateToTireSpotDetail: (Long) -> Unit,
    onNavigateToAddTireSpot: () -> Unit,
    viewModel: TireSpotListViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.tire_spots_count_title, uiState.spots.size),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.onIntent(TireSpotListIntent.ToggleFilterVisibility) }) {
                        Icon(
                            if (uiState.showFilters) Icons.Default.FilterListOff else Icons.Default.FilterList,
                            stringResource(R.string.cd_filter_toggle)
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick        = onNavigateToAddTireSpot,
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor   = MaterialTheme.colorScheme.onPrimaryContainer
            ) {
                Icon(Icons.Default.Add, contentDescription = stringResource(R.string.cd_add_button))
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            OutlinedTextField(
                value         = uiState.searchQuery,
                onValueChange = { viewModel.onIntent(TireSpotListIntent.Search(it)) },
                modifier      = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = DsSpacing.l, vertical = DsSpacing.s),
                placeholder   = { Text(stringResource(R.string.search_tire_spots)) },
                leadingIcon   = { Icon(Icons.Default.Search, null) },
                trailingIcon  = if (uiState.searchQuery.isNotEmpty()) {
                    {
                        IconButton(onClick = { viewModel.onIntent(TireSpotListIntent.Search("")) }) {
                            Icon(Icons.Default.Clear, stringResource(R.string.clear_search))
                        }
                    }
                } else null,
                singleLine    = true,
                shape         = MaterialTheme.shapes.medium
            )

            AnimatedVisibility(
                visible = uiState.showFilters,
                enter   = fadeIn() + expandVertically(),
                exit    = fadeOut() + shrinkVertically()
            ) {
                TireFilterRow(
                    filterCategory    = uiState.filterCategory,
                    filterStatus      = uiState.filterStatus,
                    showFavoritesOnly = uiState.showFavoritesOnly,
                    onCategoryChange  = { viewModel.onIntent(TireSpotListIntent.FilterCategory(it)) },
                    onStatusChange    = { viewModel.onIntent(TireSpotListIntent.FilterStatus(it)) },
                    onFavoritesChange = { viewModel.onIntent(TireSpotListIntent.ToggleFavorites(it)) }
                )
            }

            when {
                uiState.isLoading -> {
                    Column(
                        modifier = Modifier.padding(DsSpacing.l),
                        verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) { repeat(4) { LoadingShimmerCard() } }
                }
                uiState.spots.isEmpty() -> {
                    EmptyStatePanel(
                        message  = stringResource(R.string.no_tire_spots_match),
                        icon     = Icons.Default.SearchOff,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                else -> {
                    LazyColumn(
                        contentPadding      = PaddingValues(horizontal = DsSpacing.l, vertical = DsSpacing.s),
                        verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) {
                        items(uiState.spots, key = { it.id }) { spot ->
                            TireSpotCard(
                                spot             = spot,
                                onClick          = { onNavigateToTireSpotDetail(spot.id) },
                                onToggleFavorite = { viewModel.onIntent(TireSpotListIntent.ToggleFavorite(spot.id)) }
                            )
                        }
                        item { Spacer(Modifier.height(DsSpacing.giant + DsSpacing.l)) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TireFilterRow(
    filterCategory: TireSpotCategory?,
    filterStatus: TireSpotStatus?,
    showFavoritesOnly: Boolean,
    onCategoryChange: (TireSpotCategory?) -> Unit,
    onStatusChange: (TireSpotStatus?) -> Unit,
    onFavoritesChange: (Boolean) -> Unit
) {
    var showCategoryMenu by remember { mutableStateOf(false) }
    var showStatusMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DsSpacing.l, vertical = DsSpacing.xs),
        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
    ) {
        FilterChip(
            selected    = showFavoritesOnly,
            onClick     = { onFavoritesChange(!showFavoritesOnly) },
            label       = { Text(stringResource(R.string.filter_favorites)) },
            leadingIcon = if (showFavoritesOnly) {
                { Icon(Icons.Default.Favorite, null, modifier = Modifier.size(16.dp)) }
            } else null
        )

        Box {
            FilterChip(
                selected = filterCategory != null,
                onClick  = { showCategoryMenu = true },
                label    = {
                    Text(
                        filterCategory?.name?.lowercase()?.replace('_', ' ')?.replaceFirstChar { it.uppercaseChar() }
                            ?: stringResource(R.string.filter_category)
                    )
                }
            )
            DropdownMenu(expanded = showCategoryMenu, onDismissRequest = { showCategoryMenu = false }) {
                DropdownMenuItem(
                    text    = { Text(stringResource(R.string.filter_all_categories)) },
                    onClick = { onCategoryChange(null); showCategoryMenu = false }
                )
                TireSpotCategory.entries.forEach { cat ->
                    DropdownMenuItem(
                        text    = { Text(cat.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }) },
                        onClick = { onCategoryChange(cat); showCategoryMenu = false }
                    )
                }
            }
        }

        Box {
            FilterChip(
                selected = filterStatus != null,
                onClick  = { showStatusMenu = true },
                label    = {
                    Text(
                        filterStatus?.name?.lowercase()?.replace('_', ' ')?.replaceFirstChar { it.uppercaseChar() }
                            ?: stringResource(R.string.filter_status)
                    )
                }
            )
            DropdownMenu(expanded = showStatusMenu, onDismissRequest = { showStatusMenu = false }) {
                DropdownMenuItem(
                    text    = { Text(stringResource(R.string.filter_all_statuses)) },
                    onClick = { onStatusChange(null); showStatusMenu = false }
                )
                listOf(
                    TireSpotStatus.GOOD_USABLE,
                    TireSpotStatus.MANY_OUT,
                    TireSpotStatus.ALL_PUNCTURED,
                    TireSpotStatus.NO_TIRES,
                    TireSpotStatus.LOCKED_INACCESSIBLE
                ).forEach { st ->
                    DropdownMenuItem(
                        text    = { Text(st.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }) },
                        onClick = { onStatusChange(st); showStatusMenu = false }
                    )
                }
            }
        }
    }
}
