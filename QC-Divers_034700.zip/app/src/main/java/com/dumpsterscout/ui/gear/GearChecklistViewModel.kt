package com.dumpsterscout.ui.gear

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.data.local.dao.GearChecklistDao
import com.dumpsterscout.data.local.entity.GearChecklistEntity
import com.dumpsterscout.data.local.entity.GearChecklistItemEntity
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.data.sync.SyncEntityType
import com.dumpsterscout.data.sync.SyncQueueOperation
import com.dumpsterscout.data.sync.SyncQueueWriter
import com.dumpsterscout.di.SupabaseCredentials
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject

@Serializable
data class GearChecklistSyncPayload(
    val checklist: GearChecklistEntity,
    val items: List<GearChecklistItemEntity>
)

data class GearChecklistUiState(
    val checklist: GearChecklistEntity? = null,
    val items: List<GearChecklistItemEntity> = emptyList(),
    val isLoading: Boolean = true
) {
    val checkedCount: Int = items.count { it.isChecked }
    val progress: Float = if (items.isEmpty()) 0f else checkedCount.toFloat() / items.size
}

@HiltViewModel
class GearChecklistViewModel @Inject constructor(
    private val dao: GearChecklistDao,
    private val credentials: SupabaseCredentials,
    private val prefs: AppPreferences,
    private val syncQueue: SyncQueueWriter
) : ViewModel() {
    val uiState: StateFlow<GearChecklistUiState> = combine(
        dao.observeChecklists(),
        dao.observeItems()
    ) { checklists, items ->
        val checklist = checklists.firstOrNull()
        GearChecklistUiState(
            checklist = checklist,
            items = if (checklist == null) emptyList() else items.filter { it.checklistId == checklist.id },
            isLoading = false
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), GearChecklistUiState())

    init {
        viewModelScope.launch { ensureDefaultChecklist() }
    }

    fun toggleItem(itemId: Long, checked: Boolean) {
        viewModelScope.launch {
            dao.setChecked(itemId, checked, syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else "LOCAL_ONLY")
            dao.getItemById(itemId)?.let { queueChecklistIfConfigured(it.checklistId, SyncQueueOperation.UPDATE) }
        }
    }

    fun reset() {
        viewModelScope.launch {
            uiState.value.checklist?.let {
                dao.setAllChecked(it.id, false, syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else "LOCAL_ONLY")
                queueChecklistIfConfigured(it.id, SyncQueueOperation.UPDATE)
            }
        }
    }

    fun checkAll() {
        viewModelScope.launch {
            uiState.value.checklist?.let {
                dao.setAllChecked(it.id, true, syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else "LOCAL_ONLY")
                queueChecklistIfConfigured(it.id, SyncQueueOperation.UPDATE)
            }
        }
    }

    private suspend fun ensureDefaultChecklist() {
        if (dao.countChecklists() > 0) return
        val now = System.currentTimeMillis()
        val ownerId = prefs.localUserId.first()
        val syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else "LOCAL_ONLY"
        val checklistId = dao.insertChecklist(
            GearChecklistEntity(
                ownerUserId = ownerId,
                name = "Default Field Kit",
                syncStatus = syncStatus,
                createdAt = now,
                updatedAt = now
            )
        )
        defaultItems.forEachIndexed { index, item ->
            dao.insertItem(
                GearChecklistItemEntity(
                    ownerUserId = ownerId,
                    checklistId = checklistId,
                    label = item.label,
                    emoji = item.emoji,
                    category = item.category,
                    syncStatus = syncStatus,
                    sortOrder = index,
                    createdAt = now,
                    updatedAt = now
                )
            )
        }
        queueChecklistIfConfigured(checklistId, SyncQueueOperation.CREATE)
    }

    private suspend fun queueChecklistIfConfigured(checklistId: Long, operation: SyncQueueOperation) {
        if (!credentials.isConfigured) return
        val checklist = dao.getChecklistById(checklistId) ?: return
        dao.markChecklistPendingSync(checklistId)
        val items = dao.getItemsForChecklistSnapshot(checklistId)
        syncQueue.enqueue(
            entityType = SyncEntityType.GEAR_CHECKLIST,
            entityLocalId = checklistId,
            entityRemoteId = checklist.remoteId,
            operation = operation,
            payload = Json.encodeToString(GearChecklistSyncPayload(checklist, items))
        )
    }

    private data class DefaultGear(val label: String, val emoji: String, val category: String)

    private val defaultItems = listOf(
        DefaultGear("Gloves", "🧤", "Safety"),
        DefaultGear("Grabber / reaching tool", "🔧", "Tools"),
        DefaultGear("Flashlight / headlamp", "🔦", "Lighting"),
        DefaultGear("Extra bags / totes", "🛍", "Carry"),
        DefaultGear("Hand sanitizer", "🧴", "Safety"),
        DefaultGear("Containers / bins", "📦", "Carry"),
        DefaultGear("Water bottle", "💧", "Personal"),
        DefaultGear("Knife / box cutter", "🔪", "Tools"),
        DefaultGear("Rain gear / poncho", "🌧", "Weather"),
        DefaultGear("Boots", "👢", "Safety")
    )
}
