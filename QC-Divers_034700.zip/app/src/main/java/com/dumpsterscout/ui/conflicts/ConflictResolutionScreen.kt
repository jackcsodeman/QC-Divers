package com.dumpsterscout.ui.conflicts

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.EmptyStatePanel
import com.dumpsterscout.ui.theme.DsElevation
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.ScoutSurface2

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConflictResolutionScreen(
    onNavigateBack: () -> Unit,
    viewModel: ConflictResolutionViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.conflicts_title),
                subtitle = stringResource(R.string.conflicts_subtitle),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(DsSpacing.l),
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                Button(onClick = viewModel::retryFailed, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Sync, contentDescription = null)
                    Text(stringResource(R.string.conflict_retry_all))
                }
                OutlinedButton(onClick = viewModel::clearResolved, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.conflict_clear_resolved))
                }
            }
            if (uiState.items.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    EmptyStatePanel(message = stringResource(R.string.conflicts_empty), icon = Icons.Default.ReportProblem)
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(DsSpacing.l),
                    verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
                ) {
                    item {
                        Text(
                            text = stringResource(R.string.conflict_resolution_hint),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = DsSpacing.s)
                        )
                    }
                    items(uiState.items, key = { it.queueItem.id }) { item ->
                        ConflictCard(
                            item = item,
                            onKeepLocal = { viewModel.keepLocalAndRetry(item.queueItem.id) },
                            onAcceptRemote = { viewModel.acceptRemoteAndResolve(item.queueItem.id) },
                            onDuplicate = { viewModel.markDuplicateReviewed(item.queueItem.id) },
                            onDismiss = { viewModel.dismissQueueItem(item.queueItem.id) }
                        )
                    }
                    item { Spacer(Modifier.height(DsSpacing.giant)) }
                }
            }
        }
    }
}

@Composable
private fun ConflictCard(
    item: ConflictReviewItem,
    onKeepLocal: () -> Unit,
    onAcceptRemote: () -> Unit,
    onDuplicate: () -> Unit,
    onDismiss: () -> Unit
) {
    val queueItem = item.queueItem
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card)
    ) {
        Column(Modifier.padding(DsSpacing.l), verticalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                Icon(Icons.Default.ReportProblem, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Text("${queueItem.entityType} · ${queueItem.operation}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(queueItem.status, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
            }
            Text("Local ID: ${queueItem.entityLocalId}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (!queueItem.lastError.isNullOrBlank()) {
                Text(queueItem.lastError, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
            Text("Retry count: ${queueItem.retryCount} · Changed fields: ${item.changedFieldCount}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Text(
                text = stringResource(R.string.conflict_field_review_title),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            if (item.localFields.isEmpty()) {
                Text(
                    text = stringResource(R.string.conflict_no_field_snapshot),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                item.localFields.take(12).forEach { field ->
                    ConflictFieldRow(field)
                }
                if (item.localFields.size > 12) {
                    Text(
                        text = stringResource(R.string.conflict_more_fields, item.localFields.size - 12),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (!item.hasRemoteSnapshot) {
                Text(
                    text = stringResource(R.string.conflict_remote_snapshot_unavailable),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = onKeepLocal, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.conflict_keep_local))
                }
                if (item.hasRemoteSnapshot) {
                    OutlinedButton(onClick = onAcceptRemote, modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.conflict_accept_remote))
                    }
                    OutlinedButton(onClick = onDuplicate, modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.conflict_mark_duplicate))
                    }
                }
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.conflict_discard_queue_item))
                }
            }
        }
    }
}

@Composable
private fun ConflictFieldRow(field: ConflictFieldSnapshot) {
    Column(Modifier.fillMaxWidth()) {
        Text(
            text = field.name,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = if (field.isSensitive) stringResource(R.string.conflict_sensitive_field) else field.localValue,
            style = MaterialTheme.typography.bodySmall,
            color = if (field.isChanged) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        if (field.remoteValue != null) {
            Text(
                text = stringResource(
                    R.string.conflict_remote_value,
                    if (field.isSensitive) stringResource(R.string.conflict_sensitive_field) else field.remoteValue
                ),
                style = MaterialTheme.typography.labelSmall,
                color = if (field.isChanged) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
