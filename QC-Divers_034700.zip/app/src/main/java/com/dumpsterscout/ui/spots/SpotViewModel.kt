package com.dumpsterscout.ui.spots

import androidx.lifecycle.ViewModel
import com.dumpsterscout.domain.repository.SpotRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

/**
 * Legacy ViewModel being phased out in favor of specific MVI ViewModels.
 * TODO: Remove once all dependencies are migrated.
 */
@HiltViewModel
class SpotViewModel @Inject constructor(
    private val spotRepository: SpotRepository
) : ViewModel() {
    // This class is being phased out. Use SpotListViewModel, SpotDetailViewModel, or AddSpotViewModel.
}
