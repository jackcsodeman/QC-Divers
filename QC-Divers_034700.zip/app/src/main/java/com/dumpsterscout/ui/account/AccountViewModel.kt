package com.dumpsterscout.ui.account

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.AuthState
import com.dumpsterscout.domain.model.LocalUser
import com.dumpsterscout.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AccountUiState(
    val user: LocalUser? = null,
    val authState: AuthState = AuthState.LOADING,
    val isLoading: Boolean = false,
    /** True after SendOtp succeeds — switches the UI to OTP entry. */
    val otpSent: Boolean = false,
    /** Email address that received the current OTP. */
    val otpEmail: String = "",
    val error: String? = null,
    val accountDeleted: Boolean = false,
    val showDeleteAccountDialog: Boolean = false
)

private data class AccountFormState(
    val isLoading: Boolean,
    val otpSent: Boolean,
    val otpEmail: String,
    val error: String?
)

sealed class AccountUiEvent {
    data class SendOtp(val email: String) : AccountUiEvent()
    data class VerifyOtp(val email: String, val token: String) : AccountUiEvent()
    object SignOut : AccountUiEvent()
    object DeleteAccountAndCloudData : AccountUiEvent()
    data class ShowDeleteAccountDialog(val show: Boolean) : AccountUiEvent()
    object ClearError : AccountUiEvent()
    object ClearAccountDeleted : AccountUiEvent()
    object ResetOtpSent : AccountUiEvent()
}

@HiltViewModel
class AccountViewModel @Inject constructor(
    private val userRepository: UserRepository
) : ViewModel() {

    private val _loading = MutableStateFlow(false)
    private val _otpSent = MutableStateFlow(false)
    private val _otpEmail = MutableStateFlow("")
    private val _error = MutableStateFlow<String?>(null)
    private val _accountDeleted = MutableStateFlow(false)
    private val _showDeleteAccountDialog = MutableStateFlow(false)

    private val formState = combine(_loading, _otpSent, _otpEmail, _error) { loading, otpSent, otpEmail, error ->
        AccountFormState(loading, otpSent, otpEmail, error)
    }

    val uiState: StateFlow<AccountUiState> = combine(
        userRepository.getCurrentUser(),
        userRepository.getAuthState(),
        formState,
        _accountDeleted,
        _showDeleteAccountDialog
    ) { user, authState, form, accountDeleted, showDeleteDialog ->
        AccountUiState(
            user = user,
            authState = authState,
            isLoading = form.isLoading,
            otpSent = form.otpSent,
            otpEmail = form.otpEmail,
            error = form.error,
            accountDeleted = accountDeleted,
            showDeleteAccountDialog = showDeleteDialog
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = AccountUiState()
    )

    fun onEvent(event: AccountUiEvent) {
        when (event) {
            is AccountUiEvent.SendOtp -> sendOtp(event.email)
            is AccountUiEvent.VerifyOtp -> verifyOtp(event.email, event.token)
            is AccountUiEvent.SignOut -> signOut()
            is AccountUiEvent.DeleteAccountAndCloudData -> deleteAccountAndCloudData()
            is AccountUiEvent.ShowDeleteAccountDialog -> _showDeleteAccountDialog.value = event.show
            is AccountUiEvent.ClearError -> _error.value = null
            is AccountUiEvent.ClearAccountDeleted -> _accountDeleted.value = false
            is AccountUiEvent.ResetOtpSent -> {
                _otpSent.value = false
                _otpEmail.value = ""
            }
        }
    }

    private fun sendOtp(email: String) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            userRepository.signInWithOtp(email)
                .onSuccess {
                    _otpEmail.value = email
                    _otpSent.value = true
                }
                .onFailure { _error.value = it.message ?: "Failed to send code." }
            _loading.value = false
        }
    }

    private fun verifyOtp(email: String, token: String) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            userRepository.verifyOtp(email, token)
                .onFailure { _error.value = it.message ?: "Invalid code. Please try again." }
            _loading.value = false
        }
    }

    private fun deleteAccountAndCloudData() {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            _showDeleteAccountDialog.value = false
            userRepository.deleteAccountAndCloudData()
                .onSuccess {
                    _accountDeleted.value = true
                    _otpSent.value = false
                    _otpEmail.value = ""
                }
                .onFailure { _error.value = it.message ?: "Failed to delete account and cloud data." }
            _loading.value = false
        }
    }

    private fun signOut() {
        viewModelScope.launch {
            _loading.value = true
            userRepository.signOut()
            _otpSent.value = false
            _otpEmail.value = ""
            _loading.value = false
        }
    }
}
