package com.dumpsterscout.ui.voice

import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.model.VoiceParseResult
import com.dumpsterscout.domain.usecase.ProcessVoiceReportUseCase
import com.dumpsterscout.domain.usecase.SaveVoiceReportUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Stages of the voice reporting workflow.
 */
enum class VoicePhase { IDLE, LISTENING, PROCESSING, CONFIRM, EDIT, SAVED }

/**
 * Intents for the Voice Reporting flow.
 */
sealed class VoiceIntent {
    /** Start the system speech recognition. */
    data object StartListening : VoiceIntent()
    /** User cancelled or speech recognition failed to start. */
    data object CancelListening : VoiceIntent()
    /** System returned a final transcript string. */
    data class TranscriptReceived(val transcript: String) : VoiceIntent()
    /** Manually edit the raw transcript to refine parsing. */
    data class EditTranscript(val newTranscript: String) : VoiceIntent()
    /** Manually edit the notes field. */
    data class EditNotes(val notes: String) : VoiceIntent()
    /** Change the spot that this report is being logged to. */
    data class SelectSpot(val spot: DumpsterSpot) : VoiceIntent()
    /** Finalize and persist the report. */
    data object SaveReport : VoiceIntent()
    /** Reset the UI to the idle state. */
    data object Reset : VoiceIntent()
    /** Navigate to creation screen because no spot matched. */
    data object CreateNewSpot : VoiceIntent()
}

/**
 * Side effects for the Voice Reporting flow.
 */
sealed class VoiceEffect {
    /** Show an error message. */
    data class ShowError(@StringRes val messageRes: Int) : VoiceEffect()
    /** Request navigation back to the previous screen. */
    data object NavigateBack : VoiceEffect()
    /** Trigger a short haptic pulse. */
    data object TriggerHapticFeedback : VoiceEffect()
    /** Navigate to Add Spot screen with prefilled data. */
    data class NavigateToAddSpot(val name: String?, val location: String?, val status: SpotStatus?) : VoiceEffect()
}

/**
 * UI State for the Voice Reporting flow.
 */
data class VoiceUiState(
    val phase: VoicePhase = VoicePhase.IDLE,
    val parseResult: VoiceParseResult? = null,
    val matchedSpot: DumpsterSpot? = null,
    val candidateSpots: List<DumpsterSpot> = emptyList(),
    val editableTranscript: String = "",
    val editableNotes: String = "",
    val reportSaved: Boolean = false,
    @StringRes val errorMessageRes: Int? = null
)

/**
 * MVI ViewModel for the Voice Reporting flow.
 */
@HiltViewModel
class VoiceViewModel @Inject constructor(
    private val processVoiceReportUseCase: ProcessVoiceReportUseCase,
    private val saveVoiceReportUseCase: SaveVoiceReportUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(VoiceUiState())
    val uiState: StateFlow<VoiceUiState> = _uiState.asStateFlow()

    private val _effect = Channel<VoiceEffect>(Channel.BUFFERED)
    /** Observable stream of side effects. */
    val effect: Flow<VoiceEffect> = _effect.receiveAsFlow()

    private var parseJob: Job? = null

    /**
     * Handle incoming UI intents.
     *
     * @param intent The intent to process.
     */
    fun onIntent(intent: VoiceIntent) {
        when (intent) {
            VoiceIntent.StartListening -> startListening()
            VoiceIntent.CancelListening -> _uiState.update { it.copy(phase = VoicePhase.IDLE) }
            is VoiceIntent.TranscriptReceived -> handleTranscript(intent.transcript)
            is VoiceIntent.EditTranscript -> editTranscript(intent.newTranscript)
            is VoiceIntent.EditNotes -> _uiState.update { it.copy(editableNotes = intent.notes) }
            is VoiceIntent.SelectSpot -> _uiState.update { it.copy(matchedSpot = intent.spot) }
            VoiceIntent.SaveReport -> saveReport()
            VoiceIntent.Reset -> _uiState.value = VoiceUiState()
            VoiceIntent.CreateNewSpot -> handleCreateNewSpot()
        }
    }

    private fun startListening() {
        _uiState.update { it.copy(phase = VoicePhase.LISTENING, errorMessageRes = null) }
        viewModelScope.launch { _effect.send(VoiceEffect.TriggerHapticFeedback) }
    }

    private fun handleTranscript(transcript: String) {
        if (transcript.isBlank()) {
            _uiState.update { it.copy(phase = VoicePhase.IDLE, errorMessageRes = R.string.voice_error_no_speech) }
            return
        }
        _uiState.update { it.copy(phase = VoicePhase.PROCESSING, editableTranscript = transcript) }

        parseJob?.cancel()
        parseJob = viewModelScope.launch {
            val result = processVoiceReportUseCase(transcript)
            _uiState.update { state ->
                state.copy(
                    phase = VoicePhase.CONFIRM,
                    parseResult = result.result,
                    matchedSpot = result.matchedSpot,
                    candidateSpots = result.candidateSpots,
                    editableTranscript = transcript,
                    editableNotes = result.result.notes
                )
            }
        }
    }

    private fun editTranscript(newTranscript: String) {
        parseJob?.cancel()
        parseJob = viewModelScope.launch {
            val result = processVoiceReportUseCase(newTranscript)
            _uiState.update { state ->
                state.copy(
                    editableTranscript = newTranscript,
                    parseResult = result.result,
                    matchedSpot = result.matchedSpot ?: state.matchedSpot,
                    candidateSpots = result.candidateSpots.ifEmpty { state.candidateSpots },
                    editableNotes = result.result.notes
                )
            }
        }
    }

    private fun saveReport() {
        val state = _uiState.value
        val result = state.parseResult ?: return

        viewModelScope.launch {
            val saveResult = saveVoiceReportUseCase(
                parseResult = result,
                matchedSpot = state.matchedSpot,
                editedNotes = state.editableNotes,
                editedTranscript = state.editableTranscript
            )
            
            if (saveResult.isSuccess) {
                _uiState.update { it.copy(phase = VoicePhase.SAVED, reportSaved = true) }
                _effect.send(VoiceEffect.TriggerHapticFeedback)
            } else {
                _uiState.update { it.copy(phase = VoicePhase.IDLE, errorMessageRes = R.string.voice_error_save_failed) }
                _effect.send(VoiceEffect.ShowError(R.string.voice_error_save_failed))
            }
        }
    }

    private fun handleCreateNewSpot() {
        val res = _uiState.value.parseResult ?: return
        viewModelScope.launch {
            _effect.send(VoiceEffect.NavigateToAddSpot(
                name = res.parsedSpotName,
                location = res.locationHint,
                status = res.status
            ))
        }
    }
}
