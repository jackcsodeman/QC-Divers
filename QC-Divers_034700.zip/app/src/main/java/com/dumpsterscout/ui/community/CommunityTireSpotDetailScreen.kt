package com.dumpsterscout.ui.community

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.ui.components.*
import com.dumpsterscout.ui.theme.*
import com.dumpsterscout.ui.tire.TireStatusChip
import com.dumpsterscout.ui.tire.tireCategoryColor
import com.dumpsterscout.util.timeAgoString
import android.content.Intent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommunityTireSpotDetailScreen(
    remoteId: String,
    onNavigateBack: () -> Unit,
    viewModel: CommunityViewModel = hiltViewModel()
) {
    LaunchedEffect(remoteId) {
        viewModel.loadTireSpot(remoteId)
    }

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val spot = uiState.selectedTireSpot
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val reportSuccessMsg = stringResource(R.string.report_success_message)
    var showReportDialog by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.error) {
        uiState.error?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearError()
        }
    }

    LaunchedEffect(uiState.reportSuccess) {
        if (uiState.reportSuccess) {
            snackbarHostState.showSnackbar(reportSuccessMsg)
            viewModel.clearReportSuccess()
        }
    }

    if (showReportDialog && spot != null) {
        ReportDialog(
            onDismiss = { showReportDialog = false },
            onSubmit = { reason, notes ->
                showReportDialog = false
                viewModel.reportContent(
                    targetTable = "TIRE_SPOT",
                    targetRemoteId = spot.remoteId ?: "",
                    reason = reason,
                    notes = notes
                )
            }
        )
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = spot?.name ?: stringResource(R.string.spot_detail_title),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                },
                actions = {
                    if (spot != null) {
                        IconButton(onClick = {
                            val sendIntent: Intent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, "Check out this tire spot on QC Divers: qcdivers://spot/${spot.remoteId}")
                                type = "text/plain"
                            }
                            val shareIntent = Intent.createChooser(sendIntent, null)
                            context.startActivity(shareIntent)
                        }) {
                            Icon(Icons.Default.Share, stringResource(R.string.cd_share_spot))
                        }
                        IconButton(onClick = { viewModel.importTireSpot(spot) }) {
                            Icon(Icons.Default.ContentCopy, stringResource(R.string.import_to_my_spots))
                        }
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Default.MoreVert, stringResource(R.string.cd_more_options))
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.report_content)) },
                                onClick = {
                                    showMenu = false
                                    showReportDialog = true
                                },
                                leadingIcon = { Icon(Icons.Default.Report, null, tint = MaterialTheme.colorScheme.error) }
                            )
                            spot.ownerUserId?.let { ownerId ->
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.block_user)) },
                                    onClick = {
                                        showMenu = false
                                        viewModel.blockUser(ownerId)
                                        onNavigateBack()
                                    },
                                    leadingIcon = { Icon(Icons.Default.Block, null) }
                                )
                            }
                        }
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        if (uiState.isLoading) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(DsSpacing.l),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                repeat(4) { LoadingShimmerCard() }
            }
            return@Scaffold
        }

        if (spot == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                EmptyStatePanel(message = stringResource(R.string.spot_not_found))
            }
            return@Scaffold
        }

        CommunityTireSpotDetailContent(
            spot = spot,
            onImport = { viewModel.importTireSpot(spot) },
            modifier = Modifier.padding(padding)
        )
    }
}

@Composable
private fun CommunityTireSpotDetailContent(
    spot: TireSpot,
    onImport: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        contentPadding      = PaddingValues(horizontal = DsSpacing.l, vertical = DsSpacing.s),
        verticalArrangement = Arrangement.spacedBy(DsSpacing.m),
        modifier            = modifier.fillMaxSize()
    ) {
        // ── Remote Image Gallery ──────────────────────────────────────────
        if (spot.communityPhotoUrls.isNotEmpty()) {
            item {
                TireCommunityPhotoGallery(urls = spot.communityPhotoUrls)
            }
        }

        // ── Community Badge ────────────────────────────────────────────────
        item {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = MaterialTheme.shapes.small,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(DsSpacing.s),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.People, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(DsSpacing.s))
                    Text(
                        stringResource(R.string.community_badge),
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }

        // Risk banner
        if (spot.hasCameras || spot.securityCommon || spot.isLocked) {
            item {
                val riskFlags = buildList {
                    if (spot.hasCameras)     add(stringResource(R.string.risk_cameras_present))
                    if (spot.securityCommon) add(stringResource(R.string.risk_security_patrols))
                    if (spot.isLocked)       add(stringResource(R.string.risk_dumpster_locked))
                }
                RiskBanner(risks = riskFlags)
            }
        }

        // Header card
        item { CommunityTireSpotHeaderCard(spot) }

        // Access info
        if (spot.accessNotes.isNotBlank() || spot.isFenced || spot.isGated || spot.isExposed) {
            item { CommunityTireAccessSection(spot) }
        }

        // Timing section
        item { CommunityTireTimingSection(spot) }

        // Pattern insights
        item { CommunityTirePatternSection(spot) }

        // Notes
        if (spot.notes.isNotBlank()) {
            item { CommunityTireNotesSection(spot.notes) }
        }

        // Tags
        if (spot.tags.isNotEmpty()) {
            item { CommunityTireTagsRow(spot.tags) }
        }

        // ── Import Button ──────────────────────────────────────────────────
        item {
            Button(
                onClick = onImport,
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium
            ) {
                Icon(Icons.Default.ContentCopy, null)
                Spacer(Modifier.width(DsSpacing.s))
                Text(stringResource(R.string.import_to_my_spots))
            }
        }

        item { Spacer(Modifier.height(DsSpacing.xxxl)) }
    }
}

@Composable
private fun CommunityTireSpotHeaderCard(spot: TireSpot) {
    val accentColor = tireCategoryColor(spot.category)
    Card(
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.medium
    ) {
        Box {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .background(accentHeaderBrush(accentColor))
            )
            Column(modifier = Modifier.padding(DsSpacing.l)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(DsSpacing.s),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TireStatusChip(status = spot.lastStatus)
                    if (spot.isVerified) {
                        SuggestionChip(onClick = {}, label = { Text(stringResource(R.string.condition_verified), style = MaterialTheme.typography.labelSmall) })
                    }
                }
                if (spot.address.isNotBlank()) {
                    Spacer(Modifier.height(DsSpacing.s))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.width(DsSpacing.xs))
                        Text(spot.address, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                spot.lastChecked?.let { ts ->
                    Spacer(Modifier.height(DsSpacing.xs))
                    Text(
                        stringResource(R.string.checked_time_ago, timeAgoString(ts)),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(DsSpacing.s))
                Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                    SpotStatChip(
                        icon  = Icons.Default.Build,
                        value = spot.category.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() },
                        label = stringResource(R.string.tire_spot_category_label),
                        color = accentColor
                    )
                    SpotStatChip(
                        icon  = Icons.Default.Warning,
                        value = spot.puncturePattern.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() },
                        label = stringResource(R.string.tire_label_puncture_pattern),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun CommunityTireAccessSection(spot: TireSpot) {
    DetailCard(title = stringResource(R.string.section_access)) {
        if (spot.accessNotes.isNotBlank()) {
            Text(spot.accessNotes, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(DsSpacing.s))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)) {
            if (spot.isFenced)  ConditionTag(stringResource(R.string.condition_fenced))
            if (spot.isGated)   ConditionTag(stringResource(R.string.condition_gated))
            if (spot.isLocked)  ConditionTag(stringResource(R.string.condition_locked))
            if (spot.isExposed) ConditionTag(stringResource(R.string.tire_condition_exposed))
        }
    }
}

@Composable
private fun CommunityTireTimingSection(spot: TireSpot) {
    DetailCard(title = stringResource(R.string.section_pickup_schedule)) {
        InfoRow(
            label = stringResource(R.string.label_best_time),
            value = spot.bestTimeOfDay.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }
        )
        if (spot.bestDays.isNotBlank()) {
            InfoRow(label = stringResource(R.string.label_days), value = spot.bestDays)
        }
        if (spot.isSeasonal) {
            InfoRow(
                label = stringResource(R.string.tire_label_season),
                value = spot.season.name.lowercase().replaceFirstChar { it.uppercaseChar() }
            )
        }
    }
}

@Composable
private fun CommunityTirePatternSection(spot: TireSpot) {
    DetailCard(title = stringResource(R.string.section_tire_patterns)) {
        val flags = buildList {
            if (spot.usableDisappearFast)  add(stringResource(R.string.tire_label_usable_disappear_fast))
            if (spot.othersGetThereFirst)  add(stringResource(R.string.tire_label_others_first))
            if (spot.worthCheckingWhenLight) add(stringResource(R.string.tire_label_worth_light))
            if (spot.usuallyPutsOutMany)   add(stringResource(R.string.tire_label_usually_many))
        }
        if (flags.isEmpty()) {
            Text(
                stringResource(R.string.tire_no_patterns_noted),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            flags.forEach { flag ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(DsSpacing.s))
                    Text(flag, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun CommunityTireNotesSection(notes: String) {
    DetailCard(title = stringResource(R.string.section_personal_notes)) {
        Text(notes, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun CommunityTireTagsRow(tags: List<String>) {
    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)) {
        tags.forEach { tag ->
            SuggestionChip(
                onClick = {},
                label   = { Text(tag, style = MaterialTheme.typography.labelSmall) }
            )
        }
    }
}
