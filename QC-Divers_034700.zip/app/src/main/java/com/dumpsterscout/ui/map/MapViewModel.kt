package com.dumpsterscout.ui.map

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.repository.CommunityRepository
import com.dumpsterscout.domain.usecase.GetMapLocationsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Intents for interacting with the map view.
 */
sealed class MapIntent {
    /** Toggle the visibility of shared community spots on the map. */
    data class ToggleCommunity(val show: Boolean) : MapIntent()
    /** Manually trigger a refresh of community data. */
    data object RefreshCommunity : MapIntent()
    /** Select a location on the map to show its preview. */
    data class SelectLocation(val id: Long?) : MapIntent()
    /** Clear the current error state. */
    data object ClearError : MapIntent()
    /** Toggle filtering of stale community spots (older than 48h). */
    data class ToggleStaleFilter(val enabled: Boolean) : MapIntent()
}

/**
 * UI State for the map view.
 */
data class MapUiState(
    val locations: List<MapLocationItem> = emptyList(),
    val isLoading: Boolean = true,
    val isRefreshing: Boolean = false,
    val selectedLocationId: Long? = null,
    val showCommunity: Boolean = false,
    val filterStaleCommunity: Boolean = false,
    val error: String? = null
)

/**
 * MVI ViewModel for managing the main map and list view of scouting locations.
 */
@HiltViewModel
class MapViewModel @Inject constructor(
    private val getMapLocationsUseCase: GetMapLocationsUseCase,
    private val communityRepository: CommunityRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(MapUiState())
    val uiState: StateFlow<MapUiState> = _uiState.asStateFlow()

    init {
        observeLocations()
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun observeLocations() {
        val rawLocations = _uiState.map { it.showCommunity }
            .distinctUntilChanged()
            .flatMapLatest { showComm ->
                getMapLocationsUseCase(showComm)
                    .catch { e ->
                        _uiState.update { it.copy(error = e.message ?: "Failed to load map data") }
                        emit(emptyList())
                    }
            }

        val staleFilter = _uiState.map { it.filterStaleCommunity }.distinctUntilChanged()

        combine(rawLocations, staleFilter) { locations, filterStale ->
            if (filterStale) {
                val threshold = System.currentTimeMillis() - (48 * 60 * 60 * 1000)
                locations.filter { !it.isCommunity || (it.lastChecked ?: 0L) >= threshold }
            } else {
                locations
            }
        }.onEach { locations ->
            _uiState.update { it.copy(locations = locations, isLoading = false) }
        }.launchIn(viewModelScope)
    }

    /**
     * Handle incoming UI intents.
     *
     * @param intent The intent to process.
     */
    fun onIntent(intent: MapIntent) {
        when (intent) {
            is MapIntent.ToggleCommunity -> toggleCommunity(intent.show)
            MapIntent.RefreshCommunity -> refreshCommunity()
            is MapIntent.SelectLocation -> _uiState.update { it.copy(selectedLocationId = intent.id) }
            MapIntent.ClearError -> _uiState.update { it.copy(error = null) }
            is MapIntent.ToggleStaleFilter -> _uiState.update { it.copy(filterStaleCommunity = intent.enabled) }
        }
    }

    private fun toggleCommunity(show: Boolean) {
        _uiState.update { it.copy(showCommunity = show, isLoading = true) }
        if (show) refreshCommunity()
    }

    private fun refreshCommunity() {
        viewModelScope.launch {
            _uiState.update { it.copy(isRefreshing = true) }
            try {
                communityRepository.refreshCommunityData()
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "Community refresh failed: ${e.message}") }
            } finally {
                _uiState.update { it.copy(isRefreshing = false) }
            }
        }
    }
}
