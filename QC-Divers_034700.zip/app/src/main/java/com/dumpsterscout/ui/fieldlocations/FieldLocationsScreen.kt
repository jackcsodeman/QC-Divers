package com.dumpsterscout.ui.fieldlocations

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalContext
import com.dumpsterscout.ui.photos.PhotoAttachmentSection
import com.dumpsterscout.ui.photos.SpotPhotoViewModel
import com.dumpsterscout.ui.photos.createFieldPhotoUri
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.data.local.entity.FieldLocationEntity
import com.dumpsterscout.data.local.entity.FieldLocationReportEntity
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.EmptyStatePanel
import com.dumpsterscout.ui.theme.DsElevation
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.ScoutSurface2

private val locationTypes = listOf("ALL", "CLEANUP_SITE", "SALVAGE_RESOURCE", "CUSTOM")
private val priorities = listOf("NONE", "LOW", "MEDIUM", "HIGH", "URGENT")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FieldLocationsScreen(
    onNavigateBack: () -> Unit,
    viewModel: FieldLocationsViewModel = hiltViewModel(),
    photoViewModel: SpotPhotoViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val photoState by photoViewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val permissionDeniedMessage = stringResource(R.string.photo_camera_permission_denied)
    val scope = rememberCoroutineScope()
    var showAddDialog by remember { mutableStateOf(false) }
    var photoOwner by remember { mutableStateOf<FieldLocationEntity?>(null) }
    var editingLocation by remember { mutableStateOf<FieldLocationEntity?>(null) }
    var reportOwner by remember { mutableStateOf<FieldLocationEntity?>(null) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }

    val takePhotoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val capturedUri = pendingCameraUri
        pendingCameraUri = null
        if (success && capturedUri != null) photoViewModel.addPhoto(capturedUri.toString())
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val uri = createFieldPhotoUri(context)
            pendingCameraUri = uri
            takePhotoLauncher.launch(uri)
        } else {
            scope.launch { snackbarHostState.showSnackbar(permissionDeniedMessage) }
        }
    }
    val pickPhotoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) photoViewModel.addPhoto(uri.toString())
    }

    LaunchedEffect(uiState.error) {
        uiState.error?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearError()
        }
    }
    LaunchedEffect(uiState.message) {
        uiState.message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    LaunchedEffect(photoOwner?.id) {
        val owner = photoOwner
        if (owner != null) photoViewModel.loadOwner("FIELD_LOCATION", owner.id)
    }
    LaunchedEffect(photoState.error) {
        photoState.error?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            photoViewModel.clearError()
        }
    }
    val photoAttachedMsg = stringResource(R.string.msg_photo_attached)
    LaunchedEffect(photoState.lastAddedPhotoId) {
        if (photoState.lastAddedPhotoId != null) {
            snackbarHostState.showSnackbar(photoAttachedMsg)
            photoViewModel.clearLastAdded()
        }
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.field_locations_title),
                subtitle = stringResource(R.string.field_locations_subtitle),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.AddLocationAlt, contentDescription = stringResource(R.string.field_location_add))
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            OutlinedTextField(
                value = uiState.query,
                onValueChange = viewModel::setQuery,
                label = { Text(stringResource(R.string.search_label)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = DsSpacing.l, vertical = DsSpacing.s)
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = DsSpacing.l),
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                items(locationTypes) { type ->
                    FilterChip(
                        selected = uiState.selectedType == type,
                        onClick = { viewModel.setType(type) },
                        label = { Text(typeLabel(type)) }
                    )
                }
            }
            Spacer(Modifier.height(DsSpacing.s))
            if (uiState.filteredLocations.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    EmptyStatePanel(message = stringResource(R.string.field_locations_empty), icon = Icons.Default.Place)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(DsSpacing.l),
                    verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
                ) {
                    items(uiState.filteredLocations, key = { it.id }) { location ->
                        val locationReports = uiState.reports.filter { it.fieldLocationId == location.id }
                        FieldLocationCard(
                            location = location,
                            reportCount = locationReports.size,
                            latestReport = locationReports.firstOrNull(),
                            onFavorite = { viewModel.toggleFavorite(location.id) },
                            onEdit = { editingLocation = location },
                            onReports = { reportOwner = location },
                            onPhotos = { photoOwner = location },
                            onDelete = { viewModel.deleteLocation(location.id) }
                        )
                    }
                    item { Spacer(Modifier.height(DsSpacing.giant)) }
                }
            }
        }
    }

    if (showAddDialog) {
        AddFieldLocationDialog(
            onDismiss = { showAddDialog = false },
            onSave = { type, name, desc, address, lat, lng, tags, priority, resource ->
                viewModel.saveLocation(type, name, desc, address, lat, lng, tags, priority, resource)
                showAddDialog = false
            }
        )
    }

    editingLocation?.let { existing ->
        AddFieldLocationDialog(
            existing = existing,
            onDismiss = { editingLocation = null },
            onSave = { type, name, desc, address, lat, lng, tags, priority, resource ->
                viewModel.updateLocation(existing, type, name, desc, address, lat, lng, tags, priority, resource)
                editingLocation = null
            }
        )
    }

    reportOwner?.let { owner ->
        FieldLocationReportsDialog(
            location = owner,
            reports = uiState.reports.filter { it.fieldLocationId == owner.id },
            onDismiss = { reportOwner = null },
            onAddReport = { reportType, status, access, hazard, cleanupStatus, progress, findings, notes ->
                viewModel.addReport(owner, reportType, status, access, hazard, cleanupStatus, progress, findings, notes)
            },
            onDeleteReport = viewModel::deleteReport
        )
    }

    photoOwner?.let { owner ->
        AlertDialog(
            onDismissRequest = { photoOwner = null },
            confirmButton = { TextButton(onClick = { photoOwner = null }) { Text(stringResource(R.string.close)) } },
            title = { Text(owner.name) },
            text = {
                PhotoAttachmentSection(
                    title = stringResource(R.string.photo_section_field_location),
                    photos = photoState.photos,
                    onTakePhoto = {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                            val uri = createFieldPhotoUri(context)
                            pendingCameraUri = uri
                            takePhotoLauncher.launch(uri)
                        } else {
                            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                        }
                    },
                    onPickPhoto = { pickPhotoLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    onDeletePhoto = { photoViewModel.deletePhoto(it) }
                )
            }
        )
    }
}

@Composable
private fun FieldLocationCard(
    location: FieldLocationEntity,
    reportCount: Int,
    latestReport: FieldLocationReportEntity?,
    onFavorite: () -> Unit,
    onEdit: () -> Unit,
    onReports: () -> Unit,
    onPhotos: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card)
    ) {
        Column(
            modifier = Modifier.padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)) {
                Icon(
                    imageVector = if (location.type == "CLEANUP_SITE") Icons.Default.CleaningServices else Icons.Default.Handyman,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Column(Modifier.weight(1f)) {
                    Text(location.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(typeLabel(location.type), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = onFavorite) {
                    Icon(if (location.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = stringResource(R.string.field_location_favorite_cd, location.name))
                }
                IconButton(onClick = onEdit) {
                    Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.field_location_edit_cd, location.name))
                }
                IconButton(onClick = onReports) {
                    Icon(Icons.Default.Assignment, contentDescription = stringResource(R.string.field_location_reports_cd, location.name))
                }
                IconButton(onClick = onPhotos) {
                    Icon(Icons.Default.AddAPhoto, contentDescription = stringResource(R.string.photo_pick))
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.field_location_delete_cd, location.name), tint = MaterialTheme.colorScheme.error)
                }
            }
            if (location.description.isNotBlank()) {
                Text(location.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (reportCount > 0) {
                Text(
                    text = stringResource(R.string.field_location_report_summary, reportCount, latestReport?.status ?: "Unknown"),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                AssistChip(onClick = {}, label = { Text(location.cleanupPriority) })
                AssistChip(onClick = {}, label = { Text(location.hazardLevel) })
                AssistChip(onClick = {}, label = { Text(location.syncStatus.lowercase().replace('_', ' ')) })
            }
            if (location.address.isNotBlank()) {
                Text(location.address, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun AddFieldLocationDialog(
    existing: FieldLocationEntity? = null,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, Double, Double, String, String, String) -> Unit
) {
    var type by remember(existing?.id) { mutableStateOf(existing?.type ?: "CLEANUP_SITE") }
    var name by remember(existing?.id) { mutableStateOf(existing?.name.orEmpty()) }
    var description by remember(existing?.id) { mutableStateOf(existing?.description.orEmpty()) }
    var address by remember(existing?.id) { mutableStateOf(existing?.address.orEmpty()) }
    var latitude by remember(existing?.id) { mutableStateOf(existing?.latitude?.takeIf { it != 0.0 }?.toString().orEmpty()) }
    var longitude by remember(existing?.id) { mutableStateOf(existing?.longitude?.takeIf { it != 0.0 }?.toString().orEmpty()) }
    var tags by remember(existing?.id) { mutableStateOf(existing?.tags.orEmpty()) }
    var priority by remember(existing?.id) { mutableStateOf(existing?.cleanupPriority ?: "MEDIUM") }
    var resourceType by remember(existing?.id) { mutableStateOf(existing?.resourceType.orEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(if (existing == null) R.string.field_location_add_title else R.string.field_location_edit_title)) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                        items(locationTypes.filter { it != "ALL" }) { option ->
                            FilterChip(selected = type == option, onClick = { type = option }, label = { Text(typeLabel(option)) })
                        }
                    }
                }
                item { OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(stringResource(R.string.field_location_name)) }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text(stringResource(R.string.field_location_description)) }, modifier = Modifier.fillMaxWidth(), minLines = 2) }
                item { OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text(stringResource(R.string.field_location_address)) }, modifier = Modifier.fillMaxWidth()) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                        OutlinedTextField(value = latitude, onValueChange = { latitude = it }, label = { Text(stringResource(R.string.field_location_latitude)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                        OutlinedTextField(value = longitude, onValueChange = { longitude = it }, label = { Text(stringResource(R.string.field_location_longitude)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                    }
                }
                item { OutlinedTextField(value = tags, onValueChange = { tags = it }, label = { Text(stringResource(R.string.field_location_tags)) }, modifier = Modifier.fillMaxWidth()) }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                        items(priorities) { option ->
                            FilterChip(selected = priority == option, onClick = { priority = option }, label = { Text(option.lowercase().replaceFirstChar { it.uppercase() }) })
                        }
                    }
                }
                if (type == "SALVAGE_RESOURCE") {
                    item { OutlinedTextField(value = resourceType, onValueChange = { resourceType = it }, label = { Text(stringResource(R.string.field_location_resource_type)) }, modifier = Modifier.fillMaxWidth()) }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val lat = latitude.toDoubleOrNull()?.coerceIn(-90.0, 90.0) ?: 0.0
                    val lng = longitude.toDoubleOrNull()?.coerceIn(-180.0, 180.0) ?: 0.0
                    onSave(type, name, description, address, lat, lng, tags, priority, resourceType)
                },
                enabled = name.isNotBlank()
            ) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}


@Composable
private fun FieldLocationReportsDialog(
    location: FieldLocationEntity,
    reports: List<FieldLocationReportEntity>,
    onDismiss: () -> Unit,
    onAddReport: (String, String, String, String, String, Int, String, String) -> Unit,
    onDeleteReport: (FieldLocationReportEntity) -> Unit
) {
    var reportType by remember { mutableStateOf("VISIT") }
    var status by remember { mutableStateOf("CHECKED") }
    var accessStatus by remember { mutableStateOf(location.accessStatus) }
    var hazardLevel by remember { mutableStateOf(location.hazardLevel) }
    var cleanupStatus by remember { mutableStateOf(location.cleanupStatus) }
    var progress by remember { mutableStateOf("0") }
    var findings by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.field_location_reports_title, location.name)) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                item { Text(stringResource(R.string.field_location_add_report), style = MaterialTheme.typography.titleSmall) }
                item { OutlinedTextField(value = reportType, onValueChange = { reportType = it.uppercase() }, label = { Text(stringResource(R.string.field_location_report_type)) }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(value = status, onValueChange = { status = it.uppercase() }, label = { Text(stringResource(R.string.field_location_report_status)) }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(value = accessStatus, onValueChange = { accessStatus = it.uppercase() }, label = { Text(stringResource(R.string.field_location_report_access)) }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(value = hazardLevel, onValueChange = { hazardLevel = it.uppercase() }, label = { Text(stringResource(R.string.field_location_report_hazard)) }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(value = cleanupStatus, onValueChange = { cleanupStatus = it.uppercase() }, label = { Text(stringResource(R.string.field_location_report_cleanup_status)) }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(value = progress, onValueChange = { progress = it.filter(Char::isDigit).take(3) }, label = { Text(stringResource(R.string.field_location_report_progress)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(value = findings, onValueChange = { findings = it }, label = { Text(stringResource(R.string.field_location_report_findings)) }, minLines = 2, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text(stringResource(R.string.field_location_report_notes)) }, minLines = 2, modifier = Modifier.fillMaxWidth()) }
                item { Text(stringResource(R.string.field_location_report_history), style = MaterialTheme.typography.titleSmall) }
                if (reports.isEmpty()) {
                    item { Text(stringResource(R.string.field_location_reports_empty), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                } else {
                    items(reports, key = { it.id }) { report ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                            Column(Modifier.weight(1f)) {
                                Text(report.status, style = MaterialTheme.typography.labelLarge)
                                Text(report.notes.ifBlank { report.findings.ifBlank { report.reportType } }, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                            IconButton(onClick = { onDeleteReport(report) }) {
                                Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.field_location_report_delete_cd), tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                onAddReport(reportType, status, accessStatus, hazardLevel, cleanupStatus, progress.toIntOrNull() ?: 0, findings, notes)
                findings = ""
                notes = ""
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) } }
    )
}

private fun typeLabel(type: String): String = when (type) {
    "CLEANUP_SITE" -> "Cleanup Site"
    "SALVAGE_RESOURCE" -> "Salvage / Resource"
    "CUSTOM" -> "Custom"
    else -> "All"
}
