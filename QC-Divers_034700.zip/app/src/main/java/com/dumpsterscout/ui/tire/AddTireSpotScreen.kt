package com.dumpsterscout.ui.tire

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.PuncturePattern
import com.dumpsterscout.domain.model.TireBestTimeOfDay
import com.dumpsterscout.domain.model.TireSeason
import com.dumpsterscout.domain.model.TireSpotCategory
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTireSpotScreen(
    tireSpotId: Long?,
    onNavigateBack: () -> Unit,
    onSpotSaved: (Long) -> Unit,
    viewModel: AddTireSpotViewModel = hiltViewModel()
) {
    LaunchedEffect(tireSpotId) { viewModel.onIntent(AddTireSpotIntent.LoadSpot(tireSpotId)) }

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.isSaved) {
        if (uiState.isSaved) {
            uiState.savedId?.let { onSpotSaved(it) }
            viewModel.onIntent(AddTireSpotIntent.ClearSaved)
        }
    }

    LaunchedEffect(uiState.error) {
        uiState.error?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.onIntent(AddTireSpotIntent.ClearError)
        }
    }

    val isEdit = tireSpotId != null
    val spot   = uiState.spot
    val accent = tireCategoryColor(spot.category)

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = if (isEdit) stringResource(R.string.edit_tire_spot_title)
                        else stringResource(R.string.add_tire_spot_title),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                },
                actions = {
                    TextButton(
                        onClick  = { viewModel.onIntent(AddTireSpotIntent.Save) },
                        enabled  = spot.name.isNotBlank() && !uiState.isLoading
                    ) {
                        Text(stringResource(R.string.save))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            Spacer(Modifier.height(DsSpacing.xs))

            // ── Basic Info ────────────────────────────────────────────────────
            TireFormSection(title = stringResource(R.string.section_basic_info), accentColor = accent) {
                TireDsTextField(
                    value       = spot.name,
                    onChange    = { newVal -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(name = newVal) }) },
                    label       = stringResource(R.string.tire_spot_name_label),
                    leadingIcon = Icons.Default.Store,
                    singleLine  = true,
                    capitalization = KeyboardCapitalization.Words
                )
                // Category dropdown
                var showCatMenu by remember { mutableStateOf(false) }
                Box {
                    OutlinedTextField(
                        value         = spot.category.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() },
                        onValueChange = {},
                        label         = { Text(stringResource(R.string.tire_spot_category_label)) },
                        readOnly      = true,
                        modifier      = Modifier.fillMaxWidth(),
                        trailingIcon  = {
                            IconButton(onClick = { showCatMenu = true }) {
                                Icon(Icons.Default.ArrowDropDown, null)
                            }
                        },
                        shape = MaterialTheme.shapes.medium
                    )
                    DropdownMenu(expanded = showCatMenu, onDismissRequest = { showCatMenu = false }) {
                        TireSpotCategory.entries.forEach { cat ->
                            DropdownMenuItem(
                                text    = { Text(cat.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }) },
                                onClick = { viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(category = cat) }); showCatMenu = false }
                            )
                        }
                    }
                }
                TireDsTextField(
                    value       = spot.address,
                    onChange    = { newVal -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(address = newVal) }) },
                    label       = stringResource(R.string.spot_address),
                    leadingIcon = Icons.Default.LocationOn,
                    singleLine  = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                    TireDsTextField(
                        value    = if (spot.latitude != 0.0) "%.6f".format(spot.latitude) else "",
                        onChange = { raw -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(latitude = raw.toDoubleOrNull() ?: it.latitude) }) },
                        label    = stringResource(R.string.tire_label_latitude),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    TireDsTextField(
                        value    = if (spot.longitude != 0.0) "%.6f".format(spot.longitude) else "",
                        onChange = { raw -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(longitude = raw.toDoubleOrNull() ?: it.longitude) }) },
                        label    = stringResource(R.string.tire_label_longitude),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }

            // ── Access ────────────────────────────────────────────────────────
            TireFormSection(title = stringResource(R.string.section_access), accentColor = accent) {
                TireDsTextField(
                    value    = spot.accessNotes,
                    onChange = { newVal -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(accessNotes = newVal) }) },
                    label    = stringResource(R.string.spot_access_notes),
                    minLines = 2
                )
                TireDsSwitchRow(stringResource(R.string.tire_label_fenced),   spot.isFenced)   { b -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(isFenced = b) }) }
                TireDsSwitchRow(stringResource(R.string.tire_label_gated),    spot.isGated)    { b -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(isGated = b) }) }
                TireDsSwitchRow(stringResource(R.string.tire_label_locked),   spot.isLocked)   { b -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(isLocked = b) }) }
                TireDsSwitchRow(stringResource(R.string.tire_label_exposed),  spot.isExposed)  { b -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(isExposed = b) }) }
                TireDsSwitchRow(stringResource(R.string.tire_label_easy_access), spot.easyAccess) { b -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(easyAccess = b) }) }
                TireDsSwitchRow(stringResource(R.string.tire_label_cameras),  spot.hasCameras) { b -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(hasCameras = b) }) }
                TireDsSwitchRow(stringResource(R.string.tire_label_security), spot.securityCommon) { b -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(securityCommon = b) }) }
            }

            // ── Timing ────────────────────────────────────────────────────────
            TireFormSection(title = stringResource(R.string.section_timing), accentColor = accent) {
                // Best time dropdown
                var showTimeMenu by remember { mutableStateOf(false) }
                Box {
                    OutlinedTextField(
                        value         = spot.bestTimeOfDay.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() },
                        onValueChange = {},
                        label         = { Text(stringResource(R.string.label_best_time)) },
                        readOnly      = true,
                        modifier      = Modifier.fillMaxWidth(),
                        trailingIcon  = {
                            IconButton(onClick = { showTimeMenu = true }) {
                                Icon(Icons.Default.ArrowDropDown, null)
                            }
                        },
                        shape = MaterialTheme.shapes.medium
                    )
                    DropdownMenu(expanded = showTimeMenu, onDismissRequest = { showTimeMenu = false }) {
                        TireBestTimeOfDay.entries.forEach { tod ->
                            DropdownMenuItem(
                                text    = { Text(tod.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }) },
                                onClick = { viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(bestTimeOfDay = tod) }); showTimeMenu = false }
                            )
                        }
                    }
                }
                TireDsTextField(
                    value    = spot.bestDays,
                    onChange = { newVal -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(bestDays = newVal) }) },
                    label    = stringResource(R.string.label_days),
                    singleLine = true
                )
                TireDsSwitchRow(stringResource(R.string.tire_label_seasonal), spot.isSeasonal) { b -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(isSeasonal = b) }) }
                if (spot.isSeasonal) {
                    var showSeasonMenu by remember { mutableStateOf(false) }
                    Box {
                        OutlinedTextField(
                            value         = spot.season.name.lowercase().replaceFirstChar { it.uppercaseChar() },
                            onValueChange = {},
                            label         = { Text(stringResource(R.string.tire_label_season)) },
                            readOnly      = true,
                            modifier      = Modifier.fillMaxWidth(),
                            trailingIcon  = {
                                IconButton(onClick = { showSeasonMenu = true }) {
                                    Icon(Icons.Default.ArrowDropDown, null)
                                }
                            },
                            shape = MaterialTheme.shapes.medium
                        )
                        DropdownMenu(expanded = showSeasonMenu, onDismissRequest = { showSeasonMenu = false }) {
                            TireSeason.entries.forEach { s ->
                                DropdownMenuItem(
                                    text    = { Text(s.name.lowercase().replaceFirstChar { it.uppercaseChar() }) },
                                    onClick = { viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(season = s) }); showSeasonMenu = false }
                                )
                            }
                        }
                    }
                }
                TireDsSwitchRow(
                    stringResource(R.string.tire_label_better_weekends),
                    spot.betterOnWeekends ?: false
                ) { b -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(betterOnWeekends = b) }) }
                TireDsSwitchRow(
                    stringResource(R.string.tire_label_around_closing),
                    spot.putsOutAroundClosing
                ) { b -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(putsOutAroundClosing = b) }) }
            }

            // ── Patterns ──────────────────────────────────────────────────────
            TireFormSection(title = stringResource(R.string.section_tire_patterns), accentColor = accent) {
                // Puncture pattern dropdown
                var showPuncMenu by remember { mutableStateOf(false) }
                Box {
                    OutlinedTextField(
                        value         = spot.puncturePattern.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() },
                        onValueChange = {},
                        label         = { Text(stringResource(R.string.tire_label_puncture_pattern)) },
                        readOnly      = true,
                        modifier      = Modifier.fillMaxWidth(),
                        trailingIcon  = {
                            IconButton(onClick = { showPuncMenu = true }) {
                                Icon(Icons.Default.ArrowDropDown, null)
                            }
                        },
                        shape = MaterialTheme.shapes.medium
                    )
                    DropdownMenu(expanded = showPuncMenu, onDismissRequest = { showPuncMenu = false }) {
                        PuncturePattern.entries.forEach { pp ->
                            DropdownMenuItem(
                                text    = { Text(pp.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }) },
                                onClick = { viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(puncturePattern = pp) }); showPuncMenu = false }
                            )
                        }
                    }
                }
                TireDsSwitchRow(stringResource(R.string.tire_label_usable_disappear_fast), spot.usableDisappearFast) { b -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(usableDisappearFast = b) }) }
                TireDsSwitchRow(stringResource(R.string.tire_label_others_first), spot.othersGetThereFirst) { b -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(othersGetThereFirst = b) }) }
                TireDsSwitchRow(stringResource(R.string.tire_label_worth_light), spot.worthCheckingWhenLight) { b -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(worthCheckingWhenLight = b) }) }
                TireDsSwitchRow(stringResource(R.string.tire_label_usually_many), spot.usuallyPutsOutMany) { b -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(usuallyPutsOutMany = b) }) }
            }

            // ── Notes & Tags ──────────────────────────────────────────────────
            TireFormSection(title = stringResource(R.string.section_personal_notes), accentColor = accent) {
                TireDsTextField(
                    value    = spot.notes,
                    onChange = { newVal -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(notes = newVal) }) },
                    label    = stringResource(R.string.spot_notes),
                    minLines = 3
                )
                TireDsTextField(
                    value    = spot.tags.joinToString(", "),
                    onChange = { raw -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(tags = raw.split(",").map { t -> t.trim() }.filter { t -> t.isNotBlank() }) }) },
                    label    = stringResource(R.string.spot_tags),
                    singleLine = true
                )
                TireDsSwitchRow(stringResource(R.string.spot_verified), spot.isVerified) { b -> viewModel.onIntent(AddTireSpotIntent.UpdateField { it.copy(isVerified = b) }) }
            }

            // Save button
            Button(
                onClick  = { viewModel.onIntent(AddTireSpotIntent.Save) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = DsSpacing.m),
                enabled  = spot.name.isNotBlank() && !uiState.isLoading
            ) {
                if (uiState.isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                } else {
                    Text(stringResource(R.string.save))
                }
            }

            Spacer(Modifier.height(DsSpacing.giant))
        }
    }
}

// ── Local form helpers ────────────────────────────────────────────────────────

@Composable
private fun TireFormSection(
    title: String,
    accentColor: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    var expanded by remember { mutableStateOf(true) }
    Card(
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.medium
    ) {
        Column {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(accentColor)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = DsSpacing.l, vertical = DsSpacing.m),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    title,
                    style    = MaterialTheme.typography.titleSmall,
                    color    = accentColor,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick  = { expanded = !expanded },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (expanded) stringResource(R.string.cd_collapse_section) else stringResource(R.string.cd_expand_section),
                        tint     = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            AnimatedVisibility(
                visible = expanded,
                enter   = fadeIn() + expandVertically(),
                exit    = fadeOut() + shrinkVertically()
            ) {
                Column(
                    modifier = Modifier.padding(start = DsSpacing.l, end = DsSpacing.l, bottom = DsSpacing.m),
                    verticalArrangement = Arrangement.spacedBy(DsSpacing.s),
                    content = content
                )
            }
        }
    }
}

@Composable
private fun TireDsTextField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    leadingIcon: ImageVector? = null,
    singleLine: Boolean = false,
    minLines: Int = 1,
    capitalization: KeyboardCapitalization = KeyboardCapitalization.Sentences
) {
    OutlinedTextField(
        value           = value,
        onValueChange   = onChange,
        label           = { Text(label) },
        modifier        = modifier.fillMaxWidth(),
        leadingIcon     = leadingIcon?.let { { Icon(it, null) } },
        singleLine      = singleLine,
        minLines        = minLines,
        shape           = MaterialTheme.shapes.medium,
        keyboardOptions = KeyboardOptions(capitalization = capitalization)
    )
}

@Composable
private fun TireDsSwitchRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier          = Modifier.fillMaxWidth().padding(vertical = DsSpacing.xs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Switch(
            checked         = checked,
            onCheckedChange = onCheckedChange,
            modifier        = Modifier.padding(end = DsSpacing.m)
        )
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}
