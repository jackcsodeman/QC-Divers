package com.dumpsterscout.ui.gear

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.data.local.entity.GearChecklistItemEntity
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.theme.DsElevation
import com.dumpsterscout.ui.theme.DsMotion
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.DumpsterScoutTheme
import com.dumpsterscout.ui.theme.GradeHigh
import com.dumpsterscout.ui.theme.GradeMid
import com.dumpsterscout.ui.theme.GradeTrack
import com.dumpsterscout.ui.theme.ScoutSurface2

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GearChecklistScreen(
    onNavigateBack: () -> Unit,
    viewModel: GearChecklistViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val animatedProgress by animateFloatAsState(
        targetValue = uiState.progress,
        animationSpec = tween(DsMotion.medium),
        label = "gear_progress"
    )
    val allDone = uiState.items.isNotEmpty() && uiState.checkedCount == uiState.items.size

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.gear_checklist),
                subtitle = pluralStringResource(R.plurals.gear_packed_subtitle, uiState.items.size, uiState.checkedCount, uiState.items.size),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                },
                actions = {
                    TextButton(onClick = viewModel::checkAll, enabled = uiState.items.isNotEmpty() && !allDone) { Text("Check all") }
                    TextButton(onClick = viewModel::reset, enabled = uiState.checkedCount > 0) { Text(stringResource(R.string.gear_reset)) }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Column(modifier = Modifier.padding(horizontal = DsSpacing.l, vertical = DsSpacing.s)) {
                Text(
                    if (allDone) stringResource(R.string.gear_all_packed) else stringResource(R.string.gear_packed_progress, (uiState.progress * 100).toInt()),
                    style = MaterialTheme.typography.labelMedium,
                    color = if (allDone) GradeHigh else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(DsSpacing.xs))
                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(MaterialTheme.shapes.small),
                    color = when {
                        allDone -> GradeHigh
                        uiState.progress >= 0.5f -> GradeMid
                        else -> MaterialTheme.colorScheme.primary
                    },
                    trackColor = GradeTrack
                )
            }

            if (allDone) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = DsSpacing.l, vertical = DsSpacing.xs),
                    colors = CardDefaults.cardColors(containerColor = GradeHigh.copy(alpha = 0.15f)),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Row(
                        modifier = Modifier.padding(DsSpacing.m),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = stringResource(R.string.cd_all_items_checked), tint = GradeHigh, modifier = Modifier.size(20.dp))
                        Text(stringResource(R.string.gear_all_packed_message), style = MaterialTheme.typography.bodyMedium, color = GradeHigh)
                    }
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(start = DsSpacing.l, end = DsSpacing.l, top = DsSpacing.s, bottom = DsSpacing.xxxl),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.xs)
            ) {
                items(uiState.items, key = { it.id }) { item ->
                    GearChecklistItem(item = item, checked = item.isChecked, onToggle = { viewModel.toggleItem(item.id, it) })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GearChecklistItem(
    item: GearChecklistItemEntity,
    checked: Boolean,
    onToggle: (Boolean) -> Unit
) {
    val bgColor by animateColorAsState(targetValue = if (checked) GradeHigh.copy(alpha = 0.08f) else ScoutSurface2, animationSpec = tween(DsMotion.fast), label = "gear_item_bg")
    val textColor by animateColorAsState(targetValue = if (checked) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f) else MaterialTheme.colorScheme.onSurface, animationSpec = tween(DsMotion.fast), label = "gear_item_text")

    Card(
        onClick = { onToggle(!checked) },
        colors = CardDefaults.cardColors(containerColor = bgColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (checked) DsElevation.none else DsElevation.subtle),
        shape = MaterialTheme.shapes.medium,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(modifier = Modifier.padding(DsSpacing.m), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)) {
                Text(item.emoji, style = MaterialTheme.typography.titleMedium)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(item.label, style = MaterialTheme.typography.bodyMedium, color = textColor, textDecoration = if (checked) TextDecoration.LineThrough else TextDecoration.None)
                Text(item.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = if (checked) 0.4f else 0.7f))
            }
            Checkbox(checked = checked, onCheckedChange = onToggle, colors = CheckboxDefaults.colors(checkedColor = GradeHigh, checkmarkColor = Color.White))
        }
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "GearChecklist dark")
@Composable
private fun GearChecklistPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        GearChecklistScreen(onNavigateBack = {})
    }
}
