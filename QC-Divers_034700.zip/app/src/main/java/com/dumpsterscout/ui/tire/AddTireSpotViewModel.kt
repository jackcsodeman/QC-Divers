package com.dumpsterscout.ui.tire

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.repository.TireSpotRepository
import com.dumpsterscout.domain.usecase.SaveTireSpotUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class AddTireSpotIntent {
    data class LoadSpot(val id: Long?) : AddTireSpotIntent()
    data class UpdateField(val update: (TireSpot) -> TireSpot) : AddTireSpotIntent()
    data object Save : AddTireSpotIntent()
    data object ClearSaved : AddTireSpotIntent()
    data object ClearError : AddTireSpotIntent()
}

data class AddTireSpotUiState(
    val spot: TireSpot = TireSpot(name = ""),
    val isLoading: Boolean = false,
    val isSaved: Boolean = false,
    val savedId: Long? = null,
    val error: String? = null
)

@HiltViewModel
class AddTireSpotViewModel @Inject constructor(
    private val saveTireSpotUseCase: SaveTireSpotUseCase,
    private val tireSpotRepository: TireSpotRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AddTireSpotUiState())
    val uiState: StateFlow<AddTireSpotUiState> = _uiState.asStateFlow()

    fun onIntent(intent: AddTireSpotIntent) {
        when (intent) {
            is AddTireSpotIntent.LoadSpot -> loadSpot(intent.id)
            is AddTireSpotIntent.UpdateField -> _uiState.update { it.copy(spot = intent.update(it.spot)) }
            AddTireSpotIntent.Save -> saveSpot()
            AddTireSpotIntent.ClearSaved -> _uiState.update { it.copy(isSaved = false, savedId = null) }
            AddTireSpotIntent.ClearError -> _uiState.update { it.copy(error = null) }
        }
    }

    private fun loadSpot(id: Long?) {
        if (id == null) {
            _uiState.value = AddTireSpotUiState()
            return
        }
        viewModelScope.launch {
            try {
                _uiState.update { it.copy(isLoading = true) }
                val spot = tireSpotRepository.getSpotById(id)
                _uiState.update { it.copy(spot = spot ?: TireSpot(name = ""), isLoading = false) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "Failed to load spot", isLoading = false) }
            }
        }
    }

    private fun saveSpot() {
        viewModelScope.launch {
            try {
                _uiState.update { it.copy(isLoading = true) }
                saveTireSpotUseCase(_uiState.value.spot)
                    .onSuccess { id ->
                        _uiState.update { it.copy(isLoading = false, isSaved = true, savedId = id) }
                    }
                    .onFailure { e ->
                        _uiState.update { it.copy(error = e.message ?: "Failed to save spot", isLoading = false) }
                    }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
    }
}
