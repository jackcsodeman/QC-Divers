package com.dumpsterscout.ui.spots

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotCategory
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.usecase.GetSpotsUseCase
import com.dumpsterscout.domain.usecase.ToggleSpotFavoriteUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Intents for the Spot List screen.
 */
sealed class SpotListIntent {
    data class Search(val query: String) : SpotListIntent()
    data class FilterCategory(val category: SpotCategory?) : SpotListIntent()
    data class FilterStatus(val status: SpotStatus?) : SpotListIntent()
    data class ToggleFavorites(val favoritesOnly: Boolean) : SpotListIntent()
    data object ToggleFilterVisibility : SpotListIntent()
    data class ToggleFavorite(val spotId: Long) : SpotListIntent()
    data object ClearError : SpotListIntent()
}

/**
 * UI State for the Spot List screen.
 */
data class SpotListState(
    val spots: List<DumpsterSpot> = emptyList(),
    val isLoading: Boolean = true,
    val searchQuery: String = "",
    val filterCategory: SpotCategory? = null,
    val filterStatus: SpotStatus? = null,
    val showFavoritesOnly: Boolean = false,
    val showFilters: Boolean = false,
    val error: String? = null
)

/**
 * MVI ViewModel for managing the dumpster spot list and its filters.
 */
@HiltViewModel
class SpotListViewModel @Inject constructor(
    private val getSpotsUseCase: GetSpotsUseCase,
    private val toggleSpotFavoriteUseCase: ToggleSpotFavoriteUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(SpotListState())
    val uiState: StateFlow<SpotListState> = _uiState.asStateFlow()

    init {
        observeSpots()
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun observeSpots() {
        combine(
            _uiState.map { it.searchQuery }.distinctUntilChanged(),
            _uiState.map { it.filterCategory }.distinctUntilChanged(),
            _uiState.map { it.filterStatus }.distinctUntilChanged(),
            _uiState.map { it.showFavoritesOnly }.distinctUntilChanged()
        ) { query, category, status, favoritesOnly ->
            Quad(query, category, status, favoritesOnly)
        }.flatMapLatest { (query, category, status, favoritesOnly) ->
            getSpotsUseCase(query, category, status, favoritesOnly)
        }.onEach { spots ->
            _uiState.update { it.copy(spots = spots, isLoading = false) }
        }.catch { e ->
            _uiState.update { it.copy(error = e.message ?: "Failed to load spots", isLoading = false) }
        }.launchIn(viewModelScope)
    }

    /**
     * Handle UI intents.
     */
    fun onIntent(intent: SpotListIntent) {
        when (intent) {
            is SpotListIntent.Search -> _uiState.update { it.copy(searchQuery = intent.query) }
            is SpotListIntent.FilterCategory -> _uiState.update { it.copy(filterCategory = intent.category) }
            is SpotListIntent.FilterStatus -> _uiState.update { it.copy(filterStatus = intent.status) }
            is SpotListIntent.ToggleFavorites -> _uiState.update { it.copy(showFavoritesOnly = intent.favoritesOnly) }
            SpotListIntent.ToggleFilterVisibility -> _uiState.update { it.copy(showFilters = !it.showFilters) }
            is SpotListIntent.ToggleFavorite -> toggleFavorite(intent.spotId)
            SpotListIntent.ClearError -> _uiState.update { it.copy(error = null) }
        }
    }

    private fun toggleFavorite(spotId: Long) {
        viewModelScope.launch {
            toggleSpotFavoriteUseCase(spotId).onFailure { e ->
                _uiState.update { it.copy(error = e.message) }
            }
        }
    }

    private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}
