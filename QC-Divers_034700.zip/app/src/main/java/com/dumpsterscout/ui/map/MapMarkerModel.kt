package com.dumpsterscout.ui.map

import kotlin.math.floor

sealed interface MapMarkerUiModel {
    val latitude: Double
    val longitude: Double

    data class Single(val location: MapLocationItem) : MapMarkerUiModel {
        override val latitude: Double = location.latitude
        override val longitude: Double = location.longitude
    }

    data class Cluster(
        val id: String,
        val count: Int,
        override val latitude: Double,
        override val longitude: Double
    ) : MapMarkerUiModel
}

object MapClusterer {
    private const val DEFAULT_CLUSTER_THRESHOLD = 250
    private const val DEFAULT_MAX_RENDERED_MARKERS = 500
    private const val DEFAULT_CELL_SIZE_DEGREES = 0.035

    fun buildMarkers(
        locations: List<MapLocationItem>,
        clusterThreshold: Int = DEFAULT_CLUSTER_THRESHOLD,
        maxRenderedMarkers: Int = DEFAULT_MAX_RENDERED_MARKERS,
        cellSizeDegrees: Double = DEFAULT_CELL_SIZE_DEGREES
    ): List<MapMarkerUiModel> {
        val coordinateLocations = locations
            .asSequence()
            .filter { it.hasCoordinates }
            .sortedWith(compareByDescending<MapLocationItem> { it.isFavorite }.thenBy { it.name.lowercase() })
            .toList()

        if (coordinateLocations.size <= clusterThreshold) {
            return coordinateLocations
                .take(maxRenderedMarkers)
                .map(MapMarkerUiModel::Single)
        }

        return coordinateLocations
            .groupBy { location ->
                GridCell(
                    latBucket = floor(location.latitude / cellSizeDegrees).toInt(),
                    lngBucket = floor(location.longitude / cellSizeDegrees).toInt()
                )
            }
            .map { (cell, group) ->
                if (group.size == 1) {
                    MapMarkerUiModel.Single(group.first())
                } else {
                    MapMarkerUiModel.Cluster(
                        id = "${cell.latBucket}:${cell.lngBucket}",
                        count = group.size,
                        latitude = group.map { it.latitude }.average(),
                        longitude = group.map { it.longitude }.average()
                    )
                }
            }
            .sortedWith(
                compareByDescending<MapMarkerUiModel> { marker ->
                    when (marker) {
                        is MapMarkerUiModel.Cluster -> marker.count
                        is MapMarkerUiModel.Single -> if (marker.location.isFavorite) 1 else 0
                    }
                }.thenBy { marker -> marker.latitude }.thenBy { marker -> marker.longitude }
            )
            .take(maxRenderedMarkers)
    }

    private data class GridCell(val latBucket: Int, val lngBucket: Int)
}
