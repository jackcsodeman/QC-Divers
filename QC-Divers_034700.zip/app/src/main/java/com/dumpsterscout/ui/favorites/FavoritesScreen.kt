package com.dumpsterscout.ui.favorites

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.EmptyStatePanel
import com.dumpsterscout.ui.components.SpotCard
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.DumpsterScoutTheme
import com.dumpsterscout.util.SampleData

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FavoritesScreen(
    onNavigateBack: () -> Unit,
    onNavigateToSpotDetail: (Long) -> Unit,
    viewModel: FavoritesViewModel = hiltViewModel()
) {
    val favoriteSpots by viewModel.favoriteSpots.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.favorites_title),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        }
    ) { padding ->
        if (favoriteSpots.isEmpty()) {
            EmptyStatePanel(
                message  = stringResource(R.string.favorites_empty_message),
                icon     = Icons.Default.FavoriteBorder,
                modifier = Modifier.fillMaxSize().padding(padding)
            )
        } else {
            LazyColumn(
                modifier            = Modifier.fillMaxSize().padding(padding),
                contentPadding      = PaddingValues(DsSpacing.l),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                items(favoriteSpots, key = { it.id }) { spot ->
                    SpotCard(
                        spot             = spot,
                        onClick          = { onNavigateToSpotDetail(spot.id) },
                        onToggleFavorite = { viewModel.toggleFavorite(spot.id) }
                    )
                }
            }
        }
    }
}

// ── Previews ──────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "Favorites – with items (dark)")
@Composable
private fun FavoritesFilledPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title = "Favorites",
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.cd_navigate_back))
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier            = Modifier.fillMaxSize().padding(padding),
                contentPadding      = PaddingValues(DsSpacing.l),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                items(SampleData.spots.take(3), key = { it.id }) { spot ->
                    SpotCard(spot = spot, onClick = {}, onToggleFavorite = {})
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, name = "Favorites – empty")
@Composable
private fun FavoritesEmptyPreview() {
    DumpsterScoutTheme {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title = "Favorites",
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.cd_navigate_back))
                        }
                    }
                )
            }
        ) { padding ->
            EmptyStatePanel(
                message  = "Tap the heart icon on any spot to add it here",
                icon     = Icons.Default.FavoriteBorder,
                modifier = Modifier.fillMaxSize().padding(padding)
            )
        }
    }
}
