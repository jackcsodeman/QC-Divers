package com.dumpsterscout.ui.spots

import android.Manifest
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Notes
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.BestTimeOfDay
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotCategory
import com.dumpsterscout.domain.model.SpotGrade
import com.dumpsterscout.domain.model.SpotLocation
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.model.Visibility
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.categoryColor
import com.dumpsterscout.ui.theme.*
import com.dumpsterscout.util.SampleData
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun AddSpotScreen(
    spotId: Long?,
    initialName: String? = null,
    initialAddress: String? = null,
    initialStatus: SpotStatus? = null,
    onNavigateBack: () -> Unit,
    onSpotSaved: (Long) -> Unit,
    viewModel: AddSpotViewModel = hiltViewModel()
) {
    // Initial loading or prefilling logic
    LaunchedEffect(spotId, initialName, initialAddress, initialStatus) {
        if (spotId != null) {
            viewModel.onIntent(AddSpotIntent.LoadSpot(spotId))
        } else if (initialName != null || initialAddress != null || initialStatus != null) {
            viewModel.onIntent(AddSpotIntent.Prefill(initialName, initialAddress, initialStatus))
        }
    }

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val locationPermission = rememberPermissionState(Manifest.permission.ACCESS_FINE_LOCATION)

    LaunchedEffect(uiState.isSaved) {
        if (uiState.isSaved) {
            uiState.savedId?.let { onSpotSaved(it) }
            viewModel.onIntent(AddSpotIntent.ClearSaved)
        }
    }

    LaunchedEffect(uiState.error) {
        uiState.error?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.onIntent(AddSpotIntent.ClearError)
        }
    }

    val isEdit = spotId != null
    val spot = uiState.spot
    val accent = categoryColor(spot.category)

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = if (isEdit) stringResource(R.string.edit_spot_title) else stringResource(R.string.add_spot_title),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                },
                actions = {
                    TextButton(
                        onClick = { viewModel.onIntent(AddSpotIntent.Save) },
                        enabled = spot.name.isNotBlank() && !uiState.isLoading
                    ) {
                        Text(stringResource(R.string.save))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            Spacer(Modifier.height(DsSpacing.xs))

            // ── Basic Info ────────────────────────────────────────────────
            FormSection(title = stringResource(R.string.section_basic_info), accentColor = accent) {
                DsTextField(
                    value       = spot.name,
                    onChange    = { newVal -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(name = newVal) }) },
                    label       = stringResource(R.string.label_name_business),
                    leadingIcon = Icons.Default.Store,
                    singleLine  = true,
                    capitalization = KeyboardCapitalization.Words
                )
                DsTextField(
                    value       = spot.address,
                    onChange    = { newVal -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(address = newVal) }) },
                    label       = stringResource(R.string.label_address),
                    leadingIcon = Icons.Default.LocationOn,
                    singleLine  = true
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(DsSpacing.s),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DsTextField(
                        value = spot.latitude.takeIf { it != 0.0 }?.toString().orEmpty(),
                        onChange = { raw -> raw.toDoubleOrNull()?.let { lat -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(latitude = lat) }) } },
                        label = stringResource(R.string.label_latitude),
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        keyboardType = KeyboardType.Decimal
                    )
                    DsTextField(
                        value = spot.longitude.takeIf { it != 0.0 }?.toString().orEmpty(),
                        onChange = { raw -> raw.toDoubleOrNull()?.let { lng -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(longitude = lng) }) } },
                        label = stringResource(R.string.label_longitude),
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        keyboardType = KeyboardType.Decimal
                    )
                    IconButton(
                        onClick = {
                            if (locationPermission.status.isGranted) {
                                viewModel.onIntent(AddSpotIntent.UseCurrentLocation)
                            } else {
                                locationPermission.launchPermissionRequest()
                            }
                        },
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MyLocation,
                            contentDescription = "Get current location",
                            tint = accent
                        )
                    }
                }
                // Category dropdown
                var showCategoryMenu by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = showCategoryMenu, onExpandedChange = { showCategoryMenu = it }) {
                    OutlinedTextField(
                        value          = spot.category.name.lowercase().replaceFirstChar { it.uppercaseChar() },
                        onValueChange  = {},
                        readOnly       = true,
                        label          = { Text(stringResource(R.string.spot_category)) },
                        trailingIcon   = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = showCategoryMenu) },
                        modifier       = Modifier.menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
                        shape          = MaterialTheme.shapes.medium
                    )
                    ExposedDropdownMenu(expanded = showCategoryMenu, onDismissRequest = { showCategoryMenu = false }) {
                        SpotCategory.entries.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat.name.lowercase().replaceFirstChar { it.uppercaseChar() }) },
                                onClick = {
                                    viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(category = cat) })
                                    showCategoryMenu = false
                                }
                            )
                        }
                    }
                }
            }

            // ── Access & Layout ───────────────────────────────────────────
            FormSection(title = stringResource(R.string.section_access_layout), accentColor = accent) {
                var showLocationMenu by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = showLocationMenu, onExpandedChange = { showLocationMenu = it }) {
                    OutlinedTextField(
                        value         = spot.spotLocation.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() },
                        onValueChange = {},
                        readOnly      = true,
                        label         = { Text(stringResource(R.string.label_location_type)) },
                        trailingIcon  = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = showLocationMenu) },
                        modifier      = Modifier.menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
                        shape         = MaterialTheme.shapes.medium
                    )
                    ExposedDropdownMenu(expanded = showLocationMenu, onDismissRequest = { showLocationMenu = false }) {
                        SpotLocation.entries.forEach { loc ->
                            DropdownMenuItem(
                                text    = { Text(loc.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }) },
                                onClick = {
                                    viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(spotLocation = loc) })
                                    showLocationMenu = false
                                }
                            )
                        }
                    }
                }
                DsTextField(
                    value    = spot.accessNotes,
                    onChange = { newVal -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(accessNotes = newVal) }) },
                    label    = stringResource(R.string.label_access_notes),
                    minLines = 2
                )
                // Boolean flags in a 2-column grid
                SwitchFlagGrid {
                    DsSwitchRow("Fenced",             spot.isFenced)            { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(isFenced = b) }) }
                    DsSwitchRow("Gated",              spot.isGated)             { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(isGated = b) }) }
                    DsSwitchRow("Locked",             spot.isLocked)            { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(isLocked = b) }) }
                    DsSwitchRow("Compactor only",     spot.isCompactor)         { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(isCompactor = b) }) }
                    DsSwitchRow("Multiple dumpsters", spot.hasMultipleDumpsters){ b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(hasMultipleDumpsters = b) }) }
                    DsSwitchRow("Parking easy",       spot.parkingEasy)         { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(parkingEasy = b) }) }
                }
            }

            // ── Safety ─────────────────────────────────────────────────────
            FormSection(title = stringResource(R.string.section_safety_visibility), accentColor = MaterialTheme.colorScheme.error) {
                SwitchFlagGrid {
                    DsSwitchRow("Cameras nearby",   spot.hasCameras)      { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(hasCameras = b) }) }
                    DsSwitchRow("Security common",  spot.securityCommon)  { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(securityCommon = b) }) }
                    DsSwitchRow("Well lit",         spot.isWellLit)       { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(isWellLit = b) }) }
                    DsSwitchRow("Hidden from road", spot.isHiddenFromRoad){ b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(isHiddenFromRoad = b) }) }
                }
                DsTextField(
                    value    = spot.safetyNotes,
                    onChange = { newVal -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(safetyNotes = newVal) }) },
                    label    = stringResource(R.string.label_safety_notes),
                    minLines = 2
                )
            }

            // ── Schedule ───────────────────────────────────────────────────
            FormSection(title = stringResource(R.string.section_pickup_schedule), accentColor = ScoutAmberWarm) {
                DsTextField(
                    value      = spot.pickupDays,
                    onChange   = { newVal -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(pickupDays = newVal) }) },
                    label      = stringResource(R.string.label_pickup_days),
                    singleLine = true
                )
                DsTextField(
                    value      = spot.pickupTimeWindow,
                    onChange   = { newVal -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(pickupTimeWindow = newVal) }) },
                    label      = stringResource(R.string.label_pickup_time_window),
                    singleLine = true
                )
                var showTimeMenu by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = showTimeMenu, onExpandedChange = { showTimeMenu = it }) {
                    OutlinedTextField(
                        value         = spot.bestTimeOfDay.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() },
                        onValueChange = {},
                        readOnly      = true,
                        label         = { Text(stringResource(R.string.label_best_time_of_day)) },
                        trailingIcon  = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = showTimeMenu) },
                        modifier      = Modifier.menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
                        shape         = MaterialTheme.shapes.medium
                    )
                    ExposedDropdownMenu(expanded = showTimeMenu, onDismissRequest = { showTimeMenu = false }) {
                        BestTimeOfDay.entries.forEach { tod ->
                            DropdownMenuItem(
                                text    = { Text(tod.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }) },
                                onClick = {
                                    viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(bestTimeOfDay = tod) })
                                    showTimeMenu = false
                                }
                            )
                        }
                    }
                }
                SwitchFlagGrid {
                    DsSwitchRow("Before pickup day",       spot.bestBeforePickupDay)       { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(bestBeforePickupDay = b) }) }
                    DsSwitchRow("Worth after pickup",      spot.worthCheckingAfterPickup)  { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(worthCheckingAfterPickup = b) }) }
                    DsSwitchRow("Near closing time",       spot.throwsOutNearClosingTime)  { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(throwsOutNearClosingTime = b) }) }
                }
            }

            // ── Findings ───────────────────────────────────────────────────
            FormSection(title = stringResource(R.string.section_typical_finds), accentColor = ScoutGreenBright) {
                DsTextField(
                    value    = spot.usualFindings,
                    onChange = { newVal -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(usualFindings = newVal) }) },
                    label    = stringResource(R.string.label_usual_findings),
                    minLines = 2
                )
                SwitchFlagGrid {
                    DsSwitchRow("Staff destroy items",    spot.staffDestroyItems)    { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(staffDestroyItems = b) }) }
                    DsSwitchRow("Usually messy",          spot.usuallyMessy)         { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(usuallyMessy = b) }) }
                    DsSwitchRow("Sharp hazards",          spot.hasSharpHazards)      { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(hasSharpHazards = b) }) }
                    DsSwitchRow("Usually sealed bags",    spot.hasSealed)            { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(hasSealed = b) }) }
                    DsSwitchRow("Checked by other divers",spot.checkedByOtherDivers) { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(checkedByOtherDivers = b) }) }
                }
            }

            // ── Grading ────────────────────────────────────────────────────
            FormSection(title = stringResource(R.string.section_grade), accentColor = ScoutAmber) {
                GradeSliders(grade = spot.grade) { newGrade ->
                    viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(grade = newGrade) })
                }
            }

            // ── Notes & Tags ───────────────────────────────────────────────
            FormSection(title = stringResource(R.string.section_notes_tags), accentColor = MaterialTheme.colorScheme.tertiary) {
                DsTextField(
                    value    = spot.personalNotes,
                    onChange = { newVal -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(personalNotes = newVal) }) },
                    label    = stringResource(R.string.label_personal_notes),
                    minLines = 3,
                    leadingIcon = Icons.AutoMirrored.Filled.Notes
                )
                DsTextField(
                    value      = spot.tags.joinToString(", "),
                    onChange   = { raw ->
                        val tags = raw.split(",").map { it.trim() }.filter { it.isNotBlank() }
                        viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(tags = tags) })
                    },
                    label      = stringResource(R.string.label_tags),
                    leadingIcon = Icons.Default.Tag,
                    singleLine = true
                )
                SwitchFlagGrid {
                    DsSwitchRow(stringResource(R.string.label_verified), spot.isVerified) { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(isVerified = b) }) }
                    DsSwitchRow(stringResource(R.string.label_favorite), spot.isFavorite) { b -> viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(isFavorite = b) }) }
                }
            }

            // ── Sharing scope ──────────────────────────────────────────────
            FormSection(title = stringResource(R.string.section_sharing_scope), accentColor = MaterialTheme.colorScheme.primary) {
                Text(
                    text = stringResource(R.string.sharing_scope_description),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                SwitchFlagGrid {
                    DsSwitchRow(
                        label   = stringResource(R.string.sharing_scope_private),
                        checked = spot.visibility == Visibility.PRIVATE,
                        onCheckedChange = { checked ->
                            if (checked) viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(visibility = Visibility.PRIVATE) })
                        }
                    )
                    DsSwitchRow(
                        label   = stringResource(R.string.sharing_scope_community),
                        checked = spot.visibility == Visibility.COMMUNITY,
                        onCheckedChange = { checked ->
                            if (checked) viewModel.onIntent(AddSpotIntent.UpdateField { it.copy(visibility = Visibility.COMMUNITY) })
                        }
                    )
                }
            }

            Spacer(Modifier.height(DsSpacing.xxxl))
        }
    }
}

// ... existing helper composables ...
@Composable
private fun FormSection(
    title: String,
    accentColor: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    var expanded by remember { mutableStateOf(true) }
    Card(
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.medium
    ) {
        Column {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(accentColor)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = DsSpacing.l, vertical = DsSpacing.m),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    title,
                    style    = MaterialTheme.typography.titleSmall,
                    color    = accentColor,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick  = { expanded = !expanded },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (expanded) stringResource(R.string.cd_collapse_section) else stringResource(R.string.cd_expand_section),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            AnimatedVisibility(
                visible = expanded,
                enter   = fadeIn() + expandVertically(),
                exit    = fadeOut() + shrinkVertically()
            ) {
                Column(
                    modifier = Modifier.padding(start = DsSpacing.l, end = DsSpacing.l, bottom = DsSpacing.m),
                    verticalArrangement = Arrangement.spacedBy(DsSpacing.s),
                    content = content
                )
            }
        }
    }
}

@Composable
private fun DsTextField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    leadingIcon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    singleLine: Boolean = false,
    minLines: Int = 1,
    capitalization: KeyboardCapitalization = KeyboardCapitalization.Sentences,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value           = value,
        onValueChange   = onChange,
        label           = { Text(label) },
        modifier        = modifier.fillMaxWidth(),
        leadingIcon     = leadingIcon?.let { { Icon(it, null) } },
        singleLine      = singleLine,
        minLines        = minLines,
        shape           = MaterialTheme.shapes.medium,
        keyboardOptions = KeyboardOptions(capitalization = capitalization, keyboardType = keyboardType)
    )
}

@Composable
private fun SwitchFlagGrid(content: @Composable ColumnScope.() -> Unit) {
    Column(content = content)
}

@Composable
private fun DsSwitchRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier          = Modifier.fillMaxWidth().padding(vertical = DsSpacing.xs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Switch(
            checked         = checked,
            onCheckedChange = onCheckedChange,
            modifier        = Modifier.padding(end = DsSpacing.m)
        )
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun GradeSliders(grade: SpotGrade, onGradeChange: (SpotGrade) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
        StyledGradeSlider("Overall",           grade.overall,           GradeHigh) { onGradeChange(grade.copy(overall = it)) }
        StyledGradeSlider("Consistency",       grade.consistency,       GradeHigh) { onGradeChange(grade.copy(consistency = it)) }
        StyledGradeSlider("Quality",           grade.quality,           GradeHigh) { onGradeChange(grade.copy(quality = it)) }
        StyledGradeSlider("Quantity",          grade.quantity,          GradeHigh) { onGradeChange(grade.copy(quantity = it)) }
        StyledGradeSlider("Cleanliness",       grade.cleanliness,       GradeHigh) { onGradeChange(grade.copy(cleanliness = it)) }
        StyledGradeSlider("Risk",               grade.risk,        GradeLow,  isWarning = true) { onGradeChange(grade.copy(risk = it)) }
        StyledGradeSlider("Access Difficulty", grade.accessDifficulty,  GradeLow,  isWarning = true) { onGradeChange(grade.copy(accessDifficulty = it)) }
        StyledGradeSlider("Legal Sensitivity", grade.legalSensitivity,  GradeLow,  isWarning = true) { onGradeChange(grade.copy(legalSensitivity = it)) }
    }
}

@Composable
private fun StyledGradeSlider(
    label: String,
    value: Float,
    trackColor: Color,
    isWarning: Boolean = false,
    onValueChange: (Float) -> Unit
) {
    val displayColor = if (isWarning) {
        if (value >= 7f) GradeLow else if (value >= 4f) GradeMid else GradeHigh
    } else {
        if (value >= 7f) GradeHigh else if (value >= 4f) GradeMid else GradeLow
    }
    Row(
        modifier          = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(label, style = MaterialTheme.typography.bodySmall)
                Text(
                    "%.1f".format(value),
                    style = MaterialTheme.typography.labelSmall,
                    color = displayColor
                )
            }
            Slider(
                value        = value,
                onValueChange = onValueChange,
                valueRange   = 0f..10f,
                steps        = 9,
                colors       = SliderDefaults.colors(
                    thumbColor       = displayColor,
                    activeTrackColor = displayColor,
                    inactiveTrackColor = GradeTrack
                )
            )
        }
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "FormSection dark")
@Composable
private fun FormSectionPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        FormSection(title = "Basic Info", accentColor = CategoryGrocery) {
            DsTextField(value = "Trader Joe's", onChange = {}, label = "Spot Name", leadingIcon = Icons.Default.Store)
            DsTextField(value = "123 Main St", onChange = {}, label = "Address", leadingIcon = Icons.Default.LocationOn)
        }
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "GradeSliders dark")
@Composable
private fun GradeSlidersPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        GradeSliders(
            grade = SpotGrade(
                overall = 7.5f, consistency = 8f, quality = 7f, quantity = 8f,
                cleanliness = 6f, risk = 3f, accessDifficulty = 2f, legalSensitivity = 4f
            ),
            onGradeChange = {}
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "AddSpot screen dark")
@Composable
private fun AddSpotScreenPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title = "Add New Spot",
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                        }
                    },
                    actions = { TextButton(onClick = {}) { Text(stringResource(R.string.save)) } }
                )
            }
        ) { padding ->
            val spot = SampleData.spots.first()
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = DsSpacing.l),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                Spacer(Modifier.height(DsSpacing.xs))
                FormSection(title = "Basic Info", accentColor = categoryColor(spot.category)) {
                    DsTextField(value = spot.name, onChange = {}, label = "Name / Business *", leadingIcon = Icons.Default.Store, singleLine = true)
                    DsTextField(value = spot.address, onChange = {}, label = "Address", leadingIcon = Icons.Default.LocationOn, singleLine = true)
                }
                FormSection(title = "Grade", accentColor = ScoutAmber) {
                    GradeSliders(grade = spot.grade, onGradeChange = {})
                }
                Spacer(Modifier.height(DsSpacing.xxxl))
            }
        }
    }
}
