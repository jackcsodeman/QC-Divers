package com.dumpsterscout.ui.collections

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.data.local.dao.CollectionDao
import com.dumpsterscout.data.local.dao.DumpsterSpotDao
import com.dumpsterscout.data.local.dao.FieldLocationDao
import com.dumpsterscout.data.local.dao.TireSpotDao
import com.dumpsterscout.data.local.entity.CollectionEntity
import com.dumpsterscout.data.local.entity.CollectionItemEntity
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.data.sync.SyncEntityType
import com.dumpsterscout.data.sync.SyncQueueOperation
import com.dumpsterscout.data.sync.SyncQueueWriter
import com.dumpsterscout.di.SupabaseCredentials
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject

@Serializable
data class CollectionSyncPayload(
    val collection: CollectionEntity,
    val items: List<CollectionItemEntity>
)

data class CollectionUi(
    val collection: CollectionEntity,
    val items: List<CollectionItemEntity>,
    val syncStatusLabel: String = collection.syncStatus.replace('_', ' ')
)

data class CollectionsUiState(
    val collections: List<CollectionUi> = emptyList(),
    val candidateLocations: List<LocationCandidate> = emptyList(),
    val isLoading: Boolean = true,
    val message: String? = null,
    val error: String? = null
)

data class LocationCandidate(
    val type: String,
    val id: Long,
    val label: String
)

@HiltViewModel
class CollectionsViewModel @Inject constructor(
    private val collectionDao: CollectionDao,
    private val credentials: SupabaseCredentials,
    private val prefs: AppPreferences,
    private val syncQueue: SyncQueueWriter,
    spotDao: DumpsterSpotDao,
    tireSpotDao: TireSpotDao,
    fieldLocationDao: FieldLocationDao
) : ViewModel() {
    private val message = MutableStateFlow<String?>(null)
    private val error = MutableStateFlow<String?>(null)

    @Suppress("UNCHECKED_CAST")
    val uiState: StateFlow<CollectionsUiState> = combine(
        listOf(
            collectionDao.observeCollections().map { it as Any },
            collectionDao.observeItems().map { it as Any },
            spotDao.getAllActiveSpots().map { list -> list.map { LocationCandidate("DUMPSTER_SPOT", it.id, it.name) } as Any },
            tireSpotDao.getAllActiveSpots().map { list -> list.map { LocationCandidate("TIRE_SPOT", it.id, it.name) } as Any },
            fieldLocationDao.observeActive().map { list -> list.map { LocationCandidate(it.type, it.id, it.name) } as Any },
            message.map { it as Any? },
            error.map { it as Any? }
        )
    ) { values ->
        val collections = values[0] as List<CollectionEntity>
        val items = values[1] as List<CollectionItemEntity>
        val candidates = (values[2] as List<LocationCandidate>) +
            (values[3] as List<LocationCandidate>) +
            (values[4] as List<LocationCandidate>)
        CollectionsUiState(
            collections = collections.map { collection -> CollectionUi(collection, items.filter { it.collectionId == collection.id }) },
            candidateLocations = candidates.sortedBy { it.label.lowercase() },
            isLoading = false,
            message = values[5] as String?,
            error = values[6] as String?
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), CollectionsUiState())

    fun clearMessage() { message.value = null }
    fun clearError() { error.value = null }

    fun createCollection(name: String, notes: String) {
        if (name.isBlank()) {
            error.value = "Collection name is required."
            return
        }
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                val ownerId = prefs.localUserId.first()
                val id = collectionDao.insertCollection(
                    CollectionEntity(
                        ownerUserId = ownerId,
                        name = name.trim(),
                        notes = notes.trim(),
                        syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else "LOCAL_ONLY",
                        createdAt = now,
                        updatedAt = now
                    )
                )
                queueCollectionIfConfigured(id, SyncQueueOperation.CREATE)
                message.value = "Collection created."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to create collection."
            }
        }
    }

    fun deleteCollection(id: Long) {
        viewModelScope.launch {
            try {
                val collection = collectionDao.getCollectionById(id)
                collectionDao.softDeleteCollection(id)
                queueCollectionIfConfigured(id, SyncQueueOperation.DELETE, collection?.remoteId)
                message.value = "Collection deleted."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to delete collection."
            }
        }
    }

    fun addLocation(collectionId: Long, candidate: LocationCandidate) {
        viewModelScope.launch {
            try {
                collectionDao.insertItem(
                    CollectionItemEntity(
                        collectionId = collectionId,
                        locationType = candidate.type,
                        locationId = candidate.id,
                        label = candidate.label,
                        sortOrder = System.currentTimeMillis().toInt()
                    )
                )
                queueCollectionIfConfigured(collectionId, SyncQueueOperation.UPDATE)
                message.value = "Location added to collection."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to add item."
            }
        }
    }

    fun removeItem(itemId: Long) {
        viewModelScope.launch {
            try {
                val item = collectionDao.getItemById(itemId)
                collectionDao.softDeleteItem(itemId)
                if (item != null) queueCollectionIfConfigured(item.collectionId, SyncQueueOperation.UPDATE)
                message.value = "Collection item removed."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to remove item."
            }
        }
    }

    private suspend fun queueCollectionIfConfigured(
        collectionId: Long,
        operation: SyncQueueOperation,
        explicitRemoteId: String? = null
    ) {
        if (!credentials.isConfigured) return
        val collection = collectionDao.getCollectionById(collectionId) ?: return
        collectionDao.markPendingSync(collectionId)
        val items = collectionDao.getItemsForCollectionSnapshot(collectionId)
        syncQueue.enqueue(
            entityType = SyncEntityType.COLLECTION,
            entityLocalId = collectionId,
            entityRemoteId = explicitRemoteId ?: collection.remoteId,
            operation = operation,
            payload = Json.encodeToString(CollectionSyncPayload(collection, items))
        )
    }
}
