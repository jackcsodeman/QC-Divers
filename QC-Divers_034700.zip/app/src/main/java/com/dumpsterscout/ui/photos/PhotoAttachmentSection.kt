package com.dumpsterscout.ui.photos

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.PhotoAttachment
import com.dumpsterscout.domain.model.UploadStatus
import com.dumpsterscout.ui.components.SectionHeader
import com.dumpsterscout.ui.theme.DsElevation
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.ScoutSurface2

@Composable
fun PhotoAttachmentSection(
    title: String,
    photos: List<PhotoAttachment>,
    onTakePhoto: () -> Unit,
    onPickPhoto: () -> Unit,
    onDeletePhoto: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        shape = MaterialTheme.shapes.medium
    ) {
        Column(Modifier.padding(DsSpacing.l), verticalArrangement = Arrangement.spacedBy(DsSpacing.m)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionHeader(title = title, modifier = Modifier.weight(1f))
                AssistChip(
                    onClick = {},
                    label = { Text(stringResource(R.string.photo_private_badge)) },
                    leadingIcon = { Icon(Icons.Default.CloudOff, contentDescription = stringResource(R.string.cd_photo_private_badge), modifier = Modifier.size(16.dp)) }
                )
            }
            Text(
                text = stringResource(R.string.photo_private_explanation),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                Button(onClick = onTakePhoto, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.AddAPhoto, contentDescription = stringResource(R.string.cd_photo_take), modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(DsSpacing.xs))
                    Text(stringResource(R.string.photo_take))
                }
                OutlinedButton(onClick = onPickPhoto, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Image, contentDescription = stringResource(R.string.cd_photo_pick), modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(DsSpacing.xs))
                    Text(stringResource(R.string.photo_pick))
                }
            }
            if (photos.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(96.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stringResource(R.string.photo_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                    items(photos, key = { it.id }) { photo ->
                        PhotoThumbCard(photo = photo, onDelete = { onDeletePhoto(photo.id) })
                    }
                }
            }
        }
    }
}

@Composable
private fun PhotoThumbCard(
    photo: PhotoAttachment,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.size(width = 150.dp, height = 178.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.subtle)
    ) {
        Column {
            AsyncImage(
                model = photo.localUri ?: photo.remoteUrl,
                contentDescription = stringResource(R.string.cd_photo_attachment),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(112.dp)
                    .clip(MaterialTheme.shapes.small),
                contentScale = ContentScale.Crop
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = DsSpacing.s, vertical = DsSpacing.xs),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (photo.uploadStatus == UploadStatus.UPLOADED) Icons.Default.CloudDone else Icons.Default.CloudOff,
                    contentDescription = stringResource(R.string.cd_photo_upload_status, photo.uploadStatus.name.lowercase().replace('_', ' ')),
                    tint = when (photo.uploadStatus) {
                        UploadStatus.UPLOADED -> MaterialTheme.colorScheme.primary
                        UploadStatus.UPLOAD_FAILED -> MaterialTheme.colorScheme.error
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = photo.uploadStatus.name.lowercase().replace('_', ' '),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(start = DsSpacing.xs)
                )
                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, stringResource(R.string.photo_delete), modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}
