package com.dumpsterscout.ui.analytics

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.SyncProblem
import androidx.compose.material.icons.filled.TireRepair
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.EmptyStatePanel
import com.dumpsterscout.ui.theme.DsElevation
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.GradeHigh
import com.dumpsterscout.ui.theme.ScoutSurface2

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsScreen(
    onNavigateBack: () -> Unit,
    viewModel: AnalyticsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.analytics_title),
                subtitle = stringResource(R.string.analytics_subtitle),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        }
    ) { padding ->
        if (uiState.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else if (uiState.totalLocations == 0 && uiState.totalReports == 0) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                EmptyStatePanel(message = stringResource(R.string.analytics_empty), icon = Icons.Default.Analytics)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(DsSpacing.l),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.m), modifier = Modifier.fillMaxWidth()) {
                        MetricTile(stringResource(R.string.analytics_total_locations), uiState.totalLocations.toString(), Icons.Default.LocationOn, Modifier.weight(1f))
                        MetricTile(stringResource(R.string.analytics_reports), uiState.totalReports.toString(), Icons.Default.Report, Modifier.weight(1f))
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.m), modifier = Modifier.fillMaxWidth()) {
                        MetricTile(stringResource(R.string.analytics_dumpsters), uiState.dumpsterCount.toString(), Icons.Default.Analytics, Modifier.weight(1f))
                        MetricTile(stringResource(R.string.analytics_tires), uiState.tireCount.toString(), Icons.Default.TireRepair, Modifier.weight(1f))
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.m), modifier = Modifier.fillMaxWidth()) {
                        MetricTile(stringResource(R.string.analytics_field_locations), uiState.fieldLocationCount.toString(), Icons.Default.LocationOn, Modifier.weight(1f))
                        MetricTile(stringResource(R.string.analytics_favorites), uiState.favorites.toString(), Icons.Default.Favorite, Modifier.weight(1f))
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.m), modifier = Modifier.fillMaxWidth()) {
                        MetricTile(stringResource(R.string.analytics_photos), uiState.photos.toString(), Icons.Default.CameraAlt, Modifier.weight(1f))
                        MetricTile(stringResource(R.string.analytics_reminders), uiState.reminders.toString(), Icons.Default.Notifications, Modifier.weight(1f))
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.m), modifier = Modifier.fillMaxWidth()) {
                        MetricTile(stringResource(R.string.analytics_routes), uiState.routes.toString(), Icons.Default.LocationOn, Modifier.weight(1f))
                        MetricTile(stringResource(R.string.analytics_collections), uiState.collections.toString(), Icons.Default.Favorite, Modifier.weight(1f))
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.m), modifier = Modifier.fillMaxWidth()) {
                        MetricTile(stringResource(R.string.analytics_sessions), uiState.sessions.toString(), Icons.Default.Analytics, Modifier.weight(1f))
                        MetricTile(stringResource(R.string.analytics_gear_items), uiState.gearItems.toString(), Icons.Default.Report, Modifier.weight(1f))
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.m), modifier = Modifier.fillMaxWidth()) {
                        MetricTile(stringResource(R.string.analytics_route_stops), uiState.routeStops.toString(), Icons.Default.LocationOn, Modifier.weight(1f))
                        MetricTile(stringResource(R.string.analytics_session_visits), uiState.sessionVisits.toString(), Icons.Default.Analytics, Modifier.weight(1f))
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.m), modifier = Modifier.fillMaxWidth()) {
                        MetricTile(stringResource(R.string.analytics_high_priority), uiState.highPriorityLocations.toString(), Icons.Default.SyncProblem, Modifier.weight(1f))
                        MetricTile(stringResource(R.string.analytics_active_reminders), uiState.activeReminders.toString(), Icons.Default.Notifications, Modifier.weight(1f))
                    }
                }
                item {
                    HealthCard(uiState = uiState)
                }
                item { Spacer(Modifier.height(DsSpacing.giant)) }
            }
        }
    }
}

@Composable
private fun MetricTile(title: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card)
    ) {
        Column(Modifier.padding(DsSpacing.l), verticalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
            Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary)
            Text(value, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurface)
            Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun HealthCard(uiState: AnalyticsUiState) {
    val completion = if (uiState.totalLocations == 0) 0f else (uiState.totalReports.toFloat() / (uiState.totalLocations * 3).coerceAtLeast(1)).coerceIn(0f, 1f)
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card)
    ) {
        Column(Modifier.padding(DsSpacing.l), verticalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                Icon(Icons.Default.SyncProblem, contentDescription = stringResource(R.string.analytics_sync_health), tint = if (uiState.syncFailures == 0) GradeHigh else MaterialTheme.colorScheme.error)
                Text(stringResource(R.string.analytics_sync_health), style = MaterialTheme.typography.titleMedium)
            }
            Text(
                if (uiState.syncFailures == 0) stringResource(R.string.analytics_no_failed_sync)
                else stringResource(R.string.analytics_failed_sync_count, uiState.syncFailures),
                style = MaterialTheme.typography.bodyMedium
            )
            Text(stringResource(R.string.analytics_report_coverage), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            LinearProgressIndicator(progress = { completion }, modifier = Modifier.fillMaxWidth().height(6.dp))
            Text(stringResource(R.string.analytics_route_depth, uiState.averageStopsPerRoute), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(stringResource(R.string.analytics_session_depth, uiState.averageVisitsPerSession), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(stringResource(R.string.analytics_gear_completion), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            LinearProgressIndicator(progress = { uiState.gearCompletion.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(6.dp))
        }
    }
}
