package com.dumpsterscout.ui.theme

import androidx.compose.animation.core.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.scale

/**
 * Standard micro-animations for the Scout Design System.
 */
object DsAnimations {

    /**
     * A "pop" animation used for toggles, likes, and success states.
     */
    @Composable
    fun popScale(trigger: Boolean): State<Float> {
        return animateFloatAsState(
            targetValue = if (trigger) 1.15f else 1.0f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow
            ),
            label = "pop_scale"
        )
    }
}

/**
 * Modifier that applies a springy scale effect when a value changes.
 */
fun Modifier.scoutPop(trigger: Any?): Modifier = composed {
    var lastTrigger by remember { mutableStateOf(trigger) }
    val scale by animateFloatAsState(
        targetValue = if (lastTrigger != trigger) 1.2f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        finishedListener = { lastTrigger = trigger },
        label = "scout_pop"
    )
    this.scale(scale)
}
