package com.dumpsterscout.ui.sync

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.data.local.dao.SyncQueueDao
import com.dumpsterscout.data.local.entity.SyncQueueEntity
import com.dumpsterscout.data.sync.SyncQueueProcessor
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SyncQueueItemUi(
    val id: Long,
    val entityType: String,
    val operation: String,
    val status: String,
    val retryCount: Int,
    val lastError: String?,
    val createdAt: Long,
    val updatedAt: Long
)

data class SyncStatusUiState(
    val items: List<SyncQueueItemUi> = emptyList(),
    val isProcessing: Boolean = false,
    val message: String? = null
) {
    val pendingCount: Int = items.count { it.status == "PENDING" }
    val inProgressCount: Int = items.count { it.status == "IN_PROGRESS" }
    val failedCount: Int = items.count { it.status == "FAILED" }
    val succeededCount: Int = items.count { it.status == "SUCCEEDED" }
}

sealed class SyncStatusEvent {
    data object ProcessNow : SyncStatusEvent()
    data object RetryFailed : SyncStatusEvent()
    data object PruneSucceeded : SyncStatusEvent()
    data object ClearMessage : SyncStatusEvent()
}

@HiltViewModel
class SyncStatusViewModel @Inject constructor(
    private val queueDao: SyncQueueDao,
    private val processor: SyncQueueProcessor
) : ViewModel() {

    private val isProcessing = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)

    val uiState: StateFlow<SyncStatusUiState> = combine(
        queueDao.observeAll(),
        isProcessing,
        message
    ) { items, processing, currentMessage ->
        SyncStatusUiState(
            items = items.map { it.toUi() },
            isProcessing = processing,
            message = currentMessage
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = SyncStatusUiState()
    )

    fun onEvent(event: SyncStatusEvent) {
        when (event) {
            SyncStatusEvent.ProcessNow -> processNow()
            SyncStatusEvent.RetryFailed -> retryFailed()
            SyncStatusEvent.PruneSucceeded -> pruneSucceeded()
            SyncStatusEvent.ClearMessage -> message.value = null
        }
    }

    private fun processNow() {
        viewModelScope.launch {
            isProcessing.value = true
            runCatching { processor.processNextBatch(limit = 100) }
                .onSuccess { result ->
                    message.value = "Sync queue processed: ${result.succeeded} succeeded, ${result.failed} failed."
                }
                .onFailure { error ->
                    message.value = "Sync queue failed: ${error.message ?: error::class.java.simpleName}"
                }
            isProcessing.value = false
        }
    }

    private fun retryFailed() {
        viewModelScope.launch {
            processor.retryFailed()
            message.value = "Failed sync items moved back to pending."
        }
    }

    private fun pruneSucceeded() {
        viewModelScope.launch {
            queueDao.pruneSucceeded(System.currentTimeMillis())
            message.value = "Completed sync items cleared."
        }
    }

    private fun SyncQueueEntity.toUi(): SyncQueueItemUi = SyncQueueItemUi(
        id = id,
        entityType = entityType,
        operation = operation,
        status = status,
        retryCount = retryCount,
        lastError = lastError,
        createdAt = createdAt,
        updatedAt = updatedAt
    )
}
