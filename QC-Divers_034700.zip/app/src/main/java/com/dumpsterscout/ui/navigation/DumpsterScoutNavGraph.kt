package com.dumpsterscout.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.ui.about.AboutScreen
import com.dumpsterscout.ui.fieldsessions.FieldSessionsScreen
import com.dumpsterscout.ui.fieldlocations.FieldLocationsScreen
import com.dumpsterscout.ui.conflicts.ConflictResolutionScreen
import com.dumpsterscout.ui.collections.CollectionsScreen
import com.dumpsterscout.ui.analytics.AnalyticsScreen
import com.dumpsterscout.ui.community.CommunitySpotDetailScreen
import com.dumpsterscout.ui.community.CommunityTireSpotDetailScreen
import com.dumpsterscout.ui.account.ScoutProfileScreen
import com.dumpsterscout.ui.favorites.FavoritesScreen
import com.dumpsterscout.ui.field.FieldModeScreen
import com.dumpsterscout.ui.history.HistoryScreen
import com.dumpsterscout.ui.home.HomeScreen
import com.dumpsterscout.ui.map.MapScreen
import com.dumpsterscout.ui.routes.SavedRoutesScreen
import com.dumpsterscout.ui.reminders.RemindersScreen
import com.dumpsterscout.ui.settings.SettingsScreen
import com.dumpsterscout.ui.sync.SyncStatusScreen
import com.dumpsterscout.ui.spots.AddSpotScreen
import com.dumpsterscout.ui.spots.SpotDetailScreen
import com.dumpsterscout.ui.spots.SpotListScreen
import com.dumpsterscout.ui.tire.AddTireSpotScreen
import com.dumpsterscout.ui.tire.TireHistoryScreen
import com.dumpsterscout.ui.tire.TireReportScreen
import com.dumpsterscout.ui.tire.TireSpotDetailScreen
import com.dumpsterscout.ui.tire.TireSpotListScreen
import com.dumpsterscout.ui.tire.TireVoiceReportScreen
import com.dumpsterscout.ui.voice.VoiceReportScreen
import com.dumpsterscout.ui.onboarding.OnboardingScreen
import com.dumpsterscout.ui.gear.GearChecklistScreen
import com.dumpsterscout.ui.theme.DsEasing
import com.dumpsterscout.ui.theme.DsMotion

/**
 * Root navigation graph for Dumpster Scout.
 */
@Composable
fun DumpsterScoutNavGraph(
    onboardingComplete: Boolean,
    onOnboardingComplete: () -> Unit,
    initialRoute: String? = null,
    onInitialRouteConsumed: () -> Unit = {}
) {
    val navController = rememberNavController()

    LaunchedEffect(initialRoute, onboardingComplete) {
        val route = initialRoute
        if (onboardingComplete && !route.isNullOrBlank()) {
            navController.navigate(route) { launchSingleTop = true }
            onInitialRouteConsumed()
        }
    }

    NavHost(
        navController = navController,
        startDestination = if (onboardingComplete) Screen.Home.route else Screen.Onboarding.route,
        enterTransition = {
            slideInHorizontally(
                animationSpec = tween(DsMotion.enter, easing = DsEasing.emphasizedDecelerate),
                initialOffsetX = { it / 5 }
            ) + fadeIn(tween(DsMotion.enter, easing = DsEasing.emphasizedDecelerate))
        },
        exitTransition = {
            slideOutHorizontally(
                animationSpec = tween(DsMotion.exit, easing = DsEasing.emphasizedAccelerate),
                targetOffsetX = { -it / 5 }
            ) + fadeOut(tween(DsMotion.exit, easing = DsEasing.emphasizedAccelerate))
        },
        popEnterTransition = {
            slideInHorizontally(
                animationSpec = tween(DsMotion.enter, easing = DsEasing.emphasizedDecelerate),
                initialOffsetX = { -it / 5 }
            ) + fadeIn(tween(DsMotion.enter, easing = DsEasing.emphasizedDecelerate))
        },
        popExitTransition = {
            slideOutHorizontally(
                animationSpec = tween(DsMotion.exit, easing = DsEasing.emphasizedAccelerate),
                targetOffsetX = { it / 5 }
            ) + fadeOut(tween(DsMotion.exit, easing = DsEasing.emphasizedAccelerate))
        }
    ) {
        composable(Screen.Onboarding.route) {
            OnboardingScreen(
                onFinished = {
                    onOnboardingComplete()
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Onboarding.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Home.route) {
            HomeScreen(
                onNavigateToMap              = { navController.navigate(Screen.Map.route) },
                onNavigateToSpotList         = { navController.navigate(Screen.SpotList.route) },
                onNavigateToVoiceReport      = { navController.navigate(Screen.VoiceReport.route) },
                onNavigateToAddSpot          = { navController.navigate(Screen.AddSpot.createRoute()) },
                onNavigateToSpotDetail       = { id -> navController.navigate(Screen.SpotDetail.createRoute(id)) },
                onNavigateToHistory          = { navController.navigate(Screen.History.route) },
                onNavigateToSettings         = { navController.navigate(Screen.Settings.route) },
                onNavigateToFieldMode        = { navController.navigate(Screen.FieldMode.route) },
                onNavigateToTireSpotList     = { navController.navigate(Screen.TireSpotList.route) },
                onNavigateToTireHistory      = { navController.navigate(Screen.TireHistory.route) },
                onNavigateToTireVoiceReport  = { navController.navigate(Screen.TireVoiceReport.createRoute()) }
            )
        }

        composable(Screen.SpotList.route) {
            SpotListScreen(
                onNavigateBack = { navController.navigateUp() },
                onNavigateToSpotDetail = { id -> navController.navigate(Screen.SpotDetail.createRoute(id)) },
                onNavigateToAddSpot = { navController.navigate(Screen.AddSpot.createRoute()) },
                onNavigateToMap = { navController.navigate(Screen.Map.route) }
            )
        }

        composable(
            route = Screen.AddSpot.route,
            arguments = listOf(
                navArgument("spotId") { type = NavType.LongType; defaultValue = -1L },
                navArgument("name") { type = NavType.StringType; nullable = true; defaultValue = null },
                navArgument("address") { type = NavType.StringType; nullable = true; defaultValue = null },
                navArgument("status") { type = NavType.StringType; nullable = true; defaultValue = null }
            )
        ) { backStackEntry ->
            val spotId = backStackEntry.arguments?.getLong("spotId")?.takeIf { it != -1L }
            val initialName = backStackEntry.arguments?.getString("name")
            val initialAddress = backStackEntry.arguments?.getString("address")
            val initialStatusStr = backStackEntry.arguments?.getString("status")
            val initialStatus = initialStatusStr?.let { runCatching { SpotStatus.valueOf(it) }.getOrNull() }

            AddSpotScreen(
                spotId = spotId,
                initialName = initialName,
                initialAddress = initialAddress,
                initialStatus = initialStatus,
                onNavigateBack = { navController.navigateUp() },
                onSpotSaved = { savedId ->
                    navController.navigate(Screen.SpotDetail.createRoute(savedId)) {
                        popUpTo(Screen.AddSpot.route) { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = Screen.SpotDetail.route,
            arguments = listOf(navArgument("spotId") { type = NavType.LongType })
        ) { backStackEntry ->
            val spotId = backStackEntry.arguments?.getLong("spotId") ?: return@composable
            SpotDetailScreen(
                spotId = spotId,
                onNavigateBack = { navController.navigateUp() },
                onNavigateToEdit = { id -> navController.navigate(Screen.AddSpot.createRoute(id)) },
                onNavigateToVoiceReport = { navController.navigate(Screen.VoiceReport.route) }
            )
        }

        composable(Screen.VoiceReport.route) {
            VoiceReportScreen(
                onNavigateBack = { navController.navigateUp() },
                onReportSaved = { navController.navigateUp() },
                onNavigateToAddSpot = { name, location, status ->
                    navController.navigate(Screen.AddSpot.createRoute(name = name, address = location, status = status))
                }
            )
        }

        composable(Screen.Map.route) {
            MapScreen(
                onNavigateBack = { navController.navigateUp() },
                onNavigateToSpotDetail = { id -> navController.navigate(Screen.SpotDetail.createRoute(id)) },
                onNavigateToTireSpotDetail = { id -> navController.navigate(Screen.TireSpotDetail.createRoute(id)) },
                onNavigateToFieldLocations = { navController.navigate(Screen.FieldLocations.route) },
                onNavigateToAddSpot = { navController.navigate(Screen.AddSpot.createRoute()) },
                onNavigateToCommunitySpotDetail = { remoteId -> navController.navigate(Screen.CommunitySpotDetail.createRoute(remoteId)) },
                onNavigateToCommunityTireSpotDetail = { remoteId -> navController.navigate(Screen.CommunityTireSpotDetail.createRoute(remoteId)) }
            )
        }

        composable(Screen.History.route) {
            HistoryScreen(
                onNavigateBack = { navController.navigateUp() },
                onNavigateToSpotDetail = { id -> navController.navigate(Screen.SpotDetail.createRoute(id)) }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                onNavigateBack    = { navController.navigateUp() },
                onNavigateToAbout = { navController.navigate(Screen.About.route) },
                onNavigateToAccount = { navController.navigate(Screen.Account.route) },
                onNavigateToSyncStatus = { navController.navigate(Screen.SyncStatus.route) },
                onNavigateToConflicts = { navController.navigate(Screen.ConflictResolution.route) },
                onNavigateToReminders = { navController.navigate(Screen.Reminders.route) },
                onNavigateToFieldLocations = { navController.navigate(Screen.FieldLocations.route) },
                onNavigateToCollections = { navController.navigate(Screen.Collections.route) },
                onNavigateToFieldSessions = { navController.navigate(Screen.FieldSessions.route) },
                onNavigateToGearChecklist = { navController.navigate(Screen.GearChecklist.route) },
                onNavigateToAnalytics = { navController.navigate(Screen.Analytics.route) }
            )
        }

        composable(Screen.About.route) { AboutScreen(onNavigateBack = { navController.navigateUp() }) }
        composable(Screen.SyncStatus.route) { SyncStatusScreen(onNavigateBack = { navController.navigateUp() }) }
        composable(Screen.Reminders.route) { RemindersScreen(onNavigateBack = { navController.navigateUp() }) }
        composable(Screen.ConflictResolution.route) { ConflictResolutionScreen(onNavigateBack = { navController.navigateUp() }) }
        composable(Screen.FieldLocations.route) { FieldLocationsScreen(onNavigateBack = { navController.navigateUp() }) }
        composable(Screen.Collections.route) { CollectionsScreen(onNavigateBack = { navController.navigateUp() }) }
        composable(Screen.FieldSessions.route) { FieldSessionsScreen(onNavigateBack = { navController.navigateUp() }) }
        composable(Screen.Analytics.route) { AnalyticsScreen(onNavigateBack = { navController.navigateUp() }) }
        composable(Screen.GearChecklist.route) { GearChecklistScreen(onNavigateBack = { navController.navigateUp() }) }

        composable(Screen.Favorites.route) {
            FavoritesScreen(
                onNavigateBack = { navController.navigateUp() },
                onNavigateToSpotDetail = { id -> navController.navigate(Screen.SpotDetail.createRoute(id)) }
            )
        }

        composable(Screen.SavedRoutes.route) {
            SavedRoutesScreen(
                onNavigateBack = { navController.navigateUp() },
                onNavigateToSpotDetail = { id -> navController.navigate(Screen.SpotDetail.createRoute(id)) }
            )
        }

        composable(Screen.FieldMode.route) {
            FieldModeScreen(
                onNavigateBack            = { navController.navigateUp() },
                onNavigateToVoiceReport   = { navController.navigate(Screen.VoiceReport.route) },
                onNavigateToMap           = { navController.navigate(Screen.Map.route) },
                onNavigateToSpotList      = { navController.navigate(Screen.SpotList.route) },
                onNavigateToAddSpot       = { navController.navigate(Screen.AddSpot.createRoute()) },
                onNavigateToGearChecklist = { navController.navigate(Screen.GearChecklist.route) }
            )
        }

        // ── Community ──────────────────────────────────────────────────────────

        composable(
            route = Screen.CommunitySpotDetail.route,
            arguments = listOf(navArgument("remoteId") { type = NavType.StringType })
        ) { backStackEntry ->
            val remoteId = backStackEntry.arguments?.getString("remoteId") ?: return@composable
            CommunitySpotDetailScreen(
                remoteId = remoteId,
                onNavigateBack = { navController.navigateUp() }
            )
        }

        composable(
            route = Screen.CommunityTireSpotDetail.route,
            arguments = listOf(navArgument("remoteId") { type = NavType.StringType })
        ) { backStackEntry ->
            val remoteId = backStackEntry.arguments?.getString("remoteId") ?: return@composable
            CommunityTireSpotDetailScreen(
                remoteId = remoteId,
                onNavigateBack = { navController.navigateUp() }
            )
        }

        // ── Tire Spots ─────────────────────────────────────────────────────────

        composable(Screen.TireSpotList.route) {
            TireSpotListScreen(
                onNavigateBack             = { navController.navigateUp() },
                onNavigateToTireSpotDetail = { id -> navController.navigate(Screen.TireSpotDetail.createRoute(id)) },
                onNavigateToAddTireSpot    = { navController.navigate(Screen.AddTireSpot.createRoute()) }
            )
        }

        composable(
            route = Screen.AddTireSpot.route,
            arguments = listOf(navArgument("tireSpotId") { type = NavType.LongType; defaultValue = -1L })
        ) { backStackEntry ->
            val tireSpotId = backStackEntry.arguments?.getLong("tireSpotId")?.takeIf { it != -1L }
            AddTireSpotScreen(
                tireSpotId     = tireSpotId,
                onNavigateBack = { navController.navigateUp() },
                onSpotSaved    = { savedId ->
                    navController.navigate(Screen.TireSpotDetail.createRoute(savedId)) {
                        popUpTo(Screen.AddTireSpot.route) { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = Screen.TireSpotDetail.route,
            arguments = listOf(navArgument("tireSpotId") { type = NavType.LongType })
        ) { backStackEntry ->
            val tireSpotId = backStackEntry.arguments?.getLong("tireSpotId") ?: return@composable
            TireSpotDetailScreen(
                spotId                      = tireSpotId,
                onNavigateBack              = { navController.navigateUp() },
                onNavigateToEdit            = { id -> navController.navigate(Screen.AddTireSpot.createRoute(id)) },
                onNavigateToTireReport      = { id -> navController.navigate(Screen.TireReport.createRoute(id)) },
                onNavigateToTireVoiceReport = { id -> navController.navigate(Screen.TireVoiceReport.createRoute(id)) }
            )
        }

        composable(
            route = Screen.TireReport.route,
            arguments = listOf(navArgument("tireSpotId") { type = NavType.LongType; defaultValue = -1L })
        ) { backStackEntry ->
            val tireSpotId = backStackEntry.arguments?.getLong("tireSpotId")?.takeIf { it != -1L }
            TireReportScreen(
                tireSpotId     = tireSpotId,
                onNavigateBack = { navController.navigateUp() }
            )
        }

        composable(Screen.TireHistory.route) {
            TireHistoryScreen(
                onNavigateBack             = { navController.navigateUp() },
                onNavigateToTireSpotDetail = { id -> navController.navigate(Screen.TireSpotDetail.createRoute(id)) }
            )
        }

        composable(
            route = Screen.TireVoiceReport.route,
            arguments = listOf(navArgument("tireSpotId") { type = NavType.LongType; defaultValue = -1L })
        ) { backStackEntry ->
            val tireSpotId = backStackEntry.arguments?.getLong("tireSpotId")?.takeIf { it != -1L }
            TireVoiceReportScreen(
                onNavigateBack    = { navController.navigateUp() },
                onReportSaved     = { navController.navigateUp() },
                preselectedSpotId = tireSpotId
            )
        }

        // ── Account ────────────────────────────────────────────────────────────
        composable(Screen.Account.route) {
            com.dumpsterscout.ui.account.AccountScreen(onNavigateBack = { navController.navigateUp() })
        }

        composable(Screen.OAuthConsent.route) {
            com.dumpsterscout.ui.account.AuthConsentScreen(
                onAuthFinished = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = Screen.ScoutProfile.route,
            arguments = listOf(navArgument("remoteUserId") { type = NavType.StringType })
        ) { backStackEntry ->
            val remoteUserId = backStackEntry.arguments?.getString("remoteUserId") ?: return@composable
            ScoutProfileScreen(
                remoteUserId = remoteUserId,
                onNavigateBack = { navController.navigateUp() }
            )
        }
    }
}
