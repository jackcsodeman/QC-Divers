package com.dumpsterscout.ui.fieldlocations

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.data.local.dao.FieldLocationDao
import com.dumpsterscout.data.local.dao.FieldLocationReportDao
import com.dumpsterscout.data.local.entity.FieldLocationEntity
import com.dumpsterscout.data.local.entity.FieldLocationReportEntity
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.data.sync.SyncEntityType
import com.dumpsterscout.data.sync.SyncQueueOperation
import com.dumpsterscout.data.sync.SyncQueueWriter
import com.dumpsterscout.di.SupabaseCredentials
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import javax.inject.Inject

/**
 *
 */
data class FieldLocationsUiState(
    /**
     *
     */
    val locations: List<FieldLocationEntity> = emptyList(),
    /**
     *
     */
    val reports: List<FieldLocationReportEntity> = emptyList(),
    /**
     *
     */
    val query: String = "",
    /**
     *
     */
    val selectedType: String = "ALL",
    /**
     *
     */
    val isLoading: Boolean = true,
    /**
     *
     */
    val error: String? = null,
    /**
     *
     */
    val message: String? = null
) {
    /**
     *
     */
    val filteredLocations: List<FieldLocationEntity> = locations.filter { /**
                                                                           *
                                                                           */
                                                                          location ->
        (selectedType == "ALL" || location.type == selectedType) &&
            (query.isBlank() || listOf(
                location.name,
                location.description,
                location.address,
                location.tags,
                location.safetyNotes,
                location.hazardNotes,
                location.resourceType
            ).any { it.contains(query, ignoreCase = true) })
    }
}

/**
 *
 */
@HiltViewModel
class FieldLocationsViewModel @Inject constructor(
    /**
     *
     */
    private val dao: FieldLocationDao,
    /**
     *
     */
    private val reportDao: FieldLocationReportDao,
    /**
     *
     */
    private val credentials: SupabaseCredentials,
    /**
     *
     */
    private val prefs: AppPreferences,
    /**
     *
     */
    private val syncQueue: SyncQueueWriter
) : ViewModel() {
    private val query = MutableStateFlow("")
    private val selectedType = MutableStateFlow("ALL")
    private val error = MutableStateFlow<String?>(null)
    private val message = MutableStateFlow<String?>(null)

    /**
     *
     */
    val uiState: StateFlow<FieldLocationsUiState> = combine(
        dao.observeAll(),
        reportDao.observeAll(),
        query,
        selectedType,
        error,
        message
    ) { /**
                                                                    *
                                                                    */
                                                                   args: Array<*> ->
        FieldLocationsUiState(
            locations = args[0] as List<FieldLocationEntity>,
            reports = args[1] as List<FieldLocationReportEntity>,
            query = args[2] as String,
            selectedType = args[3] as String,
            isLoading = false,
            error = args[4] as String?,
            message = args[5] as String?
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), FieldLocationsUiState())

    /**
     *
     */
    fun setQuery(
        /**
         *
         */
        value: String) { query.value = value }
    /**
     *
     */
    fun setType(
        /**
         *
         */
        value: String) { selectedType.value = value }
    /**
     *
     */
    fun clearError() { error.value = null }
    /**
     *
     */
    fun clearMessage() { message.value = null }

    /**
     *
     */
    fun saveLocation(
        /**
         *
         */
        type: String,
        /**
         *
         */
        name: String,
        /**
         *
         */
        description: String,
        /**
         *
         */
        address: String,
        /**
         *
         */
        latitude: Double,
        /**
         *
         */
        longitude: Double,
        /**
         *
         */
        tags: String,
        /**
         *
         */
        cleanupPriority: String,
        /**
         *
         */
        resourceType: String
    ) {
        if (name.isBlank()) {
            error.value = "Name is required."
            return
        }
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                val ownerId = prefs.localUserId.first()
                val entity = FieldLocationEntity(
                    type = type,
                    name = name.trim(),
                    description = description.trim(),
                    address = address.trim(),
                    latitude = latitude,
                    longitude = longitude,
                    tags = tags.trim(),
                    cleanupPriority = cleanupPriority,
                    resourceType = resourceType.trim(),
                    ownerUserId = ownerId,
                    syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else "LOCAL_ONLY",
                    createdAt = now,
                    updatedAt = now
                )
                val id = dao.upsert(entity)
                if (credentials.isConfigured) {
                    syncQueue.enqueue(
                        entityType = SyncEntityType.FIELD_LOCATION,
                        entityLocalId = id,
                        entityRemoteId = null,
                        operation = SyncQueueOperation.CREATE,
                        payload = Json.encodeToString(entity.copy(id = id))
                    )
                }
                message.value = "Location saved."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to save location."
            }
        }
    }


    /**
     *
     */
    fun updateLocation(
        /**
         *
         */
        existing: FieldLocationEntity,
        /**
         *
         */
        type: String,
        /**
         *
         */
        name: String,
        /**
         *
         */
        description: String,
        /**
         *
         */
        address: String,
        /**
         *
         */
        latitude: Double,
        /**
         *
         */
        longitude: Double,
        /**
         *
         */
        tags: String,
        /**
         *
         */
        cleanupPriority: String,
        /**
         *
         */
        resourceType: String
    ) {
        if (name.isBlank()) {
            error.value = "Name is required."
            return
        }
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                val updated = existing.copy(
                    type = type,
                    name = name.trim(),
                    description = description.trim(),
                    address = address.trim(),
                    latitude = latitude,
                    longitude = longitude,
                    tags = tags.trim(),
                    cleanupPriority = cleanupPriority,
                    resourceType = resourceType.trim(),
                    syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else existing.syncStatus,
                    updatedAt = now
                )
                dao.update(updated)
                if (credentials.isConfigured) {
                    syncQueue.enqueue(
                        entityType = SyncEntityType.FIELD_LOCATION,
                        entityLocalId = updated.id,
                        entityRemoteId = updated.remoteId,
                        operation = SyncQueueOperation.UPDATE,
                        payload = Json.encodeToString(updated)
                    )
                }
                message.value = "Location updated."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to update location."
            }
        }
    }

    /**
     *
     */
    fun addReport(
        /**
         *
         */
        location: FieldLocationEntity,
        /**
         *
         */
        reportType: String,
        /**
         *
         */
        status: String,
        /**
         *
         */
        accessStatus: String,
        /**
         *
         */
        hazardLevel: String,
        /**
         *
         */
        cleanupStatus: String,
        /**
         *
         */
        cleanupProgress: Int,
        /**
         *
         */
        findings: String,
        /**
         *
         */
        notes: String
    ) {
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                val ownerId = prefs.localUserId.first()
                val syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else "LOCAL_ONLY"
                val report = FieldLocationReportEntity(
                    fieldLocationId = location.id,
                    locationName = location.name,
                    reportType = reportType,
                    status = status,
                    accessStatus = accessStatus,
                    hazardLevel = hazardLevel,
                    cleanupStatus = cleanupStatus,
                    cleanupProgress = cleanupProgress.coerceIn(0, 100),
                    findings = findings.trim(),
                    notes = notes.trim(),
                    latitude = location.latitude,
                    longitude = location.longitude,
                    ownerUserId = ownerId,
                    syncStatus = syncStatus,
                    timestamp = now,
                    createdAt = now,
                    updatedAt = now
                )
                val id = reportDao.upsert(report)
                if (credentials.isConfigured) {
                    val saved = report.copy(id = id)
                    val dependsOn = if (location.remoteId.isNullOrBlank()) {
                        syncQueue.latestQueueId(SyncEntityType.FIELD_LOCATION, location.id)
                    } else null
                    syncQueue.enqueue(
                        entityType = SyncEntityType.FIELD_LOCATION_REPORT,
                        entityLocalId = id,
                        entityRemoteId = saved.remoteId,
                        operation = SyncQueueOperation.CREATE,
                        payload = Json.encodeToString(saved),
                        dependsOnQueueItemId = dependsOn
                    )
                }
                message.value = "Report saved."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to save report."
            }
        }
    }

    /**
     *
     */
    fun deleteReport(
        /**
         *
         */
        report: FieldLocationReportEntity) {
        viewModelScope.launch {
            try {
                reportDao.softDelete(report.id, syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else report.syncStatus)
                if (credentials.isConfigured) {
                    syncQueue.enqueue(
                        entityType = SyncEntityType.FIELD_LOCATION_REPORT,
                        entityLocalId = report.id,
                        entityRemoteId = report.remoteId,
                        operation = SyncQueueOperation.DELETE,
                        payload = Json.encodeToString(mapOf("id" to report.id, "remoteId" to report.remoteId, "deletedAt" to System.currentTimeMillis()))
                    )
                }
                message.value = "Report deleted."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to delete report."
            }
        }
    }

    /**
     *
     */
    fun toggleFavorite(
        /**
         *
         */
        id: Long) {
        viewModelScope.launch {
            try {
                dao.toggleFavorite(id)
                queueUpdateIfConfigured(id)
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to update favorite."
            }
        }
    }

    /**
     *
     */
    fun deleteLocation(
        /**
         *
         */
        id: Long) {
        viewModelScope.launch {
            try {
                val entity = dao.getById(id)
                dao.softDelete(id)
                if (credentials.isConfigured && entity != null) {
                    syncQueue.enqueue(
                        entityType = SyncEntityType.FIELD_LOCATION,
                        entityLocalId = id,
                        entityRemoteId = entity.remoteId,
                        operation = SyncQueueOperation.DELETE,
                        payload = Json.encodeToString(mapOf("id" to id, "remoteId" to entity.remoteId, "deletedAt" to System.currentTimeMillis()))
                    )
                }
                message.value = "Location deleted."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to delete location."
            }
        }
    }

    private suspend fun queueUpdateIfConfigured(
        /**
         *
         */
        id: Long) {
        if (!credentials.isConfigured) return
        dao.markPendingSync(id)
        val entity = dao.getById(id) ?: return
        syncQueue.enqueue(
            entityType = SyncEntityType.FIELD_LOCATION,
            entityLocalId = entity.id,
            entityRemoteId = entity.remoteId,
            operation = SyncQueueOperation.UPDATE,
            payload = Json.encodeToString(entity)
        )
    }
}
