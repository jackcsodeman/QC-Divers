package com.dumpsterscout.ui.conflicts

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.data.local.dao.SyncQueueDao
import com.dumpsterscout.data.local.entity.SyncQueueEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ConflictFieldSnapshot(
    val name: String,
    val localValue: String,
    val remoteValue: String? = null,
    val isSensitive: Boolean = false,
    val isChanged: Boolean = false,
    val suggestedValue: String = localValue
)

data class ConflictReviewItem(
    val queueItem: SyncQueueEntity,
    val localFields: List<ConflictFieldSnapshot>,
    val hasRemoteSnapshot: Boolean,
    val changedFieldCount: Int,
    val safeToAcceptRemote: Boolean
)

data class ConflictResolutionUiState(
    val items: List<ConflictReviewItem> = emptyList(),
    val isLoading: Boolean = true
)

@HiltViewModel
class ConflictResolutionViewModel @Inject constructor(
    private val syncQueueDao: SyncQueueDao,
    private val conflictRemoteApplyUseCase: ConflictRemoteApplyUseCase
) : ViewModel() {
    val uiState: StateFlow<ConflictResolutionUiState> = syncQueueDao.observeAll()
        .map { all ->
            ConflictResolutionUiState(
                items = all
                    .filter { it.status == "FAILED" || it.status == "CONFLICT" }
                    .map(::toReviewItem),
                isLoading = false
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ConflictResolutionUiState())

    private fun toReviewItem(item: SyncQueueEntity): ConflictReviewItem {
        val parsed = ConflictPayloadParser.parse(item.payload, item.remotePayload)
        val changedCount = parsed.fields.count { it.isChanged }
        return ConflictReviewItem(
            queueItem = item,
            localFields = parsed.fields,
            hasRemoteSnapshot = parsed.hasRemoteSnapshot,
            changedFieldCount = changedCount,
            safeToAcceptRemote = parsed.hasRemoteSnapshot && changedCount > 0
        )
    }

    fun retryFailed() {
        viewModelScope.launch { syncQueueDao.retryFailed() }
    }

    fun clearResolved() {
        viewModelScope.launch { syncQueueDao.pruneSucceeded(System.currentTimeMillis()) }
    }

    fun keepLocalAndRetry(id: Long) {
        viewModelScope.launch { syncQueueDao.retryOne(id) }
    }

    fun dismissQueueItem(id: Long) {
        viewModelScope.launch { syncQueueDao.deleteById(id) }
    }

    /**
     * Accepting remote keeps an audit record instead of deleting the row.
     * Domain-specific remote writeback should update local entities once pull snapshots are captured.
     */
    fun acceptRemoteAndResolve(id: Long) {
        viewModelScope.launch {
            val item = syncQueueDao.getById(id) ?: return@launch
            val result = conflictRemoteApplyUseCase.acceptRemote(item)
            syncQueueDao.markResolvedRemote(id, result.message)
        }
    }

    /**
     * Creates a safe local duplicate when supported, then preserves the audit row for QA.
     */
    fun markDuplicateReviewed(id: Long) {
        viewModelScope.launch {
            val item = syncQueueDao.getById(id) ?: return@launch
            val result = conflictRemoteApplyUseCase.duplicateLocal(item)
            syncQueueDao.markResolvedDuplicate(id, result.message)
        }
    }
}
