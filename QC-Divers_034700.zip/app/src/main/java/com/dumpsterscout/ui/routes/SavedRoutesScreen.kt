package com.dumpsterscout.ui.routes

import android.content.Intent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Label
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedAssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.EmptyStatePanel
import com.dumpsterscout.ui.theme.DsElevation
import com.dumpsterscout.ui.theme.DsMotion
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.NeonBlue
import com.dumpsterscout.ui.theme.NeonCyan
import com.dumpsterscout.ui.theme.ScoutSurface2
import com.dumpsterscout.util.toShortDateString

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedRoutesScreen(
    onNavigateBack: () -> Unit,
    onNavigateToSpotDetail: (Long) -> Unit,
    viewModel: RoutePlanViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    var showAddDialog by remember { mutableStateOf(false) }
    var newRouteName by remember { mutableStateOf("") }
    val expandedRoutes = remember { mutableStateMapOf<Long, Boolean>() }

    LaunchedEffect(uiState.message) {
        uiState.message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }
    LaunchedEffect(uiState.error) {
        uiState.error?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearError()
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false; newRouteName = "" },
            icon = { Icon(Icons.Default.Route, null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text(stringResource(R.string.new_route_title)) },
            text = {
                OutlinedTextField(
                    value = newRouteName,
                    onValueChange = { newRouteName = it },
                    label = { Text(stringResource(R.string.route_name_label)) },
                    singleLine = true,
                    shape = MaterialTheme.shapes.medium,
                    leadingIcon = { Icon(Icons.AutoMirrored.Filled.Label, null) }
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.createRoute(newRouteName)
                        newRouteName = ""
                        showAddDialog = false
                    },
                    enabled = newRouteName.isNotBlank()
                ) { Text(stringResource(R.string.create_route)) }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false; newRouteName = "" }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.saved_routes_title),
                subtitle = if (uiState.routes.isNotEmpty()) {
                    pluralStringResource(R.plurals.routes_subtitle, uiState.routes.size, uiState.routes.size)
                } else null,
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                elevation = FloatingActionButtonDefaults.elevation(DsElevation.floating)
            ) {
                Icon(Icons.Default.Add, stringResource(R.string.cd_add_route))
            }
        }
    ) { padding ->
        AnimatedContent(
            targetState = uiState.routes.isEmpty(),
            transitionSpec = { fadeIn(tween(DsMotion.medium)) togetherWith fadeOut(tween(DsMotion.exit)) },
            label = "routes_list_toggle",
            modifier = Modifier.fillMaxSize().padding(padding)
        ) { isEmpty ->
            if (isEmpty) {
                EmptyStatePanel(
                    message = stringResource(R.string.routes_empty_message),
                    icon = Icons.Default.Route
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(DsSpacing.l),
                    verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
                ) {
                    items(uiState.routes, key = { it.id }) { route ->
                        val isExpanded = expandedRoutes[route.id] ?: false
                        RouteCard(
                            route = route,
                            candidates = uiState.candidates,
                            expanded = isExpanded,
                            onToggleExpanded = { expandedRoutes[route.id] = !isExpanded },
                            onNavigateFirstDumpster = { route.spotIds.firstOrNull()?.let(onNavigateToSpotDetail) },
                            onOpenNavigation = {
                                val uri = route.navigationUri
                                if (uri == null) {
                                    snackbarHostState.currentSnackbarData?.dismiss()
                                } else {
                                    runCatching {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply {
                                            setPackage("com.google.android.apps.maps")
                                        })
                                    }.recoverCatching {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                    }.onFailure {
                                        // Snackbar is launched through effect-safe coroutine context below.
                                    }
                                }
                            },
                            onDelete = { viewModel.deleteRoute(route.id) },
                            onOptimizeOrder = { viewModel.optimizeRoute(route.id) },
                            onAddStop = { viewModel.addStop(route.id, it) },
                            onRemoveStop = { viewModel.removeStop(it) },
                            onMoveStopUp = { viewModel.reorderStop(route, it, moveUp = true) },
                            onMoveStopDown = { viewModel.reorderStop(route, it, moveUp = false) }
                        )
                    }
                    item { Spacer(Modifier.height(DsSpacing.giant)) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RouteCard(
    route: RoutePlanUi,
    candidates: List<RouteStopCandidate>,
    expanded: Boolean,
    onToggleExpanded: () -> Unit,
    onNavigateFirstDumpster: () -> Unit,
    onOpenNavigation: () -> Unit,
    onDelete: () -> Unit,
    onOptimizeOrder: () -> Unit,
    onAddStop: (RouteStopCandidate) -> Unit,
    onRemoveStop: (Long) -> Unit,
    onMoveStopUp: (Long) -> Unit,
    onMoveStopDown: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onToggleExpanded,
        modifier = modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape = MaterialTheme.shapes.large
    ) {
        Column {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(Brush.horizontalGradient(listOf(NeonCyan, NeonBlue)))
            )
            Row(
                modifier = Modifier.padding(DsSpacing.l),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(NeonCyan.copy(alpha = 0.18f))
                ) {
                    Icon(Icons.Default.Route, contentDescription = stringResource(R.string.cd_route_icon), tint = NeonCyan, modifier = Modifier.size(24.dp))
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(route.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)) {
                        Icon(Icons.Default.Place, stringResource(R.string.cd_route_stop_count), modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            pluralStringResource(R.plurals.route_stops, route.spotCount, route.spotCount),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text("·", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(route.createdAt.toShortDateString(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (route.notes.isNotBlank()) {
                        Text(
                            route.notes,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onToggleExpanded) {
                        Icon(Icons.Default.SwapVert, contentDescription = stringResource(if (expanded) R.string.cd_collapse_route_named else R.string.cd_expand_route_named, route.name))
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.cd_delete_route_named, route.name), tint = MaterialTheme.colorScheme.error)
                    }
                }
            }

            if (expanded) {
                RouteDetails(
                    route = route,
                    candidates = candidates,
                    onNavigateFirstDumpster = onNavigateFirstDumpster,
                    onOpenNavigation = onOpenNavigation,
                    onOptimizeOrder = onOptimizeOrder,
                    onAddStop = onAddStop,
                    onRemoveStop = onRemoveStop,
                    onMoveStopUp = onMoveStopUp,
                    onMoveStopDown = onMoveStopDown
                )
            }
        }
    }
}

@Composable
private fun RouteDetails(
    route: RoutePlanUi,
    candidates: List<RouteStopCandidate>,
    onNavigateFirstDumpster: () -> Unit,
    onOpenNavigation: () -> Unit,
    onOptimizeOrder: () -> Unit,
    onAddStop: (RouteStopCandidate) -> Unit,
    onRemoveStop: (Long) -> Unit,
    onMoveStopUp: (Long) -> Unit,
    onMoveStopDown: (Long) -> Unit
) {
    Column(Modifier.padding(horizontal = DsSpacing.l, vertical = DsSpacing.m), verticalArrangement = Arrangement.spacedBy(DsSpacing.m)) {
        Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
            Button(onClick = onOpenNavigation, enabled = route.navigationUri != null) {
                Icon(Icons.Default.Navigation, contentDescription = stringResource(R.string.cd_open_route_navigation_named, route.name))
                Spacer(Modifier.size(DsSpacing.xs))
                Text(stringResource(R.string.route_open_navigation))
            }
            TextButton(onClick = onNavigateFirstDumpster, enabled = route.spotIds.isNotEmpty()) {
                Icon(Icons.Default.Map, contentDescription = stringResource(R.string.cd_view_first_route_stop_named, route.name))
                Spacer(Modifier.size(DsSpacing.xs))
                Text(stringResource(R.string.cd_view_route_details))
            }
            if (route.stops.size >= 3) {
                IconButton(onClick = onOptimizeOrder) {
                    Icon(Icons.Default.Build, contentDescription = "Optimize order by proximity")
                }
            }
        }

        Text(stringResource(R.string.route_stops_section), style = MaterialTheme.typography.titleSmall)
        if (route.stops.isEmpty()) {
            Text(stringResource(R.string.route_no_stops), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            route.stops.forEachIndexed { index, stop ->
                RouteStopRow(
                    index = index,
                    stop = stop,
                    isFirst = index == 0,
                    isLast = index == route.stops.lastIndex,
                    onRemove = { onRemoveStop(stop.id) },
                    onMoveUp = { onMoveStopUp(stop.id) },
                    onMoveDown = { onMoveStopDown(stop.id) }
                )
            }
        }

        Text(stringResource(R.string.route_available_stops), style = MaterialTheme.typography.titleSmall)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
            items(candidates.take(40), key = { it.type + it.id }) { candidate ->
                ElevatedAssistChip(
                    onClick = { onAddStop(candidate) },
                    label = { Text(candidate.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    leadingIcon = { Icon(Icons.Default.Add, contentDescription = stringResource(R.string.cd_add_route_stop_named, candidate.label)) }
                )
            }
        }
    }
}

@Composable
private fun RouteStopRow(
    index: Int,
    stop: RouteStopUi,
    isFirst: Boolean,
    isLast: Boolean,
    onRemove: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
    ) {
        Text("${index + 1}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Column(Modifier.weight(1f)) {
            Text(stop.label, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                stop.type.lowercase().replace('_', ' ') + if (stop.hasCoordinates) " · coordinates ready" else " · no coordinates",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        IconButton(onClick = onMoveUp, enabled = !isFirst) {
            Icon(Icons.Default.KeyboardArrowUp, contentDescription = stringResource(R.string.cd_move_route_stop_up_named, stop.label))
        }
        IconButton(onClick = onMoveDown, enabled = !isLast) {
            Icon(Icons.Default.KeyboardArrowDown, contentDescription = stringResource(R.string.cd_move_route_stop_down_named, stop.label))
        }
        IconButton(onClick = onRemove) {
            Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.cd_remove_route_stop_named, stop.label), tint = MaterialTheme.colorScheme.error)
        }
    }
}
