package com.dumpsterscout.ui.analytics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.data.local.dao.CollectionDao
import com.dumpsterscout.data.local.dao.DumpsterSpotDao
import com.dumpsterscout.data.local.dao.FieldLocationDao
import com.dumpsterscout.data.local.dao.FieldLocationReportDao
import com.dumpsterscout.data.local.dao.FieldSessionDao
import com.dumpsterscout.data.local.dao.GearChecklistDao
import com.dumpsterscout.data.local.dao.PersonalReportDao
import com.dumpsterscout.data.local.dao.ReminderDao
import com.dumpsterscout.data.local.dao.RoutePlanDao
import com.dumpsterscout.data.local.dao.SpotPhotoDao
import com.dumpsterscout.data.local.dao.SyncQueueDao
import com.dumpsterscout.data.local.dao.TireReportDao
import com.dumpsterscout.data.local.dao.TireSpotDao
import com.dumpsterscout.domain.usecase.CalculatePersonalEfficiencyUseCase
import com.dumpsterscout.domain.usecase.PersonalEfficiency
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

/**
 * UI State for the analytics dashboard.
 * 
 * @property dumpsterCount Total active dumpster spots.
 * @property tireCount Total active tire spots.
 * @property fieldLocationCount Total active general field locations.
 * @property reportCount Total dumpster reports.
 * @property tireReportCount Total tire reports.
 * @property fieldLocationReportCount Total field location reports.
 * @property favorites Combined count of favorite locations.
 * @property reminders Total reminders set.
 * @property activeReminders Count of pending/active reminders.
 * @property routes Total saved route plans.
 * @property routeStops Total number of stops across all routes.
 * @property collections Total number of loot collections.
 * @property collectionItems Total items across all collections.
 * @property sessions Total field sessions recorded.
 * @property sessionVisits Total stops visited during sessions.
 * @property gearItems Total items in the gear checklist.
 * @property checkedGearItems Number of gear items marked as ready.
 * @property highPriorityLocations Count of high-priority sites.
 * @property syncFailures Number of failed sync queue items.
 * @property photos Total number of spot photos.
 * @property personalEfficiency Calculated productivity metrics.
 * @property isLoading Whether data is still being aggregated.
 */
data class AnalyticsUiState(
    val dumpsterCount: Int = 0,
    val tireCount: Int = 0,
    val fieldLocationCount: Int = 0,
    val reportCount: Int = 0,
    val tireReportCount: Int = 0,
    val fieldLocationReportCount: Int = 0,
    val favorites: Int = 0,
    val reminders: Int = 0,
    val activeReminders: Int = 0,
    val routes: Int = 0,
    val routeStops: Int = 0,
    val collections: Int = 0,
    val collectionItems: Int = 0,
    val sessions: Int = 0,
    val sessionVisits: Int = 0,
    val gearItems: Int = 0,
    val checkedGearItems: Int = 0,
    val highPriorityLocations: Int = 0,
    val syncFailures: Int = 0,
    val photos: Int = 0,
    val personalEfficiency: PersonalEfficiency? = null,
    val isLoading: Boolean = true
) {
    /** Combined count of all tracked locations. */
    val totalLocations: Int = dumpsterCount + tireCount + fieldLocationCount
    /** Combined count of all submitted reports. */
    val totalReports: Int = reportCount + tireReportCount + fieldLocationReportCount
    /** Percentage of gear items marked as checked. */
    val gearCompletion: Float = if (gearItems == 0) 0f else checkedGearItems.toFloat() / gearItems
    /** Avg stops per route. */
    val averageStopsPerRoute: Float = if (routes == 0) 0f else routeStops.toFloat() / routes
    /** Avg visits per session. */
    val averageVisitsPerSession: Float = if (sessions == 0) 0f else sessionVisits.toFloat() / sessions
}

/**
 * MVI ViewModel for aggregating scouting metrics and efficiency data.
 * 
 * @property calculatePersonalEfficiencyUseCase Use case for productivity metrics.
 */
@HiltViewModel
class AnalyticsViewModel @Inject constructor(
    spotDao: DumpsterSpotDao,
    tireSpotDao: TireSpotDao,
    fieldLocationDao: FieldLocationDao,
    reportDao: PersonalReportDao,
    tireReportDao: TireReportDao,
    fieldLocationReportDao: FieldLocationReportDao,
    reminderDao: ReminderDao,
    routeDao: RoutePlanDao,
    collectionDao: CollectionDao,
    fieldSessionDao: FieldSessionDao,
    gearChecklistDao: GearChecklistDao,
    syncQueueDao: SyncQueueDao,
    photoDao: SpotPhotoDao,
    private val calculatePersonalEfficiencyUseCase: CalculatePersonalEfficiencyUseCase
) : ViewModel() {
    private val metricFlows = listOf(
        spotDao.observeActiveSpotCount(),
        tireSpotDao.observeActiveSpotCount(),
        fieldLocationDao.observeActiveCount(),
        reportDao.getReportCount(),
        tireReportDao.getReportCount(),
        fieldLocationReportDao.observeReportCount(),
        spotDao.observeFavoriteCount(),
        tireSpotDao.observeFavoriteCount(),
        fieldLocationDao.observeFavoriteCount(),
        reminderDao.observeReminderCount(),
        reminderDao.observeActiveReminderCount(),
        routeDao.observeRouteCount(),
        routeDao.observeRouteStopCount(),
        collectionDao.observeCollectionCount(),
        collectionDao.observeCollectionItemCount(),
        fieldSessionDao.observeSessionCount(),
        fieldSessionDao.observeVisitCount(),
        gearChecklistDao.observeItemCount(),
        gearChecklistDao.observeCheckedItemCount(),
        fieldLocationDao.observeHighPriorityCount(),
        syncQueueDao.observeFailedCount(),
        photoDao.observePhotoCount()
    )

    private val baseMetrics = combine(metricFlows) { values ->
        AnalyticsUiState(
            dumpsterCount = values[0] as Int,
            tireCount = values[1] as Int,
            fieldLocationCount = values[2] as Int,
            reportCount = values[3] as Int,
            tireReportCount = values[4] as Int,
            fieldLocationReportCount = values[5] as Int,
            favorites = (values[6] as Int) + (values[7] as Int) + (values[8] as Int),
            reminders = values[9] as Int,
            activeReminders = values[10] as Int,
            routes = values[11] as Int,
            routeStops = values[12] as Int,
            collections = values[13] as Int,
            collectionItems = values[14] as Int,
            sessions = values[15] as Int,
            sessionVisits = values[16] as Int,
            gearItems = values[17] as Int,
            checkedGearItems = values[18] as Int,
            highPriorityLocations = values[19] as Int,
            syncFailures = values[20] as Int,
            photos = values[21] as Int,
            isLoading = false
        )
    }

    /** State flow representing the aggregated analytics data. */
    val uiState: StateFlow<AnalyticsUiState> = baseMetrics.flatMapLatest { state ->
        flow {
            val efficiency = calculatePersonalEfficiencyUseCase()
            emit(state.copy(personalEfficiency = efficiency))
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AnalyticsUiState())
}
