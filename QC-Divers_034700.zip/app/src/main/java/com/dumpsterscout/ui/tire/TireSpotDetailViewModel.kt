package com.dumpsterscout.ui.tire

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.domain.usecase.GetTireSpotDetailUseCase
import com.dumpsterscout.domain.repository.TireSpotRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class TireSpotDetailIntent {
    data class Load(val id: Long) : TireSpotDetailIntent()
    data object ToggleFavorite : TireSpotDetailIntent()
    data class UpdateStatus(val status: TireSpotStatus) : TireSpotDetailIntent()
    data object PublishToCommunity : TireSpotDetailIntent()
    data object RetrySync : TireSpotDetailIntent()
    data class ShowDeleteDialog(val show: Boolean) : TireSpotDetailIntent()
    data object DeleteSpot : TireSpotDetailIntent()
    data object ClearError : TireSpotDetailIntent()
    data object ClearPublishedFlag : TireSpotDetailIntent()
}

data class TireSpotDetailUiState(
    val spot: TireSpot? = null,
    val reports: List<TireReport> = emptyList(),
    val isLoading: Boolean = true,
    val isOwner: Boolean = false,
    val showDeleteDialog: Boolean = false,
    val isDeleted: Boolean = false,
    val publishedSuccessfully: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class TireSpotDetailViewModel @Inject constructor(
    private val getTireSpotDetailUseCase: GetTireSpotDetailUseCase,
    private val tireSpotRepository: TireSpotRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(TireSpotDetailUiState())
    val uiState: StateFlow<TireSpotDetailUiState> = _uiState.asStateFlow()

    private var currentSpotId: Long? = null

    fun onIntent(intent: TireSpotDetailIntent) {
        when (intent) {
            is TireSpotDetailIntent.Load -> loadSpot(intent.id)
            TireSpotDetailIntent.ToggleFavorite -> toggleFavorite()
            is TireSpotDetailIntent.UpdateStatus -> updateStatus(intent.status)
            TireSpotDetailIntent.PublishToCommunity -> publishSpot()
            TireSpotDetailIntent.RetrySync -> retrySync()
            is TireSpotDetailIntent.ShowDeleteDialog -> _uiState.update { it.copy(showDeleteDialog = intent.show) }
            TireSpotDetailIntent.DeleteSpot -> deleteSpot()
            TireSpotDetailIntent.ClearError -> _uiState.update { it.copy(error = null) }
            TireSpotDetailIntent.ClearPublishedFlag -> _uiState.update { it.copy(publishedSuccessfully = false) }
        }
    }

    private fun loadSpot(id: Long) {
        currentSpotId = id
        getTireSpotDetailUseCase(id)
            .onEach { detail ->
                if (detail != null) {
                    _uiState.update { it.copy(
                        spot = detail.spot,
                        reports = detail.reports,
                        isOwner = detail.isOwner,
                        isLoading = false
                    ) }
                } else {
                    _uiState.update { it.copy(error = "Spot not found", isLoading = false) }
                }
            }
            .catch { e -> _uiState.update { it.copy(error = e.message, isLoading = false) } }
            .launchIn(viewModelScope)
    }

    private fun toggleFavorite() {
        val id = currentSpotId ?: return
        viewModelScope.launch {
            try {
                tireSpotRepository.toggleFavorite(id)
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message) }
            }
        }
    }

    private fun updateStatus(status: TireSpotStatus) {
        val id = currentSpotId ?: return
        viewModelScope.launch {
            try {
                tireSpotRepository.updateLastStatus(id, status, System.currentTimeMillis())
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message) }
            }
        }
    }

    private fun publishSpot() {
        val id = currentSpotId ?: return
        viewModelScope.launch {
            try {
                tireSpotRepository.publishSpot(id)
                _uiState.update { it.copy(publishedSuccessfully = true) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message) }
            }
        }
    }

    private fun retrySync() {
        val spot = _uiState.value.spot ?: return
        viewModelScope.launch {
            try {
                tireSpotRepository.upsertSpot(spot)
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message) }
            }
        }
    }

    private fun deleteSpot() {
        val spot = _uiState.value.spot ?: return
        viewModelScope.launch {
            try {
                tireSpotRepository.deleteSpot(spot)
                _uiState.update { it.copy(isDeleted = true, showDeleteDialog = false) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message, showDeleteDialog = false) }
            }
        }
    }
}
