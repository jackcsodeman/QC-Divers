package com.dumpsterscout.ui.spots

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.model.Visibility
import com.dumpsterscout.domain.usecase.GetSpotDetailUseCase
import com.dumpsterscout.domain.usecase.ToggleSpotFavoriteUseCase
import com.dumpsterscout.domain.usecase.UpdateSpotStatusUseCase
import com.dumpsterscout.domain.usecase.SetSpotVisibilityUseCase
import com.dumpsterscout.domain.usecase.VisibilityResult
import com.dumpsterscout.domain.repository.SpotRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Intents for the Spot Detail screen.
 */
sealed class SpotDetailIntent {
    data class Load(val id: Long) : SpotDetailIntent()
    data object ToggleFavorite : SpotDetailIntent()
    data class UpdateStatus(val status: SpotStatus) : SpotDetailIntent()
    data object PublishToCommunity : SpotDetailIntent()
    data object RetrySync : SpotDetailIntent()
    data class ShowDeleteDialog(val show: Boolean) : SpotDetailIntent()
    data object DeleteSpot : SpotDetailIntent()
    data object ClearError : SpotDetailIntent()
    data object ClearPublishedFlag : SpotDetailIntent()
}

/**
 * UI State for the Spot Detail screen.
 */
data class SpotDetailState(
    val spot: DumpsterSpot? = null,
    val reports: List<PersonalReport> = emptyList(),
    val isLoading: Boolean = true,
    val isOwner: Boolean = false,
    val showDeleteDialog: Boolean = false,
    val isDeleted: Boolean = false,
    val publishedSuccessfully: Boolean = false,
    val error: String? = null
)

/**
 * MVI ViewModel for viewing and interacting with a single dumpster spot's details.
 */
@HiltViewModel
class SpotDetailViewModel @Inject constructor(
    private val getSpotDetailUseCase: GetSpotDetailUseCase,
    private val toggleFavoriteUseCase: ToggleSpotFavoriteUseCase,
    private val updateStatusUseCase: UpdateSpotStatusUseCase,
    private val setSpotVisibilityUseCase: SetSpotVisibilityUseCase,
    private val spotRepository: SpotRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SpotDetailState())
    val uiState: StateFlow<SpotDetailState> = _uiState.asStateFlow()

    private var currentSpotId: Long? = null

    /**
     * Handle incoming UI intents.
     */
    fun onIntent(intent: SpotDetailIntent) {
        when (intent) {
            is SpotDetailIntent.Load -> loadSpot(intent.id)
            SpotDetailIntent.ToggleFavorite -> toggleFavorite()
            is SpotDetailIntent.UpdateStatus -> updateStatus(intent.status)
            SpotDetailIntent.PublishToCommunity -> publishSpot()
            SpotDetailIntent.RetrySync -> retrySync()
            is SpotDetailIntent.ShowDeleteDialog -> _uiState.update { it.copy(showDeleteDialog = intent.show) }
            SpotDetailIntent.DeleteSpot -> deleteSpot()
            SpotDetailIntent.ClearError -> _uiState.update { it.copy(error = null) }
            SpotDetailIntent.ClearPublishedFlag -> _uiState.update { it.copy(publishedSuccessfully = false) }
        }
    }

    private fun loadSpot(id: Long) {
        currentSpotId = id
        getSpotDetailUseCase(id)
            .onEach { detail ->
                if (detail != null) {
                    _uiState.update { it.copy(
                        spot = detail.spot,
                        reports = detail.reports,
                        isOwner = detail.isOwner,
                        isLoading = false
                    ) }
                } else {
                    _uiState.update { it.copy(error = "Spot not found", isLoading = false) }
                }
            }
            .catch { e -> _uiState.update { it.copy(error = e.message, isLoading = false) } }
            .launchIn(viewModelScope)
    }

    private fun toggleFavorite() {
        val id = currentSpotId ?: return
        viewModelScope.launch {
            toggleFavoriteUseCase(id).onFailure { e ->
                _uiState.update { it.copy(error = e.message) }
            }
        }
    }

    private fun updateStatus(status: SpotStatus) {
        val id = currentSpotId ?: return
        viewModelScope.launch {
            updateStatusUseCase(id, status).onFailure { e ->
                _uiState.update { it.copy(error = e.message) }
            }
        }
    }

    private fun publishSpot() {
        val id = currentSpotId ?: return
        viewModelScope.launch {
            when (val result = setSpotVisibilityUseCase(id, Visibility.COMMUNITY)) {
                is VisibilityResult.Success -> {
                    _uiState.update { it.copy(publishedSuccessfully = true) }
                }
                is VisibilityResult.Restricted -> {
                    _uiState.update { it.copy(error = result.reason) }
                }
                is VisibilityResult.Error -> {
                    _uiState.update { it.copy(error = result.message) }
                }
            }
        }
    }

    private fun retrySync() {
        val spot = _uiState.value.spot ?: return
        viewModelScope.launch {
            try {
                spotRepository.upsertSpot(spot)
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message) }
            }
        }
    }

    private fun deleteSpot() {
        val spot = _uiState.value.spot ?: return
        viewModelScope.launch {
            try {
                spotRepository.deleteSpot(spot)
                _uiState.update { it.copy(isDeleted = true, showDeleteDialog = false) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message, showDeleteDialog = false) }
            }
        }
    }
}
