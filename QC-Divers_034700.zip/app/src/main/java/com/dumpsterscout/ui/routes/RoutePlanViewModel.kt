package com.dumpsterscout.ui.routes

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.data.local.dao.DumpsterSpotDao
import com.dumpsterscout.data.local.dao.FieldLocationDao
import com.dumpsterscout.data.local.dao.RoutePlanDao
import com.dumpsterscout.data.local.dao.TireSpotDao
import com.dumpsterscout.data.local.entity.RoutePlanEntity
import com.dumpsterscout.data.local.entity.RouteStopEntity
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.data.sync.SyncEntityType
import com.dumpsterscout.data.sync.SyncQueueOperation
import com.dumpsterscout.data.sync.SyncQueueWriter
import com.dumpsterscout.di.SupabaseCredentials
import com.dumpsterscout.domain.usecase.OptimizeRouteUseCase
import kotlinx.coroutines.flow.first
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Representation of a location that can be added to a route.
 * 
 * @property type The entity type (e.g., DUMPSTER_SPOT).
 * @property id The local ID of the entity.
 * @property label The display name.
 * @property latitude Decimal latitude.
 * @property longitude Decimal longitude.
 */
data class RouteStopCandidate(
    val type: String,
    val id: Long,
    val label: String,
    val latitude: Double,
    val longitude: Double
)

/**
 * UI model for a stop within a route.
 */
data class RouteStopUi(
    val id: Long,
    val routeId: Long,
    val type: String,
    val locationId: Long,
    val label: String,
    val latitude: Double,
    val longitude: Double,
    val sortOrder: Int,
    val hasCoordinates: Boolean
)

/**
 * UI model for a complete route plan.
 */
data class RoutePlanUi(
    val id: Long,
    val name: String,
    val stops: List<RouteStopUi>,
    val spotIds: List<Long>,
    val spotCount: Int,
    val notes: String,
    val createdAt: Long,
    val navigationUri: Uri?
)

/**
 * UI state for the route planning screen.
 */
data class RoutePlanUiState(
    val routes: List<RoutePlanUi> = emptyList(),
    val candidates: List<RouteStopCandidate> = emptyList(),
    val isLoading: Boolean = true,
    val message: String? = null,
    val error: String? = null
)

/**
 * ViewModel for creating and managing multi-stop route plans.
 */
@HiltViewModel
class RoutePlanViewModel @Inject constructor(
    private val routeDao: RoutePlanDao,
    private val credentials: SupabaseCredentials,
    private val prefs: AppPreferences,
    private val syncQueue: SyncQueueWriter,
    private val optimizeRouteUseCase: OptimizeRouteUseCase,
    spotDao: DumpsterSpotDao,
    tireSpotDao: TireSpotDao,
    fieldLocationDao: FieldLocationDao
) : ViewModel() {

    private val message = MutableStateFlow<String?>(null)
    private val error = MutableStateFlow<String?>(null)

    private data class RouteData(
        val routes: List<RoutePlanEntity>,
        val stops: List<RouteStopEntity>,
        val candidates: List<RouteStopCandidate>
    )

    private val routeData = combine(
        routeDao.getAllRoutePlans(),
        routeDao.observeAllStops(),
        spotDao.getAllActiveSpots(),
        tireSpotDao.getAllActiveSpots(),
        fieldLocationDao.observeActive()
    ) { routes, stops, dumpsterSpots, tireSpots, fieldLocations ->
        RouteData(
            routes = routes,
            stops = stops,
            candidates = (
                dumpsterSpots.map { RouteStopCandidate("DUMPSTER_SPOT", it.id, it.name, it.latitude, it.longitude) } +
                    tireSpots.map { RouteStopCandidate("TIRE_SPOT", it.id, it.name, it.latitude, it.longitude) } +
                    fieldLocations.map { RouteStopCandidate(it.type, it.id, it.name, it.latitude, it.longitude) }
                ).sortedBy { it.label.lowercase() }
        )
    }

    /** The current UI state. */
    val uiState: StateFlow<RoutePlanUiState> = combine(
        routeData,
        message,
        error
    ) { data, messageValue, errorValue ->
        RoutePlanUiState(
            routes = data.routes.map { route ->
                val routeStops = data.stops
                    .filter { it.routeId == route.id }
                    .sortedBy { it.sortOrder }
                    .map { it.toUi() }
                route.toUi(routeStops)
            },
            candidates = data.candidates,
            isLoading = false,
            message = messageValue,
            error = errorValue
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = RoutePlanUiState()
    )

    /** Clear the current success message. */
    fun clearMessage() { message.value = null }
    /** Clear the current error message. */
    fun clearError() { error.value = null }

    /** Create a new empty route. */
    fun createRoute(name: String) {
        viewModelScope.launch {
            try {
                val trimmed = name.trim()
                if (trimmed.isBlank()) {
                    error.value = "Route name is required."
                    return@launch
                }
                val now = System.currentTimeMillis()
                val ownerId = prefs.localUserId.first()
                val route = RoutePlanEntity(
                    name = trimmed,
                    ownerUserId = ownerId,
                    syncStatus = if (credentials.isConfigured) "PENDING_SYNC" else "LOCAL_ONLY",
                    createdAt = now,
                    updatedAt = now
                )
                val id = routeDao.insert(route)
                queueRouteIfConfigured(id, SyncQueueOperation.CREATE)
                message.value = "Route created."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to create route."
            }
        }
    }

    /** Delete a route and its stops. */
    fun deleteRoute(id: Long) {
        viewModelScope.launch {
            try {
                val route = routeDao.getRoutePlanById(id)
                routeDao.softDeletePlan(id)
                if (route != null) {
                    queueRouteIfConfigured(id, SyncQueueOperation.DELETE, route.remoteId)
                }
                message.value = "Route deleted."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to delete route."
            }
        }
    }

    /** Add a stop to an existing route. */
    fun addStop(routeId: Long, candidate: RouteStopCandidate) {
        viewModelScope.launch {
            try {
                val sortOrder = routeDao.nextSortOrder(routeId)
                routeDao.insertStop(
                    RouteStopEntity(
                        routeId = routeId,
                        locationType = candidate.type,
                        locationId = candidate.id,
                        label = candidate.label,
                        latitude = candidate.latitude,
                        longitude = candidate.longitude,
                        sortOrder = sortOrder
                    )
                )
                queueRouteIfConfigured(routeId, SyncQueueOperation.UPDATE)
                message.value = "Stop added."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to add stop."
            }
        }
    }

    /** Remove a specific stop from a route. */
    fun removeStop(stopId: Long) {
        viewModelScope.launch {
            try {
                val stop = routeDao.getStopById(stopId)
                routeDao.softDeleteStop(stopId)
                if (stop != null) {
                    queueRouteIfConfigured(stop.routeId, SyncQueueOperation.UPDATE)
                }
                message.value = "Stop removed."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to remove stop."
            }
        }
    }

    /** Swap order of a stop. */
    fun reorderStop(route: RoutePlanUi, stopId: Long, moveUp: Boolean) {
        viewModelScope.launch {
            try {
                val current = route.stops.toMutableList()
                val index = current.indexOfFirst { it.id == stopId }
                val targetIndex = if (moveUp) index - 1 else index + 1
                if (index !in current.indices || targetIndex !in current.indices) return@launch
                val moving = current.removeAt(index)
                current.add(targetIndex, moving)
                current.forEachIndexed { idx, stop -> routeDao.updateStopOrder(stop.id, idx) }
                queueRouteIfConfigured(route.id, SyncQueueOperation.UPDATE)
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to reorder stop."
            }
        }
    }

    /** Update notes for a route. */
    fun updateRouteNotes(routeId: Long, notes: String) {
        viewModelScope.launch {
            try {
                val route = routeDao.getRoutePlanById(routeId) ?: return@launch
                routeDao.update(route.copy(notes = notes.trim(), updatedAt = System.currentTimeMillis()))
                queueRouteIfConfigured(routeId, SyncQueueOperation.UPDATE)
                message.value = "Route notes updated."
            } catch (e: Exception) {
                error.value = e.message ?: "Failed to update route notes."
            }
        }
    }

    /** Automatically optimize stop order based on location proximity. */
    fun optimizeRoute(routeId: Long) {
        viewModelScope.launch {
            try {
                val currentStops = routeDao.getStopsForRouteSnapshot(routeId)
                if (currentStops.size < 3) {
                    error.value = "At least 3 stops are required for optimization."
                    return@launch
                }
                val optimized = optimizeRouteUseCase(currentStops)
                optimized.forEach { stop ->
                    routeDao.updateStopOrder(stop.id, stop.sortOrder)
                }
                queueRouteIfConfigured(routeId, SyncQueueOperation.UPDATE)
                message.value = "Route optimized by proximity."
            } catch (e: Exception) {
                error.value = e.message ?: "Optimization failed."
            }
        }
    }


    private suspend fun queueRouteIfConfigured(
        routeId: Long,
        operation: SyncQueueOperation,
        explicitRemoteId: String? = null
    ) {
        if (!credentials.isConfigured) return
        val route = routeDao.getRoutePlanById(routeId) ?: return
        routeDao.markPlanPendingSync(routeId)
        val stops = routeDao.getStopsForRouteSnapshot(routeId)
        syncQueue.enqueue(
            entityType = SyncEntityType.ROUTE_PLAN,
            entityLocalId = routeId,
            entityRemoteId = explicitRemoteId ?: route.remoteId,
            operation = operation,
            payload = Json.encodeToString(RouteSyncPayload(route, stops))
        )
    }

    @kotlinx.serialization.Serializable
    private data class RouteSyncPayload(
        val route: RoutePlanEntity,
        val stops: List<RouteStopEntity>
    )

    private fun RoutePlanEntity.toUi(stops: List<RouteStopUi>): RoutePlanUi {
        val legacySpotIds = stops.filter { it.type == "DUMPSTER_SPOT" }.map { it.locationId }
        return RoutePlanUi(
            id = id,
            name = name,
            stops = stops,
            spotIds = legacySpotIds,
            spotCount = stops.size,
            notes = notes,
            createdAt = createdAt,
            navigationUri = stops.toNavigationUri()
        )
    }

    private fun RouteStopEntity.toUi(): RouteStopUi = RouteStopUi(
        id = id,
        routeId = routeId,
        type = locationType,
        locationId = locationId,
        label = label.ifBlank { "${locationType.replace('_', ' ')} #$locationId" },
        latitude = latitude,
        longitude = longitude,
        sortOrder = sortOrder,
        hasCoordinates = latitude != 0.0 || longitude != 0.0
    )

    private fun List<RouteStopUi>.toNavigationUri(): Uri? {
        val routable = filter { it.hasCoordinates }
        if (routable.isEmpty()) return null
        val destination = routable.last()
        val origin = routable.first()
        val waypoints = routable.drop(1).dropLast(1)
            .joinToString("|") { "${it.latitude},${it.longitude}" }
        val base = StringBuilder("https://www.google.com/maps/dir/?api=1")
            .append("&origin=${origin.latitude},${origin.longitude}")
            .append("&destination=${destination.latitude},${destination.longitude}")
            .append("&travelmode=driving")
        if (waypoints.isNotBlank()) base.append("&waypoints=").append(Uri.encode(waypoints))
        return Uri.parse(base.toString())
    }
}
