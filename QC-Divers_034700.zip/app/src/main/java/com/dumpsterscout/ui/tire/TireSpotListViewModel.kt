package com.dumpsterscout.ui.tire

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireSpotCategory
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.domain.usecase.GetTireSpotsUseCase
import com.dumpsterscout.domain.repository.TireSpotRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class TireSpotListIntent {
    data class Search(val query: String) : TireSpotListIntent()
    data class FilterCategory(val category: TireSpotCategory?) : TireSpotListIntent()
    data class FilterStatus(val status: TireSpotStatus?) : TireSpotListIntent()
    data class ToggleFavorites(val favoritesOnly: Boolean) : TireSpotListIntent()
    data object ToggleFilterVisibility : TireSpotListIntent()
    data class ToggleFavorite(val spotId: Long) : TireSpotListIntent()
    data object ClearError : TireSpotListIntent()
}

data class TireSpotListUiState(
    val spots: List<TireSpot> = emptyList(),
    val isLoading: Boolean = true,
    val searchQuery: String = "",
    val filterCategory: TireSpotCategory? = null,
    val filterStatus: TireSpotStatus? = null,
    val showFavoritesOnly: Boolean = false,
    val showFilters: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class TireSpotListViewModel @Inject constructor(
    private val getTireSpotsUseCase: GetTireSpotsUseCase,
    private val tireSpotRepository: TireSpotRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(TireSpotListUiState())
    val uiState: StateFlow<TireSpotListUiState> = _uiState.asStateFlow()

    init {
        observeSpots()
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun observeSpots() {
        combine(
            _uiState.map { it.searchQuery }.distinctUntilChanged(),
            _uiState.map { it.filterCategory }.distinctUntilChanged(),
            _uiState.map { it.filterStatus }.distinctUntilChanged(),
            _uiState.map { it.showFavoritesOnly }.distinctUntilChanged()
        ) { query, category, status, favoritesOnly ->
            Quad(query, category, status, favoritesOnly)
        }.flatMapLatest { (query, category, status, favoritesOnly) ->
            getTireSpotsUseCase(query, category, status, favoritesOnly)
        }.onEach { spots ->
            _uiState.update { it.copy(spots = spots, isLoading = false) }
        }.catch { e ->
            _uiState.update { it.copy(error = e.message ?: "Failed to load spots", isLoading = false) }
        }.launchIn(viewModelScope)
    }

    fun onIntent(intent: TireSpotListIntent) {
        when (intent) {
            is TireSpotListIntent.Search -> _uiState.update { it.copy(searchQuery = intent.query) }
            is TireSpotListIntent.FilterCategory -> _uiState.update { it.copy(filterCategory = intent.category) }
            is TireSpotListIntent.FilterStatus -> _uiState.update { it.copy(filterStatus = intent.status) }
            is TireSpotListIntent.ToggleFavorites -> _uiState.update { it.copy(showFavoritesOnly = intent.favoritesOnly) }
            TireSpotListIntent.ToggleFilterVisibility -> _uiState.update { it.copy(showFilters = !it.showFilters) }
            is TireSpotListIntent.ToggleFavorite -> toggleFavorite(intent.spotId)
            TireSpotListIntent.ClearError -> _uiState.update { it.copy(error = null) }
        }
    }

    private fun toggleFavorite(spotId: Long) {
        viewModelScope.launch {
            try {
                tireSpotRepository.toggleFavorite(spotId)
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message) }
            }
        }
    }

    private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}
