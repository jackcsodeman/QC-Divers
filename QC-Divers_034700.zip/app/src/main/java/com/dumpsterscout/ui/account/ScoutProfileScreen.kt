package com.dumpsterscout.ui.account

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.ScoutStats
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.theme.*

/**
 * Screen displaying the public profile and stats of a scout.
 * 
 * @param remoteUserId The ID of the scout to display.
 * @param onNavigateBack Callback for the back navigation action.
 * @param viewModel The view model managing the profile data.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScoutProfileScreen(
    remoteUserId: String,
    onNavigateBack: () -> Unit,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    LaunchedEffect(remoteUserId) {
        viewModel.loadProfile(remoteUserId)
    }

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = "Scout Profile",
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        }
    ) { padding ->
        when {
            uiState.isLoading -> {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            uiState.stats != null -> {
                ProfileContent(stats = uiState.stats!!, modifier = Modifier.padding(padding))
            }
            uiState.error != null -> {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    Text(uiState.error!!, color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

/**
 * Main scrollable content of the scout profile.
 * 
 * @param stats The scout's stats to display.
 * @param modifier Modifier for the layout.
 */
@Composable
private fun ProfileContent(stats: ScoutStats, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(DsSpacing.l),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(DsSpacing.xl)
    ) {
        // Avatar/Header
        Box(
            modifier = Modifier
                .size(100.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(NeonCyan, NeonMagenta))),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = stats.rankTitle.take(1),
                style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = stats.rankTitle,
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "Scout ID: ${stats.remoteUserId.take(8)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Stats Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            StatCard(
                label = "Verified",
                value = stats.spotsVerified.toString(),
                icon = Icons.Default.VerifiedUser,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                label = "Hauls",
                value = stats.haulsReported.toString(),
                icon = Icons.Default.Star,
                modifier = Modifier.weight(1f)
            )
        }

        // Trust Score
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ScoutSurface2)
        ) {
            Column(Modifier.padding(DsSpacing.l), verticalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                Text("Community Trust Score", style = MaterialTheme.typography.titleSmall)
                LinearProgressIndicator(
                    progress = { stats.trustScore / 100f },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                    color = if (stats.trustScore >= 70) ScoutGreenBright else ScoutAmber
                )
                Text(
                    text = "${stats.trustScore}% Reliable",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}

/**
 * Small card displaying a single metric with an icon.
 * 
 * @param label The name of the metric.
 * @param value The value of the metric.
 * @param icon The icon to display.
 * @param modifier Modifier for the layout.
 */
@Composable
private fun StatCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2)
    ) {
        Column(
            modifier = Modifier.padding(DsSpacing.l),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(DsSpacing.xs)
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Text(value, style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold))
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
