package com.dumpsterscout.ui.map

import android.Manifest
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AddLocation
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocationOff
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.TireRepair
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.ui.community.CommunityViewModel
import com.dumpsterscout.ui.components.DsSegmentedToggle
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.EmptyStatePanel
import com.dumpsterscout.ui.components.LoadingShimmerCard
import com.dumpsterscout.ui.theme.DsEasing
import com.dumpsterscout.ui.theme.DsElevation
import com.dumpsterscout.ui.theme.DsMotion
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.DumpsterScoutTheme
import com.dumpsterscout.ui.theme.ScoutSurface2
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.CameraPositionState
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import kotlinx.coroutines.launch

private const val MAX_RENDERED_MAP_MARKERS = 500

private enum class MapViewMode { MAP, LIST }
private enum class MapTypeFilter { ALL, DUMPSTER, TIRE, FIELD }

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun MapScreen(
    onNavigateBack: () -> Unit,
    onNavigateToSpotDetail: (Long) -> Unit,
    onNavigateToTireSpotDetail: (Long) -> Unit,
    onNavigateToFieldLocations: () -> Unit,
    onNavigateToAddSpot: () -> Unit,
    onNavigateToCommunitySpotDetail: (String) -> Unit,
    onNavigateToCommunityTireSpotDetail: (String) -> Unit,
    viewModel: MapViewModel = hiltViewModel(),
    communityViewModel: CommunityViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val locationPermission = rememberPermissionState(Manifest.permission.ACCESS_FINE_LOCATION)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()


    var viewMode by remember { mutableStateOf(MapViewMode.MAP) }
    var selectedLocation by remember { mutableStateOf<MapLocationItem?>(null) }
    var filter by remember { mutableStateOf(MapTypeFilter.ALL) }

    val defaultPosition = LatLng(41.5208, -90.5718)
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(defaultPosition, 12f)
    }

    val displayedLocations = remember(uiState.locations, filter) {
        when (filter) {
            MapTypeFilter.ALL -> uiState.locations
            MapTypeFilter.DUMPSTER -> uiState.locations.filter { it.type == MapLocationType.DUMPSTER }
            MapTypeFilter.TIRE -> uiState.locations.filter { it.type == MapLocationType.TIRE }
            MapTypeFilter.FIELD -> uiState.locations.filter { it.type == MapLocationType.FIELD }
        }
    }

    fun openLocation(location: MapLocationItem) {
        when (location.type) {
            MapLocationType.DUMPSTER -> onNavigateToSpotDetail(location.localId)
            MapLocationType.TIRE -> onNavigateToTireSpotDetail(location.localId)
            MapLocationType.FIELD -> onNavigateToFieldLocations()
        }
    }

    fun openExternalNavigation(location: MapLocationItem) {
        if (!location.hasCoordinates) return
        val encodedName = Uri.encode(location.name)
        val uri = Uri.parse("geo:${location.latitude},${location.longitude}?q=${location.latitude},${location.longitude}($encodedName)")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        runCatching { context.startActivity(intent) }
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.map_title),
                subtitle = stringResource(R.string.locations_count_title, displayedLocations.size),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToAddSpot) {
                        Icon(Icons.Default.AddLocation, stringResource(R.string.cd_add_button))
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            AnimatedContent(
                targetState = viewMode,
                transitionSpec = {
                    fadeIn(tween(DsMotion.medium, easing = DsEasing.emphasizedDecelerate)) togetherWith
                        fadeOut(tween(DsMotion.exit, easing = DsEasing.emphasizedAccelerate))
                },
                label = "map_list_toggle"
            ) { mode ->
                when (mode) {
                    MapViewMode.MAP -> MapContent(
                        locations = displayedLocations,
                        locationGranted = locationPermission.status.isGranted,
                        cameraPositionState = cameraPositionState,
                        selectedLocation = selectedLocation,
                        onMarkerClick = { selectedLocation = it },
                        modifier = Modifier.fillMaxSize()
                    )
                    MapViewMode.LIST -> ListContent(
                        locations = displayedLocations,
                        isLoading = uiState.isLoading,
                        onLocationClick = ::openLocation,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            DsSegmentedToggle(
                options = listOf(
                    Icons.Default.Map to stringResource(R.string.map_view),
                    Icons.AutoMirrored.Filled.List to stringResource(R.string.list_view)
                ),
                selectedIndex = if (viewMode == MapViewMode.MAP) 0 else 1,
                onSelect = { idx ->
                    viewMode = if (idx == 0) MapViewMode.MAP else MapViewMode.LIST
                    selectedLocation = null
                },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(end = DsSpacing.l, top = DsSpacing.s)
            )

            TypeFilterRow(
                selected = filter,
                onSelect = { filter = it; selectedLocation = null },
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(horizontal = DsSpacing.l, vertical = DsSpacing.s)
            )

            // Community & Stale Toggles
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = DsSpacing.l, top = 48.dp),
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                FilterChip(
                    selected = uiState.showCommunity,
                    onClick = { viewModel.onIntent(MapIntent.ToggleCommunity(!uiState.showCommunity)) },
                    label = { Text("Community", style = MaterialTheme.typography.labelSmall) },
                    leadingIcon = {
                        Icon(
                            Icons.Default.Public,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = if (uiState.showCommunity) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                )
                if (uiState.showCommunity) {
                    FilterChip(
                        selected = uiState.filterStaleCommunity,
                        onClick = { viewModel.onIntent(MapIntent.ToggleStaleFilter(!uiState.filterStaleCommunity)) },
                        label = { Text("Recent Only", style = MaterialTheme.typography.labelSmall) },
                        leadingIcon = {
                            Icon(
                                Icons.Default.History,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    )
                }
            }

            if (!locationPermission.status.isGranted) {

                LocationPermissionBanner(
                    onRequest = { locationPermission.launchPermissionRequest() },
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 56.dp, start = DsSpacing.l, end = DsSpacing.l)
                )
            }

            val coordinateCount = displayedLocations.count { it.hasCoordinates }
            if (viewMode == MapViewMode.MAP && coordinateCount > MAX_RENDERED_MAP_MARKERS) {
                MapDensityBanner(
                    total = coordinateCount,
                    rendered = MAX_RENDERED_MAP_MARKERS,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(DsSpacing.l)
                )
            }

            AnimatedVisibility(
                visible = viewMode == MapViewMode.MAP && selectedLocation != null,
                enter = slideInVertically { it } + fadeIn(tween(DsMotion.medium)),
                exit = slideOutVertically { it } + fadeOut(tween(DsMotion.exit)),
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                selectedLocation?.let { location ->
                    LocationPreviewCard(
                        location = location,
                        onView = {
                            if (!location.isCommunity) {
                                openLocation(location)
                            } else {
                                val remoteId = location.remoteId ?: return@LocationPreviewCard
                                when (location.type) {
                                    MapLocationType.DUMPSTER -> onNavigateToCommunitySpotDetail(remoteId)
                                    MapLocationType.TIRE -> onNavigateToCommunityTireSpotDetail(remoteId)
                                    MapLocationType.FIELD -> onNavigateToFieldLocations()
                                }
                            }
                        },
                        onImport = {
                            if (location.isCommunity) {
                                val commState = communityViewModel.uiState.value
                                when (location.type) {
                                    MapLocationType.DUMPSTER -> {
                                        val spot = commState.dumpsterSpots.find { it.remoteId == location.remoteId }
                                        if (spot != null) communityViewModel.importDumpsterSpot(spot)
                                    }
                                    MapLocationType.TIRE -> {
                                        val spot = commState.tireSpots.find { it.remoteId == location.remoteId }
                                        if (spot != null) communityViewModel.importTireSpot(spot)
                                    }
                                    else -> {}
                                }
                            }
                        },

                        onNavigate = { openExternalNavigation(location) },
                        onDismiss = { selectedLocation = null },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(DsSpacing.l)
                    )

                }
            }
        }
    }
}

@Composable
private fun MapContent(
    locations: List<MapLocationItem>,
    locationGranted: Boolean,
    cameraPositionState: CameraPositionState,
    selectedLocation: MapLocationItem?,
    onMarkerClick: (MapLocationItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val markerModels = remember(locations) {
        MapClusterer.buildMarkers(
            locations = locations,
            maxRenderedMarkers = MAX_RENDERED_MAP_MARKERS
        )
    }

    GoogleMap(
        modifier = modifier,
        cameraPositionState = cameraPositionState,
        properties = MapProperties(isMyLocationEnabled = locationGranted),
        uiSettings = MapUiSettings(
            myLocationButtonEnabled = locationGranted,
            zoomControlsEnabled = false
        )
    ) {
        markerModels.forEach { marker ->
            when (marker) {
                is MapMarkerUiModel.Single -> {
                    val location = marker.location
                    val selected = selectedLocation
                    val isSelected = selected != null && location.localId == selected.localId && location.type == selected.type
                    Marker(
                        state = remember(location.latitude, location.longitude) {
                            MarkerState(LatLng(location.latitude, location.longitude))
                        },
                        title = location.name,
                        snippet = location.subtitle,
                        icon = BitmapDescriptorFactory.defaultMarker(
                            if (isSelected) BitmapDescriptorFactory.HUE_YELLOW else location.type.markerHue()
                        ),
                        alpha = if (isSelected) 1f else 0.88f,
                        onClick = {
                            onMarkerClick(location)
                            false
                        }
                    )
                }
                is MapMarkerUiModel.Cluster -> {
                    Marker(
                        state = remember(marker.id, marker.latitude, marker.longitude) {
                            MarkerState(LatLng(marker.latitude, marker.longitude))
                        },
                        title = stringResource(R.string.map_cluster_title, marker.count),
                        snippet = stringResource(R.string.map_cluster_snippet),
                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE),
                        alpha = 0.78f
                    )
                }
            }
        }
    }
}

@Composable
private fun ListContent(
    locations: List<MapLocationItem>,
    isLoading: Boolean,
    onLocationClick: (MapLocationItem) -> Unit,
    modifier: Modifier = Modifier
) {
    when {
        isLoading -> LazyColumn(
            modifier = modifier.padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) { items(5) { LoadingShimmerCard() } }

        locations.isEmpty() -> EmptyStatePanel(
            message = stringResource(R.string.no_locations_match_filter),
            icon = Icons.Default.SearchOff,
            modifier = modifier
        )

        else -> LazyColumn(
            modifier = modifier,
            contentPadding = PaddingValues(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            items(locations, key = { "${it.type}:${it.localId}" }) { location ->
                MapLocationListCard(location = location, onClick = { onLocationClick(location) })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MapLocationListCard(location: MapLocationItem, onClick: () -> Unit) {
    val accent = location.type.accentColor()
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape = MaterialTheme.shapes.medium
    ) {
        Row {
            Box(
                Modifier
                    .width(4.dp)
                    .height(84.dp)
                    .background(accent)
            )
            Row(
                modifier = Modifier
                    .padding(DsSpacing.m)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                LocationTypeIcon(
                    type = location.type,
                    tint = accent,
                    contentDescription = stringResource(location.type.contentDescriptionRes())
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        location.name,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        location.subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = accent,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (location.address.isNotBlank()) {
                        Text(
                            location.address,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(DsSpacing.xs)
                ) {
                    AssistChip(onClick = {}, label = { Text(location.statusLabel.ifBlank { stringResource(R.string.status_unknown) }) })
                    if (location.isFavorite) {
                        Icon(Icons.Default.Favorite, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun LocationPreviewCard(
    location: MapLocationItem,
    onView: () -> Unit,
    onNavigate: () -> Unit,
    onDismiss: () -> Unit,
    onImport: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val accent = location.type.accentColor()
    Card(
        modifier = modifier,
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.sheet),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape = MaterialTheme.shapes.large
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .background(Brush.horizontalGradient(listOf(accent, accent.copy(alpha = 0.3f))))
            )
            Row(
                modifier = Modifier.padding(DsSpacing.l),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                LocationTypeIcon(
                    type = location.type,
                    tint = accent,
                    contentDescription = stringResource(location.type.contentDescriptionRes())
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(location.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(location.subtitle, style = MaterialTheme.typography.bodySmall, color = accent)
                    Spacer(Modifier.height(DsSpacing.xs))
                    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)) {
                        AssistChip(onClick = {}, label = { Text(location.visibility.lowercase().replace('_', ' ')) })
                        AssistChip(onClick = {}, label = { Text(location.syncStatus.lowercase().replace('_', ' ')) })
                    }
                }
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
                ) {
                    if (location.isCommunity) {
                        Button(
                            onClick = onImport,
                            contentPadding = PaddingValues(horizontal = DsSpacing.l, vertical = DsSpacing.s),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Icon(Icons.Default.SaveAlt, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(DsSpacing.xs))
                            Text("Save to My Spots")
                        }
                    }
                    Button(onClick = onView, contentPadding = PaddingValues(horizontal = DsSpacing.l, vertical = DsSpacing.s)) {
                        Icon(
                            Icons.AutoMirrored.Filled.OpenInNew,
                            contentDescription = stringResource(R.string.cd_view_location_named, location.name),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(DsSpacing.xs))
                        Text(stringResource(R.string.action_view))
                    }
                    OutlinedButton(
                        enabled = location.hasCoordinates,
                        onClick = onNavigate,
                        contentPadding = PaddingValues(horizontal = DsSpacing.l, vertical = DsSpacing.s)
                    ) {
                        Icon(
                            Icons.Default.Map,
                            contentDescription = stringResource(R.string.cd_navigate_to_location_named, location.name),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(DsSpacing.xs))
                        Text(stringResource(R.string.open_external_navigation))
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, stringResource(R.string.cd_dismiss_preview), modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}


@Composable
private fun TypeFilterRow(
    selected: MapTypeFilter,
    onSelect: (MapTypeFilter) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
    ) {
        MapTypeFilter.entries.forEach { filter ->
            val color = filter.accentColor()
            FilterChip(
                selected = selected == filter,
                onClick = { onSelect(filter) },
                label = { Text(stringResource(filter.labelRes()), style = MaterialTheme.typography.labelSmall) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = color.copy(alpha = 0.2f),
                    selectedLabelColor = color
                )
            )
        }
    }
}

@Composable
private fun MapDensityBanner(total: Int, rendered: Int, modifier: Modifier = Modifier) {
    Surface(
        color = MaterialTheme.colorScheme.tertiaryContainer,
        shape = MaterialTheme.shapes.medium,
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = stringResource(R.string.map_marker_limit_message, rendered, total),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onTertiaryContainer,
            modifier = Modifier.padding(DsSpacing.m)
        )
    }
}

@Composable
private fun LocationPermissionBanner(onRequest: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = MaterialTheme.shapes.medium,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(DsSpacing.m),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            Icon(
                Icons.Default.LocationOff,
                contentDescription = stringResource(R.string.cd_location_permission_needed),
                tint = MaterialTheme.colorScheme.secondary
            )
            Text(
                stringResource(R.string.enable_location_prompt),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onRequest) { Text(stringResource(R.string.allow)) }
        }
    }
}

@Composable
private fun LocationTypeIcon(
    type: MapLocationType,
    tint: Color,
    contentDescription: String?
) {
    Icon(
        imageVector = when (type) {
            MapLocationType.DUMPSTER -> Icons.Default.Place
            MapLocationType.TIRE -> Icons.Default.TireRepair
            MapLocationType.FIELD -> Icons.Default.CleaningServices
        },
        contentDescription = contentDescription,
        tint = tint,
        modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(tint.copy(alpha = 0.12f))
            .padding(8.dp)
    )
}

@Composable
private fun MapLocationType.accentColor(): Color = when (this) {
    MapLocationType.DUMPSTER -> MaterialTheme.colorScheme.primary
    MapLocationType.TIRE -> Color(0xFF8E7CFF)
    MapLocationType.FIELD -> Color(0xFF2E9E6F)
}

@Composable
private fun MapTypeFilter.accentColor(): Color = when (this) {
    MapTypeFilter.ALL -> MaterialTheme.colorScheme.primary
    MapTypeFilter.DUMPSTER -> MapLocationType.DUMPSTER.accentColor()
    MapTypeFilter.TIRE -> MapLocationType.TIRE.accentColor()
    MapTypeFilter.FIELD -> MapLocationType.FIELD.accentColor()
}

private fun MapLocationType.markerHue(): Float = when (this) {
    MapLocationType.DUMPSTER -> BitmapDescriptorFactory.HUE_GREEN
    MapLocationType.TIRE -> BitmapDescriptorFactory.HUE_VIOLET
    MapLocationType.FIELD -> BitmapDescriptorFactory.HUE_ORANGE
}

private fun MapTypeFilter.labelRes(): Int = when (this) {
    MapTypeFilter.ALL -> R.string.map_filter_all
    MapTypeFilter.DUMPSTER -> R.string.map_filter_dumpsters
    MapTypeFilter.TIRE -> R.string.map_filter_tires
    MapTypeFilter.FIELD -> R.string.map_filter_field_sites
}

private fun MapLocationType.contentDescriptionRes(): Int = when (this) {
    MapLocationType.DUMPSTER -> R.string.cd_map_location_type_dumpster
    MapLocationType.TIRE -> R.string.cd_map_location_type_tire
    MapLocationType.FIELD -> R.string.cd_map_location_type_field
}

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "Map location preview dark")
@Composable
private fun LocationPreviewCardPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        LocationPreviewCard(
            location = MapLocationItem(
                localId = 1,
                type = MapLocationType.FIELD,
                name = "River cleanup pile",
                subtitle = "Cleanup Site",
                address = "Davenport riverfront",
                latitude = 41.52,
                longitude = -90.57,
                statusLabel = "high",
                isFavorite = true,
                syncStatus = "LOCAL_ONLY",
                visibility = "PRIVATE"
            ),
            onView = {},
            onNavigate = {},
            onDismiss = {},
            modifier = Modifier.padding(16.dp)
        )
    }
}
