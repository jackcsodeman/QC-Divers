package com.dumpsterscout.ui.tire

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.domain.model.Visibility
import com.dumpsterscout.ui.components.ConditionTag
import com.dumpsterscout.ui.components.DeleteConfirmDialog
import com.dumpsterscout.ui.components.DetailCard
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.EmptyStatePanel
import com.dumpsterscout.ui.components.InfoRow
import com.dumpsterscout.ui.components.LoadingShimmerCard
import com.dumpsterscout.ui.components.RiskBanner
import com.dumpsterscout.ui.components.SectionHeader
import com.dumpsterscout.ui.components.SpotStatChip
import com.dumpsterscout.ui.photos.PhotoAttachmentSection
import com.dumpsterscout.ui.photos.SpotPhotoViewModel
import com.dumpsterscout.ui.photos.createFieldPhotoUri
import com.dumpsterscout.ui.theme.DsElevation
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.ScoutSurface2
import com.dumpsterscout.ui.theme.accentHeaderBrush
import com.dumpsterscout.util.timeAgoString
import kotlinx.coroutines.launch

/**
 * Screen displaying the full details of a specific tire spot.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TireSpotDetailScreen(
    spotId: Long,
    onNavigateBack: () -> Unit,
    onNavigateToEdit: (Long) -> Unit,
    onNavigateToTireReport: (Long) -> Unit,
    onNavigateToTireVoiceReport: (Long) -> Unit = {},
    viewModel: TireSpotDetailViewModel = hiltViewModel(),
    photoViewModel: SpotPhotoViewModel = hiltViewModel()
) {
    LaunchedEffect(spotId) {
        viewModel.onIntent(TireSpotDetailIntent.Load(spotId))
        photoViewModel.loadOwner("TIRE_SPOT", spotId)
    }

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val photoState by photoViewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val permissionDeniedMessage = stringResource(R.string.photo_camera_permission_denied)
    val scope = rememberCoroutineScope()
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }

    val takePhotoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val capturedUri = pendingCameraUri
        pendingCameraUri = null
        if (success && capturedUri != null) photoViewModel.addPhoto(capturedUri.toString())
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val uri = createFieldPhotoUri(context)
            pendingCameraUri = uri
            takePhotoLauncher.launch(uri)
        } else {
            scope.launch { snackbarHostState.showSnackbar(permissionDeniedMessage) }
        }
    }
    val pickPhotoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) photoViewModel.addPhoto(uri.toString())
    }

    // Navigate back only after confirmed deletion
    LaunchedEffect(uiState.isDeleted) {
        if (uiState.isDeleted) onNavigateBack()
    }

    // Surface ViewModel errors through the snackbar
    LaunchedEffect(uiState.error) {
        uiState.error?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.onIntent(TireSpotDetailIntent.ClearError)
        }
    }

    LaunchedEffect(photoState.error) {
        photoState.error?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            photoViewModel.clearError()
        }
    }
    val photoAddedMsg = stringResource(R.string.msg_photo_attached)
    LaunchedEffect(photoState.lastAddedPhotoId) {
        if (photoState.lastAddedPhotoId != null) {
            snackbarHostState.showSnackbar(photoAddedMsg)
            photoViewModel.clearLastAdded()
        }
    }

    val tirePublishedMsg = stringResource(R.string.msg_tire_spot_published)
    LaunchedEffect(uiState.publishedSuccessfully) {
        if (uiState.publishedSuccessfully) {
            snackbarHostState.showSnackbar(tirePublishedMsg)
            viewModel.onIntent(TireSpotDetailIntent.ClearPublishedFlag)
        }
    }

    if (uiState.showDeleteDialog) {
        DeleteConfirmDialog(
            title     = stringResource(R.string.confirm_delete_title),
            message   = stringResource(R.string.confirm_delete_message),
            onConfirm = { viewModel.onIntent(TireSpotDetailIntent.ShowDeleteDialog(false)); viewModel.onIntent(TireSpotDetailIntent.DeleteSpot) },
            onDismiss = { viewModel.onIntent(TireSpotDetailIntent.ShowDeleteDialog(false)) }
        )
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = uiState.spot?.name ?: stringResource(R.string.spot_detail_title),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                },
                actions = {
                    uiState.spot?.let { spot ->
                        IconButton(onClick = { viewModel.onIntent(TireSpotDetailIntent.ToggleFavorite) }) {
                            Icon(
                                if (spot.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = stringResource(R.string.cd_favorite_button, spot.name),
                                tint = if (spot.isFavorite) MaterialTheme.colorScheme.primary
                                       else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { onNavigateToEdit(spot.id) }) {
                            Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.cd_edit_spot))
                        }
                        IconButton(onClick = { viewModel.onIntent(TireSpotDetailIntent.ShowDeleteDialog(true)) }) {
                            Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.cd_delete_spot), tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            uiState.spot?.let { spot ->
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
                ) {
                    SmallFloatingActionButton(
                        onClick        = { onNavigateToTireVoiceReport(spot.id) },
                        containerColor = MaterialTheme.colorScheme.secondary,
                        contentColor   = MaterialTheme.colorScheme.onSecondary
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = stringResource(R.string.tire_voice_title))
                    }
                    FloatingActionButton(
                        onClick        = { onNavigateToTireReport(spot.id) },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor   = MaterialTheme.colorScheme.onPrimary
                    ) {
                        Icon(Icons.Default.Add, contentDescription = stringResource(R.string.tire_report_title))
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        when {
            uiState.isLoading -> {
                Column(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(DsSpacing.l),
                    verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
                ) { repeat(4) { LoadingShimmerCard() } }
            }
            uiState.spot == null -> {
                EmptyStatePanel(
                    message  = stringResource(R.string.spot_not_found),
                    icon     = Icons.Default.Warning,
                    modifier = Modifier.fillMaxSize().padding(padding)
                )
            }
            else -> {
                val spot = uiState.spot!!
                LazyColumn(
                    contentPadding      = PaddingValues(horizontal = DsSpacing.l, vertical = DsSpacing.s),
                    verticalArrangement = Arrangement.spacedBy(DsSpacing.m),
                    modifier            = Modifier.padding(padding)
                ) {
                    // Risk banner
                    if (spot.hasCameras || spot.securityCommon || spot.isLocked) {
                        item {
                            val riskFlags = buildList {
                                if (spot.hasCameras)     add(stringResource(R.string.risk_cameras_present))
                                if (spot.securityCommon) add(stringResource(R.string.risk_security_patrols))
                                if (spot.isLocked)       add(stringResource(R.string.risk_dumpster_locked))
                            }
                            RiskBanner(risks = riskFlags)
                        }
                    }

                    // Header card
                    item { TireSpotHeaderCard(spot) }

                    // Sync / visibility status row
                    item {
                        TireSyncStatusRow(
                            syncStatus  = spot.syncStatus,
                            visibility  = spot.visibility,
                            isOwner     = uiState.isOwner,
                            onPublish   = { viewModel.onIntent(TireSpotDetailIntent.PublishToCommunity) },
                            onRetrySync = { viewModel.onIntent(TireSpotDetailIntent.RetrySync) }
                        )
                    }

                    // Quick status update
                    item { TireQuickStatusRow(spot, onStatusSelect = { viewModel.onIntent(TireSpotDetailIntent.UpdateStatus(it)) }) }

                    // Access info
                    if (spot.accessNotes.isNotBlank() || spot.isFenced || spot.isGated || spot.isExposed) {
                        item { TireAccessSection(spot) }
                    }

                    // Timing section
                    item { TireTimingSection(spot) }

                    // Pattern insights
                    item { TirePatternSection(spot) }

                    // Notes
                    if (spot.notes.isNotBlank()) {
                        item { TireNotesSection(spot.notes) }
                    }

                    // Tags
                    if (spot.tags.isNotEmpty()) {
                        item { TireTagsRow(spot.tags) }
                    }

                    item {
                        PhotoAttachmentSection(
                            title = stringResource(R.string.photo_section_tire),
                            photos = photoState.photos,
                            onTakePhoto = {
                                if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                    val uri = createFieldPhotoUri(context)
                                    pendingCameraUri = uri
                                    takePhotoLauncher.launch(uri)
                                } else {
                                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                }
                            },
                            onPickPhoto = { pickPhotoLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            onDeletePhoto = { photoViewModel.deletePhoto(it) }
                        )
                    }

                    // Recent reports
                    if (uiState.reports.isNotEmpty()) {
                        item {
                            SectionHeader(title = stringResource(R.string.section_recent_reports))
                        }
                        items(uiState.reports.take(5), key = { it.id }) { report ->
                            TireReportSummaryCard(report)
                        }
                    }

                    item { Spacer(Modifier.height(DsSpacing.giant + DsSpacing.l)) }
                }
            }
        }
    }
}

@Composable
private fun TireSpotHeaderCard(spot: TireSpot) {
    val accentColor = tireCategoryColor(spot.category)
    Card(
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.medium
    ) {
        Box {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .background(accentHeaderBrush(accentColor))
            )
            Column(modifier = Modifier.padding(DsSpacing.l)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(DsSpacing.s),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TireStatusChip(status = spot.lastStatus)
                    if (spot.isVerified) {
                        SuggestionChip(onClick = {}, label = { Text(stringResource(R.string.condition_verified), style = MaterialTheme.typography.labelSmall) })
                    }
                    if (spot.isRetired) {
                        SuggestionChip(onClick = {}, label = { Text(stringResource(R.string.condition_retired), style = MaterialTheme.typography.labelSmall) })
                    }
                }
                if (spot.address.isNotBlank()) {
                    Spacer(Modifier.height(DsSpacing.s))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.width(DsSpacing.xs))
                        Text(spot.address, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                spot.lastChecked?.let { ts ->
                    Spacer(Modifier.height(DsSpacing.xs))
                    Text(
                        stringResource(R.string.checked_time_ago, timeAgoString(ts)),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(DsSpacing.s))
                Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                    SpotStatChip(
                        icon  = Icons.Default.Build,
                        value = spot.category.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() },
                        label = stringResource(R.string.tire_spot_category_label),
                        color = accentColor
                    )
                    SpotStatChip(
                        icon  = Icons.Default.Warning,
                        value = spot.puncturePattern.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() },
                        label = stringResource(R.string.tire_label_puncture_pattern),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun TireQuickStatusRow(
    spot: TireSpot,
    onStatusSelect: (TireSpotStatus) -> Unit
) {
    val quickStatuses = listOf(
        TireSpotStatus.GOOD_USABLE,
        TireSpotStatus.MANY_OUT,
        TireSpotStatus.ALL_PUNCTURED,
        TireSpotStatus.NO_TIRES,
        TireSpotStatus.LOCKED_INACCESSIBLE,
        TireSpotStatus.ALREADY_PICKED
    )
    DetailCard(title = stringResource(R.string.section_quick_update)) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs),
            modifier = Modifier.fillMaxWidth()
        ) {
            quickStatuses.take(3).forEach { status ->
                TireStatusChip(
                    status  = status,
                    onClick = { onStatusSelect(status) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
        Spacer(Modifier.height(DsSpacing.xs))
        Row(
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs),
            modifier = Modifier.fillMaxWidth()
        ) {
            quickStatuses.drop(3).forEach { status ->
                TireStatusChip(
                    status  = status,
                    onClick = { onStatusSelect(status) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun TireAccessSection(spot: TireSpot) {
    DetailCard(title = stringResource(R.string.section_access)) {
        if (spot.accessNotes.isNotBlank()) {
            Text(spot.accessNotes, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(DsSpacing.s))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)) {
            if (spot.isFenced)  ConditionTag(stringResource(R.string.condition_fenced))
            if (spot.isGated)   ConditionTag(stringResource(R.string.condition_gated))
            if (spot.isLocked)  ConditionTag(stringResource(R.string.condition_locked))
            if (spot.isExposed) ConditionTag(stringResource(R.string.tire_condition_exposed))
        }
    }
}

@Composable
private fun TireTimingSection(spot: TireSpot) {
    DetailCard(title = stringResource(R.string.section_pickup_schedule)) {
        InfoRow(
            label = stringResource(R.string.label_best_time),
            value = spot.bestTimeOfDay.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }
        )
        if (spot.bestDays.isNotBlank()) {
            InfoRow(label = stringResource(R.string.label_days), value = spot.bestDays)
        }
        if (spot.isSeasonal) {
            InfoRow(
                label = stringResource(R.string.tire_label_season),
                value = spot.season.name.lowercase().replaceFirstChar { it.uppercaseChar() }
            )
        }
        if (spot.putsOutAroundClosing) {
            Text(
                stringResource(R.string.tire_puts_out_around_closing),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun TirePatternSection(spot: TireSpot) {
    DetailCard(title = stringResource(R.string.section_tire_patterns)) {
        val flags = buildList {
            if (spot.usableDisappearFast)  add(stringResource(R.string.tire_label_usable_disappear_fast))
            if (spot.othersGetThereFirst)  add(stringResource(R.string.tire_label_others_first))
            if (spot.worthCheckingWhenLight) add(stringResource(R.string.tire_label_worth_light))
            if (spot.usuallyPutsOutMany)   add(stringResource(R.string.tire_label_usually_many))
        }
        if (flags.isEmpty()) {
            Text(
                stringResource(R.string.tire_no_patterns_noted),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            flags.forEach { flag ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(DsSpacing.s))
                    Text(flag, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun TireNotesSection(notes: String) {
    DetailCard(title = stringResource(R.string.section_personal_notes)) {
        Text(notes, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun TireTagsRow(tags: List<String>) {
    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)) {
        tags.forEach { tag ->
            SuggestionChip(
                onClick = {},
                label   = { Text(tag, style = MaterialTheme.typography.labelSmall) }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TireReportSummaryCard(report: TireReport) {
    Card(
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.subtle),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.small
    ) {
        Row(
            modifier          = Modifier.padding(DsSpacing.m),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TireStatusChip(status = report.status)
            Spacer(Modifier.width(DsSpacing.s))
            if (report.estimatedCount > 0) {
                Text(pluralStringResource(R.plurals.tire_summary_count, report.estimatedCount, report.estimatedCount), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(DsSpacing.s))
            }
            Spacer(Modifier.weight(1f))
            Text(timeAgoString(report.timestamp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (report.notes.isNotBlank()) {
            Text(
                report.notes,
                style    = MaterialTheme.typography.bodySmall,
                color    = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                modifier = Modifier.padding(start = DsSpacing.m, end = DsSpacing.m, bottom = DsSpacing.s)
            )
        }
    }
}

// ── TireSyncStatusRow ─────────────────────────────────────────────────────────

@Composable
private fun TireSyncStatusRow(
    syncStatus: SyncStatus,
    visibility: Visibility,
    isOwner: Boolean,
    onPublish: () -> Unit,
    onRetrySync: () -> Unit,
    modifier: Modifier = Modifier
) {
    val syncColor = when (syncStatus) {
        SyncStatus.SYNCED       -> MaterialTheme.colorScheme.primary
        SyncStatus.PENDING_SYNC -> MaterialTheme.colorScheme.tertiary
        SyncStatus.SYNC_FAILED  -> MaterialTheme.colorScheme.error
        SyncStatus.CONFLICT     -> MaterialTheme.colorScheme.error
        SyncStatus.LOCAL_ONLY   -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    val syncLabel = when (syncStatus) {
        SyncStatus.SYNCED       -> stringResource(R.string.sync_status_synced)
        SyncStatus.PENDING_SYNC -> stringResource(R.string.sync_status_pending)
        SyncStatus.SYNC_FAILED  -> stringResource(R.string.sync_status_failed)
        SyncStatus.CONFLICT     -> stringResource(R.string.sync_status_conflict)
        SyncStatus.LOCAL_ONLY   -> stringResource(R.string.sync_status_local_only)
    }
    val visibilityLabel = when (visibility) {
        Visibility.PRIVATE   -> stringResource(R.string.visibility_private)
        Visibility.COMMUNITY -> stringResource(R.string.visibility_community)
        Visibility.PUBLIC    -> stringResource(R.string.visibility_public)
    }
    val visibilityIcon = when (visibility) {
        Visibility.PRIVATE   -> Icons.Default.Lock
        Visibility.COMMUNITY -> Icons.Default.People
        Visibility.PUBLIC    -> Icons.Default.Public
    }
    val showPublish = isOwner && visibility == Visibility.PRIVATE &&
            syncStatus != SyncStatus.PENDING_SYNC &&
            syncStatus != SyncStatus.SYNC_FAILED &&
            syncStatus != SyncStatus.CONFLICT

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s),
        modifier = modifier.fillMaxWidth()
    ) {
        AssistChip(
            onClick = {},
            label   = { Text(syncLabel, style = MaterialTheme.typography.labelSmall) },
            leadingIcon = {
                Icon(
                    imageVector        = Icons.Default.CloudSync,
                    contentDescription = null,
                    modifier           = Modifier.size(16.dp),
                    tint               = syncColor
                )
            }
        )
        AssistChip(
            onClick = {},
            label   = { Text(visibilityLabel, style = MaterialTheme.typography.labelSmall) },
            leadingIcon = {
                Icon(
                    imageVector        = visibilityIcon,
                    contentDescription = null,
                    modifier           = Modifier.size(16.dp)
                )
            }
        )
        Spacer(Modifier.weight(1f))
        if (syncStatus == SyncStatus.SYNC_FAILED || syncStatus == SyncStatus.CONFLICT) {
            OutlinedButton(
                onClick = onRetrySync,
                colors  = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) {
                Text(stringResource(R.string.sync_retry_button), style = MaterialTheme.typography.labelMedium)
            }
        } else if (showPublish) {
            OutlinedButton(onClick = onPublish) {
                Text(stringResource(R.string.publish_spot_button), style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}
