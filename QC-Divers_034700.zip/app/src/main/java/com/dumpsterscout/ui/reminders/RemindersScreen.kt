package com.dumpsterscout.ui.reminders

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddAlarm
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.data.local.entity.ReminderEntity
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.EmptyStatePanel
import com.dumpsterscout.ui.theme.DsElevation
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.ScoutSurface2
import java.text.DateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RemindersScreen(
    onNavigateBack: () -> Unit,
    viewModel: RemindersViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var showAddDialog by remember { mutableStateOf(false) }
    var editingReminder by remember { mutableStateOf<ReminderEntity?>(null) }
    val context = LocalContext.current
    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        showAddDialog = true
    }

    LaunchedEffect(uiState.error) {
        uiState.error?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearError()
        }
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.reminders_title),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                if (Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    showAddDialog = true
                }
            }) {
                Icon(Icons.Default.AddAlarm, contentDescription = stringResource(R.string.reminder_add))
            }
        }
    ) { padding ->
        if (uiState.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (uiState.reminders.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                EmptyStatePanel(message = stringResource(R.string.reminders_empty))
            }
        } else {
            val spotsById = uiState.spots.associateBy { it.id }
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(DsSpacing.l),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                items(uiState.reminders, key = { it.id }) { reminder ->
                    ReminderCard(
                        reminder = reminder,
                        spotName = spotsById[reminder.spotId]?.name ?: stringResource(R.string.reminder_unknown_spot),
                        onActiveChanged = { active -> viewModel.setActive(reminder, active) },
                        onEdit = { editingReminder = reminder },
                        onComplete = { viewModel.complete(reminder) },
                        onSnooze = { viewModel.snooze(reminder) },
                        onDelete = { viewModel.delete(reminder) }
                    )
                }
                item { Spacer(Modifier.height(DsSpacing.giant)) }
            }
        }
    }

    if (showAddDialog) {
        AddReminderDialog(
            spots = uiState.spots,
            onDismiss = { showAddDialog = false },
            onSave = { spotId, label, day, hour, minute ->
                viewModel.addReminder(spotId, label, day, hour, minute)
                showAddDialog = false
            }
        )
    }

    editingReminder?.let { reminder ->
        AddReminderDialog(
            spots = uiState.spots,
            existing = reminder,
            onDismiss = { editingReminder = null },
            onSave = { _, label, day, hour, minute ->
                viewModel.updateReminder(reminder, label, day, hour, minute)
                editingReminder = null
            }
        )
    }
}

@Composable
private fun ReminderCard(
    reminder: ReminderEntity,
    spotName: String,
    onActiveChanged: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onComplete: () -> Unit,
    onSnooze: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.subtle)
    ) {
        Row(
            modifier = Modifier.padding(DsSpacing.m),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            Icon(Icons.Default.Alarm, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = reminder.label.ifBlank { stringResource(R.string.reminder_default_label) },
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = spotName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = scheduleLabel(reminder),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                reminderStatusLabel(reminder)?.let { status ->
                    Text(
                        text = status,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
            IconButton(onClick = onEdit) {
                Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.reminder_edit_cd, reminder.label.ifBlank { spotName }))
            }
            IconButton(onClick = onSnooze) {
                Icon(Icons.Default.Alarm, contentDescription = stringResource(R.string.reminder_snooze_cd, reminder.label.ifBlank { spotName }))
            }
            IconButton(onClick = onComplete) {
                Icon(Icons.Default.CheckCircle, contentDescription = stringResource(R.string.reminder_complete_cd, reminder.label.ifBlank { spotName }))
            }
            Switch(checked = reminder.isActive && reminder.completedAt == null, onCheckedChange = onActiveChanged)
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.reminder_delete), tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun AddReminderDialog(
    spots: List<DumpsterSpot>,
    existing: ReminderEntity? = null,
    onDismiss: () -> Unit,
    onSave: (Long, String, Int, Int, Int) -> Unit
) {
    var selectedSpotId by remember(spots, existing?.id) { mutableLongStateOf(existing?.spotId ?: spots.firstOrNull()?.id ?: 0L) }
    var expanded by remember { mutableStateOf(false) }
    var label by remember(existing?.id) { mutableStateOf(existing?.label.orEmpty()) }
    var hourText by remember(existing?.id) { mutableStateOf(existing?.timeHour?.toString() ?: "20") }
    var minuteText by remember(existing?.id) { mutableStateOf(existing?.timeMinute?.toString()?.padStart(2, '0') ?: "00") }
    var dayOfWeek by remember(existing?.id) { mutableIntStateOf(existing?.dayOfWeek ?: 0) }
    val selectedSpot = spots.firstOrNull { it.id == selectedSpotId }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(if (existing == null) R.string.reminder_add_title else R.string.reminder_edit)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(DsSpacing.m)) {
                Box {
                    OutlinedButton(onClick = { if (existing == null) expanded = true }, modifier = Modifier.fillMaxWidth(), enabled = existing == null) {
                        Text(
                            text = selectedSpot?.name ?: stringResource(R.string.reminder_choose_spot),
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null)
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        spots.forEach { spot ->
                            DropdownMenuItem(
                                text = { Text(spot.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                onClick = {
                                    selectedSpotId = spot.id
                                    expanded = false
                                }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text(stringResource(R.string.reminder_label)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                    OutlinedTextField(
                        value = hourText,
                        onValueChange = { hourText = it.filter(Char::isDigit).take(2) },
                        label = { Text(stringResource(R.string.reminder_hour)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minuteText,
                        onValueChange = { minuteText = it.filter(Char::isDigit).take(2) },
                        label = { Text(stringResource(R.string.reminder_minute)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)) {
                    items(dayOptions()) { option ->
                        AssistChip(
                            onClick = { dayOfWeek = option.first },
                            label = { Text(option.second) },
                            leadingIcon = if (dayOfWeek == option.first) {
                                { Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(14.dp)) }
                            } else null
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = selectedSpotId > 0L,
                onClick = {
                    onSave(
                        selectedSpotId,
                        label,
                        dayOfWeek,
                        hourText.toIntOrNull()?.coerceIn(0, 23) ?: 20,
                        minuteText.toIntOrNull()?.coerceIn(0, 59) ?: 0
                    )
                }
            ) { Text(stringResource(R.string.save)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    )
}

private fun scheduleLabel(reminder: ReminderEntity): String {
    val time = String.format(Locale.US, "%02d:%02d", reminder.timeHour, reminder.timeMinute)
    val day = dayOptions().firstOrNull { it.first == reminder.dayOfWeek }?.second ?: "One-time"
    return "$day · $time"
}


@Composable
private fun reminderStatusLabel(reminder: ReminderEntity): String? = when {
    reminder.completedAt != null -> stringResource(R.string.reminder_completed)
    reminder.snoozedUntil != null -> stringResource(
        R.string.reminder_snoozed_until,
        DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(reminder.snoozedUntil))
    )
    else -> null
}

private fun dayOptions(): List<Pair<Int, String>> = listOf(
    0 to "One-time",
    1 to "Sun",
    2 to "Mon",
    3 to "Tue",
    4 to "Wed",
    5 to "Thu",
    6 to "Fri",
    7 to "Sat"
)
