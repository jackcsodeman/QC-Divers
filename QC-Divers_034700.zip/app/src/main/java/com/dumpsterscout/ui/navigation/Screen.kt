package com.dumpsterscout.ui.navigation

import android.net.Uri
import com.dumpsterscout.domain.model.SpotStatus

/**
 * All navigation destinations in the app.
 */
sealed class Screen(val route: String) {
    data object Onboarding : Screen("onboarding")
    data object Home : Screen("home")
    data object SpotList : Screen("spot_list")
    
    data object AddSpot : Screen("add_spot?spotId={spotId}&name={name}&address={address}&status={status}") {
        fun createRoute(
            spotId: Long? = null,
            name: String? = null,
            address: String? = null,
            status: SpotStatus? = null
        ): String {
            val builder = StringBuilder("add_spot?")
            if (spotId != null) builder.append("spotId=$spotId&")
            if (name != null) builder.append("name=${Uri.encode(name)}&")
            if (address != null) builder.append("address=${Uri.encode(address)}&")
            if (status != null) builder.append("status=${status.name}&")
            return builder.toString().trimEnd('&', '?')
        }
    }

    data object SpotDetail : Screen("spot_detail/{spotId}") {
        fun createRoute(spotId: Long): String = "spot_detail/$spotId"
    }
    data object VoiceReport : Screen("voice_report")
    data object Map : Screen("map")
    data object History : Screen("history")
    data object Settings : Screen("settings")
    data object SyncStatus : Screen("sync_status")
    data object ConflictResolution : Screen("conflict_resolution")
    data object GearChecklist : Screen("gear_checklist")
    data object Reminders : Screen("reminders")
    data object FieldLocations : Screen("field_locations")
    data object Collections : Screen("collections")
    data object FieldSessions : Screen("field_sessions")
    data object Analytics : Screen("analytics")
    data object Favorites : Screen("favorites")
    data object SavedRoutes : Screen("saved_routes")
    data object FieldMode : Screen("field_mode")
    data object About : Screen("about")

    // ── Community ─────────────────────────────────────────────────────────────
    data object CommunitySpotDetail : Screen("community_spot_detail/{remoteId}") {
        fun createRoute(remoteId: String): String = "community_spot_detail/$remoteId"
    }
    data object CommunityTireSpotDetail : Screen("community_tire_spot_detail/{remoteId}") {
        fun createRoute(remoteId: String): String = "community_tire_spot_detail/$remoteId"
    }

    // ── Tire Spots ────────────────────────────────────────────────────────────
    data object TireSpotList : Screen("tire_spot_list")
    data object AddTireSpot : Screen("add_tire_spot?tireSpotId={tireSpotId}") {
        fun createRoute(tireSpotId: Long? = null): String =
            if (tireSpotId != null) "add_tire_spot?tireSpotId=$tireSpotId" else "add_tire_spot"
    }
    data object TireSpotDetail : Screen("tire_spot_detail/{tireSpotId}") {
        fun createRoute(tireSpotId: Long): String = "tire_spot_detail/$tireSpotId"
    }
    data object TireReport : Screen("tire_report?tireSpotId={tireSpotId}") {
        fun createRoute(tireSpotId: Long? = null): String =
            if (tireSpotId != null) "tire_report?tireSpotId=$tireSpotId" else "tire_report"
    }
    data object TireHistory : Screen("tire_history")
    data object TireVoiceReport : Screen("tire_voice_report?tireSpotId={tireSpotId}") {
        fun createRoute(tireSpotId: Long? = null): String =
            if (tireSpotId != null) "tire_voice_report?tireSpotId=$tireSpotId" else "tire_voice_report"
    }

    // ── Account ───────────────────────────────────────────────────────────────
    data object Account : Screen("account")
    data object OAuthConsent : Screen("oauth/consent")
    data object ScoutProfile : Screen("scout_profile/{remoteUserId}") {
        fun createRoute(remoteUserId: String): String = "scout_profile/$remoteUserId"
    }
}
