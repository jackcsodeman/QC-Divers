package com.dumpsterscout.ui.conflicts

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.longOrNull

/** Parses sync queue payload snapshots into safe user-reviewable conflict fields. */
object ConflictPayloadParser {
    private val hiddenPayloadFields = setOf(
        "remoteUrl",
        "ownerUserId",
        "ownerId",
        "localUri",
        "storagePath",
        "storage_path",
        "accessToken",
        "refreshToken",
        "token",
        "anonKey",
        "serviceRoleKey"
    )

    private val sensitivePayloadFields = setOf(
        "latitude",
        "longitude",
        "lat",
        "lng",
        "localUri",
        "remoteUrl",
        "uri",
        "storagePath",
        "storage_path"
    )

    fun parse(payload: String, remotePayload: String? = null): ConflictParsedPayload {
        if (payload.isBlank() && remotePayload.isNullOrBlank()) {
            return ConflictParsedPayload(emptyList(), hasRemoteSnapshot = false)
        }
        return runCatching {
            val localRoot = payload.toJsonObjectOrNull().orEmptyObject()
            val inlineRemote = localRoot["remote"]?.jsonObject
            val localObject = localRoot["local"]?.jsonObject
                ?: localRoot["route"]?.jsonObject
                ?: localRoot["collection"]?.jsonObject
                ?: localRoot["session"]?.jsonObject
                ?: localRoot["reminder"]?.jsonObject
                ?: localRoot["gearChecklist"]?.jsonObject
                ?: localRoot
            val remoteObject = inlineRemote ?: remotePayload.toJsonObjectOrNull()
            ConflictParsedPayload(
                fields = compare(localObject, remoteObject),
                hasRemoteSnapshot = remoteObject != null
            )
        }.getOrElse { ConflictParsedPayload(emptyList(), hasRemoteSnapshot = false) }
    }

    private fun String?.toJsonObjectOrNull(): JsonObject? {
        if (isNullOrBlank()) return null
        return runCatching { Json.parseToJsonElement(this).jsonObject }.getOrNull()
    }

    private fun JsonObject?.orEmptyObject(): JsonObject = this ?: JsonObject(emptyMap())

    private fun compare(local: JsonObject, remote: JsonObject?): List<ConflictFieldSnapshot> {
        val names = (local.keys + (remote?.keys.orEmpty()))
            .filterNot { it in hiddenPayloadFields }
            .sorted()
        return names.mapNotNull { name ->
            val localValue = local[name]?.toDisplayValue().orEmpty()
            val remoteValue = remote?.get(name)?.toDisplayValue()
            val changed = remote != null && localValue != remoteValue.orEmpty()
            if (localValue.isBlank() && remoteValue.isNullOrBlank()) return@mapNotNull null
            ConflictFieldSnapshot(
                name = name,
                localValue = localValue,
                remoteValue = remoteValue,
                isSensitive = name in sensitivePayloadFields,
                isChanged = changed,
                suggestedValue = when {
                    remoteValue.isNullOrBlank() -> localValue
                    localValue.isBlank() -> remoteValue
                    changed -> localValue
                    else -> localValue
                }
            )
        }
    }

    private fun JsonElement.toDisplayValue(): String = when (this) {
        is JsonPrimitive -> when {
            isString -> contentOrNull.orEmpty()
            booleanOrNull != null -> booleanOrNull.toString()
            longOrNull != null -> longOrNull.toString()
            doubleOrNull != null -> doubleOrNull.toString()
            else -> content
        }
        is JsonObject -> entries
            .filterNot { (key, _) -> key in hiddenPayloadFields }
            .joinToString(prefix = "{", postfix = "}") { (key, value) -> "$key=${value.toDisplayValue()}" }
        is JsonArray -> take(3)
            .joinToString(prefix = "[", postfix = if (size > 3) ", …]" else "]") { it.toDisplayValue() }
        else -> toString()
    }
}

data class ConflictParsedPayload(
    val fields: List<ConflictFieldSnapshot>,
    val hasRemoteSnapshot: Boolean
)
