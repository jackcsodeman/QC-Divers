package com.dumpsterscout.ui.spots

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.repository.LocationRepository
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.domain.usecase.SaveSpotUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Intents for the Add/Edit Spot screen.
 */
sealed class AddSpotIntent {
    data class LoadSpot(val id: Long?) : AddSpotIntent()
    data class UpdateField(val update: (DumpsterSpot) -> DumpsterSpot) : AddSpotIntent()
    data class Prefill(val name: String?, val address: String?, val status: SpotStatus?) : AddSpotIntent()
    data object UseCurrentLocation : AddSpotIntent()
    data object Save : AddSpotIntent()
    data object ClearSaved : AddSpotIntent()
    data object ClearError : AddSpotIntent()
}

/**
 * UI State for the Add/Edit Spot screen.
 */
data class AddSpotState(
    val spot: DumpsterSpot = DumpsterSpot(name = ""),
    val isLoading: Boolean = false,
    val isSaved: Boolean = false,
    val savedId: Long? = null,
    val error: String? = null
)

/**
 * MVI ViewModel for adding a new dumpster spot or editing an existing one.
 */
@HiltViewModel
class AddSpotViewModel @Inject constructor(
    private val saveSpotUseCase: SaveSpotUseCase,
    private val spotRepository: SpotRepository,
    private val locationRepository: LocationRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AddSpotState())
    val uiState: StateFlow<AddSpotState> = _uiState.asStateFlow()

    /**
     * Handle incoming UI intents.
     */
    fun onIntent(intent: AddSpotIntent) {
        when (intent) {
            is AddSpotIntent.LoadSpot -> loadSpot(intent.id)
            is AddSpotIntent.UpdateField -> _uiState.update { it.copy(spot = intent.update(it.spot)) }
            is AddSpotIntent.Prefill -> prefill(intent.name, intent.address, intent.status)
            AddSpotIntent.UseCurrentLocation -> useCurrentLocation()
            AddSpotIntent.Save -> saveSpot()
            AddSpotIntent.ClearSaved -> _uiState.update { it.copy(isSaved = false, savedId = null) }
            AddSpotIntent.ClearError -> _uiState.update { it.copy(error = null) }
        }
    }

    private fun loadSpot(id: Long?) {
        if (id == null) {
            _uiState.value = AddSpotState()
            return
        }
        viewModelScope.launch {
            try {
                _uiState.update { it.copy(isLoading = true) }
                val spot = spotRepository.getSpotById(id)
                _uiState.update { it.copy(spot = spot ?: DumpsterSpot(name = ""), isLoading = false) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "Failed to load spot", isLoading = false) }
            }
        }
    }

    private fun prefill(name: String?, address: String?, status: SpotStatus?) {
        _uiState.update { state ->
            state.copy(
                spot = state.spot.copy(
                    name = name ?: state.spot.name,
                    address = address ?: state.spot.address,
                    lastStatus = status ?: state.spot.lastStatus
                )
            )
        }
    }

    private fun useCurrentLocation() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val location = locationRepository.getLatestLocation()
            if (location != null) {
                _uiState.update { state ->
                    state.copy(
                        spot = state.spot.copy(
                            latitude = location.latitude,
                            longitude = location.longitude
                        ),
                        isLoading = false
                    )
                }
            } else {
                _uiState.update { it.copy(error = "Could not retrieve location", isLoading = false) }
            }
        }
    }

    private fun saveSpot() {
        viewModelScope.launch {
            try {
                _uiState.update { it.copy(isLoading = true) }
                saveSpotUseCase(_uiState.value.spot)
                    .onSuccess { id ->
                        _uiState.update { it.copy(isLoading = false, isSaved = true, savedId = id) }
                    }
                    .onFailure { e ->
                        _uiState.update { it.copy(error = e.message ?: "Failed to save spot", isLoading = false) }
                    }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
    }
}
