package com.dumpsterscout.ui.account

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.ScoutStats
import com.dumpsterscout.domain.repository.UserRepository
import com.dumpsterscout.domain.usecase.CalculateScoutRankUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * UI State for a scout's public profile.
 * 
 * @property stats The public scout statistics, or null if not loaded.
 * @property isLoading Whether the profile is currently being fetched.
 * @property error An error message if the fetch failed.
 */
data class ProfileUiState(
    val stats: ScoutStats? = null,
    val isLoading: Boolean = false,
    val error: String? = null
)

/**
 * MVI ViewModel for displaying public scout statistics.
 * 
 * @property userRepository The repository providing user identity and statistics.
 * @property calculateScoutRankUseCase Use case for ranking logic.
 */
@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val calculateScoutRankUseCase: CalculateScoutRankUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProfileUiState())
    /** The current UI state. */
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    /**
     * Load public statistics for the given [remoteUserId].
     * 
     * @param remoteUserId The ID of the scout to fetch stats for.
     */
    fun loadProfile(remoteUserId: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            userRepository.getUserPublicStats(remoteUserId)
                .onSuccess { stats ->
                    val rankedStats = stats.copy(rankTitle = calculateScoutRankUseCase(stats))
                    _uiState.update { it.copy(stats = rankedStats, isLoading = false) }
                }
                .onFailure { e ->
                    _uiState.update { it.copy(error = e.message, isLoading = false) }
                }
        }
    }
}
