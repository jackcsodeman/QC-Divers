package com.dumpsterscout.util

import com.dumpsterscout.domain.model.BagCondition
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.FillLevel
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.model.TimingNote
import com.dumpsterscout.domain.model.TimeRelevance
import com.dumpsterscout.domain.model.VoiceParseResult
import java.util.Locale

/**
 * Advanced voice/text parser for scouting reports.
 * 
 * Uses multi-stage entity extraction and fuzzy resolution to map natural language 
 * into structured scouting data.
 */
object VoiceParser {

    private val chainBrands = listOf(
        "Ulta", "Hy-Vee", "Walmart", "Target", "Aldi", "Kroger", "Walgreens", "CVS", 
        "PetSmart", "Petco", "Best Buy", "Five Below", "Dollar Tree", "Dollar General",
        "Home Depot", "Lowe's", "Menards", "Dick's", "Kohls", "Old Navy", "Gap", 
        "Trader Joe's", "Whole Foods", "Natural Grocers", "Staples", "Office Depot"
    )

    private val quadCityLocations = listOf(
        "Davenport", "Bettendorf", "Rock Island", "Moline", "East Moline", "Milan", "Silvis", "Eldridge"
    )

    private val fastPhrases = mapOf(
        listOf("good today", "good haul today", "good tonight", "great haul", "jackpot") to SpotStatus.GOOD_HAUL,
        listOf("bad today", "bad tonight", "nothing there") to SpotStatus.NOTHING_THERE,
        listOf("empty today", "empty tonight") to SpotStatus.EMPTY,
        listOf("locked today", "locked tonight", "it's locked") to SpotStatus.LOCKED,
        listOf("security came by", "security was there") to SpotStatus.SECURITY_ACTIVE,
        listOf("compactor only", "just a compactor") to SpotStatus.COMPACTOR_ONLY,
        listOf("overflowing", "way too full") to SpotStatus.OVERFLOWING
    )

    private val statusKeywords: Map<SpotStatus, List<String>> = mapOf(
        SpotStatus.EMPTY to listOf("empty", "nothing", "barren", "cleared out"),
        SpotStatus.FULL to listOf("full", "loaded", "packed"),
        SpotStatus.HALF_FULL to listOf("half", "partially", "halfway", "decent", "okay"),
        SpotStatus.OVERFLOWING to listOf("overflow", "overflowing", "piled up"),
        SpotStatus.LOCKED to listOf("locked", "padlocked", "gated"),
        SpotStatus.COMPACTOR_ONLY to listOf("compactor", "compacted", "crusher"),
        SpotStatus.GOOD_HAUL to listOf("good haul", "great haul", "jackpot", "score", "tons"),
        SpotStatus.SECURITY_ACTIVE to listOf("security", "guard", "cop", "police"),
        SpotStatus.ALREADY_PICKED_THROUGH to listOf("already picked", "someone else"),
        SpotStatus.NOTHING_THERE to listOf("nothing inside", "nothing good", "came up empty")
    )

    private val timeKeywords = linkedMapOf(
        TimeRelevance.THIS_MORNING to listOf("this morning", "early this morning"),
        TimeRelevance.TONIGHT to listOf("tonight", "this evening"),
        TimeRelevance.YESTERDAY to listOf("yesterday", "last night"),
        TimeRelevance.TODAY to listOf("today", "right now"),
        TimeRelevance.EARLIER to listOf("earlier", "a while ago")
    )

    /**
     * Parses the transcript with high precision for store names and locations.
     */
    fun parse(transcript: String): VoiceParseResult {
        val lower = transcript.lowercase(Locale.ROOT).trim()

        val status = detectStatus(lower)
        val timeRelevance = detectTimeRelevance(lower)
        val fillLevel = detectFillLevel(lower)
        
        // Entity extraction
        val brandMatch = chainBrands.find { lower.contains(it.lowercase()) }
        val locationMatch = quadCityLocations.find { lower.contains(it.lowercase()) }
        val streetMatch = extractStreetMatch(lower)

        // Construct a structured name if entities are found
        val parsedName = when {
            brandMatch != null && locationMatch != null -> "$brandMatch $locationMatch"
            brandMatch != null -> brandMatch
            else -> extractSpotNameFallback(lower)
        }

        val locationHint = buildString {
            if (locationMatch != null) append(locationMatch)
            if (streetMatch != null) {
                if (isNotEmpty()) append(", ")
                append(streetMatch)
            }
        }.ifBlank { extractLocationHintFallback(lower) }

        val confidence = calculateConfidence(status, parsedName, locationMatch != null)

        return VoiceParseResult(
            parsedSpotName = parsedName,
            status = status,
            fillLevel = fillLevel,
            timeRelevance = timeRelevance,
            notes = extractNotes(lower, parsedName),
            tags = extractTags(lower),
            securityMentioned = lower.contains("security") || lower.contains("guard"),
            weatherIssue = lower.contains("rain") || lower.contains("wet"),
            alreadyPicked = lower.contains("picked through"),
            timingNote = detectTimingNote(lower),
            quantityHint = extractQuantityHint(lower),
            rawTranscript = transcript,
            confidence = confidence,
            locationHint = locationHint
        )
    }

    /**
     * Resolves the parsed result against the database using fuzzy matching and geo-spatial hints.
     */
    fun resolveSpot(
        result: VoiceParseResult,
        spots: List<DumpsterSpot>,
        nearestSpotId: Long? = null
    ): VoiceParseResult {
        if (spots.isEmpty()) return result

        val query = result.parsedSpotName?.lowercase() ?: ""
        val locHint = result.locationHint?.lowercase() ?: ""

        val scored = spots.map { spot ->
            val name = spot.name.lowercase()
            val addr = spot.address.lowercase()
            var score = 0f

            if (query.isNotEmpty()) {
                if (name == query) score += 1.0f
                else if (name.contains(query)) score += 0.6f
                else if (query.contains(name)) score += 0.4f
            }

            if (locHint.isNotEmpty()) {
                if (addr.contains(locHint)) score += 0.5f
            }

            if (spot.id == nearestSpotId) score += 0.3f

            spot to score
        }.filter { it.second > 0.1f }.sortedByDescending { it.second }

        if (scored.isEmpty()) {
            return result.copy(matchedSpotId = nearestSpotId, confidence = if (nearestSpotId != null) 0.3f else 0f)
        }

        val best = scored.first()
        return result.copy(
            matchedSpotId = best.first.id,
            candidateSpotIds = scored.take(5).map { it.first.id },
            confidence = (best.second / 1.5f).coerceIn(0.1f, 1.0f)
        )
    }

    private fun detectStatus(lower: String): SpotStatus? {
        fastPhrases.forEach { (phrases, status) ->
            if (phrases.any { lower.contains(it) }) return status
        }
        return statusKeywords.entries
            .maxByOrNull { (_, keywords) -> keywords.count { lower.contains(it) } }
            ?.let { if (it.value.any { kw -> lower.contains(kw) }) it.key else null }
    }

    private fun detectTimeRelevance(lower: String): TimeRelevance =
        timeKeywords.entries.firstOrNull { (_, words) -> words.any { lower.contains(it) } }?.key ?: TimeRelevance.UNSPECIFIED

    private fun detectFillLevel(lower: String): FillLevel? = when {
        lower.contains("empty") -> FillLevel.EMPTY
        lower.contains("half") || lower.contains("decent") -> FillLevel.HALF_FULL
        lower.contains("full") || lower.contains("packed") -> FillLevel.FULL
        lower.contains("overflowing") -> FillLevel.OVERFLOWING
        else -> null
    }

    private fun detectTimingNote(lower: String): TimingNote = when {
        lower.contains("too early") -> TimingNote.CAME_TOO_EARLY
        lower.contains("too late") -> TimingNote.CAME_TOO_LATE
        else -> TimingNote.NONE
    }

    private fun extractStreetMatch(lower: String): String? {
        val streetRegex = Regex("(\\d+(?:st|nd|rd|th)? street|division|harrison|marquette|kimberly|brady|locust)")
        return streetRegex.find(lower)?.groupValues?.get(1)?.replaceFirstChar { it.uppercaseChar() }
    }

    private fun extractSpotNameFallback(lower: String): String? {
        val patterns = listOf(
            Regex("(?:at|behind|near) ([a-z0-9 ]{2,20}) (?:dumpster|bin)"),
            Regex("^([a-z0-9 ]{2,20}) is"),
            Regex("^([a-z0-9 ]{2,20}) was")
        )
        return patterns.firstNotNullOfOrNull { it.find(lower)?.groupValues?.get(1)?.trim() }
            ?.split(" ")?.joinToString(" ") { it.replaceFirstChar { c -> c.uppercaseChar() } }
    }

    private fun extractLocationHintFallback(lower: String): String? {
        val match = Regex("(?:in|on|at) ([a-z0-9 ]{2,30})").find(lower)
        return match?.groupValues?.get(1)?.trim()?.replaceFirstChar { it.uppercaseChar() }
    }

    private fun extractNotes(lower: String, name: String?): String {
        var clean = lower
        name?.lowercase()?.let { clean = clean.replace(it, "") }
        quadCityLocations.forEach { clean = clean.replace(it.lowercase(), "") }
        return clean.replace(Regex("\\s{2,}"), " ").trim()
    }

    private fun extractTags(lower: String): List<String> {
        val tags = mutableListOf<String>()
        if (lower.contains("food") || lower.contains("grocer") || lower.contains("bread")) tags.add("food")
        if (lower.contains("toy") || lower.contains("game")) tags.add("toys")
        if (lower.contains("makeup") || lower.contains("ulta") || lower.contains("beauty")) tags.add("beauty")
        return tags
    }

    private fun extractQuantityHint(lower: String): String {
        return when {
            lower.contains("tons") || lower.contains("jackpot") || lower.contains("lots of") -> "large"
            lower.contains("some") || lower.contains("decent") -> "moderate"
            else -> ""
        }
    }

    private fun calculateConfidence(status: SpotStatus?, name: String?, locationFound: Boolean): Float {
        var score = 0f
        if (status != null) score += 0.4f
        if (name != null) score += 0.4f
        if (locationFound) score += 0.2f
        return score.coerceIn(0.1f, 1.0f)
    }

    fun toReport(
        result: VoiceParseResult, 
        spotId: Long, 
        spotName: String,
        latitude: Double? = null,
        longitude: Double? = null
    ): PersonalReport = PersonalReport(
        spotId = spotId,
        spotName = spotName,
        status = result.status ?: SpotStatus.UNKNOWN,
        fillLevel = result.fillLevel ?: FillLevel.UNKNOWN,
        notes = result.notes,
        tags = result.tags,
        voiceTranscript = result.rawTranscript,
        isFromVoice = true,
        latitude = latitude,
        longitude = longitude
    )
}
