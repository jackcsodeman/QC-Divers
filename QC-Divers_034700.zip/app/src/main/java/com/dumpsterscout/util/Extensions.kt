package com.dumpsterscout.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun timeAgoString(epochMillis: Long): String {
    val diffMs = System.currentTimeMillis() - epochMillis
    val diffMin = diffMs / 60_000
    val diffHr = diffMs / 3_600_000
    val diffDays = diffMs / 86_400_000
    return when {
        diffMin < 1 -> "just now"
        diffMin < 60 -> "${diffMin}m ago"
        diffHr < 24 -> "${diffHr}h ago"
        diffDays == 1L -> "yesterday"
        diffDays < 7 -> "${diffDays}d ago"
        diffDays < 30 -> "${diffDays / 7}w ago"
        else -> {
            val sdf = SimpleDateFormat("MMM d", Locale.getDefault())
            sdf.format(Date(epochMillis))
        }
    }
}

fun formatDate(epochMillis: Long): String {
    val sdf = SimpleDateFormat("EEE, MMM d, yyyy 'at' h:mm a", Locale.getDefault())
    return sdf.format(Date(epochMillis))
}

fun formatShortDate(epochMillis: Long): String {
    val sdf = SimpleDateFormat("MMM d", Locale.getDefault())
    return sdf.format(Date(epochMillis))
}

fun Long.toShortDateString(): String = formatShortDate(this)

fun formatTime(epochMillis: Long): String {
    val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
    return sdf.format(Date(epochMillis))
}

/**
 * Standard geocoding wrapper for Android's Geocoder.
 * Suspends until completion or timeout.
 */
suspend fun android.content.Context.geocodeAddress(address: String): android.location.Address? =
    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        try {
            val geocoder = android.location.Geocoder(this@geocodeAddress)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                val results = kotlinx.coroutines.suspendCancellableCoroutine { cont ->
                    geocoder.getFromLocationName(address, 1, object : android.location.Geocoder.GeocodeListener {
                        override fun onGeocode(addresses: MutableList<android.location.Address>) {
                            cont.resume(addresses) { }
                        }
                        override fun onError(errorMessage: String?) {
                            cont.resume(mutableListOf()) { }
                        }
                    })
                }
                results.firstOrNull()
            } else {
                @Suppress("DEPRECATION")
                geocoder.getFromLocationName(address, 1)?.firstOrNull()
            }
        } catch (e: Exception) {
            null
        }
    }
