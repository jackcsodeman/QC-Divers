package com.dumpsterscout.util

import com.dumpsterscout.domain.model.TireCondition
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.domain.model.TireTimeRelevance
import com.dumpsterscout.domain.model.TireVoiceParseResult
import com.dumpsterscout.domain.model.TreadQuality

/**
 * Deterministic voice/text parser for tire-spot reports.
 *
 * Extracts: spot name, status, count, puncture state, sizes, tire types,
 * condition quality, timing, and free-form notes from a raw transcript.
 *
 * Designed to be a drop-in replacement for an ML model without interface changes.
 */
object TireVoiceParser {

    // ── Fast-phrase shortcuts ──────────────────────────────────────────────────
    private val fastPhrases: Map<List<String>, TireSpotStatus> = mapOf(
        listOf("nothing there today", "nothing there tonight", "nothing there", "no tires today",
            "no tires tonight", "no tires out", "zero tires") to TireSpotStatus.NO_TIRES,
        listOf("good usable tires", "good tires tonight", "good tires today",
            "great tires", "usable tires out") to TireSpotStatus.GOOD_USABLE,
        listOf("fresh drop", "fresh stack", "freshly out", "just put out", "looks fresh") to TireSpotStatus.FRESH_DROP,
        listOf("already picked through", "already picked", "someone already got here",
            "picked through when i got there") to TireSpotStatus.ALREADY_PICKED,
        listOf("gone fast", "tires gone fast", "they disappear fast") to TireSpotStatus.GONE_FAST,
        listOf("locked today", "locked tonight", "it's locked", "now locked",
            "locked inaccessible", "locked up") to TireSpotStatus.LOCKED_INACCESSIBLE,
        listOf("moved", "removed", "they moved", "spot is gone", "no longer there",
            "cleared out the spot") to TireSpotStatus.MOVED_REMOVED,
        listOf("all punctured", "every single one punctured",
            "all of them punctured") to TireSpotStatus.ALL_PUNCTURED,
        listOf("some punctured", "mixed punctured", "some punctured some not",
            "half punctured") to TireSpotStatus.SOME_PUNCTURED,
        listOf("unpunctured", "none punctured", "no punctures",
            "not punctured", "all good") to TireSpotStatus.UNPUNCTURED,
        listOf("worth checking", "still worth checking", "still worth a look") to TireSpotStatus.WORTH_CHECKING,
        listOf("not worth it", "not worth today", "not worth tonight",
            "waste of time today") to TireSpotStatus.NOT_WORTH_IT,
        listOf("mostly junk", "all junk", "just junk", "pure junk") to TireSpotStatus.MOSTLY_JUNK
    )

    // ── Status keyword clusters ────────────────────────────────────────────────
    private val statusKeywords: Map<TireSpotStatus, List<String>> = mapOf(
        TireSpotStatus.NO_TIRES to listOf("no tires", "nothing", "empty", "bare", "cleared"),
        TireSpotStatus.A_FEW_OUT to listOf("a few tires", "couple tires", "2 tires", "3 tires",
            "4 tires", "a couple", "just a few"),
        TireSpotStatus.MANY_OUT to listOf("many tires", "lot of tires", "tons of tires",
            "loads of tires", "stack of tires", "pile of tires", "good amount"),
        TireSpotStatus.GOOD_USABLE to listOf("good usable", "nice tires", "quality tires",
            "decent tires", "usable", "sellable", "good condition"),
        TireSpotStatus.MOSTLY_JUNK to listOf("junk", "trash", "garbage", "terrible condition",
            "mostly junk", "all junk", "no good"),
        TireSpotStatus.ALL_PUNCTURED to listOf("all punctured", "every one punctured", "all slashed",
            "all flat", "all destroyed"),
        TireSpotStatus.SOME_PUNCTURED to listOf("some punctured", "mixed punctured", "half punctured",
            "few punctured", "some slashed"),
        TireSpotStatus.UNPUNCTURED to listOf("not punctured", "none punctured", "no punctures",
            "unpunctured", "intact"),
        TireSpotStatus.ALREADY_PICKED to listOf("already picked", "picked through", "someone else",
            "been picked", "got here first"),
        TireSpotStatus.GONE_FAST to listOf("gone fast", "disappeared fast", "gone quick",
            "taken fast"),
        TireSpotStatus.LOCKED_INACCESSIBLE to listOf("locked", "inaccessible", "blocked", "gated",
            "chained", "padlocked"),
        TireSpotStatus.MOVED_REMOVED to listOf("moved", "removed", "gone", "not there anymore",
            "cleared out"),
        TireSpotStatus.WORTH_CHECKING to listOf("worth checking", "still worth", "check again",
            "worth a look"),
        TireSpotStatus.FRESH_DROP to listOf("fresh drop", "freshly out", "just dropped",
            "just put out", "looks fresh", "fresh stack"),
        TireSpotStatus.NOT_WORTH_IT to listOf("not worth", "waste of time", "skip it",
            "don't bother")
    )

    // ── Timing keywords ────────────────────────────────────────────────────────
    private val timeKeywords = linkedMapOf(
        TireTimeRelevance.THIS_MORNING to listOf("this morning", "early this morning"),
        TireTimeRelevance.TONIGHT to listOf("tonight", "this evening", "this night"),
        TireTimeRelevance.AFTER_CLOSING to listOf("after closing", "after they closed",
            "after close", "end of night", "closing time"),
        TireTimeRelevance.YESTERDAY to listOf("yesterday", "last night", "yesterday night"),
        TireTimeRelevance.TODAY to listOf("today", "earlier today"),
        TireTimeRelevance.EARLIER to listOf("earlier", "a while ago", "few hours ago")
    )

    // ── Puncture keywords ──────────────────────────────────────────────────────
    private val punctureWords = listOf(
        "punctured", "slashed", "destroyed", "unusable", "popped", "slit",
        "flat tires", "all flat", "gone flat"
    )
    private val noPunctureWords = listOf(
        "not punctured", "unpunctured", "intact", "no punctures", "none punctured"
    )

    // ── Count patterns ─────────────────────────────────────────────────────────
    private val countPatterns = listOf(
        Regex("(\\d+)\\s+tires?"),
        Regex("about\\s+(\\d+)"),
        Regex("probably\\s+(\\d+)"),
        Regex("maybe\\s+(\\d+)"),
        Regex("around\\s+(\\d+)"),
        Regex("roughly\\s+(\\d+)")
    )

    // ── Size patterns ──────────────────────────────────────────────────────────
    private val sizePattern = Regex(
        "(\\d{2,3}[/\\\\]\\d{2,3}[rR]\\d{2}|\\d{1,2}[\\s-]inch|\\d{2}[\\s-]in\\.?|\\d{2}\")"
    )

    // ── Tire type words ────────────────────────────────────────────────────────
    private val tireTypeWords = mapOf(
        "car" to listOf("car tires", "passenger tires", "sedan tires"),
        "truck" to listOf("truck tires", "pickup tires", "suv tires", "light truck"),
        "semi" to listOf("semi tires", "18 wheeler", "big rig tires", "commercial tires"),
        "trailer" to listOf("trailer tires"),
        "atv" to listOf("atv tires", "quad tires", "off-road tires"),
        "all-season" to listOf("all season", "all-season"),
        "summer" to listOf("summer tires", "performance tires"),
        "winter" to listOf("winter tires", "snow tires")
    )

    // ── Tread quality ──────────────────────────────────────────────────────────
    private val treadKeywords: Map<TreadQuality, List<String>> = mapOf(
        TreadQuality.EXCELLENT to listOf("excellent tread", "great tread", "brand new tread",
            "almost new", "barely used", "full tread"),
        TreadQuality.GOOD to listOf("good tread", "decent amount of tread", "most of the tread",
            "good amount of tread"),
        TreadQuality.DECENT to listOf("decent tread", "some tread", "okay tread", "half tread",
            "usable tread", "mid tread"),
        TreadQuality.LOW to listOf("low tread", "little tread", "wore down", "almost bald",
            "not much tread"),
        TreadQuality.VERY_LOW to listOf("bald", "no tread", "completely bald", "worn out",
            "slick", "zero tread")
    )

    // ── Condition damage words ─────────────────────────────────────────────────
    private val sidewallWords = listOf("sidewall damage", "sidewall crack", "bulge", "sidewall bulge")
    private val dryRotWords = listOf("dry rot", "cracked rubber", "weathered", "dry rotted")
    private val repairWords = listOf("patch", "patched", "repaired", "plug", "plugged", "fix on it")

    // ── Public API ─────────────────────────────────────────────────────────────

    /**
     * Parse a raw transcript into a [TireVoiceParseResult].
     * Call [resolveSpot] afterwards to match against known tire spots.
     */
    fun parse(transcript: String): TireVoiceParseResult {
        val lower = transcript.lowercase().trim()

        val fastStatus = fastPhrases.entries
            .firstOrNull { (phrases, _) -> phrases.any { phrase -> lower.contains(phrase) } }
            ?.value

        val status = fastStatus ?: detectStatus(lower)
        val timeRelevance = detectTimeRelevance(lower)
        val count = extractCount(lower)
        val sizes = extractSizes(transcript)
        val tireTypes = extractTireTypes(lower)
        val treadQuality = detectTreadQuality(lower)
        val condition = detectCondition(lower)

        val arePunctured = !lowerContainsAny(lower, noPunctureWords)
            && lowerContainsAny(lower, punctureWords)
        val somePunctured = lowerContainsAny(lower,
            listOf("some punctured", "mixed", "half punctured", "few punctured"))
        val someUnpunctured = lowerContainsAny(lower, noPunctureWords) || somePunctured

        val sidewallDamage = lowerContainsAny(lower, sidewallWords)
        val dryRot = lowerContainsAny(lower, dryRotWords)
        val repairVisible = lowerContainsAny(lower, repairWords)
        val alreadyPickedThrough = lowerContainsAny(lower,
            listOf("picked through", "already picked", "someone already", "got here first"))
        val lookedFreshOut = lowerContainsAny(lower,
            listOf("fresh", "just put out", "freshly", "just dropped", "looks fresh"))
        val weatherAffected = lowerContainsAny(lower,
            listOf("rain", "wet", "soaked", "flooded", "weather", "snow", "icy"))

        val parsedName = extractSpotName(lower)
        val locationHint = extractLocationHint(lower)
        val notes = extractNotes(lower, parsedName)
        val confidence = calculateConfidence(status, parsedName, count, timeRelevance)

        return TireVoiceParseResult(
            parsedSpotName = parsedName?.ifBlank { null },
            status = status,
            estimatedCount = count,
            timeRelevance = timeRelevance,
            arePunctured = arePunctured && !somePunctured,
            somePunctured = somePunctured,
            someUnpunctured = someUnpunctured || !arePunctured,
            commonSizes = sizes,
            tireTypes = tireTypes,
            treadQuality = treadQuality,
            condition = condition,
            sidewallDamage = sidewallDamage,
            dryRot = dryRot,
            repairVisible = repairVisible,
            alreadyPickedThrough = alreadyPickedThrough,
            lookedFreshOut = lookedFreshOut,
            weatherAffected = weatherAffected,
            notes = notes,
            rawTranscript = transcript,
            confidence = confidence,
            locationHint = locationHint
        )
    }

    /**
     * Given a parse result and a list of known tire spots, attach the best-matching spot.
     */
    fun resolveSpot(
        result: TireVoiceParseResult,
        spots: List<TireSpot>,
        nearestSpotId: Long? = null
    ): TireVoiceParseResult {
        if (spots.isEmpty()) return result

        val nameQuery = result.parsedSpotName?.lowercase() ?: ""
        val scored = spots.map { spot ->
            val nameLower = spot.name.lowercase()
            val addressLower = spot.address.lowercase()
            var score = 0f
            if (nameQuery.isNotBlank()) {
                when {
                    nameLower == nameQuery -> score += 1.0f
                    nameLower.contains(nameQuery) || nameQuery.contains(nameLower) -> score += 0.7f
                    nameQuery.split(" ").any { w -> w.length > 3 && nameLower.contains(w) } -> score += 0.4f
                    addressLower.contains(nameQuery) -> score += 0.3f
                }
            }
            if (spot.id == nearestSpotId) score += 0.2f
            spot to score
        }.filter { it.second > 0f }.sortedByDescending { it.second }

        if (scored.isEmpty()) {
            return result.copy(
                matchedSpotId = nearestSpotId,
                confidence = if (nearestSpotId != null) minOf(result.confidence + 0.1f, 0.4f)
                             else result.confidence
            )
        }

        val best = scored.first()
        val candidates = scored.take(3).map { it.first.id }
        val topConfidence = when {
            best.second >= 0.7f -> 0.9f
            best.second >= 0.4f -> 0.7f
            else -> 0.4f
        }
        return result.copy(
            matchedSpotId = best.first.id,
            candidateSpotIds = candidates,
            confidence = topConfidence.coerceAtMost(1f)
        )
    }

    /**
     * Convert a [TireVoiceParseResult] to a [TireReport] for a given spot.
     */
    fun toReport(
        result: TireVoiceParseResult,
        spotId: Long,
        spotName: String
    ): TireReport = TireReport(
        tireSpotId = spotId,
        spotName = spotName,
        status = result.status ?: TireSpotStatus.UNKNOWN,
        estimatedCount = result.estimatedCount,
        arePunctured = result.arePunctured,
        somePunctured = result.somePunctured,
        someUnpunctured = result.someUnpunctured,
        commonSizes = result.commonSizes,
        tireTypes = result.tireTypes,
        treadQuality = result.treadQuality,
        condition = result.condition,
        sidewallDamage = result.sidewallDamage,
        dryRot = result.dryRot,
        repairVisible = result.repairVisible,
        alreadyPickedThrough = result.alreadyPickedThrough,
        lookedFreshOut = result.lookedFreshOut,
        weatherAffected = result.weatherAffected,
        notes = result.notes,
        timestamp = System.currentTimeMillis()
    )

    // ── Internal helpers ───────────────────────────────────────────────────────

    private fun detectStatus(lower: String): TireSpotStatus? {
        var best: TireSpotStatus? = null
        var bestCount = 0
        statusKeywords.forEach { (status, keywords) ->
            val count = keywords.count { lower.contains(it) }
            if (count > bestCount) { bestCount = count; best = status }
        }
        return best
    }

    private fun detectTimeRelevance(lower: String): TireTimeRelevance =
        timeKeywords.entries
            .firstOrNull { (_, words) -> words.any { lower.contains(it) } }
            ?.key ?: TireTimeRelevance.UNSPECIFIED

    private fun extractCount(lower: String): Int {
        for (pattern in countPatterns) {
            val match = pattern.find(lower) ?: continue
            val n = match.groupValues[1].toIntOrNull() ?: continue
            if (n in 1..200) return n
        }
        // Word-number fallback
        return when {
            lowerContainsAny(lower, listOf("a dozen", "twelve")) -> 12
            lowerContainsAny(lower, listOf("ten", "about ten")) -> 10
            lowerContainsAny(lower, listOf("a handful", "five or six")) -> 5
            lowerContainsAny(lower, listOf("a couple", "two or three")) -> 2
            else -> 0
        }
    }

    private fun extractSizes(original: String): String {
        val matches = sizePattern.findAll(original.lowercase())
            .map { it.value.uppercase() }
            .distinct()
            .take(5)
            .toList()
        return matches.joinToString(", ")
    }

    private fun extractTireTypes(lower: String): String {
        return tireTypeWords.entries
            .filter { (_, words) -> words.any { lower.contains(it) } }
            .map { it.key.replaceFirstChar { c -> c.uppercaseChar() } }
            .joinToString(", ")
    }

    private fun detectTreadQuality(lower: String): TreadQuality =
        treadKeywords.entries
            .firstOrNull { (_, words) -> words.any { lower.contains(it) } }
            ?.key ?: TreadQuality.UNKNOWN

    private fun detectCondition(lower: String): TireCondition = when {
        lowerContainsAny(lower, listOf("all junk", "pure junk", "no good", "terrible")) -> TireCondition.JUNK
        lowerContainsAny(lower, listOf("good usable", "usable", "quality", "nice tires")) -> TireCondition.USABLE
        lowerContainsAny(lower, listOf("mixed", "some good", "some junk", "mixed quality")) -> TireCondition.MIXED
        else -> TireCondition.UNKNOWN
    }

    private fun extractSpotName(lower: String): String? {
        val patterns = listOf(
            Regex("(?:at |behind |the |near )([a-z0-9][a-z0-9 ]{1,30})(?:'s)? (?:tire shop|shop|mechanic|salvage|garage|dealer|lot|yard)"),
            Regex("([a-z0-9][a-z0-9 ]{1,30})(?:'s)? (?:tire shop|shop|mechanic|salvage|garage|dealer|lot|yard) (?:had|has|was|is|on)"),
            Regex("(?:at |behind |near )([a-z0-9][a-z0-9 ]{1,24}?)(?:\\s+(?:is|was|had|has|on|in|tire))"),
            Regex("^([a-z0-9][a-z0-9 ]{1,24}) (?:is|was|had|has|on|in|tire)")
        )
        for (pattern in patterns) {
            val match = pattern.find(lower) ?: continue
            val name = match.groupValues[1].trim()
            if (name.length > 2 && name !in listOf("the", "it", "that", "this", "a")) {
                val stripped = name.replace(Regex("\\s+(?:in|on|at|near)\\s+.*$"), "").trim()
                return stripped.split(" ").joinToString(" ") { it.replaceFirstChar { c -> c.uppercaseChar() } }
            }
        }
        return null
    }

    private fun extractLocationHint(lower: String): String? {
        val locationRegex = Regex("(?:in|on|at|near)\\s+([a-z0-9][a-z0-9 ]{1,40})")
        val match = locationRegex.find(lower)
        return match?.groupValues?.get(1)?.trim()?.split(" ")?.joinToString(" ") { it.replaceFirstChar { c -> c.uppercaseChar() } }
    }

    private fun extractNotes(lower: String, extractedName: String?): String {
        var notes = lower
        extractedName?.lowercase()?.let { notes = notes.replace(it, "") }
        statusKeywords.values.flatten().forEach { kw -> notes = notes.replace(kw, "") }
        timeKeywords.values.flatten().forEach { kw -> notes = notes.replace(kw, "") }
        notes = notes.replace(Regex("\\s{2,}"), " ").trim().trimEnd(',', '.', ' ')
        return notes.ifBlank { lower }
    }

    private fun calculateConfidence(
        status: TireSpotStatus?,
        name: String?,
        count: Int,
        timeRelevance: TireTimeRelevance
    ): Float {
        var score = 0f
        if (status != null && status != TireSpotStatus.UNKNOWN) score += 0.35f
        if (!name.isNullOrBlank()) score += 0.35f
        if (count > 0) score += 0.15f
        if (timeRelevance != TireTimeRelevance.UNSPECIFIED) score += 0.15f
        return score.coerceIn(0f, 1f)
    }

    private fun lowerContainsAny(lower: String, keywords: List<String>): Boolean =
        keywords.any { lower.contains(it) }
}
