package com.dumpsterscout.util

import android.util.Log
import com.dumpsterscout.BuildConfig

/**
 * Central logging wrapper.
 *
 * Debug/info logs are emitted only in debug builds. Warning/error logs are
 * intentionally generic in release builds; callers must not include exact
 * coordinates, tokens, private notes, transcripts, photo URLs, or other
 * sensitive field data in messages.
 */
object DsLogger {
    fun d(tag: String, message: String) {
        if (BuildConfig.DEBUG) Log.d(tag, message)
    }

    fun i(tag: String, message: String) {
        if (BuildConfig.DEBUG) Log.i(tag, message)
    }

    fun w(tag: String, message: String, throwable: Throwable? = null) {
        if (BuildConfig.DEBUG) Log.w(tag, message, throwable) else Log.w(tag, message)
    }

    fun e(tag: String, message: String, throwable: Throwable? = null) {
        if (BuildConfig.DEBUG) Log.e(tag, message, throwable) else Log.e(tag, message)
    }
}
