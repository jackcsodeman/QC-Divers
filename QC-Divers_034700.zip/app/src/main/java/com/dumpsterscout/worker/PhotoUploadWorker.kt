package com.dumpsterscout.worker

import android.content.Context
import com.dumpsterscout.util.DsLogger
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.dumpsterscout.data.remote.RemotePhotoDataSource
import com.dumpsterscout.di.SupabaseCredentials
import com.dumpsterscout.di.annotations.RemoteSource
import com.dumpsterscout.domain.repository.PhotoRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject

/**
 * Background WorkManager task that uploads locally-stored photos to
 * Supabase Storage.
 *
 * ## Current behaviour (no-op mode)
 * When [SupabaseCredentials.isConfigured] is false the worker exits with
 * [Result.success] immediately.
 *
 * ## Future behaviour (backend live)
 * 1. Queries [PhotoRepository.getPendingUploadPhotos] for records in
 *    `PENDING_UPLOAD` state.
 * 2. For each photo, calls [RemotePhotoDataSource.uploadPhoto].
 * 3. On success: calls [PhotoRepository.markUploaded] with the returned URL.
 * 4. On failure: calls [PhotoRepository.markUploadFailed] so the photo is
 *    retried on the next pass.
 *
 * ## Scheduling
 * ```kotlin
 * val request = OneTimeWorkRequestBuilder<PhotoUploadWorker>()
 *     .setConstraints(
 *         Constraints.Builder()
 *             .setRequiredNetworkType(NetworkType.CONNECTED)
 *             .setRequiresBatteryNotLow(true)
 *             .build()
 *     )
 *     .build()
 * WorkManager.getInstance(context).enqueue(request)
 * ```
 * Alternatively, chain it after spot/report saves so photos are uploaded shortly
 * after the spot is saved locally.
 */
@HiltWorker
class PhotoUploadWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val credentials: SupabaseCredentials,
    private val photoRepository: PhotoRepository,
    @RemoteSource private val remotePhotoSource: RemotePhotoDataSource
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        if (!credentials.isConfigured) {
            DsLogger.i(TAG, "Supabase not configured; skipping photo upload.")
            return Result.success()
        }

        val pending = photoRepository.getPendingUploadPhotos()
        if (pending.isEmpty()) {
            DsLogger.d(TAG, "No photos pending upload.")
            return Result.success()
        }

        DsLogger.i(TAG, "Uploading ${pending.size} photo(s).")
        var anyFailure = false

        for (photo in pending) {
            try {
                val remoteUrl = remotePhotoSource.uploadPhoto(photo)
                if (remoteUrl != null) {
                    photoRepository.markUploaded(photo.id, remoteUrl)
                    DsLogger.d(TAG, "Uploaded photo id=${photo.id}.")
                } else {
                    photoRepository.markUploadFailed(photo.id)
                    DsLogger.w(TAG, "Photo upload returned no remote reference for photo id=${photo.id}.")
                    anyFailure = true
                }
            } catch (e: Exception) {
                DsLogger.e(TAG, "Photo upload failed for photo id=${photo.id}.", e)
                photoRepository.markUploadFailed(photo.id)
                anyFailure = true
            }
        }

        return if (anyFailure) Result.retry() else Result.success()
    }

    companion object {
        const val TAG = "PhotoUploadWorker"
        const val WORK_NAME = "dumpsterscout_photo_upload"
    }
}
