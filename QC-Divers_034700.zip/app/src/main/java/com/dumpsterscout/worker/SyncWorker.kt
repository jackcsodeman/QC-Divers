package com.dumpsterscout.worker

import android.content.Context
import com.dumpsterscout.util.DsLogger
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.dumpsterscout.data.local.dao.FieldLocationDao
import com.dumpsterscout.data.local.dao.FieldLocationReportDao
import com.dumpsterscout.data.local.dao.RoutePlanDao
import com.dumpsterscout.data.local.dao.ReminderDao
import com.dumpsterscout.data.local.dao.GearChecklistDao
import com.dumpsterscout.data.local.dao.FieldSessionDao
import com.dumpsterscout.data.local.dao.CollectionDao
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.data.sync.SyncQueueProcessor
import com.dumpsterscout.data.remote.RemoteFieldLocationDataSource
import com.dumpsterscout.data.remote.RemoteFieldLocationReportDataSource
import com.dumpsterscout.data.remote.RemoteRouteDataSource
import com.dumpsterscout.data.remote.RemoteReminderDataSource
import com.dumpsterscout.data.remote.RemoteGearChecklistDataSource
import com.dumpsterscout.data.remote.RemoteFieldSessionDataSource
import com.dumpsterscout.data.remote.RemoteCollectionDataSource
import com.dumpsterscout.data.remote.RemoteReportDataSource
import com.dumpsterscout.data.remote.RemoteSpotDataSource
import com.dumpsterscout.data.remote.RemoteTireSpotDataSource
import com.dumpsterscout.data.remote.dto.toDomain
import com.dumpsterscout.data.remote.dto.toEntity
import com.dumpsterscout.di.SupabaseCredentials
import com.dumpsterscout.di.annotations.RemoteSource
import com.dumpsterscout.domain.repository.ReportRepository
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.domain.repository.TireReportRepository
import com.dumpsterscout.domain.repository.TireSpotRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first

/**
 * Background WorkManager task that pushes locally-modified records to the
 * Supabase backend.
 *
 * ## Current behaviour (no-op mode)
 * When [SupabaseCredentials.isConfigured] is false (i.e. no backend project
 * has been set up yet), the worker exits early with [Result.success] so the
 * WorkManager does not keep retrying. A log message explains the situation.
 *
 * ## Future behaviour (backend live)
 * Once credentials are configured and the real remote data sources are bound
 * in [RemoteModule], the worker will:
 * 1. Read all records in `PENDING_SYNC` state via the repository sync hooks.
 * 2. Push them to Supabase via the remote data source.
 * 3. Call `markSpotSynced(id, remoteId)` on success or `markSpotSyncFailed(id)`
 *    on failure, so failed records are retried on the next pass.
 *
 * ## Scheduling
 * Schedule via [WorkManager] in your app initialisation:
 * ```kotlin
 * val request = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
 *     .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
 *     .build()
 * WorkManager.getInstance(context).enqueueUniquePeriodicWork(
 *     SyncWorker.WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
 * ```
 */
@HiltWorker
class SyncWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val credentials: SupabaseCredentials,
    private val prefs: AppPreferences,
    private val spotRepository: SpotRepository,
    private val reportRepository: ReportRepository,
    private val tireSpotRepository: TireSpotRepository,
    private val tireReportRepository: TireReportRepository,
    private val syncQueueProcessor: SyncQueueProcessor,
    private val fieldLocationDao: FieldLocationDao,
    private val fieldLocationReportDao: FieldLocationReportDao,
    private val routeDao: RoutePlanDao,
    private val collectionDao: CollectionDao,
    private val fieldSessionDao: FieldSessionDao,
    private val reminderDao: ReminderDao,
    private val gearChecklistDao: GearChecklistDao,
    @RemoteSource private val remoteSpotSource: RemoteSpotDataSource,
    @RemoteSource private val remoteReportSource: RemoteReportDataSource,
    @RemoteSource private val remoteTireSpotSource: RemoteTireSpotDataSource,
    @RemoteSource private val remoteFieldLocationSource: RemoteFieldLocationDataSource,
    @RemoteSource private val remoteFieldLocationReportSource: RemoteFieldLocationReportDataSource,
    @RemoteSource private val remoteRouteSource: RemoteRouteDataSource,
    @RemoteSource private val remoteCollectionSource: RemoteCollectionDataSource,
    @RemoteSource private val remoteFieldSessionSource: RemoteFieldSessionDataSource,
    @RemoteSource private val remoteReminderSource: RemoteReminderDataSource,
    @RemoteSource private val remoteGearChecklistSource: RemoteGearChecklistDataSource
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        if (!credentials.isConfigured) {
            DsLogger.i(TAG, "Supabase not configured; skipping sync.")
            return Result.success()
        }

        DsLogger.i(TAG, "Starting sync pass.")
        var anyFailure = false

        // ── Push durable outbox changes first ─────────────────────────────────
        val queueResult = syncQueueProcessor.processNextBatch()
        if (queueResult.attempted > 0) {
            DsLogger.i(TAG, "Processed sync queue: attempted=${queueResult.attempted}, succeeded=${queueResult.succeeded}, failed=${queueResult.failed}.")
        }
        anyFailure = anyFailure or queueResult.hasFailures

        // ── Compatibility fallback for older records that were marked pending
        // before the durable outbox existed. New mutations should use sync_queue.
        anyFailure = anyFailure or syncSpots()
        anyFailure = anyFailure or syncReports()
        anyFailure = anyFailure or syncTireSpots()
        anyFailure = anyFailure or syncTireReports()

        // ── Pull user's remote data (new install / other device) ──────────────
        val ownerUserId = prefs.remoteUserId.first() ?: prefs.localUserId.first()
        if (ownerUserId != null) {
            pullMySpots(ownerUserId)
            pullMyReports(ownerUserId)
            pullMyTireSpots(ownerUserId)
            pullMyTireReports(ownerUserId)
            pullMyFieldLocations(ownerUserId)
            pullMyFieldLocationReports(ownerUserId)
            pullMyRoutePlans(ownerUserId)
            pullMyRouteStops(ownerUserId)
            pullMyCollections(ownerUserId)
            pullMyCollectionItems(ownerUserId)
            pullMyFieldSessions(ownerUserId)
            pullMyFieldSessionVisits(ownerUserId)
            pullMyReminders(ownerUserId)
            pullMyGearChecklists(ownerUserId)
            pullMyGearChecklistItems(ownerUserId)
        }

        return if (anyFailure) {
            DsLogger.w(TAG, "Sync pass completed with failures; will retry.")
            Result.retry()
        } else {
            DsLogger.i(TAG, "Sync pass completed successfully.")
            Result.success()
        }
    }

    private suspend fun syncSpots(): Boolean {
        val pending = spotRepository.getPendingSyncSpots()
        if (pending.isEmpty()) return false
        DsLogger.d(TAG, "Syncing ${pending.size} spots.")
        return try {
            val synced = remoteSpotSource.upsertSpots(pending)
            pending.forEach { spot ->
                val remoteId = synced[spot.id]
                if (remoteId != null) {
                    spotRepository.markSpotSynced(spot.id, remoteId)
                } else {
                    spotRepository.markSpotSyncFailed(spot.id)
                }
            }
            synced.size < pending.size
        } catch (e: Exception) {
            DsLogger.e(TAG, "Spot sync failed.", e)
            pending.forEach { spotRepository.markSpotSyncFailed(it.id) }
            true
        }
    }

    private suspend fun syncReports(): Boolean {
        val pending = reportRepository.getPendingSyncReports()
        if (pending.isEmpty()) return false
        DsLogger.d(TAG, "Syncing ${pending.size} spot reports.")

        // Resolve each report's associated spot remoteId so the backend can link
        // the report row to the correct `dumpster_spots` row via the FK.
        val spotRemoteIds: Map<Long, String?> = pending.associate { report ->
            report.id to spotRepository.getSpotById(report.spotId)?.remoteId
        }

        return try {
            val synced = remoteReportSource.upsertReports(pending, spotRemoteIds)
            pending.forEach { report ->
                val remoteId = synced[report.id]
                if (remoteId != null) {
                    reportRepository.markReportSynced(report.id, remoteId)
                } else {
                    reportRepository.markReportSyncFailed(report.id)
                }
            }
            synced.size < pending.size
        } catch (e: Exception) {
            DsLogger.e(TAG, "Report sync failed.", e)
            pending.forEach { reportRepository.markReportSyncFailed(it.id) }
            true
        }
    }

    private suspend fun syncTireSpots(): Boolean {
        val pending = tireSpotRepository.getPendingSyncSpots()
        if (pending.isEmpty()) return false
        DsLogger.d(TAG, "Syncing ${pending.size} tire spots.")
        return try {
            val synced = remoteTireSpotSource.upsertTireSpots(pending)
            pending.forEach { spot ->
                val remoteId = synced[spot.id]
                if (remoteId != null) {
                    tireSpotRepository.markSpotSynced(spot.id, remoteId)
                } else {
                    tireSpotRepository.markSpotSyncFailed(spot.id)
                }
            }
            synced.size < pending.size
        } catch (e: Exception) {
            DsLogger.e(TAG, "Tire spot sync failed.", e)
            pending.forEach { tireSpotRepository.markSpotSyncFailed(it.id) }
            true
        }
    }

    private suspend fun syncTireReports(): Boolean {
        val pending = tireReportRepository.getPendingSyncReports()
        if (pending.isEmpty()) return false
        DsLogger.d(TAG, "Syncing ${pending.size} tire reports.")

        // Resolve each tire report's associated tire spot remoteId for the backend FK.
        val tireSpotRemoteIds: Map<Long, String?> = pending.associate { report ->
            report.id to tireSpotRepository.getSpotById(report.tireSpotId)?.remoteId
        }

        return try {
            val synced = remoteReportSource.upsertTireReports(pending, tireSpotRemoteIds)
            pending.forEach { report ->
                val remoteId = synced[report.id]
                if (remoteId != null) {
                    tireReportRepository.markReportSynced(report.id, remoteId)
                } else {
                    tireReportRepository.markReportSyncFailed(report.id)
                }
            }
            synced.size < pending.size
        } catch (e: Exception) {
            DsLogger.e(TAG, "Tire report sync failed.", e)
            pending.forEach { tireReportRepository.markReportSyncFailed(it.id) }
            true
        }
    }

    /**
     * Pull the user's remote dumpster spots that don't yet exist locally.
     * Spots with a matching [remoteId] already in the DB are skipped to avoid overwriting
     * local edits.
     */
    private suspend fun pullMySpots(ownerUserId: String) {
        try {
            val remote = remoteSpotSource.fetchMySpots(ownerUserId)
            var newCount = 0
            for (spot in remote) {
                val existing = spotRepository.getSpotByRemoteId(spot.remoteId ?: continue)
                if (existing == null) {
                    spotRepository.upsertSpotFromRemote(spot)
                    newCount++
                }
            }
            if (newCount > 0) DsLogger.i(TAG, "Pulled $newCount new dumpster spots from backend.")
        } catch (e: Exception) {
            DsLogger.e(TAG, "Remote spot pull failed.", e)
        }
    }

    /**
     * Pull the user's remote dumpster reports that don't yet exist locally.
     * Resolves each [com.dumpsterscout.data.remote.dto.ReportRow.spotRemoteId] to a local
     * spot id so inserted records have a valid FK.
     */
    private suspend fun pullMyReports(ownerUserId: String) {
        try {
            val remote = remoteReportSource.fetchMyReports(ownerUserId)
            var newCount = 0
            for (row in remote) {
                if (row.remoteId.isBlank()) continue
                val existing = reportRepository.getReportByRemoteId(row.remoteId)
                if (existing == null) {
                    val localSpotId = row.spotRemoteId
                        ?.let { spotRepository.getSpotByRemoteId(it)?.id }
                    if (localSpotId == null) {
                        DsLogger.w(TAG, "Skipping remote dumpster report until parent spot is available.")
                        continue
                    }
                    reportRepository.insertReportFromRemote(row.toDomain(localSpotId = localSpotId))
                    newCount++
                }
            }
            if (newCount > 0) DsLogger.i(TAG, "Pulled $newCount new dumpster reports from backend.")
        } catch (e: Exception) {
            DsLogger.e(TAG, "Remote report pull failed.", e)
        }
    }

    /**
     * Pull the user's remote tire spots that don't yet exist locally.
     */
    private suspend fun pullMyTireSpots(ownerUserId: String) {
        try {
            val remote = remoteTireSpotSource.fetchMyTireSpots(ownerUserId)
            var newCount = 0
            for (spot in remote) {
                val existing = tireSpotRepository.getSpotByRemoteId(spot.remoteId ?: continue)
                if (existing == null) {
                    tireSpotRepository.upsertSpotFromRemote(spot)
                    newCount++
                }
            }
            if (newCount > 0) DsLogger.i(TAG, "Pulled $newCount new tire spots from backend.")
        } catch (e: Exception) {
            DsLogger.e(TAG, "Remote tire spot pull failed.", e)
        }
    }

    /**
     * Pull the user's remote tire reports that don't yet exist locally.
     * Resolves each [com.dumpsterscout.data.remote.dto.TireReportRow.tireSpotRemoteId] to a
     * local tire spot id so inserted records have a valid FK.
     */
    private suspend fun pullMyTireReports(ownerUserId: String) {
        try {
            val remote = remoteReportSource.fetchMyTireReports(ownerUserId)
            var newCount = 0
            for (row in remote) {
                if (row.remoteId.isBlank()) continue
                val existing = tireReportRepository.getReportByRemoteId(row.remoteId)
                if (existing == null) {
                    val localTireSpotId = row.tireSpotRemoteId
                        ?.let { tireSpotRepository.getSpotByRemoteId(it)?.id }
                    if (localTireSpotId == null) {
                        DsLogger.w(TAG, "Skipping remote tire report until parent tire spot is available.")
                        continue
                    }
                    tireReportRepository.insertReportFromRemote(row.toDomain(localTireSpotId = localTireSpotId))
                    newCount++
                }
            }
            if (newCount > 0) DsLogger.i(TAG, "Pulled $newCount new tire reports from backend.")
        } catch (e: Exception) {
            DsLogger.e(TAG, "Remote tire report pull failed.", e)
        }
    }

    /**
     * Pull the user's remote cleanup/salvage/custom field locations that do not yet exist locally.
     */
    private suspend fun pullMyFieldLocations(ownerUserId: String) {
        try {
            val remote = remoteFieldLocationSource.fetchMyFieldLocations(ownerUserId)
            var newCount = 0
            for (location in remote) {
                val remoteId = location.remoteId ?: continue
                val existing = fieldLocationDao.getByRemoteId(remoteId)
                if (existing == null) {
                    fieldLocationDao.upsert(location)
                    newCount++
                }
            }
            if (newCount > 0) DsLogger.i(TAG, "Pulled $newCount new field locations from backend.")
        } catch (e: Exception) {
            DsLogger.e(TAG, "Remote field-location pull failed.", e)
        }
    }


    /** Pull remote cleanup/salvage/custom field-location reports only after their parent local location exists. */
    private suspend fun pullMyFieldLocationReports(ownerUserId: String) {
        try {
            val remote = remoteFieldLocationReportSource.fetchMyReports(ownerUserId)
            var newCount = 0
            for (row in remote) {
                if (row.remoteId.isBlank()) continue
                val existing = fieldLocationReportDao.getByRemoteId(row.remoteId)
                if (existing != null) continue
                val localLocationId = row.fieldLocationRemoteId
                    ?.let { fieldLocationDao.getByRemoteId(it)?.id }
                if (localLocationId == null) {
                    DsLogger.w(TAG, "Skipping remote field-location report until parent field location is available.")
                    continue
                }
                fieldLocationReportDao.upsert(row.toEntity(localFieldLocationId = localLocationId))
                newCount++
            }
            if (newCount > 0) DsLogger.i(TAG, "Pulled $newCount new field-location reports from backend.")
        } catch (e: Exception) {
            DsLogger.e(TAG, "Remote field-location report pull failed.", e)
        }
    }

    /** Pull route plans created on another device. Child route stops are pulled immediately after parent route plans. */
    private suspend fun pullMyRoutePlans(ownerUserId: String) {
        try {
            val remote = remoteRouteSource.fetchMyRoutePlans(ownerUserId)
            var newCount = 0
            for (route in remote) {
                val remoteId = route.remoteId ?: continue
                val existing = routeDao.getRoutePlanByRemoteId(remoteId)
                if (existing == null) {
                    routeDao.insert(route.copy(id = 0, syncStatus = "SYNCED"))
                    newCount++
                }
            }
            if (newCount > 0) DsLogger.i(TAG, "Pulled $newCount new route plans from backend.")
        } catch (e: Exception) {
            DsLogger.e(TAG, "Remote route pull failed.", e)
        }
    }

    /** Pull route stops created on another device once route and location parents can be resolved locally. */
    private suspend fun pullMyRouteStops(ownerUserId: String) {
        try {
            val remote = remoteRouteSource.fetchMyRouteStops(ownerUserId)
            var newCount = 0
            for (row in remote) {
                if (row.remoteId.isBlank()) continue
                if (routeDao.getStopByRemoteId(row.remoteId) != null) continue
                val localRouteId = routeDao.getRoutePlanByRemoteId(row.routeRemoteId)?.id
                val localLocationId = resolveLocalLocationId(row.locationType, row.locationRemoteId)
                if (localRouteId == null || localLocationId == null) {
                    DsLogger.w(TAG, "Skipping remote route stop until route and location parents are available.")
                    continue
                }
                routeDao.upsertStop(row.toEntity(routeId = localRouteId, locationId = localLocationId))
                newCount++
            }
            if (newCount > 0) DsLogger.i(TAG, "Pulled $newCount new route stops from backend.")
        } catch (e: Exception) {
            DsLogger.e(TAG, "Remote route-stop pull failed.", e)
        }
    }

    /** Pull collections created on another device. Child items are pulled immediately after parent collections. */
    private suspend fun pullMyCollections(ownerUserId: String) {
        try {
            val remote = remoteCollectionSource.fetchMyCollections(ownerUserId)
            var newCount = 0
            for (collection in remote) {
                val remoteId = collection.remoteId ?: continue
                val existing = collectionDao.getCollectionByRemoteId(remoteId)
                if (existing == null) {
                    collectionDao.insertCollection(collection.copy(id = 0, syncStatus = "SYNCED"))
                    newCount++
                }
            }
            if (newCount > 0) DsLogger.i(TAG, "Pulled $newCount new collections from backend.")
        } catch (e: Exception) {
            DsLogger.e(TAG, "Remote collection pull failed.", e)
        }
    }

    /** Pull collection items created on another device once collection and location parents exist locally. */
    private suspend fun pullMyCollectionItems(ownerUserId: String) {
        try {
            val remote = remoteCollectionSource.fetchMyCollectionItems(ownerUserId)
            var newCount = 0
            for (row in remote) {
                if (row.remoteId.isBlank()) continue
                if (collectionDao.getItemByRemoteId(row.remoteId) != null) continue
                val localCollectionId = collectionDao.getCollectionByRemoteId(row.collectionRemoteId)?.id
                val localLocationId = resolveLocalLocationId(row.locationType, row.locationRemoteId)
                if (localCollectionId == null || localLocationId == null) {
                    DsLogger.w(TAG, "Skipping remote collection item until collection and location parents are available.")
                    continue
                }
                collectionDao.upsertItem(row.toEntity(collectionId = localCollectionId, locationId = localLocationId))
                newCount++
            }
            if (newCount > 0) DsLogger.i(TAG, "Pulled $newCount new collection items from backend.")
        } catch (e: Exception) {
            DsLogger.e(TAG, "Remote collection-item pull failed.", e)
        }
    }

    /** Pull field sessions created on another device. Child visits are pulled immediately after parent sessions. */
    private suspend fun pullMyFieldSessions(ownerUserId: String) {
        try {
            val remote = remoteFieldSessionSource.fetchMyFieldSessions(ownerUserId)
            var newCount = 0
            for (session in remote) {
                val remoteId = session.remoteId ?: continue
                val existing = fieldSessionDao.getSessionByRemoteId(remoteId)
                if (existing == null) {
                    fieldSessionDao.insertSession(session.copy(id = 0, syncStatus = "SYNCED"))
                    newCount++
                }
            }
            if (newCount > 0) DsLogger.i(TAG, "Pulled $newCount new field sessions from backend.")
        } catch (e: Exception) {
            DsLogger.e(TAG, "Remote field-session pull failed.", e)
        }
    }

    /** Pull field-session visits created on another device once session and location parents exist locally. */
    private suspend fun pullMyFieldSessionVisits(ownerUserId: String) {
        try {
            val remote = remoteFieldSessionSource.fetchMyFieldSessionVisits(ownerUserId)
            var newCount = 0
            for (row in remote) {
                if (row.remoteId.isBlank()) continue
                if (fieldSessionDao.getVisitByRemoteId(row.remoteId) != null) continue
                val localSessionId = fieldSessionDao.getSessionByRemoteId(row.sessionRemoteId)?.id
                val localLocationId = resolveLocalLocationId(row.locationType, row.locationRemoteId)
                if (localSessionId == null || localLocationId == null) {
                    DsLogger.w(TAG, "Skipping remote field-session visit until session and location parents are available.")
                    continue
                }
                fieldSessionDao.upsertVisit(row.toEntity(sessionId = localSessionId, locationId = localLocationId))
                newCount++
            }
            if (newCount > 0) DsLogger.i(TAG, "Pulled $newCount new field-session visits from backend.")
        } catch (e: Exception) {
            DsLogger.e(TAG, "Remote field-session visit pull failed.", e)
        }
    }

    /** Pull reminders created on another device only when their parent local location can be resolved. */
    private suspend fun pullMyReminders(ownerUserId: String) {
        try {
            val remote = remoteReminderSource.fetchMyReminders(ownerUserId)
            var newCount = 0
            for (reminder in remote) {
                val remoteId = reminder.remoteId ?: continue
                val existing = reminderDao.getReminderByRemoteId(remoteId)
                if (existing != null) continue
                val parentSpotId = reminder.locationRemoteId
                    ?.let { spotRepository.getSpotByRemoteId(it)?.id }
                    ?: reminder.spotId.takeIf { it > 0L }
                if (parentSpotId == null) {
                    DsLogger.w(TAG, "Skipping remote reminder until parent location is available.")
                    continue
                }
                reminderDao.insert(reminder.copy(id = 0, spotId = parentSpotId, syncStatus = "SYNCED"))
                newCount++
            }
            if (newCount > 0) DsLogger.i(TAG, "Pulled $newCount new reminders from backend.")
        } catch (e: Exception) {
            DsLogger.e(TAG, "Remote reminder pull failed.", e)
        }
    }

    /** Pull gear checklist shells created on another device. Child checklist items are pulled immediately after parent checklists. */
    private suspend fun pullMyGearChecklists(ownerUserId: String) {
        try {
            val remote = remoteGearChecklistSource.fetchMyChecklists(ownerUserId)
            var newCount = 0
            for (checklist in remote) {
                val remoteId = checklist.remoteId ?: continue
                val existing = gearChecklistDao.getChecklistByRemoteId(remoteId)
                if (existing == null) {
                    gearChecklistDao.insertChecklist(checklist.copy(id = 0, syncStatus = "SYNCED"))
                    newCount++
                }
            }
            if (newCount > 0) DsLogger.i(TAG, "Pulled $newCount new gear checklists from backend.")
        } catch (e: Exception) {
            DsLogger.e(TAG, "Remote gear checklist pull failed.", e)
        }
    }

    /** Pull gear checklist items created on another device once parent checklists exist locally. */
    private suspend fun pullMyGearChecklistItems(ownerUserId: String) {
        try {
            val remote = remoteGearChecklistSource.fetchMyChecklistItems(ownerUserId)
            var newCount = 0
            for (row in remote) {
                if (row.remoteId.isBlank()) continue
                if (gearChecklistDao.getItemByRemoteId(row.remoteId) != null) continue
                val localChecklistId = gearChecklistDao.getChecklistByRemoteId(row.checklistRemoteId)?.id
                if (localChecklistId == null) {
                    DsLogger.w(TAG, "Skipping remote gear checklist item until parent checklist is available.")
                    continue
                }
                gearChecklistDao.insertItem(row.toEntity(checklistId = localChecklistId))
                newCount++
            }
            if (newCount > 0) DsLogger.i(TAG, "Pulled $newCount new gear checklist items from backend.")
        } catch (e: Exception) {
            DsLogger.e(TAG, "Remote gear checklist item pull failed.", e)
        }
    }

    private suspend fun resolveLocalLocationId(locationType: String, remoteId: String?): Long? {
        if (remoteId.isNullOrBlank()) return null
        return when (locationType) {
            "DUMPSTER_SPOT" -> spotRepository.getSpotByRemoteId(remoteId)?.id
            "TIRE_SPOT" -> tireSpotRepository.getSpotByRemoteId(remoteId)?.id
            "FIELD_LOCATION", "CLEANUP_SITE", "SALVAGE_RESOURCE", "CUSTOM" -> fieldLocationDao.getByRemoteId(remoteId)?.id
            else -> fieldLocationDao.getByRemoteId(remoteId)?.id
        }
    }

    companion object {
        const val TAG = "SyncWorker"
        /** Unique name for [WorkManager.enqueueUniquePeriodicWork]. */
        const val WORK_NAME = "dumpsterscout_sync"
    }
}
