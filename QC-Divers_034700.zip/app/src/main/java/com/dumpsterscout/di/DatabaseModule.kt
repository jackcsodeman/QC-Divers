package com.dumpsterscout.di

import android.content.Context
import androidx.room.Room
import com.dumpsterscout.data.local.DumpsterScoutDatabase
import com.dumpsterscout.data.local.dao.DumpsterSpotDao
import com.dumpsterscout.data.local.dao.GearChecklistDao
import com.dumpsterscout.data.local.dao.FieldSessionDao
import com.dumpsterscout.data.local.dao.FieldLocationDao
import com.dumpsterscout.data.local.dao.FieldLocationReportDao
import com.dumpsterscout.data.local.dao.CollectionDao
import com.dumpsterscout.data.local.dao.PersonalReportDao
import com.dumpsterscout.data.local.dao.ReminderDao
import com.dumpsterscout.data.local.dao.RoutePlanDao
import com.dumpsterscout.data.local.dao.SpotPhotoDao
import com.dumpsterscout.data.local.dao.SyncQueueDao
import com.dumpsterscout.data.local.dao.TireReportDao
import com.dumpsterscout.data.local.dao.TireSpotDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): DumpsterScoutDatabase =
        Room.databaseBuilder(
            context,
            DumpsterScoutDatabase::class.java,
            DumpsterScoutDatabase.DATABASE_NAME
        )
            .addMigrations(
                DumpsterScoutDatabase.MIGRATION_1_2,
                DumpsterScoutDatabase.MIGRATION_2_3,
                DumpsterScoutDatabase.MIGRATION_3_4,
                DumpsterScoutDatabase.MIGRATION_4_5,
                DumpsterScoutDatabase.MIGRATION_5_6,
                DumpsterScoutDatabase.MIGRATION_6_7,
                DumpsterScoutDatabase.MIGRATION_7_8,
                DumpsterScoutDatabase.MIGRATION_8_9,
                DumpsterScoutDatabase.MIGRATION_9_10,
                DumpsterScoutDatabase.MIGRATION_10_11,
                DumpsterScoutDatabase.MIGRATION_11_12,
                DumpsterScoutDatabase.MIGRATION_12_13
            )
            .build()

    @Provides
    fun provideSpotDao(db: DumpsterScoutDatabase): DumpsterSpotDao = db.spotDao()

    @Provides
    fun provideReportDao(db: DumpsterScoutDatabase): PersonalReportDao = db.reportDao()

    @Provides
    fun providePhotoDao(db: DumpsterScoutDatabase): SpotPhotoDao = db.photoDao()

    @Provides
    fun provideSyncQueueDao(db: DumpsterScoutDatabase): SyncQueueDao = db.syncQueueDao()

    @Provides
    fun provideRoutePlanDao(db: DumpsterScoutDatabase): RoutePlanDao = db.routePlanDao()

    @Provides
    fun provideReminderDao(db: DumpsterScoutDatabase): ReminderDao = db.reminderDao()

    @Provides
    fun provideTireSpotDao(db: DumpsterScoutDatabase): TireSpotDao = db.tireSpotDao()

    @Provides
    fun provideTireReportDao(db: DumpsterScoutDatabase): TireReportDao = db.tireReportDao()

    @Provides
    fun provideFieldLocationDao(db: DumpsterScoutDatabase): FieldLocationDao = db.fieldLocationDao()

    @Provides
    fun provideFieldLocationReportDao(db: DumpsterScoutDatabase): FieldLocationReportDao = db.fieldLocationReportDao()

    @Provides
    fun provideCollectionDao(db: DumpsterScoutDatabase): CollectionDao = db.collectionDao()

    @Provides
    fun provideFieldSessionDao(db: DumpsterScoutDatabase): FieldSessionDao = db.fieldSessionDao()

    @Provides
    fun provideGearChecklistDao(db: DumpsterScoutDatabase): GearChecklistDao = db.gearChecklistDao()

}
