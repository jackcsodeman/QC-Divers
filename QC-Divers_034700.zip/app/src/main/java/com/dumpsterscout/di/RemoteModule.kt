package com.dumpsterscout.di

import android.content.Context
import com.dumpsterscout.data.remote.GeoBlacklistDataSource
import com.dumpsterscout.data.remote.GeoBlacklistDataSourceImpl
import com.dumpsterscout.data.remote.NoOpRemoteCollectionDataSource
import com.dumpsterscout.data.remote.NoOpRemoteGearChecklistDataSource
import com.dumpsterscout.data.remote.NoOpRemoteReminderDataSource
import com.dumpsterscout.data.remote.RemoteGearChecklistDataSource
import com.dumpsterscout.data.remote.RemoteReminderDataSource
import com.dumpsterscout.data.remote.RemoteLocationIdResolver
import com.dumpsterscout.data.remote.SupabaseGearChecklistDataSource
import com.dumpsterscout.data.remote.SupabaseReminderDataSource
import com.dumpsterscout.data.remote.NoOpRemoteFieldSessionDataSource
import com.dumpsterscout.data.remote.RemoteCollectionDataSource
import com.dumpsterscout.data.remote.RemoteFieldSessionDataSource
import com.dumpsterscout.data.remote.SupabaseCollectionDataSource
import com.dumpsterscout.data.remote.SupabaseFieldSessionDataSource
import com.dumpsterscout.data.remote.NoOpRemoteFieldLocationDataSource
import com.dumpsterscout.data.remote.NoOpRemoteFieldLocationReportDataSource
import com.dumpsterscout.data.remote.NoOpRemotePhotoDataSource
import com.dumpsterscout.data.remote.NoOpRemoteReportDataSource
import com.dumpsterscout.data.remote.SupabaseRouteDataSource
import com.dumpsterscout.data.remote.RemoteRouteDataSource
import com.dumpsterscout.data.remote.NoOpRemoteRouteDataSource
import com.dumpsterscout.data.remote.NoOpRemoteSpotDataSource
import com.dumpsterscout.data.remote.NoOpRemoteTireSpotDataSource
import com.dumpsterscout.data.remote.RemoteFieldLocationDataSource
import com.dumpsterscout.data.remote.RemoteFieldLocationReportDataSource
import com.dumpsterscout.data.remote.RemotePhotoDataSource
import com.dumpsterscout.data.remote.RemoteReportDataSource
import com.dumpsterscout.data.remote.RemoteSpotDataSource
import com.dumpsterscout.data.remote.RemoteTireSpotDataSource
import com.dumpsterscout.data.remote.SupabaseFieldLocationDataSource
import com.dumpsterscout.data.remote.SupabaseFieldLocationReportDataSource
import com.dumpsterscout.data.remote.SupabasePhotoDataSource
import com.dumpsterscout.data.remote.SupabaseReportDataSource
import com.dumpsterscout.data.remote.SupabaseSpotDataSource
import com.dumpsterscout.data.remote.SupabaseTireSpotDataSource
import com.dumpsterscout.di.annotations.RemoteSource
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import io.github.jan.supabase.SupabaseClient
import javax.inject.Singleton

/**
 * Hilt module that wires remote data source implementations.
 *
 * When a configured [SupabaseClient] is available (credentials set), real
 * Supabase-backed implementations are bound.  When the client is null
 * (local-only mode), no-op stubs are used so the rest of the app continues
 * to work unchanged.
 *
 * To migrate one source at a time, simply update the relevant `@Provides`
 * function in this module; nothing else needs to change.
 */
@Module
@InstallIn(SingletonComponent::class)
object RemoteModule {

    @Provides
    @Singleton
    @RemoteSource
    fun provideRemoteSpotDataSource(
        client: SupabaseClient?
    ): RemoteSpotDataSource =
        if (client != null) SupabaseSpotDataSource(client)
        else NoOpRemoteSpotDataSource()

    @Provides
    @Singleton
    @RemoteSource
    fun provideRemoteReportDataSource(
        client: SupabaseClient?
    ): RemoteReportDataSource =
        if (client != null) SupabaseReportDataSource(client)
        else NoOpRemoteReportDataSource()

    @Provides
    @Singleton
    @RemoteSource
    fun provideRemoteTireSpotDataSource(
        client: SupabaseClient?
    ): RemoteTireSpotDataSource =
        if (client != null) SupabaseTireSpotDataSource(client)
        else NoOpRemoteTireSpotDataSource()

    @Provides
    @Singleton
    @RemoteSource
    fun provideRemoteFieldLocationDataSource(
        client: SupabaseClient?
    ): RemoteFieldLocationDataSource =
        if (client != null) SupabaseFieldLocationDataSource(client)
        else NoOpRemoteFieldLocationDataSource()


    @Provides
    @Singleton
    @RemoteSource
    fun provideRemoteFieldLocationReportDataSource(
        client: SupabaseClient?
    ): RemoteFieldLocationReportDataSource =
        if (client != null) SupabaseFieldLocationReportDataSource(client)
        else NoOpRemoteFieldLocationReportDataSource()

    @Provides
    @Singleton
    @RemoteSource
    fun provideRemoteRouteDataSource(
        client: SupabaseClient?,
        locationIdResolver: RemoteLocationIdResolver
    ): RemoteRouteDataSource =
        if (client != null) SupabaseRouteDataSource(client, locationIdResolver)
        else NoOpRemoteRouteDataSource()


    @Provides
    @Singleton
    @RemoteSource
    fun provideRemoteCollectionDataSource(
        client: SupabaseClient?,
        locationIdResolver: RemoteLocationIdResolver
    ): RemoteCollectionDataSource =
        if (client != null) SupabaseCollectionDataSource(client, locationIdResolver)
        else NoOpRemoteCollectionDataSource()

    @Provides
    @Singleton
    @RemoteSource
    fun provideRemoteFieldSessionDataSource(
        client: SupabaseClient?,
        locationIdResolver: RemoteLocationIdResolver
    ): RemoteFieldSessionDataSource =
        if (client != null) SupabaseFieldSessionDataSource(client, locationIdResolver)
        else NoOpRemoteFieldSessionDataSource()


    @Provides
    @Singleton
    @RemoteSource
    fun provideRemoteReminderDataSource(
        client: SupabaseClient?
    ): RemoteReminderDataSource =
        if (client != null) SupabaseReminderDataSource(client)
        else NoOpRemoteReminderDataSource()

    @Provides
    @Singleton
    @RemoteSource
    fun provideRemoteGearChecklistDataSource(
        client: SupabaseClient?
    ): RemoteGearChecklistDataSource =
        if (client != null) SupabaseGearChecklistDataSource(client)
        else NoOpRemoteGearChecklistDataSource()

    @Provides
    @Singleton
    @RemoteSource
    fun provideRemotePhotoDataSource(
        client: SupabaseClient?,
        @ApplicationContext context: Context
    ): RemotePhotoDataSource =
        if (client != null) SupabasePhotoDataSource(client, context)
        else NoOpRemotePhotoDataSource()

    @Provides
    @Singleton
    fun provideGeoBlacklistDataSource(): GeoBlacklistDataSource = GeoBlacklistDataSourceImpl()
}

