package com.dumpsterscout.di

import com.dumpsterscout.data.repository.CommunityRepositoryImpl
import com.dumpsterscout.data.repository.PhotoRepositoryImpl
import com.dumpsterscout.data.repository.ReportRepositoryImpl
import com.dumpsterscout.data.repository.SpotRepositoryImpl
import com.dumpsterscout.data.repository.TireReportRepositoryImpl
import com.dumpsterscout.data.repository.TireSpotRepositoryImpl
import com.dumpsterscout.data.repository.UserRepositoryImpl
import com.dumpsterscout.domain.repository.CommunityRepository
import com.dumpsterscout.domain.repository.PhotoRepository
import com.dumpsterscout.domain.repository.ReportRepository
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.domain.repository.TireReportRepository
import com.dumpsterscout.domain.repository.TireSpotRepository
import com.dumpsterscout.domain.repository.UserRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindSpotRepository(impl: SpotRepositoryImpl): SpotRepository

    @Binds
    @Singleton
    abstract fun bindReportRepository(impl: ReportRepositoryImpl): ReportRepository

    @Binds
    @Singleton
    abstract fun bindTireSpotRepository(impl: TireSpotRepositoryImpl): TireSpotRepository

    @Binds
    @Singleton
    abstract fun bindTireReportRepository(impl: TireReportRepositoryImpl): TireReportRepository

    @Binds
    @Singleton
    abstract fun bindUserRepository(impl: UserRepositoryImpl): UserRepository

    @Binds
    @Singleton
    abstract fun bindPhotoRepository(impl: PhotoRepositoryImpl): PhotoRepository

    @Binds
    @Singleton
    abstract fun bindCommunityRepository(impl: CommunityRepositoryImpl): CommunityRepository
}

