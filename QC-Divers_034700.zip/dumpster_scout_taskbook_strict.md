# Dumpster Scout — Strict Agent Task Book

A stricter execution book for coding agents. This version is designed to reduce ambiguity and force precision.

For every task, the agent must answer these questions before editing code:
1. **What exactly is the task?**
2. **What files or modules are most likely involved?**
3. **What existing implementation must be inspected first?**
4. **What is the smallest safe implementation path?**
5. **How will the change be validated?**
6. **What is the rollback risk?**

## Mandatory agent operating contract

- Work **one phase or one vertical slice at a time**.
- Before editing, inspect the listed targets and map them to the real codebase.
- Preserve working behavior unless the task explicitly changes behavior.
- Prefer shared primitives over one-off inline fixes.
- For schema or persistence changes, add migrations/tests first or in the same batch.
- For risky refactors, keep a rollback-friendly boundary and avoid unrelated cleanup.
- Every completed batch must report:
  - files inspected
  - files edited
  - behavior changed
  - tests/previews run
  - unresolved risks

## Recommended execution order

1. Phase 0
2. Phase 1
3. Phase 2
4. Phase 3
5. Phase 4
6. Phase 5
7. Phase 6
8. Phase 7

## Task card format

Each task below includes:
- **Task**
- **Likely edit targets**
- **Inspect first**
- **Implementation steps**
- **Validation**
- **Rollback risk**

Use the real file names in the repository if they differ from the examples.

---

## Phase 0 — Foundations and build system
### Task 1 — Migrate from KAPT to KSP
**Likely edit targets**  
app/build.gradle.kts; feature module build.gradle.kts; gradle/libs.versions.toml
**Inspect first**  
Any custom annotation processor setup; current Room/Hilt compiler deps
**Implementation steps**  
1. Replace kapt plugins/config with ksp where supported
2. update compiler deps
3. remove kapt-only config
4. run clean build
**Validation / definition of done**  
Project builds on KSP only; generated code works; CI/local tests pass
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 2 — Add domain/usecase layer
**Likely edit targets**  
domain/usecase/*; ViewModels; repositories
**Inspect first**  
Large ViewModels; business rules in UI layer
**Implementation steps**  
1. Extract scoring, planning, grading, share/sync rules into injectable use cases
2. keep ViewModels orchestration-only
**Validation / definition of done**  
ViewModels slimmed down; use cases unit-tested
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 3 — Introduce DataResult<T>
**Likely edit targets**  
core/result/*; repositories; ViewModels
**Inspect first**  
Current nullable/error-prone return types
**Implementation steps**  
1. Create sealed result wrapper
2. migrate repository contracts and callers
3. centralize mapping of loading/success/error
**Validation / definition of done**  
Null/error branching reduced and standardized
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 4 — Add centralized ErrorHandler
**Likely edit targets**  
core/error/*; ViewModels; repositories
**Inspect first**  
Current scattered error messaging and exception handling
**Implementation steps**  
1. Map exceptions/domain failures to user-facing messages or UI models
**Validation / definition of done**  
Consistent error reporting and easier test coverage
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 5 — Decouple navigation callbacks
**Likely edit targets**  
ui/navigation/*; route composables; ViewModels
**Inspect first**  
Screens with many onNavigate lambdas
**Implementation steps**  
1. Introduce Navigator interface or route controller
2. reduce composable arg counts
**Validation / definition of done**  
Navigation logic centralized and screen signatures shrink
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 6 — Extract UiEvent sealed classes
**Likely edit targets**  
ui/state/*; all ViewModels
**Inspect first**  
Screens using ad hoc events or one-off booleans
**Implementation steps**  
1. Add explicit UiEvent classes/flows per screen for nav, snackbar, dialog, refresh
**Validation / definition of done**  
One-off events are explicit and consistent
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 7 — Add @Stable / @Immutable annotations
**Likely edit targets**  
ui/state/*; reusable UI models
**Inspect first**  
Mutable state models and recomposition hotspots
**Implementation steps**  
1. Annotate valid immutable/stable models
2. fix violations first
**Validation / definition of done**  
No invalid annotations; recomposition behavior improves
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 8 — Replace raw JSONArray tag serialization
**Likely edit targets**  
data/local/converter/*; entities; mappers
**Inspect first**  
Current List<String> serialization/deserialization
**Implementation steps**  
1. Add proper TypeConverter or serializer utility with tests
**Validation / definition of done**  
Tag storage is typed, tested, and migration-safe
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 9 — Module separation
**Likely edit targets**  
settings.gradle.kts; module build files; package structure
**Inspect first**  
Current package dependencies and feature boundaries
**Implementation steps**  
1. Split into core + feature modules incrementally
2. move shared APIs first
**Validation / definition of done**  
Modules compile with clear dependency graph
**Rollback risk**  
High
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 10 — Add DI scoping tests
**Likely edit targets**  
test/*; Hilt test modules
**Inspect first**  
Hilt bindings and component scopes
**Implementation steps**  
1. Add component tests covering singleton/viewmodel scoping and fake overrides
**Validation / definition of done**  
Scope regressions detectable by tests
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.


---

## Phase 1 — Persistence and performance
### Task 11 — Baseline Profiles
**Likely edit targets**  
benchmark/*; app/*; CI
**Inspect first**  
Critical startup and hot user flows
**Implementation steps**  
1. Add Macrobenchmark module
2. record launch and key navigation journeys
3. package generated profile
**Validation / definition of done**  
Release build includes baseline profile and benchmark artifact
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 12 — Room query optimization
**Likely edit targets**  
entities; DAOs; migrations
**Inspect first**  
Frequent filters/sorts: lat/lng, lastVisited, category, status
**Implementation steps**  
1. Add indexes and inspect DAO queries
2. migrate schema safely
**Validation / definition of done**  
Relevant queries are indexed and migration tests pass
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 13 — Paging 3 for long lists
**Likely edit targets**  
repositories; list/history ViewModels; screens
**Inspect first**  
Screens currently loading full lists into memory
**Implementation steps**  
1. Introduce PagingSource/Pager
2. adapt UI to LazyPagingItems
**Validation / definition of done**  
Long lists render incrementally without OOM risk
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 14 — Lazy image loading and Coil caching
**Likely edit targets**  
image loader config; media UI
**Inspect first**  
Current image requests and cache setup
**Implementation steps**  
1. Configure memory/disk cache, request sizing, thumbnails
**Validation / definition of done**  
Spot photos stop reloading aggressively
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 15 — derivedStateOf optimizations
**Likely edit targets**  
filter/list composables
**Inspect first**  
Expensive derived filters/sorts in composition
**Implementation steps**  
1. Move heavy derivations into derivedStateOf or ViewModel
**Validation / definition of done**  
Recomposition cost drops for filtered lists
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 16 — Flow debounce for search
**Likely edit targets**  
search ViewModels; repos
**Inspect first**  
Search query flow and DAO hits
**Implementation steps**  
1. Debounce text input before querying
2. cancel previous work
**Validation / definition of done**  
Typing no longer hammers Room
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 17 — WorkManager storage guard
**Likely edit targets**  
worker/*
**Inspect first**  
Current worker constraints
**Implementation steps**  
1. Add storage-not-low constraints and graceful skip behavior
**Validation / definition of done**  
Background work avoids low-storage writes
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 18 — Reduce initial composition cost
**Likely edit targets**  
HomeScreen; MapScreen; HistoryScreen
**Inspect first**  
Heavy always-composed subtrees
**Implementation steps**  
1. Defer expensive trees until visible/needed
2. stage composition
**Validation / definition of done**  
Cold open feels lighter and faster
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 19 — remember key hygiene audit
**Likely edit targets**  
major composables
**Inspect first**  
remember/rememberSaveable usage with unstable closures
**Implementation steps**  
1. Add stable keys
2. eliminate stale captures and invalid remember scopes
**Validation / definition of done**  
State bugs from stale closures reduced
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 20 — Profile recomposition hotspots
**Likely edit targets**  
Home/dashboard and top 5 screens
**Inspect first**  
Compose inspector data
**Implementation steps**  
1. Measure recompositions, patch highest-cost nodes, re-measure
**Validation / definition of done**  
Top 5 hotspots materially reduced
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.


---

## Phase 2 — Testing and DX
### Task 21 — Raise unit-test coverage
**Likely edit targets**  
test/* ViewModels and use cases
**Inspect first**  
Coverage report and lowest-covered critical logic
**Implementation steps**  
1. Add tests for listed ViewModels and complex use cases first
**Validation / definition of done**  
Coverage improves toward 80% with critical paths covered
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 22 — Add FakeTireSpotRepository
**Likely edit targets**  
test/fakes/*
**Inspect first**  
Current tire ViewModel tests using mocks or lacking coverage
**Implementation steps**  
1. Implement fake mirroring repository behavior and inject in tests
**Validation / definition of done**  
Tire tests no longer depend on heavy mocking
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 23 — VoiceParser edge-case tests
**Likely edit targets**  
test/voice/*
**Inspect first**  
Current parser coverage gaps
**Implementation steps**  
1. Add ambiguous times, punctuation, multi-item, Unicode/symbol cases
**Validation / definition of done**  
Parser edge cases covered without crashes
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 24 — TireVoiceParser tests
**Likely edit targets**  
test/voice/*
**Inspect first**  
Current tire parser behavior
**Implementation steps**  
1. Mirror dumpster parser coverage for tire voice input
**Validation / definition of done**  
Tire parser regressions become visible
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 25 — Navigation graph smoke tests
**Likely edit targets**  
androidTest/*; navigation graph
**Inspect first**  
All routes and route arguments
**Implementation steps**  
1. Add UI smoke test that visits each route and asserts expected headline
**Validation / definition of done**  
Broken navigation gets caught early
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 26 — Room migration tests
**Likely edit targets**  
androidTest/room/*; app/schemas/*
**Inspect first**  
All schema versions and migrations
**Implementation steps**  
1. Use MigrationTestHelper for each migration path
**Validation / definition of done**  
Every migration is verified
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 27 — WorkManager test harness
**Likely edit targets**  
test/worker/*
**Inspect first**  
Worker constructors and dependencies
**Implementation steps**  
1. Use TestListenableWorkerBuilder with fake deps
**Validation / definition of done**  
Workers are unit-tested deterministically
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 28 — Golden screenshot tests
**Likely edit targets**  
screenshotTest/*; key composables
**Inspect first**  
Reusable UI components and hero screens
**Implementation steps**  
1. Snapshot representative states using Paparazzi/Showkase
**Validation / definition of done**  
Visual regressions are reviewable
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 29 — Fuzz VoiceParser
**Likely edit targets**  
test/voice/*
**Inspect first**  
Parser robustness under random input
**Implementation steps**  
1. Add property/fuzz tests ensuring no uncaught exceptions
**Validation / definition of done**  
Random junk input never crashes parser
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 30 — Repository integration tests
**Likely edit targets**  
test/repository/*
**Inspect first**  
Spot and tire repository impls
**Implementation steps**  
1. Test against in-memory Room and real mappers
**Validation / definition of done**  
CRUD/query behavior verified without UI
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 79 — Add ktlint or detekt
**Likely edit targets**  
root Gradle; config files
**Inspect first**  
Current lint/static analysis state
**Implementation steps**  
1. Configure plugin, baseline, and CI gate
**Validation / definition of done**  
Style/static analysis runs locally and in CI
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 80 — Expand GitHub Actions
**Likely edit targets**  
.github/workflows/*
**Inspect first**  
Current pipeline triggers and jobs
**Implementation steps**  
1. Add PR/push validation for build/test/lint/bench where feasible
**Validation / definition of done**  
PRs are gated automatically
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 81 — Renovate or Dependabot
**Likely edit targets**  
.github/*
**Inspect first**  
Current dependency update process
**Implementation steps**  
1. Configure grouped dependency update PRs
**Validation / definition of done**  
Dependencies update automatically
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 82 — BuildConfig feature flags
**Likely edit targets**  
build.gradle.kts; feature flag wrapper
**Inspect first**  
Places using hardcoded feature toggles
**Implementation steps**  
1. Add buildConfigField-backed flags and a central access layer
**Validation / definition of done**  
Features can be toggled safely by build variant
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 83 — Opt-in local diagnostics export
**Likely edit targets**  
logging layer; settings; export util
**Inspect first**  
Current logging and privacy posture
**Implementation steps**  
1. Add privacy-safe log export with user consent
**Validation / definition of done**  
Recent diagnostics export on demand
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 84 — Room schema migration scripts
**Likely edit targets**  
app/schemas/*; migrations
**Inspect first**  
Current migration assets
**Implementation steps**  
1. Persist schema JSON/SQL and document version transitions
**Validation / definition of done**  
Schema history is versioned and testable
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 85 — ProGuard keep rules for Room
**Likely edit targets**  
proguard-rules.pro
**Inspect first**  
Release obfuscation config
**Implementation steps**  
1. Add/verify keep rules for entities, converters, schema access if needed
**Validation / definition of done**  
Release builds keep Room functioning
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 86 — API level lint checks
**Likely edit targets**  
lint config; source annotations
**Inspect first**  
SDK-int dependent code paths
**Implementation steps**  
1. Enable NewApi lint and add ChecksSdkIntAtLeast where needed
**Validation / definition of done**  
API misuse caught before runtime
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 87 — Centralized debug logging
**Likely edit targets**  
core/logging/*; replace Log.d uses
**Inspect first**  
Direct Android Log calls
**Implementation steps**  
1. Create DsLogger wrapper that is no-op or reduced in release
**Validation / definition of done**  
Logging is centralized and safe
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 88 — Add KDoc to public APIs
**Likely edit targets**  
repository interfaces; mappers; use cases
**Inspect first**  
Public APIs lacking documentation
**Implementation steps**  
1. Document contracts, parameters, and side effects
**Validation / definition of done**  
Public APIs are readable and self-explanatory
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.


---

## Phase 3 — UX and feature improvements
### Task 31 — Swipe-to-delete with undo
**Likely edit targets**  
SpotListScreen; HistoryScreen; delete use cases
**Inspect first**  
Current delete flow and Snackbar host
**Implementation steps**  
1. Add SwipeToDismiss + soft delete + undo Snackbar
**Validation / definition of done**  
Swipe delete works with undo window
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 32 — Pull-to-refresh
**Likely edit targets**  
SpotListScreen; viewmodels
**Inspect first**  
List refresh/state model
**Implementation steps**  
1. Add PullToRefresh container and explicit refresh path
**Validation / definition of done**  
User can force refresh without leaving screen
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 33 — Predictive back gesture
**Likely edit targets**  
navigation layer; route composables
**Inspect first**  
Back handling and Android 14 behavior
**Implementation steps**  
1. Adopt PredictiveBackHandler where supported
**Validation / definition of done**  
Back navigation feels modern on supported devices
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 34 — Long-press context menu
**Likely edit targets**  
SpotCard; TireSpotCard; list screens
**Inspect first**  
Card interaction patterns
**Implementation steps**  
1. Add long-press menus for edit/share/delete/common actions
**Validation / definition of done**  
Common actions reachable faster
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 35 — Haptic feedback
**Likely edit targets**  
destructive actions; sliders; toggles
**Inspect first**  
Current user feedback for key actions
**Implementation steps**  
1. Wire haptic APIs into critical interactions
**Validation / definition of done**  
Important interactions have tactile feedback
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 36 — Soft delete with 5-second undo
**Likely edit targets**  
repositories; DAO; delete flows
**Inspect first**  
Current delete semantics
**Implementation steps**  
1. Mark pending delete, schedule final removal, allow undo
**Validation / definition of done**  
Records can be restored during grace period
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 37 — Batch selection mode
**Likely edit targets**  
list screens; selection state; action bars
**Inspect first**  
Current list item selection and bulk ops
**Implementation steps**  
1. Add multi-select mode with bulk delete/tag/export
**Validation / definition of done**  
User can bulk-operate on spots
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 38 — Sort persistence
**Likely edit targets**  
DataStore; list ViewModels
**Inspect first**  
Current list sort/filter state
**Implementation steps**  
1. Persist selected sort option by screen/module
**Validation / definition of done**  
Sort survives restart
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 39 — Contextual search chips
**Likely edit targets**  
list/explore screens; filter state
**Inspect first**  
Most-used filters and existing filter sheet
**Implementation steps**  
1. Add inline one-tap chips for common queries
**Validation / definition of done**  
Fast filtering without opening sheet
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 40 — Scroll-to-top FAB
**Likely edit targets**  
SpotListScreen; HistoryScreen
**Inspect first**  
List scroll state
**Implementation steps**  
1. Show/hide animated FAB after threshold
2. scroll to top on tap
**Validation / definition of done**  
Long lists are easier to navigate
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 41 — Spot photo gallery
**Likely edit targets**  
spot detail/add-edit; media layer
**Inspect first**  
Current single-photo or no-photo support
**Implementation steps**  
1. Support multiple attachments and thumbnail rendering
**Validation / definition of done**  
Spots support multi-photo gallery
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 42 — Offline GPX export
**Likely edit targets**  
route domain; export layer
**Inspect first**  
Current route data model
**Implementation steps**  
1. Serialize saved routes to GPX and share/save file
**Validation / definition of done**  
Routes export successfully as GPX
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 43 — CSV export of spot history
**Likely edit targets**  
history repo; export util
**Inspect first**  
Current history model
**Implementation steps**  
1. Map history rows to CSV and export to safe storage
**Validation / definition of done**  
History export works and opens externally
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 44 — Barcode/QR scanner integration
**Likely edit targets**  
add/log flows; ML Kit integration
**Inspect first**  
Potential label/bin ID fields
**Implementation steps**  
1. Add scan entrypoint and parse payload into relevant fields
**Validation / definition of done**  
Scanner can populate supported fields
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 45 — Home-screen widget
**Likely edit targets**  
widget module; deep links
**Inspect first**  
Current summary metrics and quick actions
**Implementation steps**  
1. Add Glance widget with counts and quick-add shortcuts
**Validation / definition of done**  
Widget renders and deep-links correctly
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 46 — Scheduled revisit notifications
**Likely edit targets**  
WorkManager; notification layer
**Inspect first**  
Revisit cadence logic
**Implementation steps**  
1. Schedule reminders for high-grade spots with user-configurable cadence
**Validation / definition of done**  
Notifications fire correctly
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 47 — Dumpster heat map overlay
**Likely edit targets**  
MapScreen; map rendering utilities
**Inspect first**  
Current clustering/marker logic
**Implementation steps**  
1. Render density clusters/heat overlay from activity data
**Validation / definition of done**  
High-activity zones visible on map
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 48 — Street View deep-link
**Likely edit targets**  
spot detail actions
**Inspect first**  
Current map action area
**Implementation steps**  
1. Build Street View intent/fallback using coordinates
**Validation / definition of done**  
Street View action works where supported
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 49 — Duplicate spot detection
**Likely edit targets**  
add-spot use case; repo query
**Inspect first**  
Current add-spot save flow
**Implementation steps**  
1. Check nearby spots with Haversine distance before save
**Validation / definition of done**  
User gets duplicate warning within threshold
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 50 — Extend tire spot categories
**Likely edit targets**  
tire models; filters; theme/icons
**Inspect first**  
Current enum/category handling
**Implementation steps**  
1. Add FleetYard and Airport plus labels/icons/colors
**Validation / definition of done**  
New categories appear consistently
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 51 — Advanced voice commands
**Likely edit targets**  
VoiceParser; use cases; tests
**Inspect first**  
Current parser grammar and correction flow
**Implementation steps**  
1. Add haul ratings, multi-item parsing, correction interjections
**Validation / definition of done**  
Voice parser handles richer commands
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 52 — Custom tags autocomplete
**Likely edit targets**  
AddSpotScreen; tag repo/query
**Inspect first**  
Current tag input UX
**Implementation steps**  
1. Suggest existing tags as user types
**Validation / definition of done**  
Autocomplete improves tag entry
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 53 — Gear checklist templates
**Likely edit targets**  
gear checklist models/UI
**Inspect first**  
Current checklist persistence
**Implementation steps**  
1. Allow save/apply named presets
**Validation / definition of done**  
User can switch between templates
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 54 — Route ETA estimate
**Likely edit targets**  
route planner; domain/usecases
**Inspect first**  
Current route geometry and map data
**Implementation steps**  
1. Estimate ETA from waypoint geometry without network
**Validation / definition of done**  
Saved routes show ETA
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 55 — Dark map style
**Likely edit targets**  
Map resources; theme; MapScreen
**Inspect first**  
Current map styling
**Implementation steps**  
1. Apply custom dark/neon JSON style and theme switching
**Validation / definition of done**  
Map matches app identity
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.


---

## Phase 4 — Accessibility, privacy, localization, persistence
### Task 56 — Content descriptions audit
**Likely edit targets**  
all Icon/button/card composables
**Inspect first**  
Meaning-bearing icons and clickable graphics
**Implementation steps**  
1. Add content descriptions or explicit decorative nulls as appropriate
**Validation / definition of done**  
TalkBack gets correct semantics
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 57 — Minimum 48dp touch targets
**Likely edit targets**  
all interactive composables
**Inspect first**  
Compact controls and list rows
**Implementation steps**  
1. Apply minimumInteractiveComponentSize and spacing fixes
**Validation / definition of done**  
No important control is undersized
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 58 — Traversal order semantics
**Likely edit targets**  
dashboard/detail hero sections
**Inspect first**  
Current screen-reader order
**Implementation steps**  
1. Add traversal indices/semantics where reading order is illogical
**Validation / definition of done**  
TalkBack order is coherent
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 59 — Focus restoration after dialogs
**Likely edit targets**  
dialogs; sheets; triggering controls
**Inspect first**  
Current focus behavior on dismiss
**Implementation steps**  
1. Restore focus to trigger using focus requesters/accessibility manager
**Validation / definition of done**  
Focus returns correctly after overlays
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 60 — Color-blind safe palette
**Likely edit targets**  
theme tokens; badges; chips
**Inspect first**  
Current status color semantics
**Implementation steps**  
1. Audit WCAG contrast and add icon/text support where needed
**Validation / definition of done**  
Statuses remain understandable without pure color reliance
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 61 — Dynamic font scaling
**Likely edit targets**  
major screens; text-heavy cards
**Inspect first**  
Layouts under 200% font scale
**Implementation steps**  
1. Test at max scale
2. fix overflow/wrapping/ellipsis/marquee
**Validation / definition of done**  
Screens remain usable at high font scale
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 62 — Reduce motion option
**Likely edit targets**  
theme/animation layer
**Inspect first**  
Current animations vs system settings
**Implementation steps**  
1. Shorten/skip non-essential animations when motion disabled
**Validation / definition of done**  
Motion respects accessibility preference
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 63 — Encrypt in-app backups
**Likely edit targets**  
backup/export layer
**Inspect first**  
Current export format and key handling
**Implementation steps**  
1. Encrypt payload before writing to external storage
**Validation / definition of done**  
Backups export encrypted
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 64 — Per-spot redaction
**Likely edit targets**  
spot models; map/detail UI
**Inspect first**  
Current coordinate display rules
**Implementation steps**  
1. Add redaction flag and approximate display/mapping behavior
**Validation / definition of done**  
Sensitive spots can hide exact coordinates
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 65 — Screenshot prevention opt-in
**Likely edit targets**  
activity/window config; sensitive screens; settings
**Inspect first**  
Current screenshot policy
**Implementation steps**  
1. Add opt-in secure-flag handling for sensitive routes
**Validation / definition of done**  
Screenshots can be blocked when enabled
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 66 — DataStore encryption audit
**Likely edit targets**  
preferences layer
**Inspect first**  
Sensitive preference keys/values
**Implementation steps**  
1. Move sensitive prefs to encrypted storage strategy
**Validation / definition of done**  
Sensitive prefs no longer plain-text
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 67 — Location permission rationale
**Likely edit targets**  
permission flows; strings/dialogs
**Inspect first**  
Current system prompt handling
**Implementation steps**  
1. Add clear rationale dialog and denial fallback
**Validation / definition of done**  
Permission UX is clear and user-trustworthy
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 89 — Nightly database compaction
**Likely edit targets**  
workers; DB utilities
**Inspect first**  
Current DB maintenance strategy
**Implementation steps**  
1. Schedule safe VACUUM/maintenance when app idle/charging if needed
**Validation / definition of done**  
DB maintenance runs safely
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 90 — Weekly incremental backup
**Likely edit targets**  
backup worker; export util
**Inspect first**  
Current backup path and file management
**Implementation steps**  
1. Create timestamped backups in app external files dir
**Validation / definition of done**  
Periodic backups exist and do not crash
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 91 — DataStore key versioning
**Likely edit targets**  
preferences model
**Inspect first**  
Preference migration logic
**Implementation steps**  
1. Add schema version key and migration guards
**Validation / definition of done**  
App updates do not break prefs
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 92 — Spot archival policy
**Likely edit targets**  
repos; workers; filters; UI
**Inspect first**  
Active vs old spot handling
**Implementation steps**  
1. Archive stale spots after threshold with user-facing control/prompt
**Validation / definition of done**  
Old spots move out of active lists safely
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 93 — Tire report deduplication
**Likely edit targets**  
tire report use case; repo
**Inspect first**  
Current tire report save flow
**Implementation steps**  
1. Warn on same-location reports within threshold window
**Validation / definition of done**  
Likely duplicates are flagged
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 94 — Report delta diffing
**Likely edit targets**  
report models/storage layer
**Inspect first**  
Current report persistence volume
**Implementation steps**  
1. Store deltas or optimize write model without losing history semantics
**Validation / definition of done**  
Write amplification is reduced safely
**Rollback risk**  
High
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 95 — Extract hardcoded strings
**Likely edit targets**  
all UI files; strings.xml
**Inspect first**  
Remaining hardcoded user-facing text
**Implementation steps**  
1. Run lint/audit and move strings to resources
**Validation / definition of done**  
Hardcoded text is minimized
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 96 — Plural strings
**Likely edit targets**  
strings.xml; formatting utils; UI
**Inspect first**  
Count display strings
**Implementation steps**  
1. Replace manual count text with plurals resources
**Validation / definition of done**  
Counts localize correctly
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 97 — RTL support
**Likely edit targets**  
all layout modifiers; icons; previews
**Inspect first**  
Usage of left/right assumptions
**Implementation steps**  
1. Replace left/right with start/end and test RTL
**Validation / definition of done**  
Screens render correctly in RTL
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 98 — Locale date/time formatting
**Likely edit targets**  
format utils; UI
**Inspect first**  
Manual date formatting code
**Implementation steps**  
1. Use localized DateTimeFormatter/FormatStyle
**Validation / definition of done**  
Date/time respects device locale
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 99 — App shortcuts
**Likely edit targets**  
shortcuts.xml; manifest; intent handling
**Inspect first**  
Current deep links and launcher actions
**Implementation steps**  
1. Add static shortcuts for Add Spot, Voice Report, Field Mode
**Validation / definition of done**  
Launcher shortcuts work
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 100 — Review onboarding flow
**Likely edit targets**  
onboarding screens; DataStore
**Inspect first**  
Current onboarding copy/completion tracking
**Implementation steps**  
1. Add variant support and local completion counters
2. refine copy
**Validation / definition of done**  
Onboarding can be compared and improved
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.


---

## Phase 5 — Visual identity and premium polish
### Task 68 — Animated gradient hero
**Likely edit targets**  
HomeScreen; theme animations
**Inspect first**  
Hero surfaces and dashboard background
**Implementation steps**  
1. Add subtle animated gradient treatment with safe perf limits
**Validation / definition of done**  
Hero feels alive without hurting readability
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 69 — Custom app icon
**Likely edit targets**  
launcher assets; manifest
**Inspect first**  
Current launcher icon
**Implementation steps**  
1. Create adaptive icon with neon foreground and dark backing
**Validation / definition of done**  
Brand icon is custom and production-ready
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 70 — Lottie success animations
**Likely edit targets**  
save/report confirmation states
**Inspect first**  
Current success states and animations
**Implementation steps**  
1. Replace or augment basic success checkmarks with curated Lottie moments
**Validation / definition of done**  
Success feedback feels richer
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 71 — Spot grade donut chart
**Likely edit targets**  
spot detail UI; chart composable
**Inspect first**  
Current grade indicator UI
**Implementation steps**  
1. Implement animated donut/arc chart with accessible labels
**Validation / definition of done**  
Grade display is premium and legible
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 72 — Custom map markers
**Likely edit targets**  
MapScreen; marker generation utilities
**Inspect first**  
Default pin usage
**Implementation steps**  
1. Generate markers based on status/grade/category
**Validation / definition of done**  
Markers encode state visually
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 73 — Animated bottom-nav indicator
**Likely edit targets**  
navigation bar component
**Inspect first**  
Current tab indicator
**Implementation steps**  
1. Build animated pill/indicator across tabs
**Validation / definition of done**  
Bottom nav feels custom and polished
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 74 — Skeleton loading screens
**Likely edit targets**  
loading states across major screens
**Inspect first**  
Current blank/loading UX
**Implementation steps**  
1. Add shimmer placeholders for list/detail/dashboard loading
**Validation / definition of done**  
Loading states look intentional
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 75 — Dark splash screen
**Likely edit targets**  
splash theme; launcher flow
**Inspect first**  
Current startup theme
**Implementation steps**  
1. Use deep-dark background and branded accent animation/logo
**Validation / definition of done**  
Splash matches visual identity
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 76 — Contextual/shared transitions
**Likely edit targets**  
navigation transitions; SpotCard -> detail
**Inspect first**  
Current nav animation support
**Implementation steps**  
1. Use shared-element or contextual transitions where stable
**Validation / definition of done**  
Card-to-detail feels seamless
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 77 — Pull-quote empty states
**Likely edit targets**  
HistoryScreen; other empty states
**Inspect first**  
Generic empty copy
**Implementation steps**  
1. Add rotating tasteful empty-state quotes with fallback copy
**Validation / definition of done**  
Empty states feel branded, not placeholder
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 78 — Neon glow map overlay
**Likely edit targets**  
MapScreen; Canvas overlay
**Inspect first**  
Current user-location rendering
**Implementation steps**  
1. Add optional subtle radial glow around user in field mode/dark mode
**Validation / definition of done**  
Map atmosphere upgrades without harming readability
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 101 — Cyber-neon dark mode escalation
**Likely edit targets**  
ui/theme/*; token system; major screens
**Inspect first**  
Current dark theme and accent model
**Implementation steps**  
1. Introduce richer neon-accent palette, semantic gradients, glow-capable tokens, stronger contrast surfaces
**Validation / definition of done**  
Dark theme feels intentionally cyber-neon and still readable
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 102 — Module-specific visual identities
**Likely edit targets**  
theme tokens; dashboard cards; screen headers
**Inspect first**  
Current shared styling for dumpsters/tires/voice/community
**Implementation steps**  
1. Give dumpster, tire, voice, and community surfaces distinct accent families within one system
**Validation / definition of done**  
Modules are instantly distinguishable without fragmentation
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 103 — Voice flow hero treatment
**Likely edit targets**  
voice screens; mic button; success states
**Inspect first**  
Current voice-report visuals
**Implementation steps**  
1. Add richer microphone states, transcript panels, parse confidence visuals, vivid success feedback
**Validation / definition of done**  
Voice flow becomes a standout premium interaction
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 104 — Field mode tactical styling
**Likely edit targets**  
Field mode screens; theme tokens
**Inspect first**  
Current field mode visuals
**Implementation steps**  
1. Increase contrast, simplify layout, enlarge controls, add tactical night-use feel
**Validation / definition of done**  
Field mode is faster and clearer outdoors/at night
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 105 — Global consistency cleanup after neon pass
**Likely edit targets**  
shared components; all major screens
**Inspect first**  
Any mismatched chips/cards/buttons/colors/motion
**Implementation steps**  
1. Normalize variants, spacing, elevation, gradients, and status presentation
**Validation / definition of done**  
Full app feels like one coherent design system
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.


---

## Phase 6 — Community and shared-platform foundations
### Task 106 — Backend-ready entity metadata
**Likely edit targets**  
domain models; Room entities; remote DTOs
**Inspect first**  
Current local-only IDs and ownership assumptions
**Implementation steps**  
1. Add owner IDs, remote IDs, timestamps, sync status, visibility, verification, soft-delete metadata
**Validation / definition of done**  
Entities can participate in local+remote sync cleanly
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 107 — Hybrid local/private/shared visibility model
**Likely edit targets**  
repositories; UI state; detail/list screens
**Inspect first**  
Current private/shared assumptions
**Implementation steps**  
1. Implement local-only, private-cloud, shared-community visibility states
**Validation / definition of done**  
User can understand and control visibility
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 108 — Supabase-ready repository split
**Likely edit targets**  
data/repository/*; remote layer; DI
**Inspect first**  
Current repository architecture
**Implementation steps**  
1. Separate local and remote data sources
2. keep local-first behavior intact
**Validation / definition of done**  
Repos can support hybrid sync without chaos
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 109 — Auth-ready account/profile scaffolding
**Likely edit targets**  
auth layer; settings/account UI; profile models
**Inspect first**  
Current identity handling
**Implementation steps**  
1. Add account/session state, profile-ready model, signed-in vs signed-out UX hooks
**Validation / definition of done**  
User identity is real without forcing full social features
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 110 — First real dumpster sync vertical slice
**Likely edit targets**  
dumpster spot/report repos; detail/report UI; settings/help
**Inspect first**  
Current partial cloud implementation
**Implementation steps**  
1. Finish local/private/shared sync for dumpster spots and reports end to end
**Validation / definition of done**  
One real synced vertical slice works fully
**Rollback risk**  
High
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 111 — First real tire sync vertical slice
**Likely edit targets**  
tire spot/report repos; detail/report UI
**Inspect first**  
Dumpster sync implementation for reuse
**Implementation steps**  
1. Mirror the completed dumpster sync/share path for tire entities
**Validation / definition of done**  
Tire spots/reports support real hybrid sync/share
**Rollback risk**  
High
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 112 — Community read integration in explore/map
**Likely edit targets**  
map/list/detail screens; filters
**Inspect first**  
Current shared-content visibility in UI
**Implementation steps**  
1. Load and present shared community spots cleanly with ownership/visibility badges and filters
**Validation / definition of done**  
Shared content feels real and understandable
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 113 — Private vs shared note separation
**Likely edit targets**  
detail screens; data models
**Inspect first**  
Current note/report display model
**Implementation steps**  
1. Separate personal-only notes from shared/public content where needed
**Validation / definition of done**  
Private data is not accidentally exposed
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 114 — Moderation/reporting groundwork
**Likely edit targets**  
domain models; remote tables; minimal UI entry points
**Inspect first**  
Current shared-content safety model
**Implementation steps**  
1. Add moderation flags/status structures and minimal report-content path
**Validation / definition of done**  
Shared content can be flagged and modeled safely
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 115 — Trust/verification signals
**Likely edit targets**  
detail/list badges; profile/contributor models
**Inspect first**  
Current verification presentation
**Implementation steps**  
1. Add contributor/spot verification-ready signals and UI badges
**Validation / definition of done**  
Community content can surface trust cues
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 116 — Shared activity feeds on details
**Likely edit targets**  
detail screens; repos
**Inspect first**  
Current report history UX
**Implementation steps**  
1. Read and show community-shared recent reports/activity for spots
**Validation / definition of done**  
Shared layer is visible where useful
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 117 — Community-safe seeded demo data
**Likely edit targets**  
seed/demo data layer
**Inspect first**  
Current demo data strategy
**Implementation steps**  
1. Keep Quad Cities-oriented but safe sample data
2. mark approximate/demo/verified states clearly
**Validation / definition of done**  
Demo experience is rich without exposing private target data
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 118 — About/help/community copy refresh
**Likely edit targets**  
About; Help; onboarding; settings
**Inspect first**  
Current copy about privacy/local/community
**Implementation steps**  
1. Update wording to explain local vs synced vs shared behavior accurately
**Validation / definition of done**  
Product messaging matches actual functionality
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.


---

## Phase 7 — Hardening, beta, release
### Task 119 — Launch-blocker sweep
**Likely edit targets**  
all major flows; issue audit doc
**Inspect first**  
Current top crash/usability risks
**Implementation steps**  
1. Audit must-fix/should-fix/defer
2. fix highest-value blockers first
**Validation / definition of done**  
App has honest ship-readiness summary and top blockers removed
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 120 — Demo/store-ready sample states
**Likely edit targets**  
seed data; key screens; previews
**Inspect first**  
Current populated states for screenshots/demos
**Implementation steps**  
1. Curate screenshot-worthy data and polish hero screens/empty states
**Validation / definition of done**  
Major screens are presentable for demos/store
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 121 — Store listing copy + screenshot plan
**Likely edit targets**  
docs or release assets; in-app copy if needed
**Inspect first**  
Current product positioning and screen set
**Implementation steps**  
1. Draft short/long descriptions, feature bullets, screenshot sequence, message per shot
**Validation / definition of done**  
Product is easier to present and market
**Rollback risk**  
Low
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.

### Task 122 — Final release-candidate bug bash
**Likely edit targets**  
all critical screens; tests; CI
**Inspect first**  
Post-polish remaining issues
**Implementation steps**  
1. Fix regressions, weak states, preview failures, remaining accessibility/perf gaps
**Validation / definition of done**  
App reaches release-candidate quality bar
**Rollback risk**  
Medium
**Agent note**  
Keep the change narrowly scoped. If this task touches shared primitives or persistence, complete the supporting tests in the same batch.


---

## High-confidence execution batches

These are the safest and most useful batch groupings for an agent:

### Batch A — Build and architecture hygiene
- Tasks 1–8
- Stop before module extraction if the codebase is not already modularizing cleanly.

### Batch B — Performance and data correctness
- Tasks 11–20
- Pair with migration and benchmark validation.

### Batch C — Testing and CI hardening
- Tasks 21–30 and 79–88
- Keep this batch code-quality focused.

### Batch D — UX speedups and workflow polish
- Tasks 31–40 and 41–55
- Prioritize user-visible value without destabilizing persistence.

### Batch E — Accessibility, privacy, and persistence safety
- Tasks 56–67 and 89–100
- Good pre-release hardening batch.

### Batch F — Visual escalation and design-system cleanup
- Tasks 68–78 and 101–105
- Do this after shared components are stable.

### Batch G — Community/cloud readiness
- Tasks 106–118
- Execute as vertical slices, not all at once.

### Batch H — Final release hardening
- Tasks 119–122
- Last serious build batch before release.

---

## Exact prompt template for an agent batch

Use this structure when giving the agent a batch from this file:

1. Name the phase and task IDs.
2. Tell the agent to inspect the listed targets first.
3. Tell the agent to reuse current code as source of truth.
4. Tell the agent to complete implementation + validation in one pass.
5. Tell the agent to report files inspected, files changed, tests run, and remaining risks.

Example:

> Execute Phase 3, Tasks 31–36 only. Inspect the likely edit targets first and continue from the current implementation rather than rewriting from scratch. Keep the scope tightly limited to swipe-to-delete, undo, pull-to-refresh, predictive back, long-press context menus, and haptic feedback. Preserve existing behavior outside those flows. Report exactly what files were inspected, what files were changed, what tests/previews were run, and what risks remain.

---

## Notes on “insane” visual upgrades and community expansion

If you want to push the app harder than the original list:
- run Phase 5 earlier, but only after shared UI primitives are clean
- do community work as vertical slices, not giant prompts
- after the community read layer works, prioritize moderation/reporting/trust before broad social features
- never mix a big neon UI overhaul with schema/sync refactors in the same batch
