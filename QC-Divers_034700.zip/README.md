# Dumpster Scout / QC Divers

Dumpster Scout is a native Android, Kotlin, Jetpack Compose app for offline-first field scouting. It tracks dumpster spots, tire spots, cleanup/salvage/custom field locations, reports, favorites, collections, maps, routes, field sessions, persisted gear checklists, field mode, voice reports, photos, reminders, analytics, backup/restore, and optional Supabase-backed sync.

The app is private and local-first by default. Supabase is optional: the app must remain useful with no account and no network.

> Safety and respect: respect private property, obey local rules, avoid unsafe sites, leave no mess, and do not trespass.

## Current product truth

This repository is **not** a purely local-only app anymore. It includes optional account and Supabase sync scaffolding:

- Supabase Auth client wiring
- Supabase PostgREST data sources
- Supabase Storage photo upload data source
- no-op remote data sources for local-only mode
- WorkManager sync/upload workers
- visibility and sync status metadata
- a durable local `sync_queue` outbox foundation
- deployable Supabase SQL migrations and storage/RLS policies under `supabase/`

Local-only mode is still supported and must remain the default if Supabase credentials are not provided.

## Stack

- Kotlin
- Jetpack Compose
- Material 3
- Navigation Compose
- Room
- DataStore
- Hilt
- WorkManager
- Google Maps Compose
- Coil
- Accompanist permissions
- Supabase Kotlin SDK
- Ktor Android client
- JUnit 4 / MockK / Turbine / coroutine tests

## Android configuration

- `applicationId`: `com.dumpsterscout`
- `compileSdk`: 36
- `targetSdk`: 35
- `minSdk`: 26
- `versionName`: 1.0.0
- `versionCode`: 1
- Gradle wrapper: see `gradle/wrapper/gradle-wrapper.properties`
- Dependency versions: `gradle/libs.versions.toml`

## Setup

### Required for local build

```bash
chmod +x gradlew
./gradlew assembleDebug -PMAPS_API_KEY=""
./gradlew test -PMAPS_API_KEY=""
```

A real Google Maps API key is optional for compile-only checks. To use maps on device, provide the key outside source control:

```properties
MAPS_API_KEY=your_maps_key
```

Recommended locations:

- `~/.gradle/gradle.properties`
- local untracked `gradle.properties`
- CI secrets

### Optional Supabase configuration

Provide these Gradle properties outside source control:

```properties
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your_publishable_or_anon_key
```

Never commit service-role keys, signing keys, production secrets, or test account passwords.

When credentials are missing, the app uses no-op remote data sources and runs in local-only mode.

## Supabase backend

Backend artifacts live in:

```text
supabase/migrations/
supabase/verification/
```

Apply migrations in order before enabling production sync:

1. `202605180001_core_schema.sql`
2. `202605180002_private_storage.sql`
3. `202605220001_route_stop_metadata.sql`
4. `202605220002_field_sessions.sql`
5. `202605220003_gear_reminder_sync_hardening.sql`
6. `202605220004_field_location_reports_reminder_state.sql`

The storage bucket `spot-photos` is private by default. The Android app stores private storage references such as `supabase://spot-photos/<path>` rather than permanent public URLs.

## Build and release

Debug build:

```bash
./gradlew assembleDebug -PMAPS_API_KEY=""
```

Unit tests:

```bash
./gradlew test -PMAPS_API_KEY=""
```

Release bundle smoke build:

```bash
./gradlew bundleRelease -PMAPS_API_KEY=""
```

A Play Store production release still requires signing configuration, Play App Signing/upload-key setup, privacy policy, Data Safety form, screenshots, store listing, and closed/internal testing. See:

- `docs/release/RELEASE_CHECKLIST.md`
- `docs/release/IMPLEMENTATION_COMPLETION_REPORT.md`
- `docs/play-store/PLAY_STORE_READINESS.md`
- `docs/privacy/PRIVACY_POLICY_DRAFT.md`
- `docs/privacy/DATA_SAFETY_GUIDANCE.md`

## Important limitations

This repository is materially stronger after the stabilization pass, but it is not fully complete yet.

Known remaining work:

- run a real Gradle build in a network-enabled environment
- regenerate Room schema v7 with annotation processing and verify checked-in schemas
- add Room migration tests for all migration paths beyond the included 4->5 smoke test
- expand conflict resolution from retry/review to field-level local-vs-remote merge
- extend photo capture/gallery parity to tire spots, reports, cleanup sites, and salvage/resource records
- polish reminder edit/detail/history flows after the local scheduler
- add advanced analytics charts/date filters and route/session integration
- wire Android account deletion UI to the Supabase Edge Function
- complete Play Store release artifacts with real screenshots and signing details

## Architecture notes

The current architecture should remain native Android:

```text
UI screens -> ViewModels -> domain repositories -> data repositories -> Room/Supabase data sources
```

Room is the local source of truth. Supabase is a remote sync target only when the user opts in.

## CI

GitHub Actions now provides:

- debug build and unit test workflow on push/pull request
- manual unsigned release AAB smoke build
- Copilot setup workflow without hardcoded API keys

## License

Personal use unless a separate license is added.


## Release verification

Use `scripts/verify_release.sh` in a network-enabled Android environment to run clean, unit tests, instrumentation tests, debug build, and release bundle generation. This sandbox could not complete Gradle verification because it cannot download the Gradle wrapper distribution.

Release signing is configured through Gradle properties only; keystores and signing passwords must never be committed. See `docs/release/SIGNING_AND_RELEASE.md`.

Play Store prep docs live under `docs/play-store/`, and privacy/Data Safety materials live under `docs/privacy/`.

## Slow CPU / high-RAM Android Studio profile

For a slower CPU with plenty of RAM, apply the non-secret Gradle tuning profile:

```bash
./scripts/apply_slow_gradle_profile.sh gradle.properties
```

This script preserves your Maps, Supabase, and signing values while updating only Gradle performance keys. The clean source archive intentionally excludes `gradle.properties`, `local.properties`, IDE state, and build outputs because those files can contain local secrets or generated machine-specific state.

### Latest source-level sync coverage

The app currently has durable outbox processing for dumpster/tire/photo domains plus field locations, field-location reports, routes, collections, field sessions, reminders, and gear checklists. Normalized child rows for route stops, collection items, field-session visits, and gear checklist items now have remote metadata and remote pull contracts. Build/device verification is still required on a network-enabled Android environment.

## Current database/source status

The latest source-only progress package uses Room database version 13. Version 10 adds conflict-resolution metadata to the durable sync queue. If you update from an older package, regenerate the Room schema locally with the normal Gradle build before treating the exported schema as final.

For the Android Studio AI testing/fix workflow, see:

- `docs/testing/ANDROID_STUDIO_AGENT_TEST_AND_FIX_PROMPT.md`


## Supabase setup and community/sync configuration

Complete Supabase setup instructions now live in:

- `docs/supabase/SUPABASE_FULL_SETUP.md`
- `docs/supabase/COMMUNITY_AND_SYNC_SETUP.md`
- `docs/supabase/SYNC_OPERATION_MATRIX.md`
- `supabase/verification/community_and_sync_checks.sql`

Use these before enabling optional cloud sync or any community/public visibility UI in production.


## Latest source-only runtime hardening

The current source targets Room database version 13. It adds remote metadata and remote pull coverage for normalized child rows: route stops, collection items, field-session visits, and gear checklist items. It also moves backup export/import to Android Storage Access Framework, routes reminder notification taps into the app, and adds map preview external navigation plus marker-count safeguards. These changes require Android Studio/Gradle verification, Room schema regeneration, and device/Supabase staging tests before release claims are made.

### Latest source-only hardening notes

The latest source-only package adds map clustering readiness, stronger map accessibility labels, reminder scheduling unit tests, WorkManager test dependency scaffolding, and optional Supabase community-moderation readiness docs/migrations. These changes are source-level only and require a local Android Studio/Gradle build before release claims.

For first release, keep community/public sharing disabled unless reporting, blocking, moderation review, privacy policy updates, Data Safety updates, and Play content-rating answers are all completed and verified.

Optional Supabase moderation-readiness migration:

```text
supabase/migrations/202605220006_community_moderation_readiness.sql
```

Deploy this only when preparing public/community sharing moderation support. It is not required for private/local-first sync-only release behavior.
