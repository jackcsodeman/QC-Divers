# Dumpster Scout

A private, offline-first Android app for personal dumpster-diving field notes, route planning, and tire-spot tracking. Built with Kotlin, Jetpack Compose, and Material 3.

> ⚠️ **Safety & Respect:** Always respect private property, leave no mess, and comply with local laws. This app is for personal organization only.

---

## Features

### Core
- 📍 **Dumpster spot database** — Save locations with GPS, access notes, schedule, grading, tags, and visit history
- 🛞 **Tire spot tracking** — Maintain a parallel tire-spot flow with dedicated list, detail, report, history, and voice screens
- 🎤 **Dual voice reporting** — Speak quick dumpster or tire updates and confirm parsed results before saving
- 🗺️ **Map view** — See saved spots on a Google Map with color-coded status markers
- 📋 **History & favorites** — Review report history and keep high-value spots pinned
- 🧭 **Routes & field tools** — Save multi-stop routes, use field mode at night, and keep a gear checklist handy

### Grading Model
Each spot gets a multi-dimensional grade:
- Overall, Consistency, Quality, Quantity, Cleanliness (higher = better)
- Risk, Access Difficulty, Legal Sensitivity (lower = better)

### Voice Parser
The deterministic parser handles utterances like:
- *"Trader Joe's dumpster is empty today"*
- *"CVS on Main had bakery bags tonight"*
- *"The apartment complex by Oak Street got locked up"*
- *"good today"*, *"locked today"*, *"security came by"*

### Field Mode
Larger controls and improved night-time readability for use in the dark.

### Current status
- ✅ `assembleDebug` is green
- ✅ `test` is green
- ✅ Current stable toolchain: AGP 8.9.2, Gradle 8.11.1, Kotlin 2.2.0, Hilt 2.57, AndroidX Hilt 1.3.0
- ✅ Current Android config: `compileSdk 36`, `minSdk 26`, `targetSdk 35`

---

## Architecture

```
com.dumpsterscout/
├── di/                     Hilt DI modules
├── data/
│   ├── local/              Room database, entities, DAOs
│   ├── preferences/        DataStore (AppPreferences)
│   ├── mapper/             Entity ↔ Domain mappers
│   └── repository/         *RepositoryImpl classes
├── domain/
│   ├── model/              DumpsterSpot, PersonalReport, SpotGrade, VoiceParseResult…
│   └── repository/         SpotRepository, ReportRepository (interfaces)
├── ui/
│   ├── theme/              Color, Type, Theme (Material 3 + field mode)
│   ├── navigation/         Screen sealed class, NavGraph
│   ├── home/               HomeScreen + HomeViewModel
│   ├── spots/              SpotListScreen, SpotDetailScreen, AddSpotScreen + SpotViewModel
│   ├── tire/               TireSpot screens, tire reports, tire history, tire voice flow
│   ├── voice/              VoiceReportScreen + VoiceViewModel
│   ├── history/            HistoryScreen + HistoryViewModel
│   ├── map/                MapScreen + MapViewModel
│   ├── settings/           SettingsScreen + SettingsViewModel
│   ├── onboarding/         OnboardingScreen
│   ├── gear/               GearChecklistScreen
│   ├── field/              FieldModeScreen
│   ├── about/              AboutScreen
│   ├── favorites/          FavoritesScreen
│   ├── routes/             SavedRoutesScreen + RoutePlanViewModel
│   └── components/         SpotCard, StatusChip, GradeCard
├── util/
│   ├── VoiceParser.kt      Deterministic NLP parser
│   ├── SampleData.kt       Demo seed data
│   └── Extensions.kt       Date/time helpers
├── DumpsterScoutApp.kt     Hilt Application
└── MainActivity.kt         Single-activity host
```

### Key decisions
- **Single activity** with Navigation Compose for all routing
- **Unidirectional data flow**: ViewModel → StateFlow → UI events
- **Offline-first**: Room DB + DataStore for all user data
- **Hilt** for all dependency injection
- **VoiceParser** / **TireVoiceParser** are pure Kotlin parsers for easy unit testing

---

## Setup

### Prerequisites
- Recent Android Studio release with Android SDK 36 installed
- Java 17 for local development
- JDK 21 is used in GitHub Actions CI

### Google Maps API Key
1. Get a key from [Google Cloud Console](https://console.cloud.google.com/)
2. Enable Maps SDK for Android
3. Add to your Gradle properties (for example `~/.gradle/gradle.properties` or `<project-root>/gradle.properties`):
   ```
   MAPS_API_KEY=your_actual_key_here
   ```
4. For build-only validation, the repository defaults this placeholder to an empty string, so `assembleDebug` and `test` can run without a real key.

### Build
```bash
./gradlew assembleDebug -PMAPS_API_KEY=""
```

### Run Tests
```bash
./gradlew test -PMAPS_API_KEY=""
```

---

## Privacy

- All data stays **on-device** only
- No accounts, no cloud sync, no analytics
- No public sharing, feeds, or community features

---

## License

Personal use. Not affiliated with any business or establishment.
