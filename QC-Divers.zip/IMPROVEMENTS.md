# Dumpster Scout — 100 Ways to Upgrade, Improve, and Optimize

A living backlog of improvements across architecture, UX, performance, testing, features, and polish.
Items are grouped by theme; priority labels are indicative only.

---

## Architecture & Code Quality

1. **Migrate from KAPT to KSP** — Replace `kotlin-kapt` with `com.google.devtools.ksp` for Room and Hilt annotation processing. KSP is 2× faster and the recommended path going forward.
2. **Add a `domain/usecase/` layer** — Extract complex business logic (spot scoring, route planning, haul grading) out of ViewModels into dedicated use-case classes for cleaner, testable logic.
3. **Introduce a `Result<T>` wrapper** — Standardize all repository return types with `sealed class DataResult<T>` (Success, Error, Loading) to eliminate null-checks scattered across ViewModels.
4. **Add a centralized `ErrorHandler`** — Map domain exceptions to user-facing string resources instead of handling errors ad-hoc in each ViewModel.
5. **Decouple navigation callbacks** — Replace individual `onNavigateTo*` lambdas with a single `Navigator` interface injected via Hilt to reduce composable parameter count.
6. **Extract `UiEvent` sealed classes** — Ensure every screen's ViewModel has a properly sealed `UiEvent` hierarchy for consistent state management.
7. **Add `@Stable` / `@Immutable` annotations** — Annotate all UiState data classes so Compose can skip unnecessary recompositions.
8. **Replace raw `JSONArray` tag serialization** — Add a proper `@TypeConverter` or a custom `TagSerializer` utility to handle `List<String>` → `String` more robustly and consistently across all entities.
9. **Module separation** — Extract `:core`, `:feature-spots`, `:feature-tires`, `:feature-routes`, `:feature-voice` Gradle modules to speed up incremental builds and enforce clear API boundaries.
10. **Add dependency-injection scoping tests** — Verify Hilt component scoping (Singleton vs. ViewModel) with component tests to catch accidental leaks.

---

## Performance

11. **Baseline Profiles** — Generate a Baseline Profile with Macrobenchmark to achieve 20–40% faster cold-start launch for the app.
12. **Room query optimization** — Add explicit `@Index` annotations on `DumpsterSpotEntity.latitude`, `longitude`, `lastVisited`, and `category` columns for geo-proximity queries.
13. **Paging 3 for long lists** — Replace `List<DumpsterSpot>` flows with `PagingData<DumpsterSpot>` for SpotListScreen and HistoryScreen to prevent OOM on large datasets.
14. **Lazy image loading** — Add Coil disk caching configuration for spot photos so they don't reload on every recomposition.
15. **`derivedStateOf` optimizations** — Wrap expensive list-filtering derivations in `derivedStateOf { }` blocks in composables to reduce spurious recompositions.
16. **Flow debounce for search** — Debounce search-query state updates (300 ms) before triggering database queries to avoid high-frequency Room hits while typing.
17. **WorkManager background sync guard** — Add a `Constraints.Builder().setRequiresStorageNotLow(true)` constraint to any background archival workers to avoid writes during low-storage conditions.
18. **Reduce initial composition cost** — Defer heavy composable subtrees (map clusters, history charts) with `LaunchedEffect` + visibility tracking instead of always composing them eagerly.
19. **Compose `remember` key hygiene** — Audit all `remember { }` and `rememberSaveable { }` calls to ensure stable keys and avoid stale closures.
20. **Profile recomposition counts** — Run the Compose layout inspector in production builds to measure and eliminate top 5 hotspot recompositions on HomeScreen.

---

## Testing

21. **Raise unit-test coverage to ≥ 80%** — Add tests for AddSpotViewModel, HistoryViewModel, SpotListViewModel, SettingsViewModel, MapViewModel, and RoutePlanViewModel.
22. **Add `FakeTireSpotRepository`** — Implement the fake for tire spots (parallel to FakeSpotRepository) so tire-related ViewModel tests don't need MockK.
23. **Add VoiceParser edge-case tests** — Cover multi-item haul phrases, special-character location strings, and ambiguous time phrases (e.g., "yesterday evening").
24. **Add `TireVoiceParser` unit tests** — Mirror the VoiceParserTest coverage for TireVoiceParser.
25. **Navigation graph smoke tests** — Add a Compose UI test that navigates through each route and asserts the correct screen headline is visible.
26. **Room migration tests** — Use `MigrationTestHelper` to test each Room migration script as the schema evolves.
27. **WorkManager test harness** — Wire up `TestListenableWorkerBuilder` to unit-test any scheduled workers.
28. **Golden screenshot tests** — Add snapshot tests (Paparazzi or Showkase) for key composables (SpotCard, GradeCard, StatusChip) to catch unintentional visual regressions.
29. **Fuzz inputs for VoiceParser** — Add property-based fuzzing (kotlinx-test) over random strings to ensure VoiceParser never throws uncaught exceptions.
30. **Add integration tests for repository impls** — Test `SpotRepositoryImpl` and `TireSpotRepositoryImpl` against an in-memory Room database.

---

## UX & Interaction

31. **Swipe-to-delete on list items** — Add `SwipeToDismiss` gesture on SpotListScreen and HistoryScreen cards with an undo Snackbar (Material 3 spec).
32. **Pull-to-refresh** — Implement `PullToRefreshBox` on SpotListScreen so users can force-reload sorted/filtered lists.
33. **Predictive back gesture** — Add Predictive Back animation support (Android 14+) across all navigation pops using `BackHandler` + `PredictiveBackHandler`.
34. **Long-press context menu** — Add long-press action menus on SpotCard (Quick Edit, Share Note, Delete) to speed up common workflows.
35. **Haptic feedback** — Add `HapticFeedback.performHapticFeedback(HapticFeedbackType.LongPress)` for destructive actions and `HapticFeedbackType.TextHandleMove` for slider adjustments.
36. **Undo delete** — Implement soft-delete with a 5-second undo window before records are permanently removed from Room.
37. **Batch selection mode** — Add a multi-select mode on SpotListScreen to bulk-delete, bulk-tag, or bulk-export spots.
38. **Sort persistence** — Persist the user's last-chosen sort order (by grade, by date, by category) in DataStore so it survives app restarts.
39. **Contextual search chips** — Surface inline filter chips (Today, High Grade, Favorites) directly above the spot list for one-tap filtering without opening a full filter sheet.
40. **Scroll-to-top FAB** — Show a floating "Back to top" button on SpotListScreen and HistoryScreen when the user has scrolled more than 5 items, animating in/out smoothly.

---

## Features

41. **Spot photo gallery** — Allow attaching multiple photos per spot using the camera or gallery, stored locally with Coil thumbnail rendering.
42. **Offline GPX export** — Generate a `.gpx` route file from a saved route so users can load it into any mapping app.
43. **CSV export of spot history** — Let users export all visit logs as a CSV file to local Downloads storage.
44. **Barcode / QR scanner integration** — Use ML Kit Barcode Scanning to log bin IDs or location codes by scanning physical labels.
45. **Widget (Glance API)** — Add a home-screen widget showing today's spot count and a quick-add shortcut.
46. **Notification for scheduled visits** — Use WorkManager + NotificationCompat to remind users when a high-grade spot is due for a revisit (configurable cadence).
47. **Dumpster "heat map" overlay** — Render density clusters on the map screen to reveal high-activity zones at a glance.
48. **Street View deep-link** — Add a "View in Street View" action on spot detail that deep-links to Google Maps Street View for that coordinate.
49. **Duplicate spot detection** — Warn users when adding a new spot within 20 m of an existing one using Haversine distance.
50. **Tire spot categories extended** — Add `TireSpotCategory.FleetYard` and `TireSpotCategory.Airport` with matching accent colors and icons.
51. **Advanced voice commands** — Extend VoiceParser to parse haul ratings ("excellent haul", "terrible find"), multiple items in one phrase, and follow-up correction interjections ("correction: bakery not grocery").
52. **Custom tags autocomplete** — Show an autocomplete dropdown of existing tags while the user types a new tag in AddSpotScreen.
53. **Gear checklist templates** — Allow saving named gear profiles (e.g., "Night Run", "Quick Stop") that pre-fill the checklist state.
54. **Route ETA estimate** — Calculate and display an estimated driving time for a saved route using local waypoint geometry (no network required).
55. **Dark map style** — Apply a custom dark/neon JSON map style via `MapStyleOptions` in MapScreen to match the app's cyber-neon identity.

---

## Accessibility

56. **Content descriptions on all icons** — Audit every `Icon()` call across the app to ensure `contentDescription` is never null for decorative icons that convey meaning.
57. **Minimum 48 dp touch targets** — Enforce `Modifier.minimumInteractiveComponentSize()` on all interactive elements, especially in compact list rows.
58. **Screen reader traversal order** — Add `Modifier.semantics { traversalIndex }` on hero stat numbers and section headers so TalkBack reads them in logical order.
59. **Focus restoration after dialogs** — Ensure focus returns to the triggering element after dismissing dialogs and bottom sheets (AccessibilityManager API).
60. **Color-blind safe palette** — Validate all status / grade / category colors against WCAG AA (4.5:1 contrast minimum) against dark surface backgrounds.
61. **Dynamic font scaling** — Test all text at the maximum font scale (200%) and add `Modifier.basicMarquee()` fallbacks or explicit `overflow = TextOverflow.Ellipsis` on hero numbers.
62. **Reduce motion option** — Respect `AccessibilityManager.isAnimationEnabled` and skip or shorten non-essential animations for users who have opted to reduce motion.

---

## Privacy & Security

63. **In-app backup encryption** — Encrypt the exported Room database file with AES-256 before writing to external storage.
64. **Per-spot redaction** — Add a `isRedacted` flag so sensitive locations can be shown only as a region (e.g., "Downtown area") rather than exact coordinates.
65. **Screenshot prevention on sensitive screens** — Set `WindowManager.LayoutParams.FLAG_SECURE` on SpotDetailScreen to block screenshots if the user opts in.
66. **Audit DataStore encryption** — Migrate AppPreferences to `EncryptedDataStore` (Tink-backed) for sensitive preference values.
67. **Location permission rationale** — Show a proper permission rationale dialog (not just a system prompt) explaining why location is needed before requesting it.

---

## Visual & Design

68. **Animated gradient hero** — Use `InfiniteTransition` to slowly shift the hero gradient hue on HomeScreen for a subtle living background.
69. **Custom app icon** — Replace the default launcher icon with a custom night-scout neon icon (adaptive icon with a foreground layer + dark background layer).
70. **Lottie animations** — Replace simple `AnimatedVisibility` bouncy-check on SAVED phase with a Lottie JSON animation for richer success feedback.
71. **Spot grade donut chart** — Replace the linear progress indicator on SpotDetailScreen with an animated donut/arc chart for a more premium grade display.
72. **Map marker customization** — Use custom `BitmapDescriptor` map markers that reflect spot status color and grade score instead of default red pins.
73. **Animated bottom navigation indicator** — Replace the static `NavigationBar` indicator with a custom animated pill that slides between tabs.
74. **Skeleton loading screens** — Replace blank states during data loading with shimmering placeholder cards using a `ShimmerBrush`.
75. **Dark splash screen** — Update `SplashScreen` theme to use the app's deep-dark background color + neon accent logo animation.
76. **Contextual transition animations** — Use shared-element transitions (Compose 1.7+) between SpotCard → SpotDetailScreen for a seamless visual connection.
77. **Pull-quote empty states** — Replace generic empty state text with rotating motivational field-scout quotes on the HistoryScreen.
78. **Neon glow map overlay** — Apply a radial glow `Canvas`-based overlay centered on the user's location pin for dramatic field-mode atmosphere.

---

## Developer Experience

79. **Add `ktlint` or `detekt`** — Introduce a static analysis step to the Gradle build to enforce code style and catch common anti-patterns automatically.
80. **Expand the GitHub Actions pipeline** — Build on the existing manual build/test workflow by adding automatic `pull_request` / `push` validation and lint gates to prevent regressions.
81. **Renovate or Dependabot** — Configure automated dependency update PRs so library versions stay current without manual tracking.
82. **Add `BuildConfig` feature flags** — Use `buildConfigField` to define feature flags (e.g., `ENABLE_MAP`, `ENABLE_TIRE_MODULE`) for easier testing of partial feature rollouts.
83. **Opt-in local diagnostics export** — Add a privacy-safe way to export recent local logs and crash details on demand without introducing third-party crash reporting.
84. **Room schema migration scripts** — Write the SQL migration scripts for each schema version change and store them under `app/schemas/`.
85. **Add ProGuard keep rules for Room** — Ensure Room entity class names are not obfuscated in release builds by verifying `proguard-rules.pro` coverage.
86. **API level lint check** — Enable `@ChecksSdkIntAtLeast` annotations and enable `NewApi` lint checks to catch API level violations before build.
87. **`BuildConfig.DEBUG` logging** — Replace any `Log.d` calls with a centralized `DsLogger` wrapper that is a no-op in release builds.
88. **Add KDoc to public APIs** — Document every public function in the repository interfaces, mapper classes, and use-case classes.

---

## Data & Persistence

89. **Automatic daily database compaction** — Schedule a nightly Room `VACUUM` via WorkManager to keep the SQLite file size lean.
90. **Local incremental backup** — Export a timestamped Room backup `.db` file to `getExternalFilesDir()` once per week via WorkManager.
91. **DataStore key versioning** — Add a version key to AppPreferences to handle preference schema migration without crashes after app updates.
92. **Spot archival policy** — Auto-archive spots not visited in 90 days with a UI prompt, keeping the active list manageable.
93. **Tire report de-duplication** — Flag tire reports logged within 1 hour at the same location as potential duplicates before saving.
94. **Report delta diffing** — Store only changes (deltas) between successive visit reports to reduce database write amplification.

---

## Localization & Internationalization

95. **Extract all hardcoded strings** — Run a lint `HardcodedText` pass and move every remaining hardcoded user-visible string to `strings.xml`.
96. **Plural strings** — Replace "X spots" format strings with `<plurals>` resources for proper singular/plural handling in all locales.
97. **RTL support** — Use `Modifier.padding(start/end)` consistently (never `left/right`) and test the full UI in RTL layout direction.
98. **Date/time locale formatting** — Replace manual date formatting with `DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)` to respect the device locale.

---

## Miscellaneous

99. **App shortcuts (static)** — Add 3 static `<shortcut>` entries in `shortcuts.xml` for "Add Spot", "Voice Report", and "Field Mode" to surface from the launcher long-press menu.
100. **Review onboarding flow** — A/B test the onboarding screen copy with 2–3 variant strings; track completion rate via a local counter in DataStore to inform future copy decisions.
