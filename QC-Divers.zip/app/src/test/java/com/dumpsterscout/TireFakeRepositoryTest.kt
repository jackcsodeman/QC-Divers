package com.dumpsterscout

import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireSpotCategory
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.fake.FakeTireReportRepository
import com.dumpsterscout.fake.FakeTireSpotRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class TireFakeRepositoryTest {

    private lateinit var tireSpotRepo: FakeTireSpotRepository
    private lateinit var tireReportRepo: FakeTireReportRepository

    private val sampleSpot = TireSpot(
        id = 0,
        name = "Discount Tire – Bettendorf",
        category = TireSpotCategory.TIRE_SHOP,
        address = "2700 Devils Glen Rd, Bettendorf, IA",
        latitude = 41.55,
        longitude = -90.48
    )

    private val sampleReport = TireReport(
        id = 0,
        tireSpotId = 1L,
        spotName = "Discount Tire – Bettendorf",
        estimatedCount = 6,
        estimatedUsableCount = 4
    )

    @Before
    fun setup() {
        tireSpotRepo = FakeTireSpotRepository()
        tireReportRepo = FakeTireReportRepository()
    }

    // ── TireSpotRepository ─────────────────────────────────────────────────

    @Test
    fun `insert and retrieve tire spot`() = runTest {
        val id = tireSpotRepo.upsertSpot(sampleSpot)
        assertTrue(id > 0)
        val spot = tireSpotRepo.getSpotById(id)
        assertNotNull(spot)
        assertEquals("Discount Tire – Bettendorf", spot!!.name)
    }

    @Test
    fun `getAllSpots returns all tire spots`() = runTest {
        tireSpotRepo.upsertSpot(sampleSpot)
        tireSpotRepo.upsertSpot(sampleSpot.copy(name = "Firestone"))
        val all = tireSpotRepo.getAllSpots().first()
        assertEquals(2, all.size)
    }

    @Test
    fun `getActiveSpots excludes retired`() = runTest {
        val id = tireSpotRepo.upsertSpot(sampleSpot)
        tireSpotRepo.upsertSpot(sampleSpot.copy(name = "Active Spot"))
        tireSpotRepo.retireSpot(id)
        val active = tireSpotRepo.getActiveSpots().first()
        assertEquals(1, active.size)
        assertEquals("Active Spot", active[0].name)
    }

    @Test
    fun `searchSpots finds by name`() = runTest {
        tireSpotRepo.upsertSpot(sampleSpot)
        tireSpotRepo.upsertSpot(sampleSpot.copy(name = "Firestone Davenport"))
        val results = tireSpotRepo.searchSpots("Firestone").first()
        assertEquals(1, results.size)
        assertEquals("Firestone Davenport", results[0].name)
    }

    @Test
    fun `toggle favorite works for tire spot`() = runTest {
        val id = tireSpotRepo.upsertSpot(sampleSpot)
        assertFalse(tireSpotRepo.getSpotById(id)!!.isFavorite)
        tireSpotRepo.toggleFavorite(id)
        assertTrue(tireSpotRepo.getSpotById(id)!!.isFavorite)
        tireSpotRepo.toggleFavorite(id)
        assertFalse(tireSpotRepo.getSpotById(id)!!.isFavorite)
    }

    @Test
    fun `getFavoriteSpots filters correctly`() = runTest {
        val id = tireSpotRepo.upsertSpot(sampleSpot)
        tireSpotRepo.upsertSpot(sampleSpot.copy(name = "Not Fav"))
        tireSpotRepo.toggleFavorite(id)
        val favs = tireSpotRepo.getFavoriteSpots().first()
        assertEquals(1, favs.size)
        assertEquals(id, favs[0].id)
    }

    @Test
    fun `updateLastStatus updates tire spot`() = runTest {
        val id = tireSpotRepo.upsertSpot(sampleSpot)
        val now = System.currentTimeMillis()
        tireSpotRepo.updateLastStatus(id, TireSpotStatus.GOOD_USABLE, now)
        val spot = tireSpotRepo.getSpotById(id)!!
        assertEquals(TireSpotStatus.GOOD_USABLE, spot.lastStatus)
        assertEquals(now, spot.lastChecked)
    }

    @Test
    fun `deleteSpot removes tire spot`() = runTest {
        val id = tireSpotRepo.upsertSpot(sampleSpot)
        val spot = tireSpotRepo.getSpotById(id)!!
        tireSpotRepo.deleteSpot(spot)
        assertNull(tireSpotRepo.getSpotById(id))
    }

    @Test
    fun `deleteAllSpots clears all`() = runTest {
        tireSpotRepo.upsertSpot(sampleSpot)
        tireSpotRepo.upsertSpot(sampleSpot.copy(name = "Another"))
        tireSpotRepo.deleteAllSpots()
        assertTrue(tireSpotRepo.getAllSpots().first().isEmpty())
    }

    // ── Sync hooks – TireSpotRepository ───────────────────────────────────

    @Test
    fun `getPendingSyncSpots returns only PENDING_SYNC spots`() = runTest {
        tireSpotRepo.upsertSpot(sampleSpot)
        val pendingId = tireSpotRepo.upsertSpot(
            sampleSpot.copy(name = "Pending", syncStatus = SyncStatus.PENDING_SYNC)
        )
        val pending = tireSpotRepo.getPendingSyncSpots()
        assertEquals(1, pending.size)
        assertEquals(pendingId, pending[0].id)
    }

    @Test
    fun `markSpotSynced updates sync state and remoteId`() = runTest {
        val id = tireSpotRepo.upsertSpot(
            sampleSpot.copy(syncStatus = SyncStatus.PENDING_SYNC)
        )
        tireSpotRepo.markSpotSynced(id, "remote-uuid-tire-1")
        val spot = tireSpotRepo.getSpotById(id)!!
        assertEquals(SyncStatus.SYNCED, spot.syncStatus)
        assertEquals("remote-uuid-tire-1", spot.remoteId)
        assertTrue(tireSpotRepo.getPendingSyncSpots().isEmpty())
    }

    @Test
    fun `markSpotSyncFailed updates sync state`() = runTest {
        val id = tireSpotRepo.upsertSpot(
            sampleSpot.copy(syncStatus = SyncStatus.PENDING_SYNC)
        )
        tireSpotRepo.markSpotSyncFailed(id)
        assertEquals(SyncStatus.SYNC_FAILED, tireSpotRepo.getSpotById(id)!!.syncStatus)
    }

    // ── TireReportRepository ───────────────────────────────────────────────

    @Test
    fun `insert and retrieve tire report`() = runTest {
        val id = tireReportRepo.insertReport(sampleReport)
        assertTrue(id > 0)
        val report = tireReportRepo.getReportById(id)
        assertNotNull(report)
        assertEquals(6, report!!.estimatedCount)
    }

    @Test
    fun `getReportsBySpot filters correctly`() = runTest {
        tireReportRepo.insertReport(sampleReport.copy(tireSpotId = 1L))
        tireReportRepo.insertReport(sampleReport.copy(tireSpotId = 2L))
        tireReportRepo.insertReport(sampleReport.copy(tireSpotId = 1L))
        val reports = tireReportRepo.getReportsBySpot(1L).first()
        assertEquals(2, reports.size)
    }

    @Test
    fun `getRecentReports respects limit`() = runTest {
        repeat(5) { i ->
            tireReportRepo.insertReport(sampleReport.copy(timestamp = System.currentTimeMillis() + i))
        }
        val recent = tireReportRepo.getRecentReports(3).first()
        assertEquals(3, recent.size)
    }

    @Test
    fun `deleteTireReport removes it`() = runTest {
        val id = tireReportRepo.insertReport(sampleReport)
        val report = tireReportRepo.getReportById(id)!!
        tireReportRepo.deleteReport(report)
        assertNull(tireReportRepo.getReportById(id))
    }

    @Test
    fun `deleteAllTireReports clears everything`() = runTest {
        tireReportRepo.insertReport(sampleReport)
        tireReportRepo.insertReport(sampleReport.copy(notes = "Second"))
        tireReportRepo.deleteAllReports()
        assertTrue(tireReportRepo.getAllReports().first().isEmpty())
    }

    @Test
    fun `update tire report changes content`() = runTest {
        val id = tireReportRepo.insertReport(sampleReport)
        val report = tireReportRepo.getReportById(id)!!
        tireReportRepo.updateReport(report.copy(notes = "Updated notes"))
        assertEquals("Updated notes", tireReportRepo.getReportById(id)!!.notes)
    }

    // ── Sync hooks – TireReportRepository ─────────────────────────────────

    @Test
    fun `getPendingSyncReports returns only PENDING_SYNC reports`() = runTest {
        tireReportRepo.insertReport(sampleReport)
        val pendingId = tireReportRepo.insertReport(
            sampleReport.copy(syncStatus = SyncStatus.PENDING_SYNC)
        )
        val pending = tireReportRepo.getPendingSyncReports()
        assertEquals(1, pending.size)
        assertEquals(pendingId, pending[0].id)
    }

    @Test
    fun `markReportSynced updates sync state and remoteId`() = runTest {
        val id = tireReportRepo.insertReport(
            sampleReport.copy(syncStatus = SyncStatus.PENDING_SYNC)
        )
        tireReportRepo.markReportSynced(id, "remote-uuid-tr-1")
        val report = tireReportRepo.getReportById(id)!!
        assertEquals(SyncStatus.SYNCED, report.syncStatus)
        assertEquals("remote-uuid-tr-1", report.remoteId)
        assertTrue(tireReportRepo.getPendingSyncReports().isEmpty())
    }

    @Test
    fun `markReportSyncFailed updates sync state`() = runTest {
        val id = tireReportRepo.insertReport(
            sampleReport.copy(syncStatus = SyncStatus.PENDING_SYNC)
        )
        tireReportRepo.markReportSyncFailed(id)
        assertEquals(SyncStatus.SYNC_FAILED, tireReportRepo.getReportById(id)!!.syncStatus)
    }
}
