package com.dumpsterscout

import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotCategory
import com.dumpsterscout.fake.FakeReportRepository
import com.dumpsterscout.fake.FakeSpotRepository
import com.dumpsterscout.ui.voice.VoicePhase
import com.dumpsterscout.ui.voice.VoiceViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class VoiceViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    private lateinit var spotRepo: FakeSpotRepository
    private lateinit var reportRepo: FakeReportRepository
    private lateinit var viewModel: VoiceViewModel

    private val sampleSpot = DumpsterSpot(
        id = 1L,
        name = "Trader Joe's",
        category = SpotCategory.GROCERY
    )

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        spotRepo = FakeSpotRepository(listOf(sampleSpot))
        reportRepo = FakeReportRepository()
        viewModel = VoiceViewModel(spotRepo, reportRepo)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `initial state is IDLE with no error`() {
        val state = viewModel.uiState.value
        assertEquals(VoicePhase.IDLE, state.phase)
        assertNull(state.errorMessageRes)
    }

    @Test
    fun `onStartListening transitions to LISTENING and clears error`() {
        viewModel.onStartListening()
        val state = viewModel.uiState.value
        assertEquals(VoicePhase.LISTENING, state.phase)
        assertNull(state.errorMessageRes)
    }

    @Test
    fun `onListeningCancelled returns to IDLE`() {
        viewModel.onStartListening()
        viewModel.onListeningCancelled()
        assertEquals(VoicePhase.IDLE, viewModel.uiState.value.phase)
    }

    @Test
    fun `blank transcript sets error and stays IDLE`() = runTest(testDispatcher) {
        viewModel.onTranscriptReceived("")
        advanceUntilIdle()
        val state = viewModel.uiState.value
        assertEquals(VoicePhase.IDLE, state.phase)
        assertEquals(R.string.voice_error_no_speech, state.errorMessageRes)
    }

    @Test
    fun `valid transcript transitions to CONFIRM`() = runTest(testDispatcher) {
        viewModel.onTranscriptReceived("Trader Joe's was empty tonight")
        advanceUntilIdle()
        assertEquals(VoicePhase.CONFIRM, viewModel.uiState.value.phase)
    }

    @Test
    fun `valid transcript sets editableTranscript`() = runTest(testDispatcher) {
        val transcript = "Trader Joe's half full today"
        viewModel.onTranscriptReceived(transcript)
        advanceUntilIdle()
        assertEquals(transcript, viewModel.uiState.value.editableTranscript)
    }

    @Test
    fun `reset returns to clean IDLE state`() = runTest(testDispatcher) {
        viewModel.onTranscriptReceived("Trader Joe's was full")
        advanceUntilIdle()
        viewModel.reset()
        val state = viewModel.uiState.value
        assertEquals(VoicePhase.IDLE, state.phase)
        assertNull(state.errorMessageRes)
        assertNull(state.parseResult)
        assertNull(state.matchedSpot)
    }

    @Test
    fun `onNotesEdited updates editableNotes`() = runTest(testDispatcher) {
        viewModel.onTranscriptReceived("good haul today")
        advanceUntilIdle()
        viewModel.onNotesEdited("Great variety of produce")
        assertEquals("Great variety of produce", viewModel.uiState.value.editableNotes)
    }

    @Test
    fun `onSelectSpot sets matchedSpot`() = runTest(testDispatcher) {
        viewModel.onTranscriptReceived("Trader Joe's empty")
        advanceUntilIdle()
        val otherSpot = DumpsterSpot(id = 2L, name = "Aldi", category = SpotCategory.GROCERY)
        viewModel.onSelectSpot(otherSpot)
        assertEquals(otherSpot, viewModel.uiState.value.matchedSpot)
    }

    @Test
    fun `saveReport with explicitly selected spot transitions to SAVED`() = runTest(testDispatcher) {
        viewModel.onTranscriptReceived("good haul tonight")
        advanceUntilIdle()
        viewModel.onSelectSpot(sampleSpot)
        viewModel.saveReport()
        advanceUntilIdle()
        assertEquals(VoicePhase.SAVED, viewModel.uiState.value.phase)
    }

    @Test
    fun `saveReport with explicitly selected spot sets reportSaved flag`() = runTest(testDispatcher) {
        viewModel.onTranscriptReceived("good haul tonight")
        advanceUntilIdle()
        viewModel.onSelectSpot(sampleSpot)
        viewModel.saveReport()
        advanceUntilIdle()
        assertTrue(viewModel.uiState.value.reportSaved)
    }
}
