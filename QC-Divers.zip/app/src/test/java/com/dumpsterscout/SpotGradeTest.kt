package com.dumpsterscout

import com.dumpsterscout.domain.model.SpotGrade
import org.junit.Assert.*
import org.junit.Test

class SpotGradeTest {

    @Test
    fun `default grade reports not graded`() {
        val grade = SpotGrade()
        assertFalse(grade.isGraded())
    }

    @Test
    fun `graded when overall is set`() {
        val grade = SpotGrade(overall = 5f)
        assertTrue(grade.isGraded())
    }

    @Test
    fun `graded when consistency is set`() {
        val grade = SpotGrade(consistency = 3f)
        assertTrue(grade.isGraded())
    }

    @Test
    fun `graded when quality is set`() {
        val grade = SpotGrade(quality = 7f)
        assertTrue(grade.isGraded())
    }

    @Test
    fun `positive score averages consistency quality quantity cleanliness`() {
        val grade = SpotGrade(
            consistency = 8f,
            quality = 6f,
            quantity = 4f,
            cleanliness = 2f
        )
        assertEquals(5f, grade.positiveScore(), 0.01f)
    }

    @Test
    fun `negative score averages risk accessDifficulty legalSensitivity`() {
        val grade = SpotGrade(
            risk = 3f,
            accessDifficulty = 6f,
            legalSensitivity = 9f
        )
        assertEquals(6f, grade.negativeScore(), 0.01f)
    }

    @Test
    fun `positive score zero when all zeroes`() {
        val grade = SpotGrade()
        assertEquals(0f, grade.positiveScore(), 0.01f)
    }

    @Test
    fun `negative score zero when all zeroes`() {
        val grade = SpotGrade()
        assertEquals(0f, grade.negativeScore(), 0.01f)
    }

    @Test
    fun `positive score max at all tens`() {
        val grade = SpotGrade(
            consistency = 10f,
            quality = 10f,
            quantity = 10f,
            cleanliness = 10f
        )
        assertEquals(10f, grade.positiveScore(), 0.01f)
    }
}
