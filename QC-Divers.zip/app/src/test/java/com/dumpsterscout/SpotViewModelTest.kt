package com.dumpsterscout

import app.cash.turbine.test
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotCategory
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.fake.FakeReportRepository
import com.dumpsterscout.fake.FakeSpotRepository
import com.dumpsterscout.fake.FakeUserRepository
import com.dumpsterscout.ui.spots.SpotViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class SpotViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    private lateinit var spotRepo: FakeSpotRepository
    private lateinit var reportRepo: FakeReportRepository
    private lateinit var userRepo: FakeUserRepository
    private lateinit var viewModel: SpotViewModel

    private val sampleSpot = DumpsterSpot(
        id = 1L,
        name = "Aldi – West Moline",
        category = SpotCategory.GROCERY,
        address = "4000 River Dr, Moline, IL"
    )

    private val anotherSpot = DumpsterSpot(
        id = 2L,
        name = "Target – Bettendorf",
        category = SpotCategory.RETAIL,
        address = "2900 Devils Glen Rd, Bettendorf, IA",
        isFavorite = true
    )

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        spotRepo = FakeSpotRepository(listOf(sampleSpot, anotherSpot))
        reportRepo = FakeReportRepository()
        userRepo = FakeUserRepository()
        viewModel = SpotViewModel(spotRepo, reportRepo, userRepo)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    // ── List state ─────────────────────────────────────────────────────────

    @Test
    fun `initial list state has isLoading true`() {
        assertTrue(viewModel.listState.value.isLoading)
    }

    @Test
    fun `spots load and isLoading becomes false`() = runTest(testDispatcher) {
        advanceUntilIdle()
        assertFalse(viewModel.listState.value.isLoading)
        assertEquals(2, viewModel.listState.value.spots.size)
    }

    @Test
    fun `filteredSpots equals all spots when no filter`() = runTest(testDispatcher) {
        advanceUntilIdle()
        val state = viewModel.listState.value
        assertEquals(state.spots.size, state.filteredSpots.size)
    }

    @Test
    fun `search query filters spots by name`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onSearchQueryChange("Aldi")
        val filtered = viewModel.listState.value.filteredSpots
        assertEquals(1, filtered.size)
        assertEquals("Aldi – West Moline", filtered[0].name)
    }

    @Test
    fun `search query is case insensitive`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onSearchQueryChange("aldi")
        assertEquals(1, viewModel.listState.value.filteredSpots.size)
    }

    @Test
    fun `empty search query shows all spots`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onSearchQueryChange("XYZ")
        assertEquals(0, viewModel.listState.value.filteredSpots.size)
        viewModel.onSearchQueryChange("")
        assertEquals(2, viewModel.listState.value.filteredSpots.size)
    }

    @Test
    fun `category filter reduces results`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onFilterCategoryChange(SpotCategory.GROCERY)
        val filtered = viewModel.listState.value.filteredSpots
        assertEquals(1, filtered.size)
        assertEquals(SpotCategory.GROCERY, filtered[0].category)
    }

    @Test
    fun `null category filter shows all spots`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onFilterCategoryChange(SpotCategory.GROCERY)
        viewModel.onFilterCategoryChange(null)
        assertEquals(2, viewModel.listState.value.filteredSpots.size)
    }

    @Test
    fun `favorites only filter shows only favorite spots`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onShowFavoritesOnlyChange(true)
        val filtered = viewModel.listState.value.filteredSpots
        assertEquals(1, filtered.size)
        assertTrue(filtered[0].isFavorite)
    }

    @Test
    fun `favorites only false shows all spots`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onShowFavoritesOnlyChange(true)
        viewModel.onShowFavoritesOnlyChange(false)
        assertEquals(2, viewModel.listState.value.filteredSpots.size)
    }

    @Test
    fun `status filter reduces results`() = runTest(testDispatcher) {
        advanceUntilIdle()
        // Update one spot to LOCKED status
        spotRepo.updateLastStatus(sampleSpot.id, SpotStatus.LOCKED, System.currentTimeMillis())
        advanceUntilIdle()
        viewModel.onFilterStatusChange(SpotStatus.LOCKED)
        advanceUntilIdle()
        assertEquals(1, viewModel.listState.value.filteredSpots.size)
        assertEquals(SpotStatus.LOCKED, viewModel.listState.value.filteredSpots[0].lastStatus)
    }

    // ── Detail state ───────────────────────────────────────────────────────

    @Test
    fun `loadSpotDetail loads the correct spot`() = runTest(testDispatcher) {
        viewModel.loadSpotDetail(sampleSpot.id)
        advanceUntilIdle()
        val state = viewModel.detailState.value
        assertNotNull(state.spot)
        assertEquals(sampleSpot.id, state.spot!!.id)
        assertFalse(state.isLoading)
    }

    @Test
    fun `loadSpotDetail for unknown id results in null spot`() = runTest(testDispatcher) {
        viewModel.loadSpotDetail(999L)
        advanceUntilIdle()
        val state = viewModel.detailState.value
        assertNull(state.spot)
        assertFalse(state.isLoading)
    }

    @Test
    fun `toggleFavorite flips isFavorite`() = runTest(testDispatcher) {
        viewModel.loadSpotDetail(sampleSpot.id)
        advanceUntilIdle()
        assertFalse(viewModel.detailState.value.spot!!.isFavorite)
        viewModel.toggleFavorite(sampleSpot.id)
        advanceUntilIdle()
        // Detail state does not auto-update; check repository
        assertTrue(spotRepo.getSpotById(sampleSpot.id)!!.isFavorite)
    }

    @Test
    fun `updateStatus changes lastStatus in detail state`() = runTest(testDispatcher) {
        viewModel.loadSpotDetail(sampleSpot.id)
        advanceUntilIdle()
        viewModel.updateStatus(sampleSpot.id, SpotStatus.GOOD_HAUL)
        advanceUntilIdle()
        assertEquals(SpotStatus.GOOD_HAUL, viewModel.detailState.value.spot!!.lastStatus)
    }

    @Test
    fun `showDeleteDialog sets showDeleteDialog flag`() {
        viewModel.showDeleteDialog(true)
        assertTrue(viewModel.detailState.value.showDeleteDialog)
    }

    @Test
    fun `showDeleteDialog false clears the flag`() {
        viewModel.showDeleteDialog(true)
        viewModel.showDeleteDialog(false)
        assertFalse(viewModel.detailState.value.showDeleteDialog)
    }

    @Test
    fun `deleteSpot removes spot from repository`() = runTest(testDispatcher) {
        viewModel.loadSpotDetail(sampleSpot.id)
        advanceUntilIdle()
        viewModel.deleteSpot()
        advanceUntilIdle()
        assertNull(spotRepo.getSpotById(sampleSpot.id))
    }

    // ── Add/Edit state ─────────────────────────────────────────────────────

    @Test
    fun `loadSpotForEdit with null id resets add state`() = runTest(testDispatcher) {
        viewModel.loadSpotForEdit(null)
        val state = viewModel.addState.value
        assertEquals("", state.spot.name)
        assertFalse(state.isSaved)
    }

    @Test
    fun `loadSpotForEdit with valid id loads spot`() = runTest(testDispatcher) {
        viewModel.loadSpotForEdit(sampleSpot.id)
        advanceUntilIdle()
        val state = viewModel.addState.value
        assertEquals(sampleSpot.id, state.spot.id)
        assertEquals(sampleSpot.name, state.spot.name)
    }

    @Test
    fun `updateSpotField mutates the draft spot`() = runTest(testDispatcher) {
        viewModel.updateSpotField { it.copy(name = "New Name") }
        assertEquals("New Name", viewModel.addState.value.spot.name)
    }

    @Test
    fun `saveSpot sets isSaved and returns non-zero id`() = runTest(testDispatcher) {
        viewModel.updateSpotField { it.copy(name = "Brand New Spot") }
        viewModel.saveSpot()
        advanceUntilIdle()
        val state = viewModel.addState.value
        assertTrue(state.isSaved)
        assertNotNull(state.savedId)
        assertTrue(state.savedId!! > 0)
    }

    @Test
    fun `clearSaved resets isSaved and savedId`() = runTest(testDispatcher) {
        viewModel.updateSpotField { it.copy(name = "Temp") }
        viewModel.saveSpot()
        advanceUntilIdle()
        viewModel.clearSaved()
        val state = viewModel.addState.value
        assertFalse(state.isSaved)
        assertNull(state.savedId)
    }

    // ── Favorites stream ───────────────────────────────────────────────────

    @Test
    fun `favoriteSpots emits only favorite spots`() = runTest(testDispatcher) {
        viewModel.favoriteSpots.test {
            // The WhileSubscribed StateFlow emits initialValue (emptyList) first,
            // then the real emission from the upstream once it starts collecting.
            skipItems(1)
            val favorites = awaitItem()
            assertEquals(1, favorites.size)
            assertEquals(anotherSpot.id, favorites[0].id)
            cancelAndIgnoreRemainingEvents()
        }
    }
}
