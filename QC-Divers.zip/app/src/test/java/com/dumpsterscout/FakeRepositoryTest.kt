package com.dumpsterscout

import com.dumpsterscout.domain.model.*
import com.dumpsterscout.fake.FakeSpotRepository
import com.dumpsterscout.fake.FakeReportRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class FakeRepositoryTest {

    private lateinit var spotRepo: FakeSpotRepository
    private lateinit var reportRepo: FakeReportRepository

    private val sampleSpot = DumpsterSpot(
        id = 0,
        name = "Test Spot",
        category = SpotCategory.GROCERY,
        address = "123 Main St",
        latitude = 41.88,
        longitude = -87.62
    )

    private val sampleReport = PersonalReport(
        id = 0,
        spotId = 1L,
        spotName = "Test Spot",
        status = SpotStatus.GOOD_HAUL,
        notes = "Great finds"
    )

    @Before
    fun setup() {
        spotRepo = FakeSpotRepository()
        reportRepo = FakeReportRepository()
    }

    // ─── SpotRepository tests ──────────────────────────────────────────────

    @Test
    fun `insert and retrieve spot`() = runTest {
        val id = spotRepo.upsertSpot(sampleSpot)
        assertTrue(id > 0)

        val retrieved = spotRepo.getSpotById(id)
        assertNotNull(retrieved)
        assertEquals("Test Spot", retrieved!!.name)
    }

    @Test
    fun `getAllSpots returns inserted spots`() = runTest {
        spotRepo.upsertSpot(sampleSpot)
        spotRepo.upsertSpot(sampleSpot.copy(name = "Second Spot"))

        val all = spotRepo.getAllSpots().first()
        assertEquals(2, all.size)
    }

    @Test
    fun `search finds matching spots`() = runTest {
        spotRepo.upsertSpot(sampleSpot)
        spotRepo.upsertSpot(sampleSpot.copy(name = "CVS Pharmacy"))

        val results = spotRepo.searchSpots("CVS").first()
        assertEquals(1, results.size)
        assertEquals("CVS Pharmacy", results[0].name)
    }

    @Test
    fun `search finds by address`() = runTest {
        spotRepo.upsertSpot(sampleSpot.copy(address = "456 Oak Ave"))
        spotRepo.upsertSpot(sampleSpot.copy(name = "Other", address = "789 Pine St"))

        val results = spotRepo.searchSpots("Oak").first()
        assertEquals(1, results.size)
    }

    @Test
    fun `toggle favorite works`() = runTest {
        val id = spotRepo.upsertSpot(sampleSpot)
        assertFalse(spotRepo.getSpotById(id)!!.isFavorite)

        spotRepo.toggleFavorite(id)
        assertTrue(spotRepo.getSpotById(id)!!.isFavorite)

        spotRepo.toggleFavorite(id)
        assertFalse(spotRepo.getSpotById(id)!!.isFavorite)
    }

    @Test
    fun `getFavoriteSpots filters correctly`() = runTest {
        val id1 = spotRepo.upsertSpot(sampleSpot)
        spotRepo.upsertSpot(sampleSpot.copy(name = "Not Fav"))
        spotRepo.toggleFavorite(id1)

        val favorites = spotRepo.getFavoriteSpots().first()
        assertEquals(1, favorites.size)
        assertEquals(id1, favorites[0].id)
    }

    @Test
    fun `retire spot excludes from active`() = runTest {
        val id = spotRepo.upsertSpot(sampleSpot)
        spotRepo.retireSpot(id)

        val active = spotRepo.getActiveSpots().first()
        assertTrue(active.isEmpty())

        // But still in getAllSpots
        val all = spotRepo.getAllSpots().first()
        assertEquals(1, all.size)
    }

    @Test
    fun `update last status`() = runTest {
        val id = spotRepo.upsertSpot(sampleSpot)
        val now = System.currentTimeMillis()
        spotRepo.updateLastStatus(id, SpotStatus.LOCKED, now)

        val spot = spotRepo.getSpotById(id)!!
        assertEquals(SpotStatus.LOCKED, spot.lastStatus)
        assertEquals(now, spot.lastChecked)
    }

    @Test
    fun `delete spot removes it`() = runTest {
        val id = spotRepo.upsertSpot(sampleSpot)
        val spot = spotRepo.getSpotById(id)!!
        spotRepo.deleteSpot(spot)

        assertNull(spotRepo.getSpotById(id))
    }

    @Test
    fun `deleteAllSpots clears everything`() = runTest {
        spotRepo.upsertSpot(sampleSpot)
        spotRepo.upsertSpot(sampleSpot.copy(name = "Another"))
        spotRepo.deleteAllSpots()

        val all = spotRepo.getAllSpots().first()
        assertTrue(all.isEmpty())
    }

    @Test
    fun `upsert updates existing spot`() = runTest {
        val id = spotRepo.upsertSpot(sampleSpot)
        spotRepo.upsertSpot(sampleSpot.copy(id = id, name = "Updated Name"))

        val spot = spotRepo.getSpotById(id)!!
        assertEquals("Updated Name", spot.name)
        assertEquals(1, spotRepo.getAllSpots().first().size)
    }

    // ─── ReportRepository tests ────────────────────────────────────────────

    @Test
    fun `insert and retrieve report`() = runTest {
        val id = reportRepo.insertReport(sampleReport)
        assertTrue(id > 0)

        val retrieved = reportRepo.getReportById(id)
        assertNotNull(retrieved)
        assertEquals("Great finds", retrieved!!.notes)
    }

    @Test
    fun `getReportsBySpot filters correctly`() = runTest {
        reportRepo.insertReport(sampleReport.copy(spotId = 1L))
        reportRepo.insertReport(sampleReport.copy(spotId = 2L))
        reportRepo.insertReport(sampleReport.copy(spotId = 1L))

        val reports = reportRepo.getReportsBySpot(1L).first()
        assertEquals(2, reports.size)
    }

    @Test
    fun `getRecentReports respects limit`() = runTest {
        repeat(5) { i ->
            reportRepo.insertReport(sampleReport.copy(timestamp = System.currentTimeMillis() + i))
        }

        val recent = reportRepo.getRecentReports(3).first()
        assertEquals(3, recent.size)
    }

    @Test
    fun `delete report removes it`() = runTest {
        val id = reportRepo.insertReport(sampleReport)
        val report = reportRepo.getReportById(id)!!
        reportRepo.deleteReport(report)

        assertNull(reportRepo.getReportById(id))
    }

    @Test
    fun `deleteAllReports clears everything`() = runTest {
        reportRepo.insertReport(sampleReport)
        reportRepo.insertReport(sampleReport.copy(notes = "Second"))
        reportRepo.deleteAllReports()

        val all = reportRepo.getAllReports().first()
        assertTrue(all.isEmpty())
    }

    @Test
    fun `update report changes content`() = runTest {
        val id = reportRepo.insertReport(sampleReport)
        val report = reportRepo.getReportById(id)!!
        reportRepo.updateReport(report.copy(notes = "Updated notes"))

        val updated = reportRepo.getReportById(id)!!
        assertEquals("Updated notes", updated.notes)
    }

    // ── Sync hooks – SpotRepository ────────────────────────────────────────

    @Test
    fun `getPendingSyncSpots returns only PENDING_SYNC spots`() = runTest {
        spotRepo.upsertSpot(sampleSpot)
        val pendingId = spotRepo.upsertSpot(
            sampleSpot.copy(name = "Pending Spot", syncStatus = SyncStatus.PENDING_SYNC)
        )
        val pending = spotRepo.getPendingSyncSpots()
        assertEquals(1, pending.size)
        assertEquals(pendingId, pending[0].id)
    }

    @Test
    fun `markSpotSynced sets state and remoteId`() = runTest {
        val id = spotRepo.upsertSpot(
            sampleSpot.copy(syncStatus = SyncStatus.PENDING_SYNC)
        )
        spotRepo.markSpotSynced(id, "remote-uuid-1")
        val spot = spotRepo.getSpotById(id)!!
        assertEquals(SyncStatus.SYNCED, spot.syncStatus)
        assertEquals("remote-uuid-1", spot.remoteId)
        assertTrue(spotRepo.getPendingSyncSpots().isEmpty())
    }

    @Test
    fun `markSpotSyncFailed sets SYNC_FAILED state`() = runTest {
        val id = spotRepo.upsertSpot(
            sampleSpot.copy(syncStatus = SyncStatus.PENDING_SYNC)
        )
        spotRepo.markSpotSyncFailed(id)
        assertEquals(SyncStatus.SYNC_FAILED, spotRepo.getSpotById(id)!!.syncStatus)
    }

    @Test
    fun `getPendingSyncSpots excludes soft-deleted`() = runTest {
        spotRepo.upsertSpot(
            sampleSpot.copy(
                name = "Deleted Pending",
                syncStatus = SyncStatus.PENDING_SYNC,
                deletedAt = System.currentTimeMillis()
            )
        )
        assertTrue(spotRepo.getPendingSyncSpots().isEmpty())
    }

    // ── Sync hooks – ReportRepository ──────────────────────────────────────

    @Test
    fun `getPendingSyncReports returns only PENDING_SYNC reports`() = runTest {
        reportRepo.insertReport(sampleReport)
        val pendingId = reportRepo.insertReport(
            sampleReport.copy(syncStatus = SyncStatus.PENDING_SYNC)
        )
        val pending = reportRepo.getPendingSyncReports()
        assertEquals(1, pending.size)
        assertEquals(pendingId, pending[0].id)
    }

    @Test
    fun `markReportSynced sets state and remoteId`() = runTest {
        val id = reportRepo.insertReport(
            sampleReport.copy(syncStatus = SyncStatus.PENDING_SYNC)
        )
        reportRepo.markReportSynced(id, "remote-uuid-report-1")
        val report = reportRepo.getReportById(id)!!
        assertEquals(SyncStatus.SYNCED, report.syncStatus)
        assertEquals("remote-uuid-report-1", report.remoteId)
        assertTrue(reportRepo.getPendingSyncReports().isEmpty())
    }

    @Test
    fun `markReportSyncFailed sets SYNC_FAILED state`() = runTest {
        val id = reportRepo.insertReport(
            sampleReport.copy(syncStatus = SyncStatus.PENDING_SYNC)
        )
        reportRepo.markReportSyncFailed(id)
        assertEquals(SyncStatus.SYNC_FAILED, reportRepo.getReportById(id)!!.syncStatus)
    }
}
