package com.dumpsterscout.fake

import com.dumpsterscout.domain.model.AuthState
import com.dumpsterscout.domain.model.LocalUser
import com.dumpsterscout.domain.repository.UserRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOf

class FakeUserRepository(
    initialUser: LocalUser = LocalUser(localId = "fake-local-id-0001")
) : UserRepository {

    private val _user = MutableStateFlow(initialUser)

    override fun getCurrentUser(): Flow<LocalUser> = _user.asStateFlow()
    override suspend fun getOrCreateUser(): LocalUser = _user.value
    override suspend fun updateDisplayName(name: String) { _user.value = _user.value.copy(displayName = name) }
    override suspend fun linkRemoteAccount(remoteUserId: String) { _user.value = _user.value.copy(remoteUserId = remoteUserId, isAnonymous = false) }
    override suspend fun clearUser() { _user.value = LocalUser(localId = "fake-local-id-0001") }
    override suspend fun signInWithOtp(email: String): Result<Unit> = Result.failure(IllegalStateException("Not configured"))
    override suspend fun verifyOtp(email: String, token: String): Result<Unit> = Result.failure(IllegalStateException("Not configured"))
    override suspend fun signOut() { clearUser() }
    override fun getAuthState(): Flow<AuthState> = flowOf(AuthState.SIGNED_OUT)
}

