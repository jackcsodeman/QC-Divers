package com.dumpsterscout.fake

import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.domain.model.Visibility
import com.dumpsterscout.domain.repository.TireSpotRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * In-memory fake implementation of [TireSpotRepository] for unit tests.
 */
class FakeTireSpotRepository(
    initialSpots: List<TireSpot> = emptyList()
) : TireSpotRepository {

    private val spots = MutableStateFlow(initialSpots.toMutableList())
    private var nextId = (initialSpots.maxOfOrNull { it.id } ?: 0L) + 1

    override fun getAllSpots(): Flow<List<TireSpot>> =
        spots.map { it.toList() }

    override fun getFavoriteSpots(): Flow<List<TireSpot>> =
        spots.map { list -> list.filter { it.isFavorite && !it.isRetired } }

    override fun getActiveSpots(): Flow<List<TireSpot>> =
        spots.map { list -> list.filter { !it.isRetired } }

    override fun searchSpots(query: String): Flow<List<TireSpot>> =
        spots.map { list ->
            val q = query.lowercase()
            list.filter { spot ->
                !spot.isRetired && (
                    spot.name.lowercase().contains(q) ||
                    spot.address.lowercase().contains(q) ||
                    spot.notes.lowercase().contains(q) ||
                    spot.tags.any { it.lowercase().contains(q) }
                )
            }
        }

    override suspend fun getSpotById(id: Long): TireSpot? =
        spots.value.find { it.id == id }

    override suspend fun getNearestSpots(
        latitude: Double,
        longitude: Double,
        radiusMeters: Double
    ): List<TireSpot> =
        spots.value
            .filter { !it.isRetired }
            .filter { haversineMeters(latitude, longitude, it.latitude, it.longitude) <= radiusMeters }
            .sortedBy { haversineMeters(latitude, longitude, it.latitude, it.longitude) }

    override suspend fun upsertSpot(spot: TireSpot): Long {
        val id = if (spot.id == 0L) nextId++ else spot.id
        val updated = spot.copy(id = id)
        spots.update { list ->
            val mutable = list.toMutableList()
            val idx = mutable.indexOfFirst { it.id == id }
            if (idx >= 0) mutable[idx] = updated else mutable.add(updated)
            mutable
        }
        return id
    }

    override suspend fun deleteSpot(spot: TireSpot) {
        spots.update { list -> list.filter { it.id != spot.id }.toMutableList() }
    }

    override suspend fun updateLastStatus(spotId: Long, status: TireSpotStatus, timestamp: Long) {
        spots.update { list ->
            list.map { if (it.id == spotId) it.copy(lastStatus = status, lastChecked = timestamp) else it }.toMutableList()
        }
    }

    override suspend fun toggleFavorite(spotId: Long) {
        spots.update { list ->
            list.map { if (it.id == spotId) it.copy(isFavorite = !it.isFavorite) else it }.toMutableList()
        }
    }

    override suspend fun retireSpot(spotId: Long) {
        spots.update { list ->
            list.map { if (it.id == spotId) it.copy(isRetired = true) else it }.toMutableList()
        }
    }

    override suspend fun deleteAllSpots() {
        spots.value = mutableListOf()
    }

    override suspend fun getPendingSyncSpots(): List<TireSpot> =
        spots.value.filter { it.syncStatus == SyncStatus.PENDING_SYNC && it.deletedAt == null }

    override suspend fun markSpotSynced(id: Long, remoteId: String) {
        spots.update { list ->
            list.map {
                if (it.id == id) it.copy(syncStatus = SyncStatus.SYNCED, remoteId = remoteId) else it
            }.toMutableList()
        }
    }

    override suspend fun markSpotSyncFailed(id: Long) {
        spots.update { list ->
            list.map {
                if (it.id == id) it.copy(syncStatus = SyncStatus.SYNC_FAILED) else it
            }.toMutableList()
        }
    }

    private fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371000.0
        val phi1 = Math.toRadians(lat1)
        val phi2 = Math.toRadians(lat2)
        val dPhi = Math.toRadians(lat2 - lat1)
        val dLambda = Math.toRadians(lon2 - lon1)
        val a = sin(dPhi / 2) * sin(dPhi / 2) +
                cos(phi1) * cos(phi2) * sin(dLambda / 2) * sin(dLambda / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    override suspend fun publishSpot(spotId: Long) {
        spots.update { list ->
            list.map {
                if (it.id == spotId) it.copy(
                    visibility = Visibility.COMMUNITY,
                    syncStatus = SyncStatus.PENDING_SYNC
                ) else it
            }.toMutableList()
        }
    }

    override suspend fun getSpotByRemoteId(remoteId: String): TireSpot? =
        spots.value.find { it.remoteId == remoteId }

    override suspend fun upsertSpotFromRemote(spot: TireSpot): Long {
        val id = if (spot.id == 0L) nextId++ else spot.id
        val updated = spot.copy(id = id, syncStatus = SyncStatus.SYNCED)
        spots.update { list ->
            val mutable = list.toMutableList()
            val idx = mutable.indexOfFirst { it.id == id }
            if (idx >= 0) mutable[idx] = updated else mutable.add(updated)
            mutable
        }
        return id
    }
}
