package com.dumpsterscout.fake

import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.model.Visibility
import com.dumpsterscout.domain.repository.TireReportRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update

/**
 * In-memory fake implementation of [TireReportRepository] for unit tests.
 */
class FakeTireReportRepository(
    initialReports: List<TireReport> = emptyList()
) : TireReportRepository {

    private val reports = MutableStateFlow(initialReports.toMutableList())
    private var nextId = (initialReports.maxOfOrNull { it.id } ?: 0L) + 1

    override fun getAllReports(): Flow<List<TireReport>> =
        reports.map { it.sortedByDescending { r -> r.timestamp } }

    override fun getReportsBySpot(spotId: Long): Flow<List<TireReport>> =
        reports.map { list -> list.filter { it.tireSpotId == spotId }.sortedByDescending { it.timestamp } }

    override fun getRecentReports(limit: Int): Flow<List<TireReport>> =
        reports.map { list -> list.sortedByDescending { it.timestamp }.take(limit) }

    override suspend fun getReportById(id: Long): TireReport? =
        reports.value.find { it.id == id }

    override suspend fun insertReport(report: TireReport): Long {
        val id = if (report.id == 0L) nextId++ else report.id
        val updated = report.copy(id = id)
        reports.update { list ->
            val mutable = list.toMutableList()
            mutable.add(updated)
            mutable
        }
        return id
    }

    override suspend fun updateReport(report: TireReport) {
        reports.update { list ->
            list.map { if (it.id == report.id) report else it }.toMutableList()
        }
    }

    override suspend fun deleteReport(report: TireReport) {
        reports.update { list -> list.filter { it.id != report.id }.toMutableList() }
    }

    override suspend fun deleteAllReports() {
        reports.value = mutableListOf()
    }

    override suspend fun getPendingSyncReports(): List<TireReport> =
        reports.value.filter { it.syncStatus == SyncStatus.PENDING_SYNC && it.deletedAt == null }

    override suspend fun markReportSynced(id: Long, remoteId: String) {
        reports.update { list ->
            list.map {
                if (it.id == id) it.copy(syncStatus = SyncStatus.SYNCED, remoteId = remoteId) else it
            }.toMutableList()
        }
    }

    override suspend fun markReportSyncFailed(id: Long) {
        reports.update { list ->
            list.map {
                if (it.id == id) it.copy(syncStatus = SyncStatus.SYNC_FAILED) else it
            }.toMutableList()
        }
    }

    override suspend fun publishReport(reportId: Long) {
        reports.update { list ->
            list.map {
                if (it.id == reportId) it.copy(
                    visibility  = Visibility.COMMUNITY,
                    syncStatus  = SyncStatus.PENDING_SYNC
                ) else it
            }.toMutableList()
        }
    }

    override suspend fun getReportByRemoteId(remoteId: String): TireReport? =
        reports.value.find { it.remoteId == remoteId }

    override suspend fun insertReportFromRemote(report: TireReport): Long {
        val id = if (report.id == 0L) nextId++ else report.id
        val updated = report.copy(id = id, syncStatus = SyncStatus.SYNCED)
        reports.update { list ->
            val mutable = list.toMutableList()
            mutable.add(updated)
            mutable
        }
        return id
    }
}
