package com.dumpsterscout

import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.data.repository.UserRepositoryImpl
import com.dumpsterscout.fake.FakeUserRepository
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

/**
 * Unit tests for [UserRepositoryImpl] and [FakeUserRepository].
 *
 * [UserRepositoryImpl] requires [AppPreferences] which wraps DataStore; we use
 * MockK to stub it so the tests stay pure-JVM with no Android context.
 */
class UserRepositoryImplTest {

    // ── UserRepositoryImpl (with mocked AppPreferences) ────────────────────

    private fun buildPrefs(
        localId: String? = null,
        displayName: String? = null,
        remoteUserId: String? = null,
        firstSeenAt: Long? = null
    ): AppPreferences = mockk<AppPreferences>().also { prefs ->
        every { prefs.localUserId } returns flowOf(localId)
        every { prefs.displayName } returns flowOf(displayName)
        every { prefs.remoteUserId } returns flowOf(remoteUserId)
        every { prefs.firstSeenAt } returns flowOf(firstSeenAt)
        coEvery { prefs.setLocalUserId(any()) } returns Unit
        coEvery { prefs.setDisplayName(any()) } returns Unit
        coEvery { prefs.setRemoteUserId(any()) } returns Unit
        coEvery { prefs.setFirstSeenAt(any()) } returns Unit
        coEvery { prefs.clearUserIdentity() } returns Unit
    }

    @Test
    fun `getOrCreateUser generates UUID when no localId stored`() = runTest {
        val prefs = buildPrefs(localId = null)
        val repo = UserRepositoryImpl(prefs, null)

        val user = repo.getOrCreateUser()

        assertTrue("localId must not be blank", user.localId.isNotBlank())
        assertTrue("should be anonymous", user.isAnonymous)
        assertNull(user.remoteUserId)
        coVerify { prefs.setLocalUserId(any()) }
    }

    @Test
    fun `getOrCreateUser returns stored localId when present`() = runTest {
        val storedId = "stored-uuid-1234"
        val prefs = buildPrefs(localId = storedId, firstSeenAt = 1000L)
        val repo = UserRepositoryImpl(prefs, null)

        val user = repo.getOrCreateUser()

        assertEquals(storedId, user.localId)
    }

    @Test
    fun `getOrCreateUser uses remoteUserId and marks non-anonymous`() = runTest {
        val prefs = buildPrefs(
            localId = "local-abc",
            remoteUserId = "supabase-uid-xyz",
            firstSeenAt = 5000L
        )
        val repo = UserRepositoryImpl(prefs, null)

        val user = repo.getOrCreateUser()

        assertEquals("supabase-uid-xyz", user.remoteUserId)
        assertFalse(user.isAnonymous)
    }

    @Test
    fun `updateDisplayName delegates to prefs`() = runTest {
        val prefs = buildPrefs(localId = "local-abc", firstSeenAt = 1000L)
        val repo = UserRepositoryImpl(prefs, null)

        repo.updateDisplayName("Scout Jack")

        coVerify { prefs.setDisplayName("Scout Jack") }
    }

    @Test
    fun `linkRemoteAccount delegates to prefs`() = runTest {
        val prefs = buildPrefs(localId = "local-abc", firstSeenAt = 1000L)
        val repo = UserRepositoryImpl(prefs, null)

        repo.linkRemoteAccount("supabase-uid-new")

        coVerify { prefs.setRemoteUserId("supabase-uid-new") }
    }

    @Test
    fun `clearUser delegates to prefs`() = runTest {
        val prefs = buildPrefs(localId = "local-abc", firstSeenAt = 1000L)
        val repo = UserRepositoryImpl(prefs, null)

        repo.clearUser()

        coVerify { prefs.clearUserIdentity() }
    }

    // ── FakeUserRepository ─────────────────────────────────────────────────

    @Test
    fun `fake getOrCreateUser returns initial user`() = runTest {
        val fake = FakeUserRepository()
        val user = fake.getOrCreateUser()
        assertEquals("fake-local-id-0001", user.localId)
        assertTrue(user.isAnonymous)
    }

    @Test
    fun `fake updateDisplayName reflects in getCurrentUser`() = runTest {
        val fake = FakeUserRepository()
        fake.updateDisplayName("Test Diver")
        val user = fake.getCurrentUser().first()
        assertEquals("Test Diver", user.displayName)
    }

    @Test
    fun `fake linkRemoteAccount sets remoteUserId and clears anonymous flag`() = runTest {
        val fake = FakeUserRepository()
        fake.linkRemoteAccount("remote-uid-abc")
        val user = fake.getCurrentUser().first()
        assertEquals("remote-uid-abc", user.remoteUserId)
        assertFalse(user.isAnonymous)
    }

    @Test
    fun `fake clearUser resets to anonymous`() = runTest {
        val fake = FakeUserRepository()
        fake.linkRemoteAccount("remote-uid-abc")
        fake.clearUser()
        val user = fake.getCurrentUser().first()
        assertNull(user.remoteUserId)
        assertTrue(user.isAnonymous)
    }
}
