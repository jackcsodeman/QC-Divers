package com.dumpsterscout

import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.model.TimeRelevance
import com.dumpsterscout.domain.model.TimingNote
import com.dumpsterscout.util.VoiceParser
import org.junit.Assert.*
import org.junit.Test

class VoiceParserTest {

    @Test
    fun `parse fast phrase - empty today`() {
        val result = VoiceParser.parse("empty today")
        assertEquals(SpotStatus.EMPTY, result.status)
        assertEquals(TimeRelevance.TODAY, result.timeRelevance)
    }

    @Test
    fun `parse fast phrase - locked today`() {
        val result = VoiceParser.parse("locked today")
        assertEquals(SpotStatus.LOCKED, result.status)
    }

    @Test
    fun `parse fast phrase - security came by`() {
        val result = VoiceParser.parse("security came by")
        assertEquals(SpotStatus.SECURITY_ACTIVE, result.status)
        assertTrue(result.securityMentioned)
    }

    @Test
    fun `parse fast phrase - good haul today`() {
        val result = VoiceParser.parse("good haul today")
        assertEquals(SpotStatus.GOOD_HAUL, result.status)
        assertEquals(TimeRelevance.TODAY, result.timeRelevance)
    }

    @Test
    fun `parse fast phrase - nothing there today`() {
        val result = VoiceParser.parse("nothing there today")
        assertEquals(SpotStatus.NOTHING_THERE, result.status)
    }

    @Test
    fun `parse fast phrase - compactor only`() {
        val result = VoiceParser.parse("compactor only, don't bother")
        assertEquals(SpotStatus.COMPACTOR_ONLY, result.status)
    }

    @Test
    fun `parse spot name from transcript - dumpster suffix`() {
        val result = VoiceParser.parse("The Aldi dumpster is empty today")
        assertNotNull(result.parsedSpotName)
        assertTrue(result.parsedSpotName!!.lowercase().contains("aldi"))
        assertEquals(SpotStatus.EMPTY, result.status)
        assertEquals(TimeRelevance.TODAY, result.timeRelevance)
    }

    @Test
    fun `parse spot name - CVS with findings`() {
        val result = VoiceParser.parse("CVS on Main had expired snacks and flowers tonight")
        // Should detect some status / name
        assertEquals(TimeRelevance.TONIGHT, result.timeRelevance)
        assertTrue(result.tags.contains("flowers") || result.tags.contains("food"))
    }

    @Test
    fun `parse rain damage`() {
        val result = VoiceParser.parse("Trader Joe's dumpster was full but rain soaked everything")
        assertTrue(result.weatherIssue)
    }

    @Test
    fun `parse came too early`() {
        val result = VoiceParser.parse("came too early, trash not thrown out yet")
        assertEquals(TimingNote.CAME_TOO_EARLY, result.timingNote)
    }

    @Test
    fun `parse came too late`() {
        val result = VoiceParser.parse("came too late, already picked up")
        assertEquals(TimingNote.CAME_TOO_LATE, result.timingNote)
    }

    @Test
    fun `parse already picked through`() {
        val result = VoiceParser.parse("someone already picked through it")
        assertTrue(result.alreadyPicked)
    }

    @Test
    fun `confidence increases with more signals`() {
        val minimal = VoiceParser.parse("went there")
        val detailed = VoiceParser.parse("Aldi dumpster was empty today")
        assertTrue(detailed.confidence > minimal.confidence)
    }

    @Test
    fun `raw transcript preserved`() {
        val input = "Target had a ton of clothing tonight"
        val result = VoiceParser.parse(input)
        assertEquals(input, result.rawTranscript)
    }

    @Test
    fun `tags extracted for food`() {
        val result = VoiceParser.parse("CVS had lots of snacks and expired bread")
        assertTrue(result.tags.contains("food") || result.tags.contains("pharmacy"))
    }

    @Test
    fun `tags extracted for flowers`() {
        val result = VoiceParser.parse("found flowers and expired medicine")
        assertTrue(result.tags.contains("flowers") || result.tags.contains("pharmacy"))
    }

    @Test
    fun `quantity hint - large`() {
        val result = VoiceParser.parse("tons of stuff in there, jackpot")
        assertEquals("large", result.quantityHint)
    }

    @Test
    fun `parse overflowing`() {
        val result = VoiceParser.parse("dumpster was overflowing tonight")
        assertEquals(SpotStatus.OVERFLOWING, result.status)
        assertEquals(TimeRelevance.TONIGHT, result.timeRelevance)
    }

    @Test
    fun `resolve spot - exact name match`() {
        val spots = listOf(
            com.dumpsterscout.domain.model.DumpsterSpot(id = 1L, name = "Aldi West Side"),
            com.dumpsterscout.domain.model.DumpsterSpot(id = 2L, name = "CVS Main Street")
        )
        val result = VoiceParser.parse("Aldi dumpster is empty today")
        val resolved = VoiceParser.resolveSpot(result, spots)
        assertEquals(1L, resolved.matchedSpotId)
    }

    @Test
    fun `resolve spot - falls back to nearest when no name`() {
        val spots = listOf(
            com.dumpsterscout.domain.model.DumpsterSpot(id = 1L, name = "Aldi West Side"),
        )
        val result = VoiceParser.parse("empty today")
        val resolved = VoiceParser.resolveSpot(result, spots, nearestSpotId = 1L)
        assertEquals(1L, resolved.matchedSpotId)
    }

    @Test
    fun `toReport creates PersonalReport correctly`() {
        val result = VoiceParser.parse("Aldi dumpster empty today")
        val report = VoiceParser.toReport(result, spotId = 1L, spotName = "Aldi")
        assertEquals(1L, report.spotId)
        assertTrue(report.isFromVoice)
        assertNotNull(report.voiceTranscript)
        assertEquals(SpotStatus.EMPTY, report.status)
    }
}
