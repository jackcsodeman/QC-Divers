package com.dumpsterscout

import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.fake.FakeReportRepository
import com.dumpsterscout.ui.history.FilterPeriod
import com.dumpsterscout.ui.history.HistoryViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class HistoryViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    private lateinit var reportRepo: FakeReportRepository
    private lateinit var viewModel: HistoryViewModel

    private val now = System.currentTimeMillis()
    private val oneDayMs = 86_400_000L

    private val todayReport = PersonalReport(
        id = 1L,
        spotId = 1L,
        spotName = "Aldi – West Moline",
        status = SpotStatus.GOOD_HAUL,
        notes = "Great produce tonight",
        timestamp = now
    )

    private val weekOldReport = PersonalReport(
        id = 2L,
        spotId = 2L,
        spotName = "Target – Bettendorf",
        status = SpotStatus.FULL,
        notes = "Tons of clothes",
        timestamp = now - 3 * oneDayMs
    )

    private val oldReport = PersonalReport(
        id = 3L,
        spotId = 1L,
        spotName = "Aldi – West Moline",
        status = SpotStatus.EMPTY,
        notes = "Already picked",
        timestamp = now - 14 * oneDayMs
    )

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        reportRepo = FakeReportRepository(listOf(todayReport, weekOldReport, oldReport))
        viewModel = HistoryViewModel(reportRepo)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    // ── Initial state ──────────────────────────────────────────────────────

    @Test
    fun `initial state has isLoading true`() {
        assertTrue(viewModel.uiState.value.isLoading)
    }

    @Test
    fun `reports load and isLoading becomes false`() = runTest(testDispatcher) {
        advanceUntilIdle()
        assertFalse(viewModel.uiState.value.isLoading)
    }

    @Test
    fun `all 3 reports are loaded`() = runTest(testDispatcher) {
        advanceUntilIdle()
        assertEquals(3, viewModel.uiState.value.reports.size)
    }

    @Test
    fun `default filter is ALL and shows all reports`() = runTest(testDispatcher) {
        advanceUntilIdle()
        val state = viewModel.uiState.value
        assertEquals(FilterPeriod.ALL, state.filterPeriod)
        assertEquals(3, state.filteredReports.size)
    }

    // ── Period filter ──────────────────────────────────────────────────────

    @Test
    fun `TODAY filter shows only today's reports`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onFilterPeriodChange(FilterPeriod.TODAY)
        val filtered = viewModel.uiState.value.filteredReports
        assertEquals(1, filtered.size)
        assertEquals(todayReport.id, filtered[0].id)
    }

    @Test
    fun `THIS_WEEK filter shows reports from last 7 days`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onFilterPeriodChange(FilterPeriod.THIS_WEEK)
        val filtered = viewModel.uiState.value.filteredReports
        // todayReport (0d ago) and weekOldReport (3d ago) qualify; oldReport (14d ago) does not
        assertEquals(2, filtered.size)
    }

    @Test
    fun `ALL filter after THIS_WEEK shows all reports again`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onFilterPeriodChange(FilterPeriod.THIS_WEEK)
        viewModel.onFilterPeriodChange(FilterPeriod.ALL)
        assertEquals(3, viewModel.uiState.value.filteredReports.size)
    }

    // ── Search filter ──────────────────────────────────────────────────────

    @Test
    fun `search by spot name filters correctly`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onSearchQueryChange("Target")
        val filtered = viewModel.uiState.value.filteredReports
        assertEquals(1, filtered.size)
        assertEquals(weekOldReport.id, filtered[0].id)
    }

    @Test
    fun `search by notes filters correctly`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onSearchQueryChange("Great produce")
        val filtered = viewModel.uiState.value.filteredReports
        assertEquals(1, filtered.size)
        assertEquals(todayReport.id, filtered[0].id)
    }

    @Test
    fun `search is case insensitive`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onSearchQueryChange("great produce")
        assertEquals(1, viewModel.uiState.value.filteredReports.size)
    }

    @Test
    fun `empty search shows all reports`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onSearchQueryChange("XYZ")
        assertEquals(0, viewModel.uiState.value.filteredReports.size)
        viewModel.onSearchQueryChange("")
        assertEquals(3, viewModel.uiState.value.filteredReports.size)
    }

    @Test
    fun `period and search filters combine correctly`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onFilterPeriodChange(FilterPeriod.THIS_WEEK)
        viewModel.onSearchQueryChange("Aldi")
        // todayReport is within this week AND matches "Aldi"; weekOldReport does not match "Aldi"
        val filtered = viewModel.uiState.value.filteredReports
        assertEquals(1, filtered.size)
        assertEquals(todayReport.id, filtered[0].id)
    }

    // ── Delete report ──────────────────────────────────────────────────────

    @Test
    fun `deleteReport removes it from the list`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.deleteReport(todayReport)
        advanceUntilIdle()
        val reports = viewModel.uiState.value.reports
        assertEquals(2, reports.size)
        assertFalse(reports.any { it.id == todayReport.id })
    }

    @Test
    fun `deleteReport updates filteredReports`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.deleteReport(todayReport)
        advanceUntilIdle()
        val filtered = viewModel.uiState.value.filteredReports
        assertFalse(filtered.any { it.id == todayReport.id })
    }

    @Test
    fun `deleteReport only removes the targeted report`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.deleteReport(weekOldReport)
        advanceUntilIdle()
        val remaining = viewModel.uiState.value.reports
        assertEquals(2, remaining.size)
        assertTrue(remaining.any { it.id == todayReport.id })
        assertTrue(remaining.any { it.id == oldReport.id })
    }

    @Test
    fun `filterPeriod is stored in state after change`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onFilterPeriodChange(FilterPeriod.TODAY)
        assertEquals(FilterPeriod.TODAY, viewModel.uiState.value.filterPeriod)
    }

    @Test
    fun `searchQuery is stored in state after change`() = runTest(testDispatcher) {
        advanceUntilIdle()
        viewModel.onSearchQueryChange("Aldi")
        assertEquals("Aldi", viewModel.uiState.value.searchQuery)
    }
}
