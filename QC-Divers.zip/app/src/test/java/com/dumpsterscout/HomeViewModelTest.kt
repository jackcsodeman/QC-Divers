package com.dumpsterscout

import com.dumpsterscout.data.local.dao.RoutePlanDao
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.SpotCategory
import com.dumpsterscout.domain.repository.ReportRepository
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.domain.repository.TireReportRepository
import com.dumpsterscout.domain.repository.TireSpotRepository
import com.dumpsterscout.ui.home.HomeViewModel
import io.mockk.coEvery
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    private lateinit var spotRepository: SpotRepository
    private lateinit var reportRepository: ReportRepository
    private lateinit var tireSpotRepository: TireSpotRepository
    private lateinit var tireReportRepository: TireReportRepository
    private lateinit var appPreferences: AppPreferences
    private lateinit var routePlanDao: RoutePlanDao

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)

        spotRepository = mockk()
        reportRepository = mockk()
        tireSpotRepository = mockk()
        tireReportRepository = mockk()
        appPreferences = mockk()
        routePlanDao = mockk()

        every { appPreferences.demoDataSeeded } returns flowOf(true)
        every { spotRepository.getActiveSpots() } returns flowOf(
            listOf(DumpsterSpot(id = 1L, name = "Aldi", category = SpotCategory.GROCERY))
        )
        every { spotRepository.getFavoriteSpots() } returns flowOf(emptyList())
        every { reportRepository.getRecentReports(10) } returns flowOf(
            listOf(
                PersonalReport(id = 1L, spotId = 1L, spotName = "Aldi", timestamp = 200L),
                PersonalReport(id = 2L, spotId = 1L, spotName = "Aldi", timestamp = 100L)
            )
        )
        every { reportRepository.getReportCount() } returns flowOf(42)
        every { tireSpotRepository.getActiveSpots() } returns flowOf(emptyList())
        every { tireReportRepository.getRecentReports(3) } returns flowOf(emptyList())

        coEvery { appPreferences.setDemoDataSeeded(any()) } returns Unit
        coEvery { routePlanDao.insert(any()) } returns 1L
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `observeData uses lightweight report count and keeps recent reports list`() = runTest(testDispatcher) {
        val viewModel = HomeViewModel(
            spotRepository = spotRepository,
            reportRepository = reportRepository,
            tireSpotRepository = tireSpotRepository,
            tireReportRepository = tireReportRepository,
            appPreferences = appPreferences,
            routePlanDao = routePlanDao
        )

        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertEquals(42, state.totalReports)
        assertEquals(2, state.recentReports.size)
        verify(exactly = 1) { reportRepository.getRecentReports(10) }
        verify(exactly = 1) { reportRepository.getReportCount() }
        verify(exactly = 0) { reportRepository.getAllReports() }
    }
}
