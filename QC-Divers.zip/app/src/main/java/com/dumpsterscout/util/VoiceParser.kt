package com.dumpsterscout.util

import com.dumpsterscout.domain.model.BagCondition
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.FillLevel
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.model.TimingNote
import com.dumpsterscout.domain.model.TimeRelevance
import com.dumpsterscout.domain.model.VoiceParseResult

/**
 * Deterministic voice/text parser.
 *
 * Takes a raw transcript string and extracts structured fields.
 * Designed to be replaced by an ML/NLP model without changing the interface.
 *
 * Priority: fast-phrase matching → status keywords → name extraction → fallback.
 */
object VoiceParser {

    // ──────────────────────────────────────────────────────────────────────────
    // Fast-phrase shortcuts
    // ──────────────────────────────────────────────────────────────────────────
    private val fastPhrases = mapOf(
        listOf("good today", "good haul today", "good tonight") to SpotStatus.GOOD_HAUL,
        listOf("bad today", "bad tonight") to SpotStatus.NOTHING_THERE,
        listOf("empty today", "empty tonight") to SpotStatus.EMPTY,
        listOf("locked today", "locked tonight", "it's locked", "now locked") to SpotStatus.LOCKED,
        listOf("nothing there today", "nothing there tonight", "nothing there") to SpotStatus.NOTHING_THERE,
        listOf("security came by", "security was there", "security active") to SpotStatus.SECURITY_ACTIVE,
        listOf("compactor only", "just a compactor") to SpotStatus.COMPACTOR_ONLY,
        listOf("overflowing", "way too full", "spilling over") to SpotStatus.OVERFLOWING
    )

    // ──────────────────────────────────────────────────────────────────────────
    // Status keyword clusters
    // ──────────────────────────────────────────────────────────────────────────
    private val statusKeywords: Map<SpotStatus, List<String>> = mapOf(
        SpotStatus.EMPTY to listOf("empty", "nothing", "barren", "cleared out", "already emptied"),
        SpotStatus.FULL to listOf("full", "loaded", "packed"),
        SpotStatus.HALF_FULL to listOf("half", "partially", "halfway"),
        SpotStatus.OVERFLOWING to listOf("overflow", "overflowing", "spilling", "piled up"),
        SpotStatus.LOCKED to listOf("locked", "padlocked", "gated up", "chained", "blocked"),
        SpotStatus.COMPACTOR_ONLY to listOf("compactor", "compacted", "crusher"),
        SpotStatus.GOOD_HAUL to listOf("good haul", "great haul", "jackpot", "score", "tons of stuff", "full of good"),
        SpotStatus.SECURITY_ACTIVE to listOf("security", "guard", "camera", "cop", "police", "management"),
        SpotStatus.CONSTRUCTION_REMOVED to listOf("construction", "removed", "gone", "demolished", "fenced off"),
        SpotStatus.ALREADY_PICKED_THROUGH to listOf("already picked", "picked through", "someone else", "been gone through"),
        SpotStatus.NOTHING_THERE to listOf("nothing there", "nothing inside", "nothing good", "no good stuff", "came up empty")
    )

    private val timeKeywords = linkedMapOf(
        TimeRelevance.THIS_MORNING to listOf("this morning", "early this morning"),
        TimeRelevance.TONIGHT to listOf("tonight", "this evening", "this night"),
        TimeRelevance.YESTERDAY to listOf("yesterday", "last night", "yesterday night"),
        TimeRelevance.TODAY to listOf("today", "earlier today"),
        TimeRelevance.EARLIER to listOf("earlier", "a while ago", "few hours ago")
    )

    private val fillKeywords = mapOf(
        FillLevel.EMPTY to listOf("empty", "nothing"),
        FillLevel.HALF_FULL to listOf("half", "halfway", "partial"),
        FillLevel.FULL to listOf("full", "packed", "loaded"),
        FillLevel.OVERFLOWING to listOf("overflow", "overflowing", "spilling")
    )

    // ──────────────────────────────────────────────────────────────────────────
    // Public API
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Parse raw transcript into a [VoiceParseResult].
     * Call [resolveSpot] afterwards to attach spot candidates.
     */
    fun parse(transcript: String): VoiceParseResult {
        val lower = transcript.lowercase().trim()

        // Fast phrase match first
        val fastStatus = fastPhrases.entries
            .firstOrNull { (phrases, _) -> phrases.any { phrase -> lower.contains(phrase) } }
            ?.value

        val status = fastStatus ?: detectStatus(lower)
        val timeRelevance = detectTimeRelevance(lower)
        val fillLevel = detectFillLevel(lower)
        val securityMentioned = lowerContainsAny(lower, listOf("security", "guard", "cop", "police"))
        val weatherIssue = lowerContainsAny(lower, listOf("rain", "wet", "soaked", "flooded", "moisture"))
        val alreadyPicked = lowerContainsAny(lower, listOf("picked through", "already picked", "someone already"))
        val timingNote = when {
            lowerContainsAny(lower, listOf("came too early", "too early", "not thrown out yet")) -> TimingNote.CAME_TOO_EARLY
            lowerContainsAny(lower, listOf("came too late", "too late", "already picked up")) -> TimingNote.CAME_TOO_LATE
            else -> TimingNote.NONE
        }

        val parsedName = extractSpotName(lower)
        val notes = extractNotes(lower, parsedName)
        val tags = extractTags(lower)
        val quantityHint = extractQuantityHint(lower)

        val confidence = calculateConfidence(status, parsedName, timeRelevance)

        return VoiceParseResult(
            parsedSpotName = parsedName?.ifBlank { null },
            status = status,
            fillLevel = fillLevel,
            timeRelevance = timeRelevance,
            notes = notes,
            tags = tags,
            securityMentioned = securityMentioned,
            weatherIssue = weatherIssue,
            alreadyPicked = alreadyPicked,
            timingNote = timingNote,
            quantityHint = quantityHint,
            rawTranscript = transcript,
            confidence = confidence
        )
    }

    /**
     * Given a parse result and a list of available spots, attach the best match.
     */
    fun resolveSpot(
        result: VoiceParseResult,
        spots: List<DumpsterSpot>,
        nearestSpotId: Long? = null
    ): VoiceParseResult {
        if (spots.isEmpty()) return result

        val nameQuery = result.parsedSpotName?.lowercase() ?: ""

        val scored = spots.map { spot ->
            val nameLower = spot.name.lowercase()
            val addressLower = spot.address.lowercase()
            var score = 0f

            if (nameQuery.isNotBlank()) {
                when {
                    nameLower == nameQuery -> score += 1.0f
                    nameLower.contains(nameQuery) || nameQuery.contains(nameLower) -> score += 0.7f
                    nameQuery.split(" ").any { word -> word.length > 3 && nameLower.contains(word) } -> score += 0.4f
                    addressLower.contains(nameQuery) -> score += 0.3f
                }
            }

            // Boost nearest spot
            if (spot.id == nearestSpotId) score += 0.2f

            spot to score
        }.filter { it.second > 0f }.sortedByDescending { it.second }

        if (scored.isEmpty()) {
            // Fall back to nearest if available
            return result.copy(
                matchedSpotId = nearestSpotId,
                confidence = if (nearestSpotId != null) 0.3f else result.confidence
            )
        }

        val best = scored.first()
        val candidates = scored.take(3).map { it.first.id }
        val topConfidence = if (best.second >= 0.7f) 0.9f
                           else if (best.second >= 0.4f) 0.7f
                           else 0.4f

        return result.copy(
            matchedSpotId = best.first.id,
            candidateSpotIds = candidates,
            confidence = topConfidence.coerceAtMost(1f)
        )
    }

    /**
     * Convert a [VoiceParseResult] to a [PersonalReport] for a given spot.
     */
    fun toReport(
        result: VoiceParseResult,
        spotId: Long,
        spotName: String,
        latitude: Double? = null,
        longitude: Double? = null
    ): PersonalReport = PersonalReport(
        spotId = spotId,
        spotName = spotName,
        status = result.status ?: SpotStatus.UNKNOWN,
        fillLevel = result.fillLevel ?: FillLevel.UNKNOWN,
        bagCondition = BagCondition.UNKNOWN,
        notes = result.notes,
        tags = result.tags,
        securitySeen = result.securityMentioned,
        rainDamage = result.weatherIssue,
        alreadyPickedThrough = result.alreadyPicked,
        cameTooEarly = result.timingNote == TimingNote.CAME_TOO_EARLY,
        cameTooLate = result.timingNote == TimingNote.CAME_TOO_LATE,
        voiceTranscript = result.rawTranscript,
        isFromVoice = true,
        latitude = latitude,
        longitude = longitude
    )

    // ──────────────────────────────────────────────────────────────────────────
    // Internal helpers
    // ──────────────────────────────────────────────────────────────────────────

    private fun detectStatus(lower: String): SpotStatus? {
        var best: SpotStatus? = null
        var bestCount = 0
        statusKeywords.forEach { (status, keywords) ->
            val count = keywords.count { lower.contains(it) }
            if (count > bestCount) {
                bestCount = count
                best = status
            }
        }
        return best
    }

    private fun detectTimeRelevance(lower: String): TimeRelevance {
        return timeKeywords.entries
            .firstOrNull { (_, words) -> words.any { lower.contains(it) } }
            ?.key ?: TimeRelevance.UNSPECIFIED
    }

    private fun detectFillLevel(lower: String): FillLevel? {
        return fillKeywords.entries
            .firstOrNull { (_, words) -> words.any { lower.contains(it) } }
            ?.key
    }

    private fun extractSpotName(lower: String): String? {
        // Common patterns: "<Name> dumpster", "<Name> is", "at <Name>", "behind <Name>", "the <Name>"
        val patterns = listOf(
            Regex("(?:the |at |behind |near )([a-z][a-z ]{1,30})(?:'s)? dumpster"),
            Regex("([a-z][a-z ]{1,30})(?:'s)? (?:dumpster|bin|trash|garbage) (?:is|was|had|has)"),
            Regex("(?:at |behind |near )([a-z][a-z ]{1,24}?)(?:\\s+(?:is|was|had|has|on|in|dumpster))"),
            Regex("^([a-z][a-z ]{1,24}) (?:is|was|had|has|on|in)")
        )
        for (pattern in patterns) {
            val match = pattern.find(lower) ?: continue
            val name = match.groupValues[1].trim()
            if (name.length > 2 && name !in listOf("the", "it", "that", "this")) {
                return name.split(" ").joinToString(" ") { it.replaceFirstChar { c -> c.uppercaseChar() } }
            }
        }
        return null
    }

    private fun extractNotes(lower: String, extractedName: String?): String {
        // Remove parsed fragments and return remainder as free-form notes
        var notes = lower
        extractedName?.lowercase()?.let { notes = notes.replace(it, "") }
        statusKeywords.values.flatten().forEach { kw -> notes = notes.replace(kw, "") }
        timeKeywords.values.flatten().forEach { kw -> notes = notes.replace(kw, "") }
        notes = notes.replace(Regex("\\s{2,}"), " ").trim().trimEnd(',', '.', ' ')
        return notes.ifBlank { lower } // return original if everything stripped
    }

    private fun extractTags(lower: String): List<String> {
        val tagKeywords = mapOf(
            "food" to listOf("food", "groceries", "produce", "bread", "bakery", "dairy", "meat", "snacks"),
            "electronics" to listOf("electronics", "tech", "gadget", "phone", "computer"),
            "clothing" to listOf("clothes", "clothing", "shirts", "pants", "jackets"),
            "furniture" to listOf("furniture", "couch", "chair", "table", "desk"),
            "pharmacy" to listOf("pharmacy", "medicine", "health", "vitamins"),
            "flowers" to listOf("flowers", "bouquet", "plants"),
            "sealed-bags" to listOf("sealed", "unopened", "wrapped"),
            "rain-damaged" to listOf("rain", "wet", "soaked")
        )
        return tagKeywords.entries
            .filter { (_, keywords) -> keywords.any { lower.contains(it) } }
            .map { it.key }
    }

    private fun extractQuantityHint(lower: String): String {
        return when {
            lowerContainsAny(lower, listOf("tons of", "loads of", "full of", "jackpot")) -> "large"
            lowerContainsAny(lower, listOf("some", "a few", "decent", "handful")) -> "moderate"
            lowerContainsAny(lower, listOf("nothing", "empty", "bare", "very little")) -> "none"
            else -> ""
        }
    }

    private fun calculateConfidence(
        status: SpotStatus?,
        name: String?,
        timeRelevance: TimeRelevance
    ): Float {
        var score = 0f
        if (status != null && status != SpotStatus.UNKNOWN) score += 0.4f
        if (!name.isNullOrBlank()) score += 0.35f
        if (timeRelevance != TimeRelevance.UNSPECIFIED) score += 0.15f
        return score.coerceIn(0f, 1f)
    }

    private fun lowerContainsAny(lower: String, keywords: List<String>): Boolean =
        keywords.any { lower.contains(it) }
}
