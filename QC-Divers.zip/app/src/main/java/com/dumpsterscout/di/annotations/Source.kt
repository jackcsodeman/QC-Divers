package com.dumpsterscout.di.annotations

import javax.inject.Qualifier

/**
 * Hilt binding qualifier for the local (Room) data source.
 * Inject with `@LocalSource` on a constructor parameter or @Provides parameter.
 */
@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class LocalSource

/**
 * Hilt binding qualifier for the remote (Supabase) data source.
 * Inject with `@RemoteSource` on a constructor parameter or @Provides parameter.
 * The bound implementation is a no-op stub until a real backend is wired up.
 */
@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class RemoteSource
