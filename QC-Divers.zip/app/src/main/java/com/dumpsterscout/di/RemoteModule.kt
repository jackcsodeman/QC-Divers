package com.dumpsterscout.di

import android.content.Context
import com.dumpsterscout.data.remote.NoOpRemotePhotoDataSource
import com.dumpsterscout.data.remote.NoOpRemoteReportDataSource
import com.dumpsterscout.data.remote.NoOpRemoteSpotDataSource
import com.dumpsterscout.data.remote.NoOpRemoteTireSpotDataSource
import com.dumpsterscout.data.remote.RemotePhotoDataSource
import com.dumpsterscout.data.remote.RemoteReportDataSource
import com.dumpsterscout.data.remote.RemoteSpotDataSource
import com.dumpsterscout.data.remote.RemoteTireSpotDataSource
import com.dumpsterscout.data.remote.SupabasePhotoDataSource
import com.dumpsterscout.data.remote.SupabaseReportDataSource
import com.dumpsterscout.data.remote.SupabaseSpotDataSource
import com.dumpsterscout.data.remote.SupabaseTireSpotDataSource
import com.dumpsterscout.di.annotations.RemoteSource
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import io.github.jan.supabase.SupabaseClient
import javax.inject.Singleton

/**
 * Hilt module that wires remote data source implementations.
 *
 * When a configured [SupabaseClient] is available (credentials set), real
 * Supabase-backed implementations are bound.  When the client is null
 * (local-only mode), no-op stubs are used so the rest of the app continues
 * to work unchanged.
 *
 * To migrate one source at a time, simply update the relevant `@Provides`
 * function in this module; nothing else needs to change.
 */
@Module
@InstallIn(SingletonComponent::class)
object RemoteModule {

    @Provides
    @Singleton
    @RemoteSource
    fun provideRemoteSpotDataSource(
        client: SupabaseClient?
    ): RemoteSpotDataSource =
        if (client != null) SupabaseSpotDataSource(client)
        else NoOpRemoteSpotDataSource()

    @Provides
    @Singleton
    @RemoteSource
    fun provideRemoteReportDataSource(
        client: SupabaseClient?
    ): RemoteReportDataSource =
        if (client != null) SupabaseReportDataSource(client)
        else NoOpRemoteReportDataSource()

    @Provides
    @Singleton
    @RemoteSource
    fun provideRemoteTireSpotDataSource(
        client: SupabaseClient?
    ): RemoteTireSpotDataSource =
        if (client != null) SupabaseTireSpotDataSource(client)
        else NoOpRemoteTireSpotDataSource()

    @Provides
    @Singleton
    @RemoteSource
    fun provideRemotePhotoDataSource(
        client: SupabaseClient?,
        @ApplicationContext context: Context
    ): RemotePhotoDataSource =
        if (client != null) SupabasePhotoDataSource(client, context)
        else NoOpRemotePhotoDataSource()
}

