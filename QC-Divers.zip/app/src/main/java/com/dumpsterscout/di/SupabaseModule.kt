package com.dumpsterscout.di

import android.util.Log
import com.dumpsterscout.BuildConfig
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.storage.Storage
import javax.inject.Singleton

/**
 * Holds Supabase project credentials read from [BuildConfig].
 *
 * Credentials are injected via Gradle properties at build time:
 *   SUPABASE_URL=https://tnrxalbpaqzlvzhmjmft.supabase.co
 *   SUPABASE_ANON_KEY=sb_publishable_...
 *
 * Both values default to empty strings when not provided, making the app
 * safe to build and run locally without a live backend.
 */
data class SupabaseCredentials(
    val url: String,
    val anonKey: String
) {
    /** True when both credentials are non-empty and the backend can be reached. */
    val isConfigured: Boolean get() = url.isNotBlank() && anonKey.isNotBlank()
}

@Module
@InstallIn(SingletonComponent::class)
object SupabaseModule {

    @Provides
    @Singleton
    fun provideSupabaseCredentials(): SupabaseCredentials {
        val creds = SupabaseCredentials(
            url = BuildConfig.SUPABASE_URL,
            anonKey = BuildConfig.SUPABASE_ANON_KEY
        )
        if (!creds.isConfigured) {
            Log.i("SupabaseModule", "Supabase credentials not configured — running in local-only mode.")
        } else {
            Log.i("SupabaseModule", "Supabase credentials loaded (URL=${creds.url.take(40)}…)")
        }
        return creds
    }

    /**
     * Provides a real [SupabaseClient] with Postgrest, Auth, and Storage plugins installed.
     * Returns null when credentials are not configured so the app stays fully functional
     * offline without a backend.
     */
    @Provides
    @Singleton
    fun provideSupabaseClient(credentials: SupabaseCredentials): SupabaseClient? {
        if (!credentials.isConfigured) return null
        return createSupabaseClient(credentials.url, credentials.anonKey) {
            install(Postgrest)
            install(Auth)
            install(Storage)
        }
    }
}
