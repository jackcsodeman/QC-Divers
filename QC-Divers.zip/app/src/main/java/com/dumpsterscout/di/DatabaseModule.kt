package com.dumpsterscout.di

import android.content.Context
import androidx.room.Room
import com.dumpsterscout.data.local.DumpsterScoutDatabase
import com.dumpsterscout.data.local.dao.DumpsterSpotDao
import com.dumpsterscout.data.local.dao.PersonalReportDao
import com.dumpsterscout.data.local.dao.ReminderDao
import com.dumpsterscout.data.local.dao.RoutePlanDao
import com.dumpsterscout.data.local.dao.SpotPhotoDao
import com.dumpsterscout.data.local.dao.TireReportDao
import com.dumpsterscout.data.local.dao.TireSpotDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): DumpsterScoutDatabase =
        Room.databaseBuilder(
            context,
            DumpsterScoutDatabase::class.java,
            DumpsterScoutDatabase.DATABASE_NAME
        )
            .addMigrations(DumpsterScoutDatabase.MIGRATION_1_2, DumpsterScoutDatabase.MIGRATION_2_3, DumpsterScoutDatabase.MIGRATION_3_4)
            .build()

    @Provides
    fun provideSpotDao(db: DumpsterScoutDatabase): DumpsterSpotDao = db.spotDao()

    @Provides
    fun provideReportDao(db: DumpsterScoutDatabase): PersonalReportDao = db.reportDao()

    @Provides
    fun providePhotoDao(db: DumpsterScoutDatabase): SpotPhotoDao = db.photoDao()

    @Provides
    fun provideRoutePlanDao(db: DumpsterScoutDatabase): RoutePlanDao = db.routePlanDao()

    @Provides
    fun provideReminderDao(db: DumpsterScoutDatabase): ReminderDao = db.reminderDao()

    @Provides
    fun provideTireSpotDao(db: DumpsterScoutDatabase): TireSpotDao = db.tireSpotDao()

    @Provides
    fun provideTireReportDao(db: DumpsterScoutDatabase): TireReportDao = db.tireReportDao()
}
