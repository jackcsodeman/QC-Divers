package com.dumpsterscout.data.repository

import com.dumpsterscout.data.local.dao.DumpsterSpotDao
import com.dumpsterscout.data.local.entity.DumpsterSpotEntity
import com.dumpsterscout.data.mapper.toDomain
import com.dumpsterscout.data.mapper.toEntity
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.di.SupabaseCredentials
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.repository.SpotRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

@Singleton
class SpotRepositoryImpl @Inject constructor(
    private val dao: DumpsterSpotDao,
    private val credentials: SupabaseCredentials,
    private val prefs: AppPreferences
) : SpotRepository {

    override fun getAllSpots(): Flow<List<DumpsterSpot>> =
        dao.getAllSpots().map { entities -> entities.map { it.toDomain() } }

    override fun getFavoriteSpots(): Flow<List<DumpsterSpot>> =
        dao.getFavoriteSpots().map { entities -> entities.map { it.toDomain() } }

    override fun getActiveSpots(): Flow<List<DumpsterSpot>> =
        dao.getAllActiveSpots().map { entities -> entities.map { it.toDomain() } }

    override fun searchSpots(query: String): Flow<List<DumpsterSpot>> =
        dao.searchSpots(query).map { entities -> entities.map { it.toDomain() } }

    override suspend fun getSpotById(id: Long): DumpsterSpot? =
        dao.getSpotById(id)?.toDomain()

    override suspend fun getNearestSpots(
        latitude: Double,
        longitude: Double,
        radiusMeters: Double
    ): List<DumpsterSpot> {
        val candidates = dao.getNearestSpots(latitude, longitude)
        return candidates
            .map { it.toDomain() }
            .filter { haversineMeters(latitude, longitude, it.latitude, it.longitude) <= radiusMeters }
            .sortedBy { haversineMeters(latitude, longitude, it.latitude, it.longitude) }
    }

    override suspend fun upsertSpot(spot: DumpsterSpot): Long {
        val ownerId = spot.ownerUserId ?: prefs.localUserId.first()
        val entity = spot.copy(
            ownerUserId = ownerId,
            syncStatus  = if (credentials.isConfigured) SyncStatus.PENDING_SYNC else spot.syncStatus
        ).toEntity()
        return dao.upsert(entity)
    }

    override suspend fun deleteSpot(spot: DumpsterSpot) =
        dao.delete(spot.toEntity())

    override suspend fun updateLastStatus(spotId: Long, status: SpotStatus, timestamp: Long) =
        dao.updateLastStatus(spotId, status.name, timestamp)

    override suspend fun toggleFavorite(spotId: Long) =
        dao.toggleFavorite(spotId)

    override suspend fun retireSpot(spotId: Long) =
        dao.retire(spotId)

    override suspend fun deleteAllSpots() =
        dao.deleteAll()

    override suspend fun exportToJson(): String {
        val entities = dao.getAllSpotsSnapshot()
        val arr = JSONArray()
        for (entity in entities) {
            arr.put(entityToJson(entity))
        }
        return arr.toString(2)
    }

    override suspend fun importFromJson(json: String): Int {
        val arr = JSONArray(json)
        var imported = 0
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val entity = jsonToEntity(obj)
            dao.upsert(entity)
            imported++
        }
        return imported
    }

    override suspend fun getPendingSyncSpots(): List<DumpsterSpot> =
        dao.getPendingSyncSpots().map { it.toDomain() }

    override suspend fun markSpotSynced(id: Long, remoteId: String) =
        dao.markSynced(id, remoteId)

    override suspend fun markSpotSyncFailed(id: Long) =
        dao.markSyncFailed(id)

    override suspend fun publishSpot(spotId: Long) =
        dao.publishSpot(spotId)

    override suspend fun getSpotByRemoteId(remoteId: String): DumpsterSpot? =
        dao.getByRemoteId(remoteId)?.toDomain()

    override suspend fun upsertSpotFromRemote(spot: DumpsterSpot): Long {
        // Incoming remote spots are already SYNCED — do not stamp PENDING_SYNC.
        return dao.upsert(spot.toEntity())
    }

    private fun entityToJson(e: DumpsterSpotEntity): JSONObject = JSONObject().apply {
        put("name", e.name)
        put("category", e.category)
        put("address", e.address)
        put("latitude", e.latitude)
        put("longitude", e.longitude)
        put("accessNotes", e.accessNotes)
        put("spotLocation", e.spotLocation)
        put("isFenced", e.isFenced)
        put("isGated", e.isGated)
        put("isLocked", e.isLocked)
        put("isCompactor", e.isCompactor)
        put("hasMultipleDumpsters", e.hasMultipleDumpsters)
        put("dumpsterCount", e.dumpsterCount)
        put("dumpsterLabels", e.dumpsterLabels)
        put("lidEasyToOpen", e.lidEasyToOpen)
        put("parkingEasy", e.parkingEasy)
        put("distanceFromRoad", e.distanceFromRoad)
        put("vehicleAccessNotes", e.vehicleAccessNotes)
        put("lightingNotes", e.lightingNotes)
        put("safetyNotes", e.safetyNotes)
        put("securityCommon", e.securityCommon)
        put("hasCameras", e.hasCameras)
        put("isWellLit", e.isWellLit)
        put("isHiddenFromRoad", e.isHiddenFromRoad)
        put("pickupDays", e.pickupDays)
        put("pickupTimeWindow", e.pickupTimeWindow)
        put("bestTimeOfDay", e.bestTimeOfDay)
        if (e.betterOnWeekends != null) put("betterOnWeekends", e.betterOnWeekends)
        put("bestSeason", e.bestSeason)
        put("worthCheckingAfterPickup", e.worthCheckingAfterPickup)
        put("bestBeforePickupDay", e.bestBeforePickupDay)
        put("throwsOutNearClosingTime", e.throwsOutNearClosingTime)
        put("checkMoreThanOncePerWeek", e.checkMoreThanOncePerWeek)
        put("worstDay", e.worstDay)
        put("usualFindings", e.usualFindings)
        put("goodFindsCategories", e.goodFindsCategories)
        put("avoidReasons", e.avoidReasons)
        put("staffDestroyItems", e.staffDestroyItems)
        put("worthCheckingWhenEmpty", e.worthCheckingWhenEmpty)
        put("usuallyMessy", e.usuallyMessy)
        put("hasSharpHazards", e.hasSharpHazards)
        put("hasSealed", e.hasSealed)
        put("checkedByOtherDivers", e.checkedByOtherDivers)
        put("betterEarlierInNight", e.betterEarlierInNight)
        put("conditionSmell", e.conditionSmell)
        put("conditionPests", e.conditionPests)
        put("conditionMoisture", e.conditionMoisture)
        put("recommendedGear", e.recommendedGear)
        put("gradeOverall", e.gradeOverall.toDouble())
        put("gradeConsistency", e.gradeConsistency.toDouble())
        put("gradeQuality", e.gradeQuality.toDouble())
        put("gradeQuantity", e.gradeQuantity.toDouble())
        put("gradeCleanliness", e.gradeCleanliness.toDouble())
        put("gradeRisk", e.gradeRisk.toDouble())
        put("gradeAccessDifficulty", e.gradeAccessDifficulty.toDouble())
        put("gradeLegalSensitivity", e.gradeLegalSensitivity.toDouble())
        put("personalNotes", e.personalNotes)
        put("tags", e.tags)
        put("isFavorite", e.isFavorite)
        put("isVerified", e.isVerified)
        put("isRetired", e.isRetired)
        if (e.lastChecked != null) put("lastChecked", e.lastChecked)
        put("lastStatus", e.lastStatus)
        put("createdAt", e.createdAt)
        put("updatedAt", e.updatedAt)
    }

    private fun jsonToEntity(o: JSONObject): DumpsterSpotEntity = DumpsterSpotEntity(
        name = o.optString("name", ""),
        category = o.optString("category", "OTHER"),
        address = o.optString("address", ""),
        latitude = o.optDouble("latitude", 0.0),
        longitude = o.optDouble("longitude", 0.0),
        accessNotes = o.optString("accessNotes", ""),
        spotLocation = o.optString("spotLocation", "OTHER"),
        isFenced = o.optBoolean("isFenced", false),
        isGated = o.optBoolean("isGated", false),
        isLocked = o.optBoolean("isLocked", false),
        isCompactor = o.optBoolean("isCompactor", false),
        hasMultipleDumpsters = o.optBoolean("hasMultipleDumpsters", false),
        dumpsterCount = o.optInt("dumpsterCount", 1),
        dumpsterLabels = o.optString("dumpsterLabels", ""),
        lidEasyToOpen = o.optBoolean("lidEasyToOpen", true),
        parkingEasy = o.optBoolean("parkingEasy", true),
        distanceFromRoad = o.optString("distanceFromRoad", ""),
        vehicleAccessNotes = o.optString("vehicleAccessNotes", ""),
        lightingNotes = o.optString("lightingNotes", ""),
        safetyNotes = o.optString("safetyNotes", ""),
        securityCommon = o.optBoolean("securityCommon", false),
        hasCameras = o.optBoolean("hasCameras", false),
        isWellLit = o.optBoolean("isWellLit", false),
        isHiddenFromRoad = o.optBoolean("isHiddenFromRoad", false),
        pickupDays = o.optString("pickupDays", ""),
        pickupTimeWindow = o.optString("pickupTimeWindow", ""),
        bestTimeOfDay = o.optString("bestTimeOfDay", "VARIES"),
        betterOnWeekends = if (o.has("betterOnWeekends")) o.optBoolean("betterOnWeekends") else null,
        bestSeason = o.optString("bestSeason", "YEAR_ROUND"),
        worthCheckingAfterPickup = o.optBoolean("worthCheckingAfterPickup", false),
        bestBeforePickupDay = o.optBoolean("bestBeforePickupDay", false),
        throwsOutNearClosingTime = o.optBoolean("throwsOutNearClosingTime", false),
        checkMoreThanOncePerWeek = o.optBoolean("checkMoreThanOncePerWeek", false),
        worstDay = o.optString("worstDay", ""),
        usualFindings = o.optString("usualFindings", ""),
        goodFindsCategories = o.optString("goodFindsCategories", ""),
        avoidReasons = o.optString("avoidReasons", ""),
        staffDestroyItems = o.optBoolean("staffDestroyItems", false),
        worthCheckingWhenEmpty = o.optBoolean("worthCheckingWhenEmpty", false),
        usuallyMessy = o.optBoolean("usuallyMessy", false),
        hasSharpHazards = o.optBoolean("hasSharpHazards", false),
        hasSealed = o.optBoolean("hasSealed", false),
        checkedByOtherDivers = o.optBoolean("checkedByOtherDivers", false),
        betterEarlierInNight = o.optBoolean("betterEarlierInNight", true),
        conditionSmell = o.optString("conditionSmell", ""),
        conditionPests = o.optBoolean("conditionPests", false),
        conditionMoisture = o.optBoolean("conditionMoisture", false),
        recommendedGear = o.optString("recommendedGear", ""),
        gradeOverall = o.optDouble("gradeOverall", 0.0).toFloat(),
        gradeConsistency = o.optDouble("gradeConsistency", 0.0).toFloat(),
        gradeQuality = o.optDouble("gradeQuality", 0.0).toFloat(),
        gradeQuantity = o.optDouble("gradeQuantity", 0.0).toFloat(),
        gradeCleanliness = o.optDouble("gradeCleanliness", 0.0).toFloat(),
        gradeRisk = o.optDouble("gradeRisk", 0.0).toFloat(),
        gradeAccessDifficulty = o.optDouble("gradeAccessDifficulty", 0.0).toFloat(),
        gradeLegalSensitivity = o.optDouble("gradeLegalSensitivity", 0.0).toFloat(),
        personalNotes = o.optString("personalNotes", ""),
        tags = o.optString("tags", ""),
        isFavorite = o.optBoolean("isFavorite", false),
        isVerified = o.optBoolean("isVerified", false),
        isRetired = o.optBoolean("isRetired", false),
        lastChecked = if (o.has("lastChecked")) o.optLong("lastChecked") else null,
        lastStatus = o.optString("lastStatus", "UNKNOWN"),
        createdAt = o.optLong("createdAt", System.currentTimeMillis()),
        updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
    )

    private fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371000.0
        val phi1 = Math.toRadians(lat1)
        val phi2 = Math.toRadians(lat2)
        val dPhi = Math.toRadians(lat2 - lat1)
        val dLambda = Math.toRadians(lon2 - lon1)
        val a = sin(dPhi / 2) * sin(dPhi / 2) +
                cos(phi1) * cos(phi2) * sin(dLambda / 2) * sin(dLambda / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }
}
