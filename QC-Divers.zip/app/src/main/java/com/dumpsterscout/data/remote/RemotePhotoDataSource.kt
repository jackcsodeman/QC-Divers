package com.dumpsterscout.data.remote

import com.dumpsterscout.domain.model.PhotoAttachment

/**
 * Contract for the remote (Supabase Storage) photo data source.
 *
 * Activate by implementing [SupabasePhotoDataSource] when the backend is live.
 * The real implementation will call `supabase.storage.from("spot-photos").upload(...)`.
 */
interface RemotePhotoDataSource {

    /**
     * Upload a photo to remote storage.
     *
     * @param photo  The local photo record. [PhotoAttachment.localUri] must be non-null.
     * @return       The public/signed remote URL, or null if the upload failed.
     */
    suspend fun uploadPhoto(photo: PhotoAttachment): String?

    /**
     * Delete a photo from remote storage.
     *
     * @param remoteUrl  The URL previously returned by [uploadPhoto].
     */
    suspend fun deletePhoto(remoteUrl: String)
}
