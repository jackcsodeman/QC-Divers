package com.dumpsterscout.data.repository

import com.dumpsterscout.data.local.dao.TireSpotDao
import com.dumpsterscout.data.mapper.toDomain
import com.dumpsterscout.data.mapper.toEntity
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.di.SupabaseCredentials
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.domain.repository.TireSpotRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

@Singleton
class TireSpotRepositoryImpl @Inject constructor(
    private val dao: TireSpotDao,
    private val credentials: SupabaseCredentials,
    private val prefs: AppPreferences
) : TireSpotRepository {

    override fun getAllSpots(): Flow<List<TireSpot>> =
        dao.getAllSpots().map { entities -> entities.map { it.toDomain() } }

    override fun getFavoriteSpots(): Flow<List<TireSpot>> =
        dao.getFavoriteSpots().map { entities -> entities.map { it.toDomain() } }

    override fun getActiveSpots(): Flow<List<TireSpot>> =
        dao.getAllActiveSpots().map { entities -> entities.map { it.toDomain() } }

    override fun searchSpots(query: String): Flow<List<TireSpot>> =
        dao.searchSpots(query).map { entities -> entities.map { it.toDomain() } }

    override suspend fun getSpotById(id: Long): TireSpot? =
        dao.getSpotById(id)?.toDomain()

    override suspend fun getNearestSpots(
        latitude: Double,
        longitude: Double,
        radiusMeters: Double
    ): List<TireSpot> {
        val candidates = dao.getNearestSpots(latitude, longitude)
        return candidates
            .map { it.toDomain() }
            .filter { haversineMeters(latitude, longitude, it.latitude, it.longitude) <= radiusMeters }
            .sortedBy { haversineMeters(latitude, longitude, it.latitude, it.longitude) }
    }

    override suspend fun upsertSpot(spot: TireSpot): Long {
        val ownerId = spot.ownerUserId ?: prefs.localUserId.first()
        val entity = spot.toEntity().copy(
            ownerUserId = ownerId,
            syncStatus  = if (credentials.isConfigured) SyncStatus.PENDING_SYNC.name else spot.syncStatus.name
        )
        return dao.upsert(entity)
    }

    override suspend fun deleteSpot(spot: TireSpot) =
        dao.delete(spot.toEntity())

    override suspend fun updateLastStatus(spotId: Long, status: TireSpotStatus, timestamp: Long) =
        dao.updateLastStatus(spotId, status.name, timestamp)

    override suspend fun toggleFavorite(spotId: Long) =
        dao.toggleFavorite(spotId)

    override suspend fun retireSpot(spotId: Long) =
        dao.retire(spotId)

    override suspend fun deleteAllSpots() =
        dao.deleteAll()

    override suspend fun getPendingSyncSpots(): List<TireSpot> =
        dao.getPendingSyncSpots().map { it.toDomain() }

    override suspend fun markSpotSynced(id: Long, remoteId: String) =
        dao.markSynced(id, remoteId)

    override suspend fun markSpotSyncFailed(id: Long) =
        dao.markSyncFailed(id)

    override suspend fun publishSpot(spotId: Long) =
        dao.publishSpot(spotId)

    override suspend fun getSpotByRemoteId(remoteId: String): TireSpot? =
        dao.getByRemoteId(remoteId)?.toDomain()

    override suspend fun upsertSpotFromRemote(spot: TireSpot): Long =
        dao.upsert(spot.toEntity().copy(syncStatus = SyncStatus.SYNCED.name))

    private fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371000.0
        val phi1 = Math.toRadians(lat1)
        val phi2 = Math.toRadians(lat2)
        val dPhi = Math.toRadians(lat2 - lat1)
        val dLambda = Math.toRadians(lon2 - lon1)
        val a = sin(dPhi / 2) * sin(dPhi / 2) +
                cos(phi1) * cos(phi2) * sin(dLambda / 2) * sin(dLambda / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }
}

