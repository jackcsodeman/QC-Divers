package com.dumpsterscout.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.dumpsterscout.data.local.entity.PersonalReportEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PersonalReportDao {

    @Query("SELECT * FROM personal_reports ORDER BY timestamp DESC")
    fun getAllReports(): Flow<List<PersonalReportEntity>>

    @Query("SELECT * FROM personal_reports WHERE spotId = :spotId ORDER BY timestamp DESC")
    fun getReportsBySpot(spotId: Long): Flow<List<PersonalReportEntity>>

    @Query("SELECT * FROM personal_reports ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentReports(limit: Int): Flow<List<PersonalReportEntity>>

    @Query("SELECT COUNT(*) FROM personal_reports")
    fun getReportCount(): Flow<Int>

    @Query("SELECT * FROM personal_reports WHERE id = :id")
    suspend fun getReportById(id: Long): PersonalReportEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(report: PersonalReportEntity): Long

    @Update
    suspend fun update(report: PersonalReportEntity)

    @Delete
    suspend fun delete(report: PersonalReportEntity)

    @Query("SELECT COUNT(*) FROM personal_reports WHERE spotId = :spotId")
    suspend fun countReportsForSpot(spotId: Long): Int

    @Query("SELECT * FROM personal_reports ORDER BY timestamp DESC")
    suspend fun getAllReportsSnapshot(): List<PersonalReportEntity>

    @Query("SELECT * FROM personal_reports WHERE syncStatus = 'PENDING_SYNC' AND deletedAt IS NULL ORDER BY updatedAt ASC")
    suspend fun getPendingSyncReports(): List<PersonalReportEntity>

    @Query("UPDATE personal_reports SET syncStatus = 'SYNCED', remoteId = :remoteId, updatedAt = :now WHERE id = :id")
    suspend fun markSynced(id: Long, remoteId: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE personal_reports SET syncStatus = 'SYNC_FAILED', updatedAt = :now WHERE id = :id")
    suspend fun markSyncFailed(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE personal_reports SET visibility = 'COMMUNITY', syncStatus = 'PENDING_SYNC', updatedAt = :now WHERE id = :id")
    suspend fun publishReport(id: Long, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM personal_reports WHERE remoteId = :remoteId LIMIT 1")
    suspend fun getByRemoteId(remoteId: String): PersonalReportEntity?

    @Query("DELETE FROM personal_reports")
    suspend fun deleteAll()
}
