package com.dumpsterscout.data.remote.dto

import com.dumpsterscout.domain.model.PuncturePattern
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.TireBestTimeOfDay
import com.dumpsterscout.domain.model.TireSeason
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireSpotCategory
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.domain.model.Visibility
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Remote DTO for the `tire_spots` Supabase table.
 *
 * Essential schema (SQL):
 * ```sql
 * create table tire_spots (
 *   id                    uuid primary key default gen_random_uuid(),
 *   owner_id              uuid references auth.users(id),
 *   name                  text not null,
 *   category              text not null,
 *   address               text,
 *   latitude              double precision not null,
 *   longitude             double precision not null,
 *   visibility            text not null default 'PRIVATE',
 *   access_notes          text,
 *   is_fenced             boolean not null default false,
 *   is_gated              boolean not null default false,
 *   is_locked             boolean not null default false,
 *   is_exposed            boolean not null default false,
 *   easy_access           boolean not null default true,
 *   has_cameras           boolean not null default false,
 *   security_common       boolean not null default false,
 *   best_time_of_day      text,
 *   best_days             text,
 *   better_on_weekends    boolean,
 *   is_seasonal           boolean not null default false,
 *   season                text,
 *   puts_out_around_closing boolean not null default false,
 *   puncture_pattern      text,
 *   usable_disappear_fast boolean not null default false,
 *   others_get_there_first boolean not null default false,
 *   worth_checking_when_light boolean not null default false,
 *   usually_puts_out_many boolean not null default false,
 *   is_verified           boolean not null default false,
 *   is_favorite           boolean not null default false,
 *   is_retired            boolean not null default false,
 *   last_status           text,
 *   last_checked          bigint,
 *   notes                 text,
 *   tags                  text,
 *   created_at            bigint not null,
 *   updated_at            bigint not null,
 *   deleted_at            bigint
 * );
 * ```
 */
@Serializable
data class TireSpotRow(
    @SerialName("id") val remoteId: String = "",
    @SerialName("owner_id") val ownerId: String? = null,
    @SerialName("name") val name: String,
    @SerialName("category") val category: String,
    @SerialName("address") val address: String,
    @SerialName("latitude") val latitude: Double,
    @SerialName("longitude") val longitude: Double,
    @SerialName("visibility") val visibility: String,
    @SerialName("access_notes") val accessNotes: String,
    @SerialName("is_fenced") val isFenced: Boolean,
    @SerialName("is_gated") val isGated: Boolean,
    @SerialName("is_locked") val isLocked: Boolean,
    @SerialName("is_exposed") val isExposed: Boolean,
    @SerialName("easy_access") val easyAccess: Boolean,
    @SerialName("has_cameras") val hasCameras: Boolean,
    @SerialName("security_common") val securityCommon: Boolean,
    @SerialName("best_time_of_day") val bestTimeOfDay: String,
    @SerialName("best_days") val bestDays: String,
    @SerialName("better_on_weekends") val betterOnWeekends: Boolean?,
    @SerialName("is_seasonal") val isSeasonal: Boolean,
    @SerialName("season") val season: String,
    @SerialName("puts_out_around_closing") val putsOutAroundClosing: Boolean,
    @SerialName("puncture_pattern") val puncturePattern: String,
    @SerialName("usable_disappear_fast") val usableDisappearFast: Boolean,
    @SerialName("others_get_there_first") val othersGetThereFirst: Boolean,
    @SerialName("worth_checking_when_light") val worthCheckingWhenLight: Boolean,
    @SerialName("usually_puts_out_many") val usuallyPutsOutMany: Boolean,
    @SerialName("is_verified") val isVerified: Boolean,
    @SerialName("is_favorite") val isFavorite: Boolean,
    @SerialName("is_retired") val isRetired: Boolean,
    @SerialName("last_status") val lastStatus: String,
    @SerialName("last_checked") val lastChecked: Long?,
    @SerialName("notes") val notes: String,
    @SerialName("tags") val tags: String,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: Long,
    @SerialName("deleted_at") val deletedAt: Long?
)

fun TireSpot.toRow(ownerId: String? = null): TireSpotRow = TireSpotRow(
    remoteId             = remoteId ?: "",
    ownerId              = ownerId ?: ownerUserId,
    name                 = name,
    category             = category.name,
    address              = address,
    latitude             = latitude,
    longitude            = longitude,
    visibility           = visibility.name,
    accessNotes          = accessNotes,
    isFenced             = isFenced,
    isGated              = isGated,
    isLocked             = isLocked,
    isExposed            = isExposed,
    easyAccess           = easyAccess,
    hasCameras           = hasCameras,
    securityCommon       = securityCommon,
    bestTimeOfDay        = bestTimeOfDay.name,
    bestDays             = bestDays,
    betterOnWeekends     = betterOnWeekends,
    isSeasonal           = isSeasonal,
    season               = season.name,
    putsOutAroundClosing = putsOutAroundClosing,
    puncturePattern      = puncturePattern.name,
    usableDisappearFast  = usableDisappearFast,
    othersGetThereFirst  = othersGetThereFirst,
    worthCheckingWhenLight = worthCheckingWhenLight,
    usuallyPutsOutMany   = usuallyPutsOutMany,
    isVerified           = isVerified,
    isFavorite           = isFavorite,
    isRetired            = isRetired,
    lastStatus           = lastStatus.name,
    lastChecked          = lastChecked,
    notes                = notes,
    tags                 = tags.joinToString(","),
    createdAt            = createdAt,
    updatedAt            = updatedAt,
    deletedAt            = deletedAt
)

/**
 * Convert an incoming [TireSpotRow] from Supabase back to a [TireSpot] domain model.
 */
fun TireSpotRow.toDomain(): TireSpot = TireSpot(
    remoteId             = remoteId.ifBlank { null },
    ownerUserId          = ownerId,
    name                 = name,
    category             = runCatching { TireSpotCategory.valueOf(category) }.getOrDefault(TireSpotCategory.OTHER),
    address              = address,
    latitude             = latitude,
    longitude            = longitude,
    visibility           = runCatching { Visibility.valueOf(visibility) }.getOrDefault(Visibility.PRIVATE),
    accessNotes          = accessNotes,
    isFenced             = isFenced,
    isGated              = isGated,
    isLocked             = isLocked,
    isExposed            = isExposed,
    easyAccess           = easyAccess,
    hasCameras           = hasCameras,
    securityCommon       = securityCommon,
    bestTimeOfDay        = runCatching { TireBestTimeOfDay.valueOf(bestTimeOfDay) }.getOrDefault(TireBestTimeOfDay.VARIES),
    bestDays             = bestDays,
    betterOnWeekends     = betterOnWeekends,
    isSeasonal           = isSeasonal,
    season               = runCatching { TireSeason.valueOf(season) }.getOrDefault(TireSeason.YEAR_ROUND),
    putsOutAroundClosing = putsOutAroundClosing,
    puncturePattern      = runCatching { PuncturePattern.valueOf(puncturePattern) }.getOrDefault(PuncturePattern.UNKNOWN),
    usableDisappearFast  = usableDisappearFast,
    othersGetThereFirst  = othersGetThereFirst,
    worthCheckingWhenLight = worthCheckingWhenLight,
    usuallyPutsOutMany   = usuallyPutsOutMany,
    isVerified           = isVerified,
    isFavorite           = isFavorite,
    isRetired            = isRetired,
    lastStatus           = runCatching { TireSpotStatus.valueOf(lastStatus) }.getOrDefault(TireSpotStatus.UNKNOWN),
    lastChecked          = lastChecked,
    notes                = notes,
    tags                 = if (tags.isBlank()) emptyList() else tags.split(",").map { it.trim() }.filter { it.isNotEmpty() },
    createdAt            = createdAt,
    updatedAt            = updatedAt,
    deletedAt            = deletedAt,
    syncStatus           = SyncStatus.SYNCED
)
