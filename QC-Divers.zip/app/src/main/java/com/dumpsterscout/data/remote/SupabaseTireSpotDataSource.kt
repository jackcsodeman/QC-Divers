package com.dumpsterscout.data.remote

import android.util.Log
import com.dumpsterscout.data.remote.dto.TireSpotRow
import com.dumpsterscout.data.remote.dto.toDomain
import com.dumpsterscout.data.remote.dto.toRow
import com.dumpsterscout.domain.model.TireSpot
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from

/**
 * Real [RemoteTireSpotDataSource] implementation backed by Supabase Postgrest.
 *
 * Table: `tire_spots` — see [TireSpotRow] for schema details.
 */
class SupabaseTireSpotDataSource(
    private val client: SupabaseClient
) : RemoteTireSpotDataSource {

    override suspend fun upsertTireSpots(spots: List<TireSpot>): Map<Long, String> {
        val result = mutableMapOf<Long, String>()
        for (spot in spots) {
            try {
                val row = spot.toRow()
                val returned = if (spot.remoteId == null) {
                    client.from(TABLE).insert(row) { select() }.decodeSingle<TireSpotRow>()
                } else {
                    client.from(TABLE).upsert(row) { select() }.decodeSingle<TireSpotRow>()
                }
                result[spot.id] = returned.remoteId
            } catch (e: Exception) {
                Log.e(TAG, "Failed to upsert tire spot id=${spot.id}: ${e.message}")
            }
        }
        return result
    }

    override suspend fun deleteTireSpots(remoteIds: List<String>): Set<String> {
        val deleted = mutableSetOf<String>()
        val nowMillis = System.currentTimeMillis()
        for (id in remoteIds) {
            try {
                client.from(TABLE).update({ set("deleted_at", nowMillis) }) {
                    filter { eq("id", id) }
                }
                deleted.add(id)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to soft-delete tire spot remoteId=$id: ${e.message}")
            }
        }
        return deleted
    }

    override suspend fun fetchMyTireSpots(ownerUserId: String): List<TireSpot> {
        return try {
            client.from(TABLE)
                .select { filter { eq("owner_id", ownerUserId) } }
                .decodeList<TireSpotRow>()
                .filter { it.deletedAt == null }
                .map { it.toDomain() }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch tire spots for owner=$ownerUserId: ${e.message}")
            emptyList()
        }
    }

    private companion object {
        const val TAG = "SupabaseTireSpotDS"
        const val TABLE = "tire_spots"
    }
}
