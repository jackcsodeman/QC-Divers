package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Room entity for personal visit reports.
 */
@Entity(
    tableName = "personal_reports",
    foreignKeys = [
        ForeignKey(
            entity = DumpsterSpotEntity::class,
            parentColumns = ["id"],
            childColumns = ["spotId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("spotId")]
)
data class PersonalReportEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val spotId: Long,
    val spotName: String = "",
    val status: String = "UNKNOWN",
    val fillLevel: String = "UNKNOWN",
    val bagCondition: String = "UNKNOWN",
    val notes: String = "",
    val tags: String = "",            // JSON array
    val photoUris: String = "",       // JSON array
    val bagsFresh: Boolean? = null,
    val alreadyPickedThrough: Boolean = false,
    val rainDamage: Boolean = false,
    val securitySeen: Boolean = false,
    val cameTooEarly: Boolean = false,
    val cameTooLate: Boolean = false,
    val workersStillOutside: Boolean = false,
    val storeStillOpen: Boolean = false,
    val voiceTranscript: String? = null,
    val isFromVoice: Boolean = false,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),

    // Sync / backend-ready metadata
    val remoteId: String? = null,
    val ownerUserId: String? = null,
    val syncStatus: String = "LOCAL_ONLY",
    val visibility: String = "PRIVATE",
    val deletedAt: Long? = null
)
