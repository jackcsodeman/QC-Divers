package com.dumpsterscout.data.repository

import com.dumpsterscout.data.local.dao.PersonalReportDao
import com.dumpsterscout.data.mapper.toDomain
import com.dumpsterscout.data.mapper.toEntity
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.di.SupabaseCredentials
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.repository.ReportRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReportRepositoryImpl @Inject constructor(
    private val dao: PersonalReportDao,
    private val credentials: SupabaseCredentials,
    private val prefs: AppPreferences
) : ReportRepository {

    override fun getAllReports(): Flow<List<PersonalReport>> =
        dao.getAllReports().map { entities -> entities.map { it.toDomain() } }

    override fun getReportCount(): Flow<Int> = dao.getReportCount()

    override fun getReportsBySpot(spotId: Long): Flow<List<PersonalReport>> =
        dao.getReportsBySpot(spotId).map { entities -> entities.map { it.toDomain() } }

    override fun getRecentReports(limit: Int): Flow<List<PersonalReport>> =
        dao.getRecentReports(limit).map { entities -> entities.map { it.toDomain() } }

    override suspend fun insertReport(report: PersonalReport): Long {
        val ownerId = report.ownerUserId ?: prefs.localUserId.first()
        val entity = report.toEntity().copy(
            ownerUserId = ownerId,
            syncStatus  = if (credentials.isConfigured) SyncStatus.PENDING_SYNC.name else report.toEntity().syncStatus
        )
        return dao.insert(entity)
    }

    override suspend fun updateReport(report: PersonalReport) {
        val ownerId = report.ownerUserId ?: prefs.localUserId.first()
        val entity = report.toEntity().copy(
            ownerUserId = ownerId,
            syncStatus  = if (credentials.isConfigured) SyncStatus.PENDING_SYNC.name else report.toEntity().syncStatus
        )
        dao.update(entity)
    }

    override suspend fun deleteReport(report: PersonalReport) =
        dao.delete(report.toEntity())

    override suspend fun deleteAllReports() =
        dao.deleteAll()

    override suspend fun getReportById(id: Long): PersonalReport? =
        dao.getReportById(id)?.toDomain()

    override suspend fun getPendingSyncReports(): List<PersonalReport> =
        dao.getPendingSyncReports().map { it.toDomain() }

    override suspend fun markReportSynced(id: Long, remoteId: String) =
        dao.markSynced(id, remoteId)

    override suspend fun markReportSyncFailed(id: Long) =
        dao.markSyncFailed(id)

    override suspend fun publishReport(reportId: Long) =
        dao.publishReport(reportId)

    override suspend fun getReportByRemoteId(remoteId: String): PersonalReport? =
        dao.getByRemoteId(remoteId)?.toDomain()

    override suspend fun insertReportFromRemote(report: PersonalReport): Long {
        // Incoming remote reports are already SYNCED — do not stamp PENDING_SYNC.
        return dao.insert(report.toEntity())
    }
}
