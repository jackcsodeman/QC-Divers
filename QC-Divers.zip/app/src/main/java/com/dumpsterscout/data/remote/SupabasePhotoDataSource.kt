package com.dumpsterscout.data.remote

import android.content.Context
import android.net.Uri
import android.util.Log
import com.dumpsterscout.domain.model.PhotoAttachment
import dagger.hilt.android.qualifiers.ApplicationContext
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.storage.storage

/**
 * Real [RemotePhotoDataSource] implementation backed by Supabase Storage.
 *
 * Bucket: `spot-photos` — public bucket (or use signed URLs for private).
 *
 * Storage path convention: `{ownerUserId}/{ownerId}/{photoId}.jpg`
 * This groups photos by user and owning record, making ownership queries
 * and moderation efficient.
 */
class SupabasePhotoDataSource(
    private val client: SupabaseClient,
    private val context: Context
) : RemotePhotoDataSource {

    override suspend fun uploadPhoto(photo: PhotoAttachment): String? {
        val uri = photo.localUri ?: run {
            Log.e(TAG, "Cannot upload photo id=${photo.id}: localUri is null")
            return null
        }
        return try {
            val bytes = readUriBytes(uri) ?: return null
            val path = buildPath(photo)
            client.storage.from(BUCKET).upload(path, bytes) { upsert = true }
            client.storage.from(BUCKET).publicUrl(path)
        } catch (e: Exception) {
            Log.e(TAG, "Upload failed for photo id=${photo.id}: ${e.message}")
            null
        }
    }

    override suspend fun deletePhoto(remoteUrl: String) {
        try {
            val path = remoteUrl.substringAfter("$BUCKET/")
            client.storage.from(BUCKET).delete(path)
        } catch (e: Exception) {
            Log.e(TAG, "Delete failed for url=$remoteUrl: ${e.message}")
        }
    }

    private fun buildPath(photo: PhotoAttachment): String {
        val uid = photo.ownerUserId ?: "anonymous"
        return "$uid/${photo.ownerType}_${photo.ownerId}/${photo.id}.jpg"
    }

    private fun readUriBytes(uri: String): ByteArray? =
        try {
            context.contentResolver.openInputStream(Uri.parse(uri))?.use { it.readBytes() }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to read URI bytes: ${e.message}")
            null
        }

    private companion object {
        const val TAG = "SupabasePhotoDS"
        const val BUCKET = "spot-photos"
    }
}
