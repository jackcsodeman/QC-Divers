package com.dumpsterscout.data.remote

import android.util.Log
import com.dumpsterscout.domain.model.TireSpot
import javax.inject.Inject

/**
 * No-op [RemoteTireSpotDataSource] used while the Supabase backend is not yet live.
 */
class NoOpRemoteTireSpotDataSource @Inject constructor() : RemoteTireSpotDataSource {

    override suspend fun upsertTireSpots(spots: List<TireSpot>): Map<Long, String> {
        Log.d(TAG, "upsertTireSpots: no-op (${spots.size}). Wire up Supabase to activate.")
        return emptyMap()
    }

    override suspend fun deleteTireSpots(remoteIds: List<String>): Set<String> {
        Log.d(TAG, "deleteTireSpots: no-op (${remoteIds.size}). Wire up Supabase to activate.")
        return emptySet()
    }

    override suspend fun fetchMyTireSpots(ownerUserId: String): List<TireSpot> {
        Log.d(TAG, "fetchMyTireSpots: no-op. Wire up Supabase to activate.")
        return emptyList()
    }

    private companion object {
        const val TAG = "NoOpRemoteTireSpotDS"
    }
}
