package com.dumpsterscout.data.remote

import com.dumpsterscout.data.remote.dto.ReportRow
import com.dumpsterscout.data.remote.dto.TireReportRow
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.TireReport

/**
 * Contract for the remote (Supabase) report data sources.
 *
 * Spot reports and tire reports share the same structural pattern:
 * push pending local records, receive back remote IDs.
 *
 * Activate by implementing [SupabaseReportDataSource] when the backend is live.
 */
interface RemoteReportDataSource {

    /**
     * Push spot reports to the remote backend.
     * @param spotRemoteIds Optional map of localId → spotRemoteId for backend FK resolution.
     * @return Map of localId → remoteId for successful upserts.
     */
    suspend fun upsertReports(
        reports: List<PersonalReport>,
        spotRemoteIds: Map<Long, String?> = emptyMap()
    ): Map<Long, String>

    /**
     * Push tire reports to the remote backend.
     * @param tireSpotRemoteIds Optional map of localId → tireSpotRemoteId for backend FK resolution.
     * @return Map of localId → remoteId for successful upserts.
     */
    suspend fun upsertTireReports(
        reports: List<TireReport>,
        tireSpotRemoteIds: Map<Long, String?> = emptyMap()
    ): Map<Long, String>

    /**
     * Fetch all dumpster reports owned by [ownerUserId] from the backend.
     *
     * Returns raw [ReportRow] DTOs so the caller can resolve [ReportRow.spotRemoteId]
     * to a local spot id before inserting/upserting.
     */
    suspend fun fetchMyReports(ownerUserId: String): List<ReportRow>

    /**
     * Fetch all tire reports owned by [ownerUserId] from the backend.
     *
     * Returns raw [TireReportRow] DTOs so the caller can resolve
     * [TireReportRow.tireSpotRemoteId] to a local tire spot id before inserting/upserting.
     */
    suspend fun fetchMyTireReports(ownerUserId: String): List<TireReportRow>
}
