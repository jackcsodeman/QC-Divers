package com.dumpsterscout.data.remote

import android.util.Log
import com.dumpsterscout.data.remote.dto.ReportRow
import com.dumpsterscout.data.remote.dto.TireReportRow
import com.dumpsterscout.data.remote.dto.toRow
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.TireReport
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from

/**
 * Real [RemoteReportDataSource] implementation backed by Supabase Postgrest.
 *
 * Tables: `dumpster_reports`, `tire_reports` — see [ReportRow] / [TireReportRow] for schema.
 */
class SupabaseReportDataSource(
    private val client: SupabaseClient
) : RemoteReportDataSource {

    override suspend fun upsertReports(
        reports: List<PersonalReport>,
        spotRemoteIds: Map<Long, String?>
    ): Map<Long, String> {
        val result = mutableMapOf<Long, String>()
        for (report in reports) {
            try {
                val spotRemoteId = spotRemoteIds[report.id]
                val row = report.toRow(spotRemoteId = spotRemoteId)
                val returned = if (report.remoteId == null) {
                    client.from(SPOT_REPORTS_TABLE).insert(row) { select() }.decodeSingle<ReportRow>()
                } else {
                    client.from(SPOT_REPORTS_TABLE).upsert(row) { select() }.decodeSingle<ReportRow>()
                }
                result[report.id] = returned.remoteId
            } catch (e: Exception) {
                Log.e(TAG, "Failed to upsert report id=${report.id}: ${e.message}")
            }
        }
        return result
    }

    override suspend fun upsertTireReports(
        reports: List<TireReport>,
        tireSpotRemoteIds: Map<Long, String?>
    ): Map<Long, String> {
        val result = mutableMapOf<Long, String>()
        for (report in reports) {
            try {
                val tireSpotRemoteId = tireSpotRemoteIds[report.id]
                val row = report.toRow(tireSpotRemoteId = tireSpotRemoteId)
                val returned = if (report.remoteId == null) {
                    client.from(TIRE_REPORTS_TABLE).insert(row) { select() }.decodeSingle<TireReportRow>()
                } else {
                    client.from(TIRE_REPORTS_TABLE).upsert(row) { select() }.decodeSingle<TireReportRow>()
                }
                result[report.id] = returned.remoteId
            } catch (e: Exception) {
                Log.e(TAG, "Failed to upsert tire report id=${report.id}: ${e.message}")
            }
        }
        return result
    }

    override suspend fun fetchMyReports(ownerUserId: String): List<ReportRow> {
        return try {
            client.from(SPOT_REPORTS_TABLE)
                .select { filter { eq("owner_id", ownerUserId) } }
                .decodeList<ReportRow>()
                .filter { it.deletedAt == null }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch reports for owner=$ownerUserId: ${e.message}")
            emptyList()
        }
    }

    override suspend fun fetchMyTireReports(ownerUserId: String): List<TireReportRow> {
        return try {
            client.from(TIRE_REPORTS_TABLE)
                .select { filter { eq("owner_id", ownerUserId) } }
                .decodeList<TireReportRow>()
                .filter { it.deletedAt == null }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch tire reports for owner=$ownerUserId: ${e.message}")
            emptyList()
        }
    }

    private companion object {
        const val TAG = "SupabaseReportDS"
        const val SPOT_REPORTS_TABLE = "dumpster_reports"
        const val TIRE_REPORTS_TABLE = "tire_reports"
    }
}
