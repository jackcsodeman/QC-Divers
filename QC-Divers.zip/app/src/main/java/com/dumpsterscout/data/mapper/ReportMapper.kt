package com.dumpsterscout.data.mapper

import com.dumpsterscout.data.local.entity.PersonalReportEntity
import com.dumpsterscout.domain.model.BagCondition
import com.dumpsterscout.domain.model.FillLevel
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.Visibility
import org.json.JSONArray

fun PersonalReportEntity.toDomain(): PersonalReport = PersonalReport(
    id = id,
    spotId = spotId,
    spotName = spotName,
    status = SpotStatus.values().find { it.name == status } ?: SpotStatus.UNKNOWN,
    fillLevel = FillLevel.values().find { it.name == fillLevel } ?: FillLevel.UNKNOWN,
    bagCondition = BagCondition.values().find { it.name == bagCondition } ?: BagCondition.UNKNOWN,
    notes = notes,
    tags = tags.parseJsonStringList(),
    photoUris = photoUris.parseJsonStringList(),
    bagsFresh = bagsFresh,
    alreadyPickedThrough = alreadyPickedThrough,
    rainDamage = rainDamage,
    securitySeen = securitySeen,
    cameTooEarly = cameTooEarly,
    cameTooLate = cameTooLate,
    workersStillOutside = workersStillOutside,
    storeStillOpen = storeStillOpen,
    voiceTranscript = voiceTranscript,
    isFromVoice = isFromVoice,
    latitude = latitude,
    longitude = longitude,
    timestamp = timestamp,
    createdAt = createdAt,
    updatedAt = updatedAt,
    remoteId = remoteId,
    ownerUserId = ownerUserId,
    syncStatus = SyncStatus.entries.find { it.name == syncStatus } ?: SyncStatus.LOCAL_ONLY,
    visibility = Visibility.entries.find { it.name == visibility } ?: Visibility.PRIVATE,
    deletedAt = deletedAt
)

fun PersonalReport.toEntity(): PersonalReportEntity = PersonalReportEntity(
    id = id,
    spotId = spotId,
    spotName = spotName,
    status = status.name,
    fillLevel = fillLevel.name,
    bagCondition = bagCondition.name,
    notes = notes,
    tags = tags.toJsonString(),
    photoUris = photoUris.toJsonString(),
    bagsFresh = bagsFresh,
    alreadyPickedThrough = alreadyPickedThrough,
    rainDamage = rainDamage,
    securitySeen = securitySeen,
    cameTooEarly = cameTooEarly,
    cameTooLate = cameTooLate,
    workersStillOutside = workersStillOutside,
    storeStillOpen = storeStillOpen,
    voiceTranscript = voiceTranscript,
    isFromVoice = isFromVoice,
    latitude = latitude,
    longitude = longitude,
    timestamp = timestamp,
    createdAt = createdAt,
    updatedAt = updatedAt,
    remoteId = remoteId,
    ownerUserId = ownerUserId,
    syncStatus = syncStatus.name,
    visibility = visibility.name,
    deletedAt = deletedAt
)

private fun String.parseJsonStringList(): List<String> {
    if (isBlank() || this == "[]") return emptyList()
    return try {
        val arr = JSONArray(this)
        (0 until arr.length()).map { arr.getString(it) }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun List<String>.toJsonString(): String {
    val arr = JSONArray()
    forEach { arr.put(it) }
    return arr.toString()
}
