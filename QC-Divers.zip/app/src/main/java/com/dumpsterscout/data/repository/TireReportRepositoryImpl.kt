package com.dumpsterscout.data.repository

import com.dumpsterscout.data.local.dao.TireReportDao
import com.dumpsterscout.data.mapper.toDomain
import com.dumpsterscout.data.mapper.toEntity
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.di.SupabaseCredentials
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.model.Visibility
import com.dumpsterscout.domain.repository.TireReportRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TireReportRepositoryImpl @Inject constructor(
    private val dao: TireReportDao,
    private val credentials: SupabaseCredentials,
    private val prefs: AppPreferences
) : TireReportRepository {

    override fun getAllReports(): Flow<List<TireReport>> =
        dao.getAllReports().map { entities -> entities.map { it.toDomain() } }

    override fun getReportsBySpot(spotId: Long): Flow<List<TireReport>> =
        dao.getReportsBySpot(spotId).map { entities -> entities.map { it.toDomain() } }

    override fun getRecentReports(limit: Int): Flow<List<TireReport>> =
        dao.getRecentReports(limit).map { entities -> entities.map { it.toDomain() } }

    override suspend fun getReportById(id: Long): TireReport? =
        dao.getReportById(id)?.toDomain()

    override suspend fun insertReport(report: TireReport): Long {
        val ownerId = report.ownerUserId ?: prefs.localUserId.first()
        val stamped = if (credentials.isConfigured) {
            report.copy(
                ownerUserId = ownerId,
                syncStatus  = SyncStatus.PENDING_SYNC
            )
        } else {
            report.copy(ownerUserId = ownerId)
        }
        return dao.insert(stamped.toEntity())
    }

    override suspend fun updateReport(report: TireReport) {
        val current = dao.getReportById(report.id)
        val ownerId = report.ownerUserId
            ?: current?.ownerUserId
            ?: prefs.localUserId.first()
        val stamped = if (credentials.isConfigured) {
            report.copy(
                ownerUserId = ownerId,
                syncStatus  = SyncStatus.PENDING_SYNC
            )
        } else {
            report.copy(ownerUserId = ownerId)
        }
        dao.update(stamped.toEntity())
    }

    override suspend fun deleteReport(report: TireReport) =
        dao.delete(report.toEntity())

    override suspend fun deleteAllReports() =
        dao.deleteAll()

    override suspend fun getPendingSyncReports(): List<TireReport> =
        dao.getPendingSyncReports().map { it.toDomain() }

    override suspend fun markReportSynced(id: Long, remoteId: String) =
        dao.markSynced(id, remoteId)

    override suspend fun markReportSyncFailed(id: Long) =
        dao.markSyncFailed(id)

    override suspend fun publishReport(reportId: Long) =
        dao.publishReport(reportId)

    override suspend fun getReportByRemoteId(remoteId: String): TireReport? =
        dao.getByRemoteId(remoteId)?.toDomain()

    override suspend fun insertReportFromRemote(report: TireReport): Long =
        dao.insert(report.toEntity().copy(syncStatus = SyncStatus.SYNCED.name))
}
