package com.dumpsterscout.data.remote

import android.util.Log
import com.dumpsterscout.data.remote.dto.SpotRow
import com.dumpsterscout.data.remote.dto.toDomain
import com.dumpsterscout.data.remote.dto.toRow
import com.dumpsterscout.domain.model.DumpsterSpot
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from

/**
 * Real [RemoteSpotDataSource] implementation backed by Supabase Postgrest.
 *
 * Bound via [com.dumpsterscout.di.RemoteModule] when a configured
 * [io.github.jan.supabase.SupabaseClient] is available.
 *
 * Table: `dumpster_spots` — see [SpotRow] for schema details.
 */
class SupabaseSpotDataSource(
    private val client: SupabaseClient
) : RemoteSpotDataSource {

    override suspend fun upsertSpots(spots: List<DumpsterSpot>): Map<Long, String> {
        val result = mutableMapOf<Long, String>()
        for (spot in spots) {
            try {
                val row = spot.toRow()
                val returned = if (spot.remoteId == null) {
                    client.from(TABLE).insert(row) { select() }.decodeSingle<SpotRow>()
                } else {
                    client.from(TABLE).upsert(row) { select() }.decodeSingle<SpotRow>()
                }
                result[spot.id] = returned.remoteId
            } catch (e: Exception) {
                Log.e(TAG, "Failed to upsert spot id=${spot.id}: ${e.message}")
            }
        }
        return result
    }

    override suspend fun deleteSpots(remoteIds: List<String>): Set<String> {
        val deleted = mutableSetOf<String>()
        val nowMillis = System.currentTimeMillis()
        for (id in remoteIds) {
            try {
                client.from(TABLE).update({ set("deleted_at", nowMillis) }) {
                    filter { eq("id", id) }
                }
                deleted.add(id)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to soft-delete spot remoteId=$id: ${e.message}")
            }
        }
        return deleted
    }

    override suspend fun fetchMySpots(ownerUserId: String): List<DumpsterSpot> {
        return try {
            client.from(TABLE)
                .select { filter { eq("owner_id", ownerUserId) } }
                .decodeList<SpotRow>()
                .filter { it.deletedAt == null }
                .map { it.toDomain() }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch spots for owner=$ownerUserId: ${e.message}")
            emptyList()
        }
    }

    private companion object {
        const val TAG = "SupabaseSpotDS"
        const val TABLE = "dumpster_spots"
    }
}
