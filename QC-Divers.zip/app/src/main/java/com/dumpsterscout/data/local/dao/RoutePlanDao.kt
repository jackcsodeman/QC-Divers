package com.dumpsterscout.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.dumpsterscout.data.local.entity.RoutePlanEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface RoutePlanDao {

    @Query("SELECT * FROM route_plans ORDER BY createdAt DESC")
    fun getAllRoutePlans(): Flow<List<RoutePlanEntity>>

    @Query("SELECT * FROM route_plans WHERE id = :id")
    suspend fun getRoutePlanById(id: Long): RoutePlanEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(plan: RoutePlanEntity): Long

    @Update
    suspend fun update(plan: RoutePlanEntity)

    @Delete
    suspend fun delete(plan: RoutePlanEntity)
}
