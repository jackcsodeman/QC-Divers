package com.dumpsterscout.data.mapper

import com.dumpsterscout.data.local.entity.TireReportEntity
import com.dumpsterscout.data.local.entity.TireSpotEntity
import com.dumpsterscout.domain.model.PuncturePattern
import com.dumpsterscout.domain.model.TireBestTimeOfDay
import com.dumpsterscout.domain.model.TireCondition
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.model.TireSeason
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireSpotCategory
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.domain.model.TreadQuality
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.Visibility
import org.json.JSONArray

fun TireSpotEntity.toDomain(): TireSpot = TireSpot(
    id = id,
    name = name,
    category = TireSpotCategory.entries.find { it.name == category } ?: TireSpotCategory.OTHER,
    address = address,
    latitude = latitude,
    longitude = longitude,
    accessNotes = accessNotes,
    isFenced = isFenced,
    isGated = isGated,
    isLocked = isLocked,
    isExposed = isExposed,
    easyAccess = easyAccess,
    hasCameras = hasCameras,
    securityCommon = securityCommon,
    bestTimeOfDay = TireBestTimeOfDay.entries.find { it.name == bestTimeOfDay } ?: TireBestTimeOfDay.VARIES,
    bestDays = bestDays,
    betterOnWeekends = betterOnWeekends,
    isSeasonal = isSeasonal,
    season = TireSeason.entries.find { it.name == season } ?: TireSeason.YEAR_ROUND,
    putsOutAroundClosing = putsOutAroundClosing,
    puncturePattern = PuncturePattern.entries.find { it.name == puncturePattern } ?: PuncturePattern.UNKNOWN,
    usableDisappearFast = usableDisappearFast,
    othersGetThereFirst = othersGetThereFirst,
    worthCheckingWhenLight = worthCheckingWhenLight,
    usuallyPutsOutMany = usuallyPutsOutMany,
    isVerified = isVerified,
    isFavorite = isFavorite,
    isRetired = isRetired,
    lastChecked = lastChecked,
    lastStatus = TireSpotStatus.entries.find { it.name == lastStatus } ?: TireSpotStatus.UNKNOWN,
    notes = notes,
    tags = tags.parseTireJsonStringList(),
    createdAt = createdAt,
    updatedAt = updatedAt,
    remoteId = remoteId,
    ownerUserId = ownerUserId,
    syncStatus = SyncStatus.entries.find { it.name == syncStatus } ?: SyncStatus.LOCAL_ONLY,
    deletedAt = deletedAt,
    visibility = Visibility.entries.find { it.name == visibility } ?: Visibility.PRIVATE
)

fun TireSpot.toEntity(): TireSpotEntity = TireSpotEntity(
    id = id,
    name = name,
    category = category.name,
    address = address,
    latitude = latitude,
    longitude = longitude,
    accessNotes = accessNotes,
    isFenced = isFenced,
    isGated = isGated,
    isLocked = isLocked,
    isExposed = isExposed,
    easyAccess = easyAccess,
    hasCameras = hasCameras,
    securityCommon = securityCommon,
    bestTimeOfDay = bestTimeOfDay.name,
    bestDays = bestDays,
    betterOnWeekends = betterOnWeekends,
    isSeasonal = isSeasonal,
    season = season.name,
    putsOutAroundClosing = putsOutAroundClosing,
    puncturePattern = puncturePattern.name,
    usableDisappearFast = usableDisappearFast,
    othersGetThereFirst = othersGetThereFirst,
    worthCheckingWhenLight = worthCheckingWhenLight,
    usuallyPutsOutMany = usuallyPutsOutMany,
    isVerified = isVerified,
    isFavorite = isFavorite,
    isRetired = isRetired,
    lastChecked = lastChecked,
    lastStatus = lastStatus.name,
    notes = notes,
    tags = tags.toTireJsonString(),
    createdAt = createdAt,
    updatedAt = updatedAt,
    remoteId = remoteId,
    ownerUserId = ownerUserId,
    syncStatus = syncStatus.name,
    deletedAt = deletedAt,
    visibility = visibility.name
)

fun TireReportEntity.toDomain(): TireReport = TireReport(
    id = id,
    tireSpotId = tireSpotId,
    spotName = spotName,
    status = TireSpotStatus.entries.find { it.name == status } ?: TireSpotStatus.UNKNOWN,
    estimatedCount = estimatedCount,
    estimatedUsableCount = estimatedUsableCount,
    estimatedJunkCount = estimatedJunkCount,
    arePunctured = arePunctured,
    somePunctured = somePunctured,
    someUnpunctured = someUnpunctured,
    commonSizes = commonSizes,
    tireTypes = tireTypes,
    treadQuality = TreadQuality.entries.find { it.name == treadQuality } ?: TreadQuality.UNKNOWN,
    condition = TireCondition.entries.find { it.name == condition } ?: TireCondition.UNKNOWN,
    sidewallDamage = sidewallDamage,
    dryRot = dryRot,
    repairVisible = repairVisible,
    conditionNotes = conditionNotes,
    yearNotes = yearNotes,
    alreadyPickedThrough = alreadyPickedThrough,
    lookedFreshOut = lookedFreshOut,
    weatherAffected = weatherAffected,
    notes = notes,
    photoUris = photoUris.parseTireJsonStringList(),
    timestamp = timestamp,
    createdAt = createdAt,
    updatedAt = updatedAt,
    remoteId = remoteId,
    ownerUserId = ownerUserId,
    syncStatus = SyncStatus.entries.find { it.name == syncStatus } ?: SyncStatus.LOCAL_ONLY,
    visibility = Visibility.entries.find { it.name == visibility } ?: Visibility.PRIVATE,
    deletedAt = deletedAt
)

fun TireReport.toEntity(): TireReportEntity = TireReportEntity(
    id = id,
    tireSpotId = tireSpotId,
    spotName = spotName,
    status = status.name,
    estimatedCount = estimatedCount,
    estimatedUsableCount = estimatedUsableCount,
    estimatedJunkCount = estimatedJunkCount,
    arePunctured = arePunctured,
    somePunctured = somePunctured,
    someUnpunctured = someUnpunctured,
    commonSizes = commonSizes,
    tireTypes = tireTypes,
    treadQuality = treadQuality.name,
    condition = condition.name,
    sidewallDamage = sidewallDamage,
    dryRot = dryRot,
    repairVisible = repairVisible,
    conditionNotes = conditionNotes,
    yearNotes = yearNotes,
    alreadyPickedThrough = alreadyPickedThrough,
    lookedFreshOut = lookedFreshOut,
    weatherAffected = weatherAffected,
    notes = notes,
    photoUris = photoUris.toTireJsonString(),
    timestamp = timestamp,
    createdAt = createdAt,
    updatedAt = updatedAt,
    remoteId = remoteId,
    ownerUserId = ownerUserId,
    syncStatus = syncStatus.name,
    visibility = visibility.name,
    deletedAt = deletedAt
)

private fun String.parseTireJsonStringList(): List<String> {
    if (isBlank() || this == "[]") return emptyList()
    return try {
        val arr = JSONArray(this)
        (0 until arr.length()).map { arr.getString(it) }
    } catch (_: Exception) {
        if (contains(",")) split(",").map { it.trim() } else if (isNotBlank()) listOf(trim()) else emptyList()
    }
}

private fun List<String>.toTireJsonString(): String {
    val arr = JSONArray()
    forEach { arr.put(it) }
    return arr.toString()
}
