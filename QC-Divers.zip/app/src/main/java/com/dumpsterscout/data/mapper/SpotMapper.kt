package com.dumpsterscout.data.mapper

import com.dumpsterscout.data.local.entity.DumpsterSpotEntity
import com.dumpsterscout.domain.model.BestSeason
import com.dumpsterscout.domain.model.BestTimeOfDay
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotCategory
import com.dumpsterscout.domain.model.SpotGrade
import com.dumpsterscout.domain.model.SpotLocation
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.Visibility
import org.json.JSONArray

fun DumpsterSpotEntity.toDomain(): DumpsterSpot = DumpsterSpot(
    id = id,
    name = name,
    category = SpotCategory.values().find { it.name == category } ?: SpotCategory.OTHER,
    address = address,
    latitude = latitude,
    longitude = longitude,
    accessNotes = accessNotes,
    spotLocation = SpotLocation.values().find { it.name == spotLocation } ?: SpotLocation.OTHER,
    isFenced = isFenced,
    isGated = isGated,
    isLocked = isLocked,
    isCompactor = isCompactor,
    hasMultipleDumpsters = hasMultipleDumpsters,
    dumpsterCount = dumpsterCount,
    dumpsterLabels = dumpsterLabels,
    lidEasyToOpen = lidEasyToOpen,
    parkingEasy = parkingEasy,
    distanceFromRoad = distanceFromRoad,
    vehicleAccessNotes = vehicleAccessNotes,
    lightingNotes = lightingNotes,
    safetyNotes = safetyNotes,
    securityCommon = securityCommon,
    hasCameras = hasCameras,
    isWellLit = isWellLit,
    isHiddenFromRoad = isHiddenFromRoad,
    pickupDays = pickupDays,
    pickupTimeWindow = pickupTimeWindow,
    bestTimeOfDay = BestTimeOfDay.values().find { it.name == bestTimeOfDay } ?: BestTimeOfDay.VARIES,
    betterOnWeekends = betterOnWeekends,
    bestSeason = BestSeason.values().find { it.name == bestSeason } ?: BestSeason.YEAR_ROUND,
    worthCheckingAfterPickup = worthCheckingAfterPickup,
    bestBeforePickupDay = bestBeforePickupDay,
    throwsOutNearClosingTime = throwsOutNearClosingTime,
    checkMoreThanOncePerWeek = checkMoreThanOncePerWeek,
    worstDay = worstDay,
    usualFindings = usualFindings,
    goodFindsCategories = goodFindsCategories,
    avoidReasons = avoidReasons,
    staffDestroyItems = staffDestroyItems,
    worthCheckingWhenEmpty = worthCheckingWhenEmpty,
    usuallyMessy = usuallyMessy,
    hasSharpHazards = hasSharpHazards,
    hasSealed = hasSealed,
    checkedByOtherDivers = checkedByOtherDivers,
    betterEarlierInNight = betterEarlierInNight,
    conditionSmell = conditionSmell,
    conditionPests = conditionPests,
    conditionMoisture = conditionMoisture,
    recommendedGear = recommendedGear,
    grade = SpotGrade(
        overall = gradeOverall,
        consistency = gradeConsistency,
        quality = gradeQuality,
        quantity = gradeQuantity,
        cleanliness = gradeCleanliness,
        risk = gradeRisk,
        accessDifficulty = gradeAccessDifficulty,
        legalSensitivity = gradeLegalSensitivity
    ),
    personalNotes = personalNotes,
    tags = tags.parseJsonStringList(),
    isFavorite = isFavorite,
    isVerified = isVerified,
    isRetired = isRetired,
    lastChecked = lastChecked,
    lastStatus = SpotStatus.values().find { it.name == lastStatus } ?: SpotStatus.UNKNOWN,
    createdAt = createdAt,
    updatedAt = updatedAt,
    remoteId = remoteId,
    ownerUserId = ownerUserId,
    syncStatus = SyncStatus.entries.find { it.name == syncStatus } ?: SyncStatus.LOCAL_ONLY,
    deletedAt = deletedAt,
    visibility = Visibility.entries.find { it.name == visibility } ?: Visibility.PRIVATE
)

fun DumpsterSpot.toEntity(): DumpsterSpotEntity = DumpsterSpotEntity(
    id = id,
    name = name,
    category = category.name,
    address = address,
    latitude = latitude,
    longitude = longitude,
    accessNotes = accessNotes,
    spotLocation = spotLocation.name,
    isFenced = isFenced,
    isGated = isGated,
    isLocked = isLocked,
    isCompactor = isCompactor,
    hasMultipleDumpsters = hasMultipleDumpsters,
    dumpsterCount = dumpsterCount,
    dumpsterLabels = dumpsterLabels,
    lidEasyToOpen = lidEasyToOpen,
    parkingEasy = parkingEasy,
    distanceFromRoad = distanceFromRoad,
    vehicleAccessNotes = vehicleAccessNotes,
    lightingNotes = lightingNotes,
    safetyNotes = safetyNotes,
    securityCommon = securityCommon,
    hasCameras = hasCameras,
    isWellLit = isWellLit,
    isHiddenFromRoad = isHiddenFromRoad,
    pickupDays = pickupDays,
    pickupTimeWindow = pickupTimeWindow,
    bestTimeOfDay = bestTimeOfDay.name,
    betterOnWeekends = betterOnWeekends,
    bestSeason = bestSeason.name,
    worthCheckingAfterPickup = worthCheckingAfterPickup,
    bestBeforePickupDay = bestBeforePickupDay,
    throwsOutNearClosingTime = throwsOutNearClosingTime,
    checkMoreThanOncePerWeek = checkMoreThanOncePerWeek,
    worstDay = worstDay,
    usualFindings = usualFindings,
    goodFindsCategories = goodFindsCategories,
    avoidReasons = avoidReasons,
    staffDestroyItems = staffDestroyItems,
    worthCheckingWhenEmpty = worthCheckingWhenEmpty,
    usuallyMessy = usuallyMessy,
    hasSharpHazards = hasSharpHazards,
    hasSealed = hasSealed,
    checkedByOtherDivers = checkedByOtherDivers,
    betterEarlierInNight = betterEarlierInNight,
    conditionSmell = conditionSmell,
    conditionPests = conditionPests,
    conditionMoisture = conditionMoisture,
    recommendedGear = recommendedGear,
    gradeOverall = grade.overall,
    gradeConsistency = grade.consistency,
    gradeQuality = grade.quality,
    gradeQuantity = grade.quantity,
    gradeCleanliness = grade.cleanliness,
    gradeRisk = grade.risk,
    gradeAccessDifficulty = grade.accessDifficulty,
    gradeLegalSensitivity = grade.legalSensitivity,
    personalNotes = personalNotes,
    tags = tags.toJsonString(),
    isFavorite = isFavorite,
    isVerified = isVerified,
    isRetired = isRetired,
    lastChecked = lastChecked,
    lastStatus = lastStatus.name,
    createdAt = createdAt,
    updatedAt = updatedAt,
    remoteId = remoteId,
    ownerUserId = ownerUserId,
    syncStatus = syncStatus.name,
    deletedAt = deletedAt,
    visibility = visibility.name
)

private fun String.parseJsonStringList(): List<String> {
    if (isBlank() || this == "[]") return emptyList()
    return try {
        val arr = JSONArray(this)
        (0 until arr.length()).map { arr.getString(it) }
    } catch (_: Exception) {
        if (contains(",")) split(",").map { it.trim() } else if (isNotBlank()) listOf(trim()) else emptyList()
    }
}

private fun List<String>.toJsonString(): String {
    val arr = JSONArray()
    forEach { arr.put(it) }
    return arr.toString()
}
