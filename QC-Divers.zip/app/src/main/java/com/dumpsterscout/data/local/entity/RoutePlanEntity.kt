package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room entity for saved route plans (ordered list of spot ids).
 */
@Entity(tableName = "route_plans")
data class RoutePlanEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val spotIds: String = "",   // JSON array of spot ids
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
