package com.dumpsterscout.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.dumpsterscout.data.local.entity.SpotPhotoEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SpotPhotoDao {

    /** Active (non-deleted) photos for a spot, newest first. */
    @Query("SELECT * FROM spot_photos WHERE spotId = :spotId AND deletedAt IS NULL ORDER BY takenAt DESC")
    fun getPhotosForSpot(spotId: Long): Flow<List<SpotPhotoEntity>>

    /** All photos including soft-deleted, for a spot. */
    @Query("SELECT * FROM spot_photos WHERE spotId = :spotId ORDER BY takenAt DESC")
    fun getAllPhotosForSpot(spotId: Long): Flow<List<SpotPhotoEntity>>

    @Query("SELECT * FROM spot_photos WHERE id = :id")
    suspend fun getById(id: Long): SpotPhotoEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(photo: SpotPhotoEntity): Long

    @Update
    suspend fun update(photo: SpotPhotoEntity)

    @Delete
    suspend fun delete(photo: SpotPhotoEntity)

    /** Soft-delete: stamps deletedAt and marks pending sync so the deletion is pushed on next sync. */
    @Query("UPDATE spot_photos SET deletedAt = :now, updatedAt = :now, uploadStatus = 'PENDING_UPLOAD' WHERE id = :id")
    suspend fun softDelete(id: Long, now: Long = System.currentTimeMillis())

    /** Hard-delete all photos for a spot (used when spot itself is deleted). */
    @Query("DELETE FROM spot_photos WHERE spotId = :spotId")
    suspend fun deleteAllForSpot(spotId: Long)

    /** Photos queued for upload/deletion — includes soft-deleted records so the worker can push remote deletions. */
    @Query("SELECT * FROM spot_photos WHERE uploadStatus = 'PENDING_UPLOAD' ORDER BY createdAt ASC")
    suspend fun getPendingUploadPhotos(): List<SpotPhotoEntity>

    /** Mark a photo as uploaded and store the remote URL. */
    @Query("UPDATE spot_photos SET uploadStatus = 'UPLOADED', remoteUrl = :remoteUrl, updatedAt = :now WHERE id = :id")
    suspend fun markUploaded(id: Long, remoteUrl: String, now: Long = System.currentTimeMillis())

    /** Mark a photo upload as failed. */
    @Query("UPDATE spot_photos SET uploadStatus = 'UPLOAD_FAILED', updatedAt = :now WHERE id = :id")
    suspend fun markUploadFailed(id: Long, now: Long = System.currentTimeMillis())
}

