package com.dumpsterscout.data.remote.dto

import com.dumpsterscout.domain.model.FillLevel
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.model.Visibility
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Remote DTO for the `dumpster_reports` Supabase table.
 *
 * Essential schema (SQL):
 * ```sql
 * create table dumpster_reports (
 *   id           uuid primary key default gen_random_uuid(),
 *   spot_id      uuid references dumpster_spots(id),
 *   owner_id     uuid references auth.users(id),
 *   status       text not null,
 *   fill_level   text not null,
 *   notes        text,
 *   tags         text,
 *   visibility   text not null default 'PRIVATE',
 *   is_from_voice boolean not null default false,
 *   timestamp    bigint not null,
 *   created_at   bigint not null,
 *   updated_at   bigint not null,
 *   deleted_at   bigint
 * );
 * ```
 */
@Serializable
data class ReportRow(
    @SerialName("id") val remoteId: String = "",
    @SerialName("spot_id") val spotRemoteId: String?,
    @SerialName("owner_id") val ownerId: String? = null,
    @SerialName("status") val status: String,
    @SerialName("fill_level") val fillLevel: String,
    @SerialName("notes") val notes: String,
    @SerialName("tags") val tags: String,
    @SerialName("visibility") val visibility: String,
    @SerialName("is_from_voice") val isFromVoice: Boolean,
    @SerialName("timestamp") val timestamp: Long,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: Long,
    @SerialName("deleted_at") val deletedAt: Long?
)

/**
 * Remote DTO for the `tire_reports` Supabase table.
 *
 * Essential schema (SQL):
 * ```sql
 * create table tire_reports (
 *   id                    uuid primary key default gen_random_uuid(),
 *   tire_spot_id          uuid references tire_spots(id),
 *   owner_id              uuid references auth.users(id),
 *   status                text not null,
 *   estimated_count       integer not null default 0,
 *   estimated_usable_count integer not null default 0,
 *   notes                 text,
 *   visibility            text not null default 'PRIVATE',
 *   is_from_voice         boolean not null default false,
 *   timestamp             bigint not null,
 *   created_at            bigint not null,
 *   updated_at            bigint not null,
 *   deleted_at            bigint
 * );
 * ```
 */
@Serializable
data class TireReportRow(
    @SerialName("id") val remoteId: String = "",
    @SerialName("tire_spot_id") val tireSpotRemoteId: String?,
    @SerialName("owner_id") val ownerId: String? = null,
    @SerialName("status") val status: String,
    @SerialName("estimated_count") val estimatedCount: Int,
    @SerialName("estimated_usable_count") val estimatedUsableCount: Int,
    @SerialName("notes") val notes: String,
    @SerialName("visibility") val visibility: String,
    @SerialName("is_from_voice") val isFromVoice: Boolean,
    @SerialName("timestamp") val timestamp: Long,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: Long,
    @SerialName("deleted_at") val deletedAt: Long?
)

fun PersonalReport.toRow(ownerId: String? = null, spotRemoteId: String? = null): ReportRow = ReportRow(
    remoteId     = remoteId ?: "",
    spotRemoteId = spotRemoteId,
    ownerId      = ownerId ?: ownerUserId,
    status       = status.name,
    fillLevel    = fillLevel.name,
    notes        = notes,
    tags         = tags.joinToString(","),
    visibility   = visibility.name,
    isFromVoice  = isFromVoice,
    timestamp    = timestamp,
    createdAt    = createdAt,
    updatedAt    = updatedAt,
    deletedAt    = deletedAt
)

fun TireReport.toRow(ownerId: String? = null, tireSpotRemoteId: String? = null): TireReportRow = TireReportRow(
    remoteId          = remoteId ?: "",
    tireSpotRemoteId  = tireSpotRemoteId,
    ownerId           = ownerId ?: ownerUserId,
    status            = status.name,
    estimatedCount    = estimatedCount,
    estimatedUsableCount = estimatedUsableCount,
    notes             = notes,
    visibility        = visibility.name,
    isFromVoice       = false,
    timestamp         = timestamp,
    createdAt         = createdAt,
    updatedAt         = updatedAt,
    deletedAt         = deletedAt
)

/**
 * Convert an incoming [ReportRow] from Supabase back to a [PersonalReport] domain model.
 * The [localSpotId] must be resolved by the caller by looking up the spot with matching remoteId.
 */
fun ReportRow.toDomain(localSpotId: Long = 0L): PersonalReport = PersonalReport(
    remoteId    = remoteId.ifBlank { null },
    ownerUserId = ownerId,
    spotId      = localSpotId,
    status      = runCatching { SpotStatus.valueOf(status) }.getOrDefault(SpotStatus.UNKNOWN),
    fillLevel   = runCatching { FillLevel.valueOf(fillLevel) }.getOrDefault(FillLevel.UNKNOWN),
    notes       = notes,
    tags        = if (tags.isBlank()) emptyList() else tags.split(",").map { it.trim() }.filter { it.isNotEmpty() },
    visibility  = runCatching { Visibility.valueOf(visibility) }.getOrDefault(Visibility.PRIVATE),
    isFromVoice = isFromVoice,
    timestamp   = timestamp,
    createdAt   = createdAt,
    updatedAt   = updatedAt,
    deletedAt   = deletedAt,
    syncStatus  = SyncStatus.SYNCED
)

/**
 * Convert an incoming [TireReportRow] from Supabase back to a [TireReport] domain model.
 * The [localTireSpotId] must be resolved by the caller.
 */
fun TireReportRow.toDomain(localTireSpotId: Long = 0L): com.dumpsterscout.domain.model.TireReport =
    com.dumpsterscout.domain.model.TireReport(
        remoteId             = remoteId.ifBlank { null },
        ownerUserId          = ownerId,
        tireSpotId           = localTireSpotId,
        status               = runCatching { com.dumpsterscout.domain.model.TireSpotStatus.valueOf(status) }
                                   .getOrDefault(com.dumpsterscout.domain.model.TireSpotStatus.UNKNOWN),
        estimatedCount       = estimatedCount,
        estimatedUsableCount = estimatedUsableCount,
        notes                = notes,
        timestamp            = timestamp,
        createdAt            = createdAt,
        updatedAt            = updatedAt,
        deletedAt            = deletedAt,
        visibility           = runCatching { Visibility.valueOf(visibility) }.getOrDefault(Visibility.PRIVATE),
        syncStatus           = SyncStatus.SYNCED
    )
