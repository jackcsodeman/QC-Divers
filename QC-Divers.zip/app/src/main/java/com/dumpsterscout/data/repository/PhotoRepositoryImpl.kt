package com.dumpsterscout.data.repository

import com.dumpsterscout.data.local.dao.SpotPhotoDao
import com.dumpsterscout.data.mapper.toDomain
import com.dumpsterscout.data.mapper.toSpotPhotoEntity
import com.dumpsterscout.domain.model.PhotoAttachment
import com.dumpsterscout.domain.repository.PhotoRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PhotoRepositoryImpl @Inject constructor(
    private val dao: SpotPhotoDao
) : PhotoRepository {

    override fun getPhotosForSpot(spotId: Long): Flow<List<PhotoAttachment>> =
        dao.getPhotosForSpot(spotId).map { entities -> entities.map { it.toDomain() } }

    override suspend fun getPhotoById(id: Long): PhotoAttachment? =
        dao.getById(id)?.toDomain()

    override suspend fun addPhoto(photo: PhotoAttachment): Long =
        dao.insert(photo.toSpotPhotoEntity())

    override suspend fun updatePhoto(photo: PhotoAttachment) =
        dao.update(photo.toSpotPhotoEntity())

    override suspend fun softDeletePhoto(id: Long) =
        dao.softDelete(id)

    override suspend fun deleteAllForSpot(spotId: Long) =
        dao.deleteAllForSpot(spotId)

    override suspend fun getPendingUploadPhotos(): List<PhotoAttachment> =
        dao.getPendingUploadPhotos().map { it.toDomain() }

    override suspend fun markUploaded(id: Long, remoteUrl: String) =
        dao.markUploaded(id, remoteUrl)

    override suspend fun markUploadFailed(id: Long) =
        dao.markUploadFailed(id)
}
