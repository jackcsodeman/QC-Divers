package com.dumpsterscout.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.dumpsterscout.data.local.dao.DumpsterSpotDao
import com.dumpsterscout.data.local.dao.PersonalReportDao
import com.dumpsterscout.data.local.dao.ReminderDao
import com.dumpsterscout.data.local.dao.RoutePlanDao
import com.dumpsterscout.data.local.dao.SpotPhotoDao
import com.dumpsterscout.data.local.dao.TireReportDao
import com.dumpsterscout.data.local.dao.TireSpotDao
import com.dumpsterscout.data.local.entity.DumpsterSpotEntity
import com.dumpsterscout.data.local.entity.PersonalReportEntity
import com.dumpsterscout.data.local.entity.ReminderEntity
import com.dumpsterscout.data.local.entity.RoutePlanEntity
import com.dumpsterscout.data.local.entity.SpotPhotoEntity
import com.dumpsterscout.data.local.entity.TireReportEntity
import com.dumpsterscout.data.local.entity.TireSpotEntity

/**
 * Room database for Dumpster Scout.
 * All data stays local on device — offline-first by design.
 *
 * Version history:
 *  1 → 2  Added tire_spots and tire_reports tables.
 *  2 → 3  Added sync/backend-ready metadata columns to all core tables
 *         (syncStatus, ownerUserId, remoteId, deletedAt, visibility where
 *         applicable) and enriched spot_photos with upload-state columns.
 */
@Database(
    entities = [
        DumpsterSpotEntity::class,
        PersonalReportEntity::class,
        SpotPhotoEntity::class,
        RoutePlanEntity::class,
        ReminderEntity::class,
        TireSpotEntity::class,
        TireReportEntity::class
    ],
    version = 4,
    exportSchema = true
)
abstract class DumpsterScoutDatabase : RoomDatabase() {

    abstract fun spotDao(): DumpsterSpotDao
    abstract fun reportDao(): PersonalReportDao
    abstract fun photoDao(): SpotPhotoDao
    abstract fun routePlanDao(): RoutePlanDao
    abstract fun reminderDao(): ReminderDao
    abstract fun tireSpotDao(): TireSpotDao
    abstract fun tireReportDao(): TireReportDao

    companion object {
        const val DATABASE_NAME = "dumpster_scout.db"

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `tire_spots` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `name` TEXT NOT NULL,
                        `category` TEXT NOT NULL DEFAULT 'OTHER',
                        `address` TEXT NOT NULL DEFAULT '',
                        `latitude` REAL NOT NULL DEFAULT 0.0,
                        `longitude` REAL NOT NULL DEFAULT 0.0,
                        `accessNotes` TEXT NOT NULL DEFAULT '',
                        `isFenced` INTEGER NOT NULL DEFAULT 0,
                        `isGated` INTEGER NOT NULL DEFAULT 0,
                        `isLocked` INTEGER NOT NULL DEFAULT 0,
                        `isExposed` INTEGER NOT NULL DEFAULT 0,
                        `easyAccess` INTEGER NOT NULL DEFAULT 1,
                        `hasCameras` INTEGER NOT NULL DEFAULT 0,
                        `securityCommon` INTEGER NOT NULL DEFAULT 0,
                        `bestTimeOfDay` TEXT NOT NULL DEFAULT 'VARIES',
                        `bestDays` TEXT NOT NULL DEFAULT '',
                        `betterOnWeekends` INTEGER,
                        `isSeasonal` INTEGER NOT NULL DEFAULT 0,
                        `season` TEXT NOT NULL DEFAULT 'YEAR_ROUND',
                        `putsOutAroundClosing` INTEGER NOT NULL DEFAULT 0,
                        `puncturePattern` TEXT NOT NULL DEFAULT 'UNKNOWN',
                        `usableDisappearFast` INTEGER NOT NULL DEFAULT 0,
                        `othersGetThereFirst` INTEGER NOT NULL DEFAULT 0,
                        `worthCheckingWhenLight` INTEGER NOT NULL DEFAULT 0,
                        `usuallyPutsOutMany` INTEGER NOT NULL DEFAULT 0,
                        `isVerified` INTEGER NOT NULL DEFAULT 0,
                        `isFavorite` INTEGER NOT NULL DEFAULT 0,
                        `isRetired` INTEGER NOT NULL DEFAULT 0,
                        `lastChecked` INTEGER,
                        `lastStatus` TEXT NOT NULL DEFAULT 'UNKNOWN',
                        `notes` TEXT NOT NULL DEFAULT '',
                        `tags` TEXT NOT NULL DEFAULT '',
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `tire_reports` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `tireSpotId` INTEGER NOT NULL,
                        `spotName` TEXT NOT NULL DEFAULT '',
                        `status` TEXT NOT NULL DEFAULT 'UNKNOWN',
                        `estimatedCount` INTEGER NOT NULL DEFAULT 0,
                        `estimatedUsableCount` INTEGER NOT NULL DEFAULT 0,
                        `estimatedJunkCount` INTEGER NOT NULL DEFAULT 0,
                        `arePunctured` INTEGER NOT NULL DEFAULT 0,
                        `somePunctured` INTEGER NOT NULL DEFAULT 0,
                        `someUnpunctured` INTEGER NOT NULL DEFAULT 0,
                        `commonSizes` TEXT NOT NULL DEFAULT '',
                        `tireTypes` TEXT NOT NULL DEFAULT '',
                        `treadQuality` TEXT NOT NULL DEFAULT 'UNKNOWN',
                        `condition` TEXT NOT NULL DEFAULT 'UNKNOWN',
                        `sidewallDamage` INTEGER NOT NULL DEFAULT 0,
                        `dryRot` INTEGER NOT NULL DEFAULT 0,
                        `repairVisible` INTEGER NOT NULL DEFAULT 0,
                        `conditionNotes` TEXT NOT NULL DEFAULT '',
                        `yearNotes` TEXT NOT NULL DEFAULT '',
                        `alreadyPickedThrough` INTEGER NOT NULL DEFAULT 0,
                        `lookedFreshOut` INTEGER NOT NULL DEFAULT 0,
                        `weatherAffected` INTEGER NOT NULL DEFAULT 0,
                        `notes` TEXT NOT NULL DEFAULT '',
                        `photoUris` TEXT NOT NULL DEFAULT '',
                        `timestamp` INTEGER NOT NULL,
                        FOREIGN KEY(`tireSpotId`) REFERENCES `tire_spots`(`id`) ON DELETE CASCADE
                    )
                """.trimIndent())

                db.execSQL("CREATE INDEX IF NOT EXISTS `index_tire_reports_tireSpotId` ON `tire_reports` (`tireSpotId`)")
            }
        }
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // dumpster_spots: add sync metadata + visibility
                db.execSQL("ALTER TABLE `dumpster_spots` ADD COLUMN `remoteId` TEXT")
                db.execSQL("ALTER TABLE `dumpster_spots` ADD COLUMN `ownerUserId` TEXT")
                db.execSQL("ALTER TABLE `dumpster_spots` ADD COLUMN `syncStatus` TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                db.execSQL("ALTER TABLE `dumpster_spots` ADD COLUMN `deletedAt` INTEGER")
                db.execSQL("ALTER TABLE `dumpster_spots` ADD COLUMN `visibility` TEXT NOT NULL DEFAULT 'PRIVATE'")

                // personal_reports: add sync metadata + createdAt/updatedAt
                db.execSQL("ALTER TABLE `personal_reports` ADD COLUMN `createdAt` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `personal_reports` ADD COLUMN `updatedAt` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `personal_reports` ADD COLUMN `remoteId` TEXT")
                db.execSQL("ALTER TABLE `personal_reports` ADD COLUMN `ownerUserId` TEXT")
                db.execSQL("ALTER TABLE `personal_reports` ADD COLUMN `syncStatus` TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                db.execSQL("ALTER TABLE `personal_reports` ADD COLUMN `deletedAt` INTEGER")
                // Backfill timestamps from existing `timestamp` column so rows don't sit at epoch=0
                db.execSQL("UPDATE `personal_reports` SET createdAt = timestamp, updatedAt = timestamp WHERE createdAt = 0")

                // tire_spots: add sync metadata + visibility
                db.execSQL("ALTER TABLE `tire_spots` ADD COLUMN `remoteId` TEXT")
                db.execSQL("ALTER TABLE `tire_spots` ADD COLUMN `ownerUserId` TEXT")
                db.execSQL("ALTER TABLE `tire_spots` ADD COLUMN `syncStatus` TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                db.execSQL("ALTER TABLE `tire_spots` ADD COLUMN `deletedAt` INTEGER")
                db.execSQL("ALTER TABLE `tire_spots` ADD COLUMN `visibility` TEXT NOT NULL DEFAULT 'PRIVATE'")

                // tire_reports: add sync metadata + createdAt/updatedAt
                db.execSQL("ALTER TABLE `tire_reports` ADD COLUMN `createdAt` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `tire_reports` ADD COLUMN `updatedAt` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `tire_reports` ADD COLUMN `remoteId` TEXT")
                db.execSQL("ALTER TABLE `tire_reports` ADD COLUMN `ownerUserId` TEXT")
                db.execSQL("ALTER TABLE `tire_reports` ADD COLUMN `syncStatus` TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                db.execSQL("ALTER TABLE `tire_reports` ADD COLUMN `deletedAt` INTEGER")
                // Backfill timestamps from existing `timestamp` column
                db.execSQL("UPDATE `tire_reports` SET createdAt = timestamp, updatedAt = timestamp WHERE createdAt = 0")

                // spot_photos: enrich with upload-state, ownership, soft-delete columns
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `remoteUrl` TEXT")
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `uploadStatus` TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `mimeType` TEXT NOT NULL DEFAULT 'image/jpeg'")
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `fileSizeBytes` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `ownerUserId` TEXT")
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `createdAt` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `updatedAt` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `spot_photos` ADD COLUMN `deletedAt` INTEGER")
                // Backfill photo timestamps from `takenAt`
                db.execSQL("UPDATE `spot_photos` SET createdAt = takenAt, updatedAt = takenAt WHERE createdAt = 0")
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // personal_reports: add visibility column (missing from migration 2→3)
                db.execSQL("ALTER TABLE `personal_reports` ADD COLUMN `visibility` TEXT NOT NULL DEFAULT 'PRIVATE'")
                // tire_reports: add visibility column for parity
                db.execSQL("ALTER TABLE `tire_reports` ADD COLUMN `visibility` TEXT NOT NULL DEFAULT 'PRIVATE'")
            }
        }
    }
}
