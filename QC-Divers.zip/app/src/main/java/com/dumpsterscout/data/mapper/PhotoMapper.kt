package com.dumpsterscout.data.mapper

import com.dumpsterscout.data.local.entity.SpotPhotoEntity
import com.dumpsterscout.domain.model.PhotoAttachment
import com.dumpsterscout.domain.model.UploadStatus

fun SpotPhotoEntity.toDomain(): PhotoAttachment = PhotoAttachment(
    id = id,
    ownerId = spotId,
    ownerType = "spot",
    localUri = uri.ifBlank { null },
    remoteUrl = remoteUrl,
    uploadStatus = UploadStatus.entries.find { it.name == uploadStatus } ?: UploadStatus.LOCAL_ONLY,
    ownerUserId = ownerUserId,
    caption = caption,
    mimeType = mimeType,
    fileSizeBytes = fileSizeBytes,
    takenAt = takenAt,
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)

fun PhotoAttachment.toSpotPhotoEntity(): SpotPhotoEntity = SpotPhotoEntity(
    id = id,
    spotId = ownerId,
    uri = localUri ?: "",
    remoteUrl = remoteUrl,
    uploadStatus = uploadStatus.name,
    caption = caption,
    mimeType = mimeType,
    fileSizeBytes = fileSizeBytes,
    ownerUserId = ownerUserId,
    takenAt = takenAt,
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt
)
