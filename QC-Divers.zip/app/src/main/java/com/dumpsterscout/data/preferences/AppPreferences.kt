package com.dumpsterscout.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "app_prefs")

/**
 * App-wide preferences via DataStore.
 */
@Singleton
class AppPreferences @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val Keys = object {
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
        val FIELD_MODE = booleanPreferencesKey("field_mode")
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        val DEMO_DATA_SEEDED = booleanPreferencesKey("demo_data_seeded")
        val LIST_COLUMNS = intPreferencesKey("list_columns")
        val DEFAULT_MAP_ZOOM = intPreferencesKey("default_map_zoom")
        // User identity keys (local-only; remote fields populated when auth is live)
        val LOCAL_USER_ID = stringPreferencesKey("local_user_id")
        val DISPLAY_NAME = stringPreferencesKey("display_name")
        val REMOTE_USER_ID = stringPreferencesKey("remote_user_id")
        val FIRST_SEEN_AT = androidx.datastore.preferences.core.longPreferencesKey("first_seen_at")
    }

    val darkTheme: Flow<Boolean> = context.dataStore.data.map { it[Keys.DARK_THEME] ?: false }
    val dynamicColor: Flow<Boolean> = context.dataStore.data.map { it[Keys.DYNAMIC_COLOR] ?: true }
    val fieldMode: Flow<Boolean> = context.dataStore.data.map { it[Keys.FIELD_MODE] ?: false }
    val onboardingDone: Flow<Boolean> = context.dataStore.data.map { it[Keys.ONBOARDING_DONE] ?: false }
    val demoDataSeeded: Flow<Boolean> = context.dataStore.data.map { it[Keys.DEMO_DATA_SEEDED] ?: false }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DARK_THEME] = enabled }
    }

    suspend fun setDynamicColor(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DYNAMIC_COLOR] = enabled }
    }

    suspend fun setFieldMode(enabled: Boolean) {
        context.dataStore.edit { it[Keys.FIELD_MODE] = enabled }
    }

    suspend fun setOnboardingDone(done: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDING_DONE] = done }
    }

    suspend fun setDemoDataSeeded(seeded: Boolean) {
        context.dataStore.edit { it[Keys.DEMO_DATA_SEEDED] = seeded }
    }

    // ── User identity ─────────────────────────────────────────────────────────

    val localUserId: Flow<String?> = context.dataStore.data.map { it[Keys.LOCAL_USER_ID] }
    val displayName: Flow<String?> = context.dataStore.data.map { it[Keys.DISPLAY_NAME] }
    val remoteUserId: Flow<String?> = context.dataStore.data.map { it[Keys.REMOTE_USER_ID] }
    val firstSeenAt: Flow<Long?> = context.dataStore.data.map { it[Keys.FIRST_SEEN_AT] }

    suspend fun setLocalUserId(id: String) {
        context.dataStore.edit { it[Keys.LOCAL_USER_ID] = id }
    }

    suspend fun setDisplayName(name: String) {
        context.dataStore.edit { it[Keys.DISPLAY_NAME] = name }
    }

    suspend fun setRemoteUserId(uid: String) {
        context.dataStore.edit { it[Keys.REMOTE_USER_ID] = uid }
    }

    suspend fun setFirstSeenAt(millis: Long) {
        context.dataStore.edit { it[Keys.FIRST_SEEN_AT] = millis }
    }

    suspend fun clearUserIdentity() {
        context.dataStore.edit {
            // LOCAL_USER_ID is intentionally preserved — it is a stable per-install identifier
            // used as ownerUserId on local records. Clearing it on sign-out would generate a new
            // identity and orphan all existing locally-owned records.
            it.remove(Keys.DISPLAY_NAME)
            it.remove(Keys.REMOTE_USER_ID)
        }
    }
}
