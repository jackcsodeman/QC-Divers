package com.dumpsterscout.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Room entity for photos attached to spots.
 * Mirrors the [com.dumpsterscout.domain.model.PhotoAttachment] domain model.
 * Designed to support both local-only URIs today and remote Supabase Storage
 * URLs in the future.
 */
@Entity(
    tableName = "spot_photos",
    foreignKeys = [
        ForeignKey(
            entity = DumpsterSpotEntity::class,
            parentColumns = ["id"],
            childColumns = ["spotId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("spotId")]
)
data class SpotPhotoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val spotId: Long,

    /** content:// or file:// URI on the local device. */
    val uri: String,

    /** Supabase Storage public/signed URL. Null until uploaded. */
    val remoteUrl: String? = null,

    /** UploadStatus enum name. Default LOCAL_ONLY. */
    val uploadStatus: String = "LOCAL_ONLY",

    val caption: String = "",
    val mimeType: String = "image/jpeg",
    val fileSizeBytes: Long = 0,

    /** User ID of the contributor (device localId in anonymous mode). */
    val ownerUserId: String? = null,

    val takenAt: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),

    /** Soft-delete timestamp. Null = active. */
    val deletedAt: Long? = null
)

