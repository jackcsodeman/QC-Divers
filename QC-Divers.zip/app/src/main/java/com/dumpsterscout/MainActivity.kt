package com.dumpsterscout

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.ui.navigation.DumpsterScoutNavGraph
import com.dumpsterscout.ui.theme.DumpsterScoutTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Single activity host for the Compose UI.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var appPreferences: AppPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val darkTheme by appPreferences.darkTheme.collectAsState(initial = false)
            val dynamicColor by appPreferences.dynamicColor.collectAsState(initial = true)
            val fieldMode by appPreferences.fieldMode.collectAsState(initial = false)

            DumpsterScoutTheme(
                darkTheme = darkTheme,
                dynamicColor = dynamicColor,
                fieldMode = fieldMode
            ) {
                DumpsterScoutNavGraph()
            }
        }
    }
}
