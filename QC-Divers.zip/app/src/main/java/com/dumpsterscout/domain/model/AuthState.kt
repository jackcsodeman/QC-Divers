package com.dumpsterscout.domain.model

/**
 * Authentication state of the current user session.
 *
 * The app is fully usable in [SIGNED_OUT] — all local data remains accessible.
 * [SIGNED_IN] unlocks cloud sync, spot sharing, and future community features.
 */
enum class AuthState {
    /** Initial state while the saved session is being restored from storage. */
    LOADING,
    /** No active session. App works in local-only mode. */
    SIGNED_OUT,
    /** Active Supabase session. Cloud features are available. */
    SIGNED_IN
}
