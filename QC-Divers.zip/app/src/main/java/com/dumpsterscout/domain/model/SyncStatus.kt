package com.dumpsterscout.domain.model

/**
 * Sync lifecycle state for any entity that can eventually be synced to a remote backend.
 *
 * Transition model (local-first):
 *   LOCAL_ONLY → PENDING_SYNC → SYNCED
 *                             → SYNC_FAILED → PENDING_SYNC (retry)
 *   SYNCED     → PENDING_SYNC (after local edit)
 *   Any state  → CONFLICT     (remote change detected during push)
 */
enum class SyncStatus {
    /** Created/modified locally; never pushed to a remote backend. Default for all new records. */
    LOCAL_ONLY,

    /** Modified locally; queued for the next sync pass. */
    PENDING_SYNC,

    /** Successfully synced with the remote backend. */
    SYNCED,

    /** Last sync attempt failed; will be retried. */
    SYNC_FAILED,

    /** Local and remote versions diverged; manual resolution required. */
    CONFLICT
}
