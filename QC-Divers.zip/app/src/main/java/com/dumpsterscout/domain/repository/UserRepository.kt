package com.dumpsterscout.domain.repository

import com.dumpsterscout.domain.model.AuthState
import com.dumpsterscout.domain.model.LocalUser
import kotlinx.coroutines.flow.Flow

/**
 * Repository for user identity and authentication.
 *
 * Local-only identity (anonymous) is always available via DataStore.
 * Auth methods delegate to Supabase Auth when the client is configured;
 * they return [Result.failure] gracefully when no backend is available.
 *
 * Contract for all implementations:
 *  - [getCurrentUser] always returns a non-null [LocalUser]; the first call
 *    generates and persists a stable localId if none exists.
 *  - [getAuthState] reflects the real Supabase session when configured, or
 *    always emits [AuthState.SIGNED_OUT] in local-only mode.
 *  - [signOut] is a no-op in local-only mode (no session to clear).
 */
interface UserRepository {

    /** Observable stream of the current user. Never emits null. */
    fun getCurrentUser(): Flow<LocalUser>

    /** Returns the current user once, suspending until one is available. */
    suspend fun getOrCreateUser(): LocalUser

    /** Update the user's local display name. */
    suspend fun updateDisplayName(name: String)

    /**
     * Associate a Supabase auth UID with the local identity.
     * Called automatically after a successful OTP verification.
     */
    suspend fun linkRemoteAccount(remoteUserId: String)

    /** Clear the local user identity (e.g., on sign-out). Resets to anonymous. */
    suspend fun clearUser()

    // ── Auth methods (no-op / fail gracefully when Supabase not configured) ─────

    /**
     * Send a one-time password (OTP) to the given email address.
     *
     * If the user does not exist yet a new account is created.
     * Returns [Result.failure] when Supabase is not configured or the request fails.
     */
    suspend fun signInWithOtp(email: String): Result<Unit>

    /**
     * Verify the 6-digit OTP code received by email.
     *
     * On success the Supabase session is persisted locally and [getAuthState]
     * transitions to [AuthState.SIGNED_IN].  The remote UID is written to
     * DataStore via [linkRemoteAccount].
     */
    suspend fun verifyOtp(email: String, token: String): Result<Unit>

    /**
     * Sign out of the current Supabase session.
     * Local data is preserved; only the remote session is cleared.
     */
    suspend fun signOut()

    /**
     * Observable stream of the current authentication state.
     * Emits [AuthState.SIGNED_OUT] when Supabase is not configured.
     */
    fun getAuthState(): Flow<AuthState>
}

