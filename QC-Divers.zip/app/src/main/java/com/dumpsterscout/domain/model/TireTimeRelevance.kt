package com.dumpsterscout.domain.model

/** When the tire-spot visit/observation occurred, extracted from voice or text. */
enum class TireTimeRelevance {
    UNSPECIFIED,
    TODAY,
    TONIGHT,
    THIS_MORNING,
    AFTER_CLOSING,
    YESTERDAY,
    EARLIER
}
