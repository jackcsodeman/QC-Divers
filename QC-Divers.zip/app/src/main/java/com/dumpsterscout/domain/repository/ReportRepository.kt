package com.dumpsterscout.domain.repository

import com.dumpsterscout.domain.model.PersonalReport
import kotlinx.coroutines.flow.Flow

/**
 * Repository interface for personal reports / activity log.
 */
interface ReportRepository {

    fun getAllReports(): Flow<List<PersonalReport>>

    fun getReportCount(): Flow<Int>

    fun getReportsBySpot(spotId: Long): Flow<List<PersonalReport>>

    fun getRecentReports(limit: Int = 20): Flow<List<PersonalReport>>

    suspend fun insertReport(report: PersonalReport): Long

    suspend fun updateReport(report: PersonalReport)

    suspend fun deleteReport(report: PersonalReport)

    suspend fun deleteAllReports()

    suspend fun getReportById(id: Long): PersonalReport?

    // ── Sync hooks ────────────────────────────────────────────────────────────

    /** Reports with local changes not yet pushed to the remote backend. */
    suspend fun getPendingSyncReports(): List<PersonalReport>

    /** Mark a report as successfully synced and store the backend-assigned remote ID. */
    suspend fun markReportSynced(id: Long, remoteId: String)

    /** Mark a report sync as failed so it will be retried. */
    suspend fun markReportSyncFailed(id: Long)

    /**
     * Publish a report to the community layer.
     * Sets visibility = COMMUNITY and schedules a sync pass.
     */
    suspend fun publishReport(reportId: Long)

    /** Look up a report by its backend UUID (used during remote pull to avoid duplicates). */
    suspend fun getReportByRemoteId(remoteId: String): PersonalReport?

    /**
     * Insert a report that originated from the remote backend.
     * Does NOT stamp PENDING_SYNC — the record is already synced.
     */
    suspend fun insertReportFromRemote(report: PersonalReport): Long
}
