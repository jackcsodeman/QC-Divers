package com.dumpsterscout.domain.model

/**
 * A private report filed for a spot visit.
 */
data class PersonalReport(
    val id: Long = 0,
    val spotId: Long,
    val spotName: String = "",

    val status: SpotStatus = SpotStatus.UNKNOWN,
    val fillLevel: FillLevel = FillLevel.UNKNOWN,
    val bagCondition: BagCondition = BagCondition.UNKNOWN,

    val notes: String = "",
    val tags: List<String> = emptyList(),
    val photoUris: List<String> = emptyList(),

    val bagsFresh: Boolean? = null,
    val alreadyPickedThrough: Boolean = false,
    val rainDamage: Boolean = false,
    val securitySeen: Boolean = false,
    val cameTooEarly: Boolean = false,
    val cameTooLate: Boolean = false,
    val workersStillOutside: Boolean = false,
    val storeStillOpen: Boolean = false,

    /** Raw voice transcript if from voice report */
    val voiceTranscript: String? = null,
    val isFromVoice: Boolean = false,

    val latitude: Double? = null,
    val longitude: Double? = null,

    val timestamp: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),

    // ── Sync / backend-ready metadata ──────────────────────────────────────────
    /** Stable remote ID from the future backend. Null until first sync. */
    val remoteId: String? = null,
    /** User ID of the owner (device localId in anonymous mode). */
    val ownerUserId: String? = null,
    /** Current sync lifecycle state. */
    val syncStatus: SyncStatus = SyncStatus.LOCAL_ONLY,
    /** Visibility: private, cloud-synced private, or community-shared. */
    val visibility: Visibility = Visibility.PRIVATE,
    /** Soft-delete timestamp. Null = active. */
    val deletedAt: Long? = null
)

enum class FillLevel {
    UNKNOWN, EMPTY, QUARTER_FULL, HALF_FULL, THREE_QUARTER_FULL, FULL, OVERFLOWING
}

enum class BagCondition {
    UNKNOWN, SEALED, LOOSE, RIPPED_OPEN, RAIN_DAMAGED, ALREADY_PICKED
}
