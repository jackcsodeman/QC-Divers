package com.dumpsterscout.domain.model

/**
 * Multi-dimensional grading model for a dumpster spot.
 * Scores are 0–10. Higher = better, except risk/access/legal where higher = harder.
 */
data class SpotGrade(
    /** Overall composite score 0–10 */
    val overall: Float = 0f,
    /** How reliably good is this spot across visits? 0–10 */
    val consistency: Float = 0f,
    /** Quality of typical finds 0–10 */
    val quality: Float = 0f,
    /** Volume/quantity of typical finds 0–10 */
    val quantity: Float = 0f,
    /** How clean/organized is the dumpster 0–10 */
    val cleanliness: Float = 0f,
    /** Risk level (0 = low risk, 10 = high risk) */
    val risk: Float = 0f,
    /** How hard is access (0 = easy, 10 = nearly impossible) */
    val accessDifficulty: Float = 0f,
    /** Legal sensitivity in this area (0 = no concern, 10 = very sensitive) */
    val legalSensitivity: Float = 0f
) {
    fun isGraded(): Boolean =
        overall != 0f ||
            consistency != 0f ||
            quality != 0f ||
            quantity != 0f ||
            cleanliness != 0f ||
            risk != 0f ||
            accessDifficulty != 0f ||
            legalSensitivity != 0f

    fun positiveScore(): Float = (consistency + quality + quantity + cleanliness) / 4f
    fun negativeScore(): Float = (risk + accessDifficulty + legalSensitivity) / 3f
}
