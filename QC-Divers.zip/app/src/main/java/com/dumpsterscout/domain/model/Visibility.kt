package com.dumpsterscout.domain.model

/**
 * Visibility / sharing scope for spots and reports.
 *
 * - PRIVATE    : visible only to the owning user (current default for all records)
 * - COMMUNITY  : visible to verified community members once a backend is live
 * - PUBLIC     : visible to anyone with a link or via search
 *
 * All records default to PRIVATE until a user explicitly opts in.
 */
enum class Visibility {
    PRIVATE,
    COMMUNITY,
    PUBLIC
}
