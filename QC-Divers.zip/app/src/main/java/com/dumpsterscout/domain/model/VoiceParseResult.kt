package com.dumpsterscout.domain.model

/**
 * Result of the deterministic voice/text parser.
 * All fields are optional since the input may be partial.
 */
data class VoiceParseResult(
    /** Parsed business/place name, if found */
    val parsedSpotName: String? = null,
    /** Parsed status */
    val status: SpotStatus? = null,
    /** Fill level hint */
    val fillLevel: FillLevel? = null,
    /** Whether "today" / "tonight" was mentioned */
    val timeRelevance: TimeRelevance = TimeRelevance.UNSPECIFIED,
    /** Free-form notes portion */
    val notes: String = "",
    /** Tags extracted from keywords */
    val tags: List<String> = emptyList(),
    /** Whether security was mentioned */
    val securityMentioned: Boolean = false,
    /** Whether rain/weather was mentioned */
    val weatherIssue: Boolean = false,
    /** Whether "picked through" was mentioned */
    val alreadyPicked: Boolean = false,
    /** Whether "came too early/late" was mentioned */
    val timingNote: TimingNote = TimingNote.NONE,
    /** Quantity/quality hint words */
    val quantityHint: String = "",
    /** The raw transcript unchanged */
    val rawTranscript: String = "",
    /** How confident the parser is 0.0–1.0 */
    val confidence: Float = 0f,
    /** The best matching spot id, if resolved */
    val matchedSpotId: Long? = null,
    /** Multiple candidates if confidence is low */
    val candidateSpotIds: List<Long> = emptyList()
)

enum class TimeRelevance {
    UNSPECIFIED, TODAY, TONIGHT, YESTERDAY, THIS_MORNING, EARLIER
}

enum class TimingNote {
    NONE, CAME_TOO_EARLY, CAME_TOO_LATE
}
