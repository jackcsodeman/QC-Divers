package com.dumpsterscout.domain.repository

import com.dumpsterscout.domain.model.PhotoAttachment
import kotlinx.coroutines.flow.Flow

/**
 * Repository for spot photos and media attachments.
 *
 * Today this manages local-only photos (content:// or file:// URIs).
 * When Supabase Storage is wired up, [getPendingUploadPhotos] feeds the
 * upload worker and [markUploaded] persists the resulting remote URL.
 *
 * All returned photos exclude soft-deleted records unless stated otherwise.
 */
interface PhotoRepository {

    /** Observable list of active (non-deleted) photos for a spot, newest first. */
    fun getPhotosForSpot(spotId: Long): Flow<List<PhotoAttachment>>

    /** Single photo by ID, or null if not found. */
    suspend fun getPhotoById(id: Long): PhotoAttachment?

    /**
     * Add a new photo attachment.  The caller sets [PhotoAttachment.localUri]
     * and leaves [PhotoAttachment.remoteUrl] null; the upload worker fills it later.
     */
    suspend fun addPhoto(photo: PhotoAttachment): Long

    /** Update an existing photo record (e.g. to change caption). */
    suspend fun updatePhoto(photo: PhotoAttachment)

    /**
     * Soft-delete a photo.  Stamps [PhotoAttachment.deletedAt] and marks it
     * [UploadStatus.PENDING_UPLOAD] so the deletion is pushed to remote storage
     * on the next sync pass.
     */
    suspend fun softDeletePhoto(id: Long)

    /** Hard-delete all photos for a spot (called when the spot itself is deleted). */
    suspend fun deleteAllForSpot(spotId: Long)

    // ── Upload worker hooks ────────────────────────────────────────────────────

    /**
     * Returns photos that need to be uploaded or whose deletion needs to be
     * pushed to remote storage.  Fed by the future upload WorkManager task.
     */
    suspend fun getPendingUploadPhotos(): List<PhotoAttachment>

    /**
     * Mark a photo as successfully uploaded to Supabase Storage.
     * @param id       Local photo ID.
     * @param remoteUrl  The signed/public URL returned by Supabase Storage.
     */
    suspend fun markUploaded(id: Long, remoteUrl: String)

    /** Mark a photo upload as failed so it can be retried. */
    suspend fun markUploadFailed(id: Long)
}
