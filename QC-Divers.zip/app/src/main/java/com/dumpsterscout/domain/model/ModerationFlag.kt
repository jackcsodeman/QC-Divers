package com.dumpsterscout.domain.model

/**
 * The type of entity being flagged for moderation review.
 * Maps to the future Supabase `moderation_flags.target_type` column.
 */
enum class ModerationTargetType {
    SPOT,
    REPORT,
    TIRE_SPOT,
    TIRE_REPORT,
    PHOTO,
    USER
}

/**
 * Pre-defined reason a user might flag a piece of content.
 */
enum class ModerationFlagReason {
    INACCURATE_LOCATION,
    SPAM,
    INAPPROPRIATE_CONTENT,
    FAKE_OR_TEST_DATA,
    DUPLICATE,
    PRIVACY_CONCERN,
    SAFETY_HAZARD,
    OTHER
}

/**
 * Lifecycle state of a moderation flag, managed by the future moderator/admin system.
 */
enum class ModerationFlagStatus {
    /** Flag has been submitted and is awaiting review. */
    PENDING,
    /** Under active review by a moderator. */
    REVIEWING,
    /** Flag was accepted; content has been actioned. */
    RESOLVED,
    /** Flag was reviewed and dismissed as invalid. */
    DISMISSED
}

/**
 * A moderation flag raised by a user against any flaggable piece of content.
 *
 * Local-only for now.  When the backend is live, these will be written to
 * the `moderation_flags` Supabase table.  The [reporterUserId] will be the
 * reporter's Supabase Auth UID (or local device ID in anonymous mode).
 *
 * No Android imports — pure Kotlin data class.
 */
data class ModerationFlag(
    val id: Long = 0,

    /** The type of entity being flagged. */
    val targetType: ModerationTargetType,

    /** Local ID of the flagged record (spotId, reportId, etc.). */
    val targetId: Long,

    /** Stable remote ID of the flagged record. Null until synced. */
    val targetRemoteId: String? = null,

    /** User who raised the flag (device localId in anonymous mode). */
    val reporterUserId: String? = null,

    val reason: ModerationFlagReason = ModerationFlagReason.OTHER,

    /** Optional free-text elaboration from the reporter. */
    val notes: String = "",

    val status: ModerationFlagStatus = ModerationFlagStatus.PENDING,

    /** Moderator/admin user ID who actioned this flag. Null until reviewed. */
    val reviewedByUserId: String? = null,

    /** Notes left by the moderator when actioning. */
    val reviewNotes: String = "",

    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),

    /** Sync state for eventual backend push. */
    val syncStatus: SyncStatus = SyncStatus.LOCAL_ONLY
)
