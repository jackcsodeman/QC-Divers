package com.dumpsterscout.domain.repository

import com.dumpsterscout.domain.model.TireReport
import kotlinx.coroutines.flow.Flow

/**
 * Repository interface for tire reports.
 * Implementations live in the data layer.
 */
interface TireReportRepository {

    fun getAllReports(): Flow<List<TireReport>>

    fun getReportsBySpot(spotId: Long): Flow<List<TireReport>>

    fun getRecentReports(limit: Int = 20): Flow<List<TireReport>>

    suspend fun getReportById(id: Long): TireReport?

    suspend fun insertReport(report: TireReport): Long

    suspend fun updateReport(report: TireReport)

    suspend fun deleteReport(report: TireReport)

    suspend fun deleteAllReports()

    // ── Sync hooks ────────────────────────────────────────────────────────────

    /** Tire reports with local changes not yet pushed to the remote backend. */
    suspend fun getPendingSyncReports(): List<TireReport>

    /** Mark a tire report as successfully synced and store the backend-assigned remote ID. */
    suspend fun markReportSynced(id: Long, remoteId: String)

    /** Mark a tire report sync as failed so it will be retried. */
    suspend fun markReportSyncFailed(id: Long)

    /** Publish a tire report to the community layer (sets visibility=COMMUNITY, queues for sync). */
    suspend fun publishReport(reportId: Long)

    /** Look up a tire report by its backend UUID (used during remote pull to avoid duplicates). */
    suspend fun getReportByRemoteId(remoteId: String): TireReport?

    /**
     * Insert a tire report that originated from the remote backend.
     * Does NOT stamp PENDING_SYNC — the record is already synced.
     */
    suspend fun insertReportFromRemote(report: TireReport): Long
}
