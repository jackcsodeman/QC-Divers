package com.dumpsterscout.domain.model

/**
 * Represents the current user identity in local-only or future authenticated modes.
 *
 * In local-only mode [isAnonymous] is true and [remoteUserId] is null.
 * When a future account system is added, [remoteUserId] will be populated
 * with the Supabase auth UID and [isAnonymous] set to false.
 *
 * [localId] is a stable UUID generated once on first install and stored in
 * DataStore. It is used as the [ownerUserId] on all locally-created records.
 */
data class LocalUser(
    /** Stable UUID generated on first launch. Used as ownerUserId for local records. */
    val localId: String,

    /** Optional display name chosen by the user. */
    val displayName: String? = null,

    /** Supabase auth UID. Null until the user creates/links an account. */
    val remoteUserId: String? = null,

    /** True while the user has not signed in to a remote account. */
    val isAnonymous: Boolean = true,

    /** Whether the user has been verified as a trusted contributor (future). */
    val isVerifiedContributor: Boolean = false,

    /** Epoch millis of the device's first app launch. */
    val firstSeenAt: Long = System.currentTimeMillis()
)
