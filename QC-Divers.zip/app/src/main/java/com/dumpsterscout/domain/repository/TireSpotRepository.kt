package com.dumpsterscout.domain.repository

import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireSpotStatus
import kotlinx.coroutines.flow.Flow

/**
 * Repository interface for tire spots.
 * Implementations live in the data layer.
 */
interface TireSpotRepository {

    fun getAllSpots(): Flow<List<TireSpot>>

    fun getFavoriteSpots(): Flow<List<TireSpot>>

    fun getActiveSpots(): Flow<List<TireSpot>>

    fun searchSpots(query: String): Flow<List<TireSpot>>

    suspend fun getSpotById(id: Long): TireSpot?

    suspend fun getNearestSpots(latitude: Double, longitude: Double, radiusMeters: Double = 5000.0): List<TireSpot>

    suspend fun upsertSpot(spot: TireSpot): Long

    suspend fun deleteSpot(spot: TireSpot)

    suspend fun updateLastStatus(spotId: Long, status: TireSpotStatus, timestamp: Long)

    suspend fun toggleFavorite(spotId: Long)

    suspend fun retireSpot(spotId: Long)

    suspend fun deleteAllSpots()

    // ── Sync hooks ────────────────────────────────────────────────────────────

    /** Tire spots with local changes not yet pushed to the remote backend. */
    suspend fun getPendingSyncSpots(): List<TireSpot>

    /** Mark a tire spot as successfully synced and store the backend-assigned remote ID. */
    suspend fun markSpotSynced(id: Long, remoteId: String)

    /** Mark a tire spot sync as failed so it will be retried. */
    suspend fun markSpotSyncFailed(id: Long)

    /**
     * Publish a tire spot to the community layer.
     * Sets visibility = COMMUNITY and schedules a sync pass.
     */
    suspend fun publishSpot(spotId: Long)

    /** Look up a tire spot by its backend UUID (used during remote pull to avoid duplicates). */
    suspend fun getSpotByRemoteId(remoteId: String): TireSpot?

    /**
     * Upsert a tire spot that originated from the remote backend.
     * Does NOT stamp PENDING_SYNC — the record is already synced.
     */
    suspend fun upsertSpotFromRemote(spot: TireSpot): Long
}
