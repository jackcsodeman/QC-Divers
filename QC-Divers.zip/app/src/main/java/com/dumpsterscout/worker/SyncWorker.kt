package com.dumpsterscout.worker

import android.content.Context
import android.util.Log
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.data.remote.RemoteReportDataSource
import com.dumpsterscout.data.remote.RemoteSpotDataSource
import com.dumpsterscout.data.remote.RemoteTireSpotDataSource
import com.dumpsterscout.data.remote.dto.toDomain
import com.dumpsterscout.di.SupabaseCredentials
import com.dumpsterscout.di.annotations.RemoteSource
import com.dumpsterscout.domain.repository.ReportRepository
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.domain.repository.TireReportRepository
import com.dumpsterscout.domain.repository.TireSpotRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first

/**
 * Background WorkManager task that pushes locally-modified records to the
 * Supabase backend.
 *
 * ## Current behaviour (no-op mode)
 * When [SupabaseCredentials.isConfigured] is false (i.e. no backend project
 * has been set up yet), the worker exits early with [Result.success] so the
 * WorkManager does not keep retrying. A log message explains the situation.
 *
 * ## Future behaviour (backend live)
 * Once credentials are configured and the real remote data sources are bound
 * in [RemoteModule], the worker will:
 * 1. Read all records in `PENDING_SYNC` state via the repository sync hooks.
 * 2. Push them to Supabase via the remote data source.
 * 3. Call `markSpotSynced(id, remoteId)` on success or `markSpotSyncFailed(id)`
 *    on failure, so failed records are retried on the next pass.
 *
 * ## Scheduling
 * Schedule via [WorkManager] in your app initialisation:
 * ```kotlin
 * val request = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
 *     .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
 *     .build()
 * WorkManager.getInstance(context).enqueueUniquePeriodicWork(
 *     SyncWorker.WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
 * ```
 */
@HiltWorker
class SyncWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val credentials: SupabaseCredentials,
    private val prefs: AppPreferences,
    private val spotRepository: SpotRepository,
    private val reportRepository: ReportRepository,
    private val tireSpotRepository: TireSpotRepository,
    private val tireReportRepository: TireReportRepository,
    @RemoteSource private val remoteSpotSource: RemoteSpotDataSource,
    @RemoteSource private val remoteReportSource: RemoteReportDataSource,
    @RemoteSource private val remoteTireSpotSource: RemoteTireSpotDataSource
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        if (!credentials.isConfigured) {
            Log.i(TAG, "Supabase not configured — skipping sync.")
            return Result.success()
        }

        Log.i(TAG, "Starting sync pass…")
        var anyFailure = false

        // ── Push outbound changes ──────────────────────────────────────────────
        anyFailure = anyFailure or syncSpots()
        anyFailure = anyFailure or syncReports()
        anyFailure = anyFailure or syncTireSpots()
        anyFailure = anyFailure or syncTireReports()

        // ── Pull user's remote data (new install / other device) ──────────────
        val ownerUserId = prefs.remoteUserId.first() ?: prefs.localUserId.first()
        if (ownerUserId != null) {
            pullMySpots(ownerUserId)
            pullMyReports(ownerUserId)
            pullMyTireSpots(ownerUserId)
            pullMyTireReports(ownerUserId)
        }

        return if (anyFailure) {
            Log.w(TAG, "Sync pass completed with failures — will retry.")
            Result.retry()
        } else {
            Log.i(TAG, "Sync pass completed successfully.")
            Result.success()
        }
    }

    private suspend fun syncSpots(): Boolean {
        val pending = spotRepository.getPendingSyncSpots()
        if (pending.isEmpty()) return false
        Log.d(TAG, "Syncing ${pending.size} spots…")
        return try {
            val synced = remoteSpotSource.upsertSpots(pending)
            pending.forEach { spot ->
                val remoteId = synced[spot.id]
                if (remoteId != null) {
                    spotRepository.markSpotSynced(spot.id, remoteId)
                } else {
                    spotRepository.markSpotSyncFailed(spot.id)
                }
            }
            synced.size < pending.size
        } catch (e: Exception) {
            Log.e(TAG, "Spot sync failed: ${e.message}")
            pending.forEach { spotRepository.markSpotSyncFailed(it.id) }
            true
        }
    }

    private suspend fun syncReports(): Boolean {
        val pending = reportRepository.getPendingSyncReports()
        if (pending.isEmpty()) return false
        Log.d(TAG, "Syncing ${pending.size} spot reports…")

        // Resolve each report's associated spot remoteId so the backend can link
        // the report row to the correct `dumpster_spots` row via the FK.
        val spotRemoteIds: Map<Long, String?> = pending.associate { report ->
            report.id to spotRepository.getSpotById(report.spotId)?.remoteId
        }

        return try {
            val synced = remoteReportSource.upsertReports(pending, spotRemoteIds)
            pending.forEach { report ->
                val remoteId = synced[report.id]
                if (remoteId != null) {
                    reportRepository.markReportSynced(report.id, remoteId)
                } else {
                    reportRepository.markReportSyncFailed(report.id)
                }
            }
            synced.size < pending.size
        } catch (e: Exception) {
            Log.e(TAG, "Report sync failed: ${e.message}")
            pending.forEach { reportRepository.markReportSyncFailed(it.id) }
            true
        }
    }

    private suspend fun syncTireSpots(): Boolean {
        val pending = tireSpotRepository.getPendingSyncSpots()
        if (pending.isEmpty()) return false
        Log.d(TAG, "Syncing ${pending.size} tire spots…")
        return try {
            val synced = remoteTireSpotSource.upsertTireSpots(pending)
            pending.forEach { spot ->
                val remoteId = synced[spot.id]
                if (remoteId != null) {
                    tireSpotRepository.markSpotSynced(spot.id, remoteId)
                } else {
                    tireSpotRepository.markSpotSyncFailed(spot.id)
                }
            }
            synced.size < pending.size
        } catch (e: Exception) {
            Log.e(TAG, "Tire spot sync failed: ${e.message}")
            pending.forEach { tireSpotRepository.markSpotSyncFailed(it.id) }
            true
        }
    }

    private suspend fun syncTireReports(): Boolean {
        val pending = tireReportRepository.getPendingSyncReports()
        if (pending.isEmpty()) return false
        Log.d(TAG, "Syncing ${pending.size} tire reports…")

        // Resolve each tire report's associated tire spot remoteId for the backend FK.
        val tireSpotRemoteIds: Map<Long, String?> = pending.associate { report ->
            report.id to tireSpotRepository.getSpotById(report.tireSpotId)?.remoteId
        }

        return try {
            val synced = remoteReportSource.upsertTireReports(pending, tireSpotRemoteIds)
            pending.forEach { report ->
                val remoteId = synced[report.id]
                if (remoteId != null) {
                    tireReportRepository.markReportSynced(report.id, remoteId)
                } else {
                    tireReportRepository.markReportSyncFailed(report.id)
                }
            }
            synced.size < pending.size
        } catch (e: Exception) {
            Log.e(TAG, "Tire report sync failed: ${e.message}")
            pending.forEach { tireReportRepository.markReportSyncFailed(it.id) }
            true
        }
    }

    /**
     * Pull the user's remote dumpster spots that don't yet exist locally.
     * Spots with a matching [remoteId] already in the DB are skipped to avoid overwriting
     * local edits.
     */
    private suspend fun pullMySpots(ownerUserId: String) {
        try {
            val remote = remoteSpotSource.fetchMySpots(ownerUserId)
            var newCount = 0
            for (spot in remote) {
                val existing = spotRepository.getSpotByRemoteId(spot.remoteId ?: continue)
                if (existing == null) {
                    spotRepository.upsertSpotFromRemote(spot)
                    newCount++
                }
            }
            if (newCount > 0) Log.i(TAG, "Pulled $newCount new dumpster spots from backend.")
        } catch (e: Exception) {
            Log.e(TAG, "pullMySpots failed: ${e.message}")
        }
    }

    /**
     * Pull the user's remote dumpster reports that don't yet exist locally.
     * Resolves each [com.dumpsterscout.data.remote.dto.ReportRow.spotRemoteId] to a local
     * spot id so inserted records have a valid FK.
     */
    private suspend fun pullMyReports(ownerUserId: String) {
        try {
            val remote = remoteReportSource.fetchMyReports(ownerUserId)
            var newCount = 0
            for (row in remote) {
                if (row.remoteId.isBlank()) continue
                val existing = reportRepository.getReportByRemoteId(row.remoteId)
                if (existing == null) {
                    val localSpotId = row.spotRemoteId
                        ?.let { spotRepository.getSpotByRemoteId(it)?.id }
                        ?: 0L
                    reportRepository.insertReportFromRemote(row.toDomain(localSpotId = localSpotId))
                    newCount++
                }
            }
            if (newCount > 0) Log.i(TAG, "Pulled $newCount new dumpster reports from backend.")
        } catch (e: Exception) {
            Log.e(TAG, "pullMyReports failed: ${e.message}")
        }
    }

    /**
     * Pull the user's remote tire spots that don't yet exist locally.
     */
    private suspend fun pullMyTireSpots(ownerUserId: String) {
        try {
            val remote = remoteTireSpotSource.fetchMyTireSpots(ownerUserId)
            var newCount = 0
            for (spot in remote) {
                val existing = tireSpotRepository.getSpotByRemoteId(spot.remoteId ?: continue)
                if (existing == null) {
                    tireSpotRepository.upsertSpotFromRemote(spot)
                    newCount++
                }
            }
            if (newCount > 0) Log.i(TAG, "Pulled $newCount new tire spots from backend.")
        } catch (e: Exception) {
            Log.e(TAG, "pullMyTireSpots failed: ${e.message}")
        }
    }

    /**
     * Pull the user's remote tire reports that don't yet exist locally.
     * Resolves each [com.dumpsterscout.data.remote.dto.TireReportRow.tireSpotRemoteId] to a
     * local tire spot id so inserted records have a valid FK.
     */
    private suspend fun pullMyTireReports(ownerUserId: String) {
        try {
            val remote = remoteReportSource.fetchMyTireReports(ownerUserId)
            var newCount = 0
            for (row in remote) {
                if (row.remoteId.isBlank()) continue
                val existing = tireReportRepository.getReportByRemoteId(row.remoteId)
                if (existing == null) {
                    val localTireSpotId = row.tireSpotRemoteId
                        ?.let { tireSpotRepository.getSpotByRemoteId(it)?.id }
                        ?: 0L
                    tireReportRepository.insertReportFromRemote(row.toDomain(localTireSpotId = localTireSpotId))
                    newCount++
                }
            }
            if (newCount > 0) Log.i(TAG, "Pulled $newCount new tire reports from backend.")
        } catch (e: Exception) {
            Log.e(TAG, "pullMyTireReports failed: ${e.message}")
        }
    }

    companion object {
        const val TAG = "SyncWorker"
        /** Unique name for [WorkManager.enqueueUniquePeriodicWork]. */
        const val WORK_NAME = "dumpsterscout_sync"
    }
}
