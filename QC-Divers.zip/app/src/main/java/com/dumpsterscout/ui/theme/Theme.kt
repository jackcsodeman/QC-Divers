package com.dumpsterscout.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// ─────────────────────────────────────────────────────────────────────────────
// Dumpster Scout — Custom Color Schemes
//
// Dynamic color (Material You) is intentionally disabled by default so our
// branded palette is always used.  Users can opt into dynamic color in Settings
// if they prefer it, but the app's identity depends on consistent green/amber.
// ─────────────────────────────────────────────────────────────────────────────

private val DarkColorScheme = darkColorScheme(
    primary              = NeonCyan,
    onPrimary            = Color(0xFF003338),
    primaryContainer     = NeonCyanDeep,
    onPrimaryContainer   = Color(0xFFB2EBF2),
    secondary            = NeonMagenta,
    onSecondary          = Color(0xFF1A0020),
    secondaryContainer   = NeonMagentaContainer,
    onSecondaryContainer = Color(0xFFF3B0FF),
    tertiary             = NeonBlue,
    onTertiary           = Color(0xFF001240),
    tertiaryContainer    = Color(0xFF0A1F5C),
    onTertiaryContainer  = NeonBlueLight,
    background           = ScoutSurface0,
    onBackground         = ScoutOnSurface,
    surface              = ScoutSurface1,
    onSurface            = ScoutOnSurface,
    surfaceVariant       = ScoutSurface2,
    onSurfaceVariant     = ScoutOnSurfaceDim,
    surfaceTint          = NeonCyan,
    outline              = Color(0xFF1E3040),
    outlineVariant       = Color(0xFF0F1E28),
    error                = StatusSecurity,
    onError              = Color(0xFF2C0008),
    errorContainer       = Color(0xFF4C000F),
    onErrorContainer     = Color(0xFFFFB3BB),
    inverseSurface       = ScoutOnSurface,
    inverseOnSurface     = ScoutSurface1,
    inversePrimary       = NeonCyanDeep,
)

private val LightColorScheme = lightColorScheme(
    primary              = ScoutGreen,
    onPrimary            = Color.White,
    primaryContainer     = ScoutGreenContainer,
    onPrimaryContainer   = ScoutGreenDark,
    secondary            = ScoutAmber,
    onSecondary          = Color.White,
    secondaryContainer   = ScoutAmberContainer,
    onSecondaryContainer = ScoutAmberDark,
    tertiary             = ScoutSlate,
    onTertiary           = Color.White,
    tertiaryContainer    = ScoutSlateContainer,
    onTertiaryContainer  = ScoutSlateDark,
    background           = Color(0xFFF4F6F4),
    onBackground         = ScoutSlateDark,
    surface              = Color(0xFFFAFCF9),
    onSurface            = ScoutSlateDark,
    surfaceVariant       = Color(0xFFE8EDE8),
    onSurfaceVariant     = ScoutSlate,
    outline              = Color(0xFF73796E),
    error                = GradeLow,
    onError              = Color.White,
    errorContainer       = Color(0xFFFFDAD6),
    onErrorContainer     = Color(0xFF410002),
)

// Night-field scheme: even darker surfaces + amber-shifted accents to
// preserve night vision during field use.
private val NightFieldColorScheme = DarkColorScheme.copy(
    background       = NightSurface,
    surface          = NightSurfaceRaised,
    surfaceVariant   = Color(0xFF0C0A00),
    primary          = NightAmber,
    onPrimary        = Color(0xFF1A0D00),
    secondary        = Color(0xFFCC8800),
    onBackground     = NightText,
    onSurface        = NightText,
    onSurfaceVariant = NightTextDim,
)

/** Whether field mode (bigger targets, dim-friendly surfaces) is active. */
val LocalFieldMode = compositionLocalOf { false }

@Composable
fun DumpsterScoutTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Dynamic color is OFF by default — our branded palette is intentional.
    // Enable only if the user explicitly opts in via Settings.
    dynamicColor: Boolean = false,
    fieldMode: Boolean = false,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when {
        // Night-field mode takes priority: it combines field mode + dark in one
        // extra-dim scheme.
        fieldMode && darkTheme -> NightFieldColorScheme
        // Material You dynamic color — only available on Android 12+ (API 31).
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            // Draw edge-to-edge; let the system bars be transparent.
            WindowCompat.setDecorFitsSystemWindows(window, false)
            @Suppress("DEPRECATION")
            window.statusBarColor = Color.Transparent.toArgb()
            WindowCompat.getInsetsController(window, view)
                .isAppearanceLightStatusBars = !darkTheme
        }
    }

    CompositionLocalProvider(LocalFieldMode provides fieldMode) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography  = if (fieldMode) FieldModeTypography else DumpsterScoutTypography,
            content     = content
        )
    }
}
