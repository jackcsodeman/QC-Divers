package com.dumpsterscout.ui.routes

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Label
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.EmptyStatePanel
import com.dumpsterscout.ui.theme.*
import com.dumpsterscout.util.toShortDateString

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedRoutesScreen(
    onNavigateBack: () -> Unit,
    onNavigateToSpotDetail: (Long) -> Unit,
    viewModel: RoutePlanViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }
    var newRouteName by remember { mutableStateOf("") }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false; newRouteName = "" },
            icon  = { Icon(Icons.Default.Route, null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text(stringResource(R.string.new_route_title)) },
            text  = {
                OutlinedTextField(
                    value         = newRouteName,
                    onValueChange = { newRouteName = it },
                    label         = { Text(stringResource(R.string.route_name_label)) },
                    singleLine    = true,
                    shape         = MaterialTheme.shapes.medium,
                    leadingIcon   = { Icon(Icons.AutoMirrored.Filled.Label, null) }
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newRouteName.isNotBlank()) {
                            viewModel.createRoute(newRouteName.trim())
                            newRouteName = ""
                            showAddDialog = false
                        }
                    },
                    enabled = newRouteName.isNotBlank()
                ) { Text(stringResource(R.string.create_route)) }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false; newRouteName = "" }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title    = stringResource(R.string.saved_routes_title),
                subtitle = if (uiState.routes.isNotEmpty()) stringResource(R.string.routes_subtitle, uiState.routes.size) else null,
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick           = { showAddDialog = true },
                containerColor    = MaterialTheme.colorScheme.primary,
                contentColor      = MaterialTheme.colorScheme.onPrimary,
                elevation         = FloatingActionButtonDefaults.elevation(DsElevation.floating)
            ) {
                Icon(Icons.Default.Add, stringResource(R.string.cd_add_route))
            }
        }
    ) { padding ->
        AnimatedContent(
            targetState = uiState.routes.isEmpty(),
            transitionSpec = { fadeIn(tween(DsMotion.medium)) togetherWith fadeOut(tween(DsMotion.exit)) },
            label = "routes_list_toggle",
            modifier = Modifier.fillMaxSize().padding(padding)
        ) { isEmpty ->
            if (isEmpty) {
                EmptyStatePanel(
                    message = stringResource(R.string.routes_empty_message),
                    icon    = Icons.Default.Route
                )
            } else {
                LazyColumn(
                    modifier        = Modifier.fillMaxSize(),
                    contentPadding  = PaddingValues(DsSpacing.l),
                    verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
                ) {
                    items(uiState.routes, key = { it.id }) { route ->
                        RouteCard(
                            routeName  = route.name,
                            stopCount  = route.spotCount,
                            dateLabel  = route.createdAt.toShortDateString(),
                            notes      = route.notes,
                            onNavigate = { route.spotIds.firstOrNull()?.let { onNavigateToSpotDetail(it) } },
                            onDelete   = { viewModel.deleteRoute(route.id) }
                        )
                    }
                }
            }
        }
    }
}

// ── RouteCard ──────────────────────────────────────────────────────────────────

/**
 * A rich card representing a saved route plan.
 * Shows name, stop count, creation date, and optional notes.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RouteCard(
    routeName: String,
    stopCount: Int,
    dateLabel: String,
    notes: String,
    onNavigate: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick   = onNavigate,
        modifier  = modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.large
    ) {
        Column {
            // Accent top strip — neon cyan/blue route gradient
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(Brush.horizontalGradient(listOf(NeonCyan, NeonBlue)))
            )
            Row(
                modifier = Modifier.padding(DsSpacing.l),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                // Route icon badge
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(NeonCyan.copy(alpha = 0.18f))
                ) {
                    Icon(
                        Icons.Default.Route,
                        contentDescription = null,
                        tint     = NeonCyan,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        routeName,
                        style    = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment  = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)
                    ) {
                        Icon(
                            Icons.Default.Place,
                            null,
                            modifier = Modifier.size(12.dp),
                            tint     = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            pluralStringResource(R.plurals.route_stops, stopCount, stopCount),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text("·", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            dateLabel,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (notes.isNotBlank()) {
                        Text(
                            notes,
                            style    = MaterialTheme.typography.bodySmall,
                            color    = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Actions
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.ChevronRight,
                        contentDescription = stringResource(R.string.cd_view_route_details),
                        tint     = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                    IconButton(
                        onClick  = onDelete,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = stringResource(R.string.cd_delete_route),
                            tint     = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

// ── Previews ───────────────────────────────────────────────────────────────────

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "RouteCard dark")
@Composable
private fun RouteCardPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            RouteCard(
                routeName = "Tuesday Night Run",
                stopCount = 7,
                dateLabel = "Mar 28",
                notes     = "Grocery row + big box retail",
                onNavigate = {},
                onDelete   = {}
            )
            RouteCard(
                routeName = "Weekend Deep Sweep",
                stopCount = 12,
                dateLabel = "Mar 15",
                notes     = "",
                onNavigate = {},
                onDelete   = {}
            )
        }
    }
}
