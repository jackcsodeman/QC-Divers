package com.dumpsterscout.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// ─────────────────────────────────────────────────────────────────────────────
// Dumpster Scout Design System — Cyber-Neon Color Token Palette
// ─────────────────────────────────────────────────────────────────────────────

// ── Primary: Electric Cyan ────────────────────────────────────────────────────
val NeonCyan          = Color(0xFF00E5FF)   // electric cyan – primary accent
val NeonCyanDim       = Color(0xFF00B8D4)   // slightly dimmer cyan
val NeonCyanDeep      = Color(0xFF006064)   // deep cyan container
val NeonCyanGlow      = Color(0x2600E5FF)   // glow overlay (alpha 15%)
val NeonCyanContainer = Color(0xFF003E47)   // primary container dark

// Legacy aliases — keep old names so existing screens compile unchanged
val ScoutGreen          = NeonCyan
val ScoutGreenDark      = NeonCyanDeep
val ScoutGreenLight     = NeonCyanDim
val ScoutGreenBright    = NeonCyan
val ScoutGreenContainer = Color(0xFF002F35)

// ── Secondary: Vivid Magenta ──────────────────────────────────────────────────
val NeonMagenta          = Color(0xFFE040FB)   // vivid magenta – secondary accent
val NeonMagentaDim       = Color(0xFFAA00FF)   // deeper magenta
val NeonMagentaLight     = Color(0xFFEA80FC)   // lighter magenta
val NeonMagentaGlow      = Color(0x26E040FB)   // glow overlay (alpha 15%)
val NeonMagentaContainer = Color(0xFF38004A)

// Legacy aliases
val ScoutAmber          = NeonMagenta
val ScoutAmberDark      = NeonMagentaDim
val ScoutAmberLight     = NeonMagentaLight
val ScoutAmberWarm      = NeonMagenta
val ScoutAmberContainer = Color(0xFF4A0060)

// ── Tertiary: Laser Blue ──────────────────────────────────────────────────────
val NeonBlue      = Color(0xFF448AFF)   // laser blue – tertiary accent
val NeonBlueDim   = Color(0xFF2962FF)   // deep electric blue
val NeonBlueLight = Color(0xFF82B1FF)   // light laser blue

// Legacy aliases
val ScoutSlate          = NeonBlueDim
val ScoutSlateDark      = Color(0xFF080D1A)
val ScoutSlateLight     = NeonBlue
val ScoutSlateContainer = Color(0xFF82B1FF)

// ── Deep Dark Surfaces ────────────────────────────────────────────────────────
val ScoutSurface0       = Color(0xFF060810)   // absolute background – near-black blue
val ScoutSurface1       = Color(0xFF0D1117)   // default card surface
val ScoutSurface2       = Color(0xFF111520)   // slightly elevated card
val ScoutSurface3       = Color(0xFF161B26)   // raised panel / bottom-sheet
val ScoutSurface4       = Color(0xFF1B2030)   // dialogs / sheets
val ScoutOnSurface      = Color(0xFFE0F4FF)   // primary text – icy white-blue
val ScoutOnSurfaceDim   = Color(0xFF7B9BB8)   // muted label text

// Legacy aliases
val ScoutSurface        = ScoutSurface1
val ScoutSurfaceVariant = ScoutSurface2

// ── Neon Status Colors ────────────────────────────────────────────────────────
val StatusEmpty       = Color(0xFF00E5FF)   // electric cyan  – clean / available
val StatusHalfFull    = Color(0xFFFF6D00)   // vivid orange   – partially filled
val StatusFull        = Color(0xFF76FF03)   // neon lime       – worth checking
val StatusOverflowing = Color(0xFFFF1744)   // electric red    – spilling over
val StatusLocked      = Color(0xFF546E7A)   // steel grey      – inaccessible
val StatusCompactor   = Color(0xFFD500F9)   // neon purple     – compactor present
val StatusGoodHaul    = Color(0xFF00E676)   // electric green  – great find
val StatusSecurity    = Color(0xFFFF1744)   // electric red    – security risk

// ── Grade Spectrum ────────────────────────────────────────────────────────────
val GradeHigh  = Color(0xFF00E676)   // electric green
val GradeMid   = Color(0xFFFF6D00)   // vivid orange
val GradeLow   = Color(0xFFFF1744)   // electric red
val GradeTrack = Color(0xFF0D1117)   // progress-bar track

// ── Neon Category Accent Colors ───────────────────────────────────────────────
val CategoryGrocery     = Color(0xFF00E5FF)   // electric cyan
val CategoryBakery      = Color(0xFFFF6D00)   // vivid orange
val CategoryPharmacy    = Color(0xFF448AFF)   // laser blue
val CategoryRetail      = Color(0xFFD500F9)   // neon purple
val CategoryRestaurant  = Color(0xFFFF1744)   // electric red
val CategoryApartment   = Color(0xFF00E676)   // electric green
val CategoryOffice      = Color(0xFF40C4FF)   // sky cyan
val CategoryWarehouse   = Color(0xFFCCFF90)   // neon lime
val CategoryElectronics = Color(0xFF00E5FF)   // cyan
val CategoryFurniture   = Color(0xFFFFAB40)   // warm amber
val CategoryOther       = Color(0xFF7B9BB8)   // muted blue-grey

// ── Night-Field Mode ──────────────────────────────────────────────────────────
val NightSurface       = Color(0xFF03050A)
val NightSurfaceRaised = Color(0xFF080D14)
val NightAmber         = Color(0xFFFF6F00)   // hot amber – tactical
val NightText          = Color(0xFFFFCC02)   // bright gold text
val NightTextDim       = Color(0xFF7A5C00)   // muted gold

// ── Glow / Overlay Tokens ─────────────────────────────────────────────────────
val GlowCyan12    = Color(0x1F00E5FF)   // 12% cyan glow
val GlowCyan20    = Color(0x3300E5FF)   // 20% cyan glow
val GlowMagenta12 = Color(0x1FE040FB)   // 12% magenta glow
val GlowMagenta20 = Color(0x33E040FB)   // 20% magenta glow
val GlowBlue12    = Color(0x1F448AFF)   // 12% blue glow
val GlowWhite08   = Color(0x14FFFFFF)   // 8% white overlay

// ── Reusable Gradient Brushes ─────────────────────────────────────────────────

/** Vertical gradient for card headers — cyan accent fades to transparent. */
fun accentHeaderBrush(color: Color): Brush = Brush.verticalGradient(
    colors = listOf(color.copy(alpha = 0.22f), color.copy(alpha = 0f))
)

/** Diagonal hero gradient — cyan → deep dark. */
val HeroGradient: Brush = Brush.linearGradient(
    colors = listOf(Color(0xFF003E47), ScoutSurface0)
)

/** Dual-neon hero gradient — cyan to magenta (diagonal). */
val HeroNeonGradient: Brush = Brush.linearGradient(
    colors = listOf(Color(0xFF003E47), Color(0xFF1B0026))
)

/** Card surface neon tint — subtle cyan luminance on card backgrounds. */
val CardNeonTint: Brush = Brush.radialGradient(
    colors = listOf(Color(0x0A00E5FF), Color(0x00000000)),
    radius = 600f
)

/** Subtle bottom fade on lists. */
val BottomFadeGradient: Brush = Brush.verticalGradient(
    colors = listOf(Color.Transparent, ScoutSurface0.copy(alpha = 0.95f))
)

/** Voice/listening radial glow — electric cyan pulse. */
val VoiceGlowBrush: Brush = Brush.radialGradient(
    colors = listOf(Color(0x4000E5FF), Color(0x0000E5FF), Color(0x00000000)),
    radius = 400f
)

/** Neon border gradient for active/focused components. */
val NeonBorderBrush: Brush = Brush.linearGradient(
    colors = listOf(NeonCyan, NeonMagenta)
)

// ── Tire Category Accent Colors ───────────────────────────────────────────────
val TireTireShop    = Color(0xFFFF6D00)   // vivid orange
val TireMechanic    = Color(0xFF40C4FF)   // sky cyan
val TireDealership  = Color(0xFF448AFF)   // laser blue
val TireGarage      = Color(0xFF00E676)   // electric green
val TireSalvage     = Color(0xFFFFAB40)   // warm amber
val TireRoadside    = Color(0xFF00E5FF)   // electric cyan
val TireWarehouse   = Color(0xFFCCFF90)   // neon lime
val TireOther       = Color(0xFF7B9BB8)   // muted blue-grey
