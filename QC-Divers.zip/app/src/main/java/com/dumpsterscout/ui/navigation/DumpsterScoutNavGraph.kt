package com.dumpsterscout.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.dumpsterscout.ui.about.AboutScreen
import com.dumpsterscout.ui.favorites.FavoritesScreen
import com.dumpsterscout.ui.field.FieldModeScreen
import com.dumpsterscout.ui.history.HistoryScreen
import com.dumpsterscout.ui.home.HomeScreen
import com.dumpsterscout.ui.map.MapScreen
import com.dumpsterscout.ui.routes.SavedRoutesScreen
import com.dumpsterscout.ui.settings.SettingsScreen
import com.dumpsterscout.ui.spots.AddSpotScreen
import com.dumpsterscout.ui.spots.SpotDetailScreen
import com.dumpsterscout.ui.spots.SpotListScreen
import com.dumpsterscout.ui.tire.AddTireSpotScreen
import com.dumpsterscout.ui.tire.TireHistoryScreen
import com.dumpsterscout.ui.tire.TireReportScreen
import com.dumpsterscout.ui.tire.TireSpotDetailScreen
import com.dumpsterscout.ui.tire.TireSpotListScreen
import com.dumpsterscout.ui.tire.TireVoiceReportScreen
import com.dumpsterscout.ui.voice.VoiceReportScreen
import com.dumpsterscout.ui.onboarding.OnboardingScreen
import com.dumpsterscout.ui.gear.GearChecklistScreen
import com.dumpsterscout.ui.theme.DsEasing
import com.dumpsterscout.ui.theme.DsMotion

/**
 * Root navigation graph for Dumpster Scout.
 *
 * Uses Material 3 emphasized easing curves for enter/exit transitions
 * so page changes feel premium and physically grounded.
 */
@Composable
fun DumpsterScoutNavGraph() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Screen.Home.route,
        enterTransition = {
            slideInHorizontally(
                animationSpec = tween(DsMotion.enter, easing = DsEasing.emphasizedDecelerate),
                initialOffsetX = { it / 5 }
            ) + fadeIn(tween(DsMotion.enter, easing = DsEasing.emphasizedDecelerate))
        },
        exitTransition = {
            slideOutHorizontally(
                animationSpec = tween(DsMotion.exit, easing = DsEasing.emphasizedAccelerate),
                targetOffsetX = { -it / 5 }
            ) + fadeOut(tween(DsMotion.exit, easing = DsEasing.emphasizedAccelerate))
        },
        popEnterTransition = {
            slideInHorizontally(
                animationSpec = tween(DsMotion.enter, easing = DsEasing.emphasizedDecelerate),
                initialOffsetX = { -it / 5 }
            ) + fadeIn(tween(DsMotion.enter, easing = DsEasing.emphasizedDecelerate))
        },
        popExitTransition = {
            slideOutHorizontally(
                animationSpec = tween(DsMotion.exit, easing = DsEasing.emphasizedAccelerate),
                targetOffsetX = { it / 5 }
            ) + fadeOut(tween(DsMotion.exit, easing = DsEasing.emphasizedAccelerate))
        }
    ) {
        composable(Screen.Onboarding.route) {
            OnboardingScreen(
                onFinished = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Onboarding.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Home.route) {
            HomeScreen(
                onNavigateToMap              = { navController.navigate(Screen.Map.route) },
                onNavigateToSpotList         = { navController.navigate(Screen.SpotList.route) },
                onNavigateToVoiceReport      = { navController.navigate(Screen.VoiceReport.route) },
                onNavigateToAddSpot          = { navController.navigate(Screen.AddSpot.createRoute()) },
                onNavigateToSpotDetail       = { id -> navController.navigate(Screen.SpotDetail.createRoute(id)) },
                onNavigateToHistory          = { navController.navigate(Screen.History.route) },
                onNavigateToSettings         = { navController.navigate(Screen.Settings.route) },
                onNavigateToFieldMode        = { navController.navigate(Screen.FieldMode.route) },
                onNavigateToTireSpotList     = { navController.navigate(Screen.TireSpotList.route) },
                onNavigateToTireHistory      = { navController.navigate(Screen.TireHistory.route) },
                onNavigateToTireVoiceReport  = { navController.navigate(Screen.TireVoiceReport.createRoute()) }
            )
        }

        composable(Screen.SpotList.route) {
            SpotListScreen(
                onNavigateBack = { navController.navigateUp() },
                onNavigateToSpotDetail = { id -> navController.navigate(Screen.SpotDetail.createRoute(id)) },
                onNavigateToAddSpot = { navController.navigate(Screen.AddSpot.createRoute()) },
                onNavigateToMap = { navController.navigate(Screen.Map.route) }
            )
        }

        composable(
            route = Screen.AddSpot.route,
            arguments = listOf(
                navArgument("spotId") {
                    type = NavType.LongType
                    defaultValue = -1L
                }
            )
        ) { backStackEntry ->
            val spotId = backStackEntry.arguments?.getLong("spotId")?.takeIf { it != -1L }
            AddSpotScreen(
                spotId = spotId,
                onNavigateBack = { navController.navigateUp() },
                onSpotSaved = { savedId ->
                    navController.navigate(Screen.SpotDetail.createRoute(savedId)) {
                        popUpTo(Screen.AddSpot.route) { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = Screen.SpotDetail.route,
            arguments = listOf(navArgument("spotId") { type = NavType.LongType })
        ) { backStackEntry ->
            val spotId = backStackEntry.arguments?.getLong("spotId") ?: return@composable
            SpotDetailScreen(
                spotId = spotId,
                onNavigateBack = { navController.navigateUp() },
                onNavigateToEdit = { id -> navController.navigate(Screen.AddSpot.createRoute(id)) },
                onNavigateToVoiceReport = { navController.navigate(Screen.VoiceReport.route) }
            )
        }

        composable(Screen.VoiceReport.route) {
            VoiceReportScreen(
                onNavigateBack = { navController.navigateUp() },
                onReportSaved = { navController.navigateUp() }
            )
        }

        composable(Screen.Map.route) {
            MapScreen(
                onNavigateBack = { navController.navigateUp() },
                onNavigateToSpotDetail = { id -> navController.navigate(Screen.SpotDetail.createRoute(id)) },
                onNavigateToAddSpot = { navController.navigate(Screen.AddSpot.createRoute()) }
            )
        }

        composable(Screen.History.route) {
            HistoryScreen(
                onNavigateBack = { navController.navigateUp() },
                onNavigateToSpotDetail = { id -> navController.navigate(Screen.SpotDetail.createRoute(id)) }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                onNavigateBack    = { navController.navigateUp() },
                onNavigateToAbout = { navController.navigate(Screen.About.route) },
                onNavigateToAccount = { navController.navigate(Screen.Account.route) }
            )
        }

        composable(Screen.About.route) {
            AboutScreen(
                onNavigateBack = { navController.navigateUp() }
            )
        }

        composable(Screen.GearChecklist.route) {
            GearChecklistScreen(
                onNavigateBack = { navController.navigateUp() }
            )
        }

        composable(Screen.Favorites.route) {
            FavoritesScreen(
                onNavigateBack = { navController.navigateUp() },
                onNavigateToSpotDetail = { id -> navController.navigate(Screen.SpotDetail.createRoute(id)) }
            )
        }

        composable(Screen.SavedRoutes.route) {
            SavedRoutesScreen(
                onNavigateBack = { navController.navigateUp() },
                onNavigateToSpotDetail = { id -> navController.navigate(Screen.SpotDetail.createRoute(id)) }
            )
        }

        composable(Screen.FieldMode.route) {
            FieldModeScreen(
                onNavigateBack            = { navController.navigateUp() },
                onNavigateToVoiceReport   = { navController.navigate(Screen.VoiceReport.route) },
                onNavigateToMap           = { navController.navigate(Screen.Map.route) },
                onNavigateToSpotList      = { navController.navigate(Screen.SpotList.route) },
                onNavigateToAddSpot       = { navController.navigate(Screen.AddSpot.createRoute()) },
                onNavigateToGearChecklist = { navController.navigate(Screen.GearChecklist.route) }
            )
        }

        // ── Tire Spots ─────────────────────────────────────────────────────────

        composable(Screen.TireSpotList.route) {
            TireSpotListScreen(
                onNavigateBack             = { navController.navigateUp() },
                onNavigateToTireSpotDetail = { id -> navController.navigate(Screen.TireSpotDetail.createRoute(id)) },
                onNavigateToAddTireSpot    = { navController.navigate(Screen.AddTireSpot.createRoute()) }
            )
        }

        composable(
            route = Screen.AddTireSpot.route,
            arguments = listOf(
                navArgument("tireSpotId") {
                    type = NavType.LongType
                    defaultValue = -1L
                }
            )
        ) { backStackEntry ->
            val tireSpotId = backStackEntry.arguments?.getLong("tireSpotId")?.takeIf { it != -1L }
            AddTireSpotScreen(
                tireSpotId     = tireSpotId,
                onNavigateBack = { navController.navigateUp() },
                onSpotSaved    = { savedId ->
                    navController.navigate(Screen.TireSpotDetail.createRoute(savedId)) {
                        popUpTo(Screen.AddTireSpot.route) { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = Screen.TireSpotDetail.route,
            arguments = listOf(navArgument("tireSpotId") { type = NavType.LongType })
        ) { backStackEntry ->
            val tireSpotId = backStackEntry.arguments?.getLong("tireSpotId") ?: return@composable
            TireSpotDetailScreen(
                spotId                      = tireSpotId,
                onNavigateBack              = { navController.navigateUp() },
                onNavigateToEdit            = { id -> navController.navigate(Screen.AddTireSpot.createRoute(id)) },
                onNavigateToTireReport      = { id -> navController.navigate(Screen.TireReport.createRoute(id)) },
                onNavigateToTireVoiceReport = { id -> navController.navigate(Screen.TireVoiceReport.createRoute(id)) }
            )
        }

        composable(
            route = Screen.TireReport.route,
            arguments = listOf(
                navArgument("tireSpotId") {
                    type = NavType.LongType
                    defaultValue = -1L
                }
            )
        ) { backStackEntry ->
            val tireSpotId = backStackEntry.arguments?.getLong("tireSpotId")?.takeIf { it != -1L }
            TireReportScreen(
                tireSpotId     = tireSpotId,
                onNavigateBack = { navController.navigateUp() }
            )
        }

        composable(Screen.TireHistory.route) {
            TireHistoryScreen(
                onNavigateBack             = { navController.navigateUp() },
                onNavigateToTireSpotDetail = { id -> navController.navigate(Screen.TireSpotDetail.createRoute(id)) }
            )
        }

        composable(
            route = Screen.TireVoiceReport.route,
            arguments = listOf(navArgument("tireSpotId") { type = NavType.LongType; defaultValue = -1L })
        ) { backStackEntry ->
            val tireSpotId = backStackEntry.arguments?.getLong("tireSpotId")?.takeIf { it != -1L }
            TireVoiceReportScreen(
                onNavigateBack    = { navController.navigateUp() },
                onReportSaved     = { navController.navigateUp() },
                preselectedSpotId = tireSpotId
            )
        }

        // ── Account ────────────────────────────────────────────────────────────
        composable(Screen.Account.route) {
            com.dumpsterscout.ui.account.AccountScreen(
                onNavigateBack = { navController.navigateUp() }
            )
        }
    }
}
