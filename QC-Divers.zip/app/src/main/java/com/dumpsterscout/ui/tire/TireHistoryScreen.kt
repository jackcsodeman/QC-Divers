package com.dumpsterscout.ui.tire

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.ui.components.*
import com.dumpsterscout.ui.theme.DsElevation
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.DumpsterScoutTheme
import com.dumpsterscout.ui.theme.ScoutSurface2
import com.dumpsterscout.util.SampleData
import com.dumpsterscout.util.timeAgoString

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TireHistoryScreen(
    onNavigateBack: () -> Unit,
    onNavigateToTireSpotDetail: (Long) -> Unit,
    viewModel: TireHistoryViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.error) {
        uiState.error?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearError()
        }
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title    = stringResource(R.string.tire_history_title),
                subtitle = stringResource(R.string.history_entries, uiState.filteredReports.size),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            DsSearchField(
                value         = uiState.searchQuery,
                onValueChange = viewModel::onSearchQueryChange,
                placeholder   = stringResource(R.string.search_tire_logs),
                modifier      = Modifier.padding(horizontal = DsSpacing.l, vertical = DsSpacing.s)
            )

            val periodOptions = listOf(
                stringResource(R.string.filter_all)       to (uiState.filterPeriod == TireFilterPeriod.ALL),
                stringResource(R.string.filter_today)     to (uiState.filterPeriod == TireFilterPeriod.TODAY),
                stringResource(R.string.filter_this_week) to (uiState.filterPeriod == TireFilterPeriod.THIS_WEEK)
            )
            FilterChipGroup(
                options  = periodOptions,
                onSelect = { idx -> viewModel.onFilterPeriodChange(TireFilterPeriod.entries[idx]) },
                modifier = Modifier.padding(horizontal = DsSpacing.l)
            )
            Spacer(Modifier.height(DsSpacing.s))

            when {
                uiState.isLoading -> {
                    Column(
                        modifier  = Modifier.padding(DsSpacing.l),
                        verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) { repeat(5) { LoadingShimmerCard() } }
                }
                uiState.filteredReports.isEmpty() -> {
                    EmptyStatePanel(
                        message  = if (uiState.reports.isEmpty())
                            stringResource(R.string.no_tire_history)
                        else
                            stringResource(R.string.no_tire_reports_match),
                        icon     = if (uiState.reports.isEmpty())
                            Icons.Default.HistoryEdu
                        else
                            Icons.Default.SearchOff,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                else -> {
                    LazyColumn(
                        contentPadding      = PaddingValues(horizontal = DsSpacing.l, vertical = DsSpacing.s),
                        verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) {
                        items(uiState.filteredReports, key = { it.id }) { report ->
                            TireReportHistoryCardWrapper(
                                report   = report,
                                onClick  = { onNavigateToTireSpotDetail(report.tireSpotId) },
                                onDelete = { viewModel.deleteReport(report) }
                            )
                        }
                        item { Spacer(Modifier.height(DsSpacing.xxxl)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun TireReportHistoryCardWrapper(
    report: TireReport,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteDialog by remember { mutableStateOf(false) }

    if (showDeleteDialog) {
        DeleteConfirmDialog(
            title     = stringResource(R.string.confirm_delete_report_title),
            message   = stringResource(R.string.confirm_delete_report_message),
            onConfirm = { onDelete(); showDeleteDialog = false },
            onDismiss = { showDeleteDialog = false }
        )
    }

    TireReportCard(
        report   = report,
        onClick  = onClick,
        onDelete = { showDeleteDialog = true }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TireReportCard(
    report: TireReport,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        onClick   = onClick,
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.medium
    ) {
        Column(modifier = Modifier.padding(DsSpacing.l)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text  = report.spotName,
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = stringResource(R.string.delete),
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(DsSpacing.xs))
            Row(
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TireStatusChip(status = report.status)
                if (report.estimatedCount > 0) {
                    SuggestionChip(
                        onClick = {},
                        label   = { Text(stringResource(R.string.tire_count_chip, report.estimatedCount), style = MaterialTheme.typography.labelSmall) }
                    )
                }
                Spacer(Modifier.weight(1f))
                Text(
                    text  = timeAgoString(report.timestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (report.arePunctured || report.somePunctured || report.someUnpunctured) {
                Spacer(Modifier.height(DsSpacing.xs))
                val punctureText = when {
                    report.arePunctured    -> stringResource(R.string.tire_report_all_punctured)
                    report.somePunctured   -> stringResource(R.string.tire_report_some_punctured)
                    report.someUnpunctured -> stringResource(R.string.tire_report_some_unpunctured)
                    else -> ""
                }
                if (punctureText.isNotBlank()) {
                    Text(
                        text  = punctureText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (report.notes.isNotBlank()) {
                Spacer(Modifier.height(DsSpacing.xs))
                Text(
                    text     = report.notes,
                    style    = MaterialTheme.typography.bodySmall,
                    color    = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2
                )
            }
        }
    }
}

// ── Previews ──────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "TireHistory – filled (dark)")
@Composable
private fun TireHistoryFilledPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title    = "Tire Log",
                    subtitle = "${SampleData.tireReports.size} entries",
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                contentPadding      = PaddingValues(horizontal = DsSpacing.l, vertical = DsSpacing.s),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.s),
                modifier            = Modifier.padding(padding)
            ) {
                items(SampleData.tireReports, key = { it.id }) { report ->
                    TireReportCard(report = report, onClick = {}, onDelete = {})
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, name = "TireHistory – empty")
@Composable
private fun TireHistoryEmptyPreview() {
    DumpsterScoutTheme {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title    = "Tire Log",
                    subtitle = "0 entries",
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                        }
                    }
                )
            }
        ) { padding ->
            EmptyStatePanel(
                message  = "No tire reports yet.",
                icon     = Icons.Default.HistoryEdu,
                modifier = Modifier.fillMaxSize().padding(padding)
            )
        }
    }
}
