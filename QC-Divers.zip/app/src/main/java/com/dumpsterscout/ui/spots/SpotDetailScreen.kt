package com.dumpsterscout.ui.spots

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Notes
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotGrade
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.Visibility
import com.dumpsterscout.ui.components.*
import com.dumpsterscout.ui.theme.*
import com.dumpsterscout.util.SampleData
import com.dumpsterscout.util.formatDate
import com.dumpsterscout.util.timeAgoString

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpotDetailScreen(
    spotId: Long,
    onNavigateBack: () -> Unit,
    onNavigateToEdit: (Long) -> Unit,
    onNavigateToVoiceReport: () -> Unit,
    viewModel: SpotViewModel = hiltViewModel()
) {
    LaunchedEffect(spotId) { viewModel.loadSpotDetail(spotId) }

    val uiState by viewModel.detailState.collectAsStateWithLifecycle()
    val spot = uiState.spot
    val snackbarHostState = remember { SnackbarHostState() }

    // Navigate back only after confirmed deletion
    LaunchedEffect(uiState.isDeleted) {
        if (uiState.isDeleted) onNavigateBack()
    }

    // Surface ViewModel errors through the snackbar
    LaunchedEffect(uiState.error) {
        uiState.error?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearDetailError()
        }
    }

    // Confirm publish success via snackbar
    val publishedMsg = stringResource(R.string.msg_spot_published)
    LaunchedEffect(uiState.publishedSuccessfully) {
        if (uiState.publishedSuccessfully) {
            snackbarHostState.showSnackbar(publishedMsg)
            viewModel.clearPublishedFlag()
        }
    }

    if (uiState.showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.showDeleteDialog(false) },
            title            = { Text(stringResource(R.string.confirm_delete_title)) },
            text             = {
                Text(
                    if (spot?.name != null)
                        stringResource(R.string.confirm_delete_spot_message, spot.name)
                    else
                        stringResource(R.string.confirm_delete_message)
                )
            },
            confirmButton    = {
                TextButton(onClick = {
                    viewModel.showDeleteDialog(false)
                    viewModel.deleteSpot()
                }) {
                    Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton    = {
                TextButton(onClick = { viewModel.showDeleteDialog(false) }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title    = spot?.name ?: stringResource(R.string.spot_detail_title),
                subtitle = spot?.let {
                    it.category.name.lowercase().replaceFirstChar { c -> c.uppercaseChar() }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                },
                actions = {
                    if (spot != null) {
                        IconButton(onClick = { viewModel.toggleFavorite(spot.id) }) {
                            Icon(
                                if (spot.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                stringResource(R.string.cd_favorite_button, spot.name),
                                tint = if (spot.isFavorite) MaterialTheme.colorScheme.primary
                                       else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { onNavigateToEdit(spot.id) }) {
                            Icon(Icons.Default.Edit, stringResource(R.string.cd_edit_spot))
                        }
                        IconButton(onClick = { viewModel.showDeleteDialog(true) }) {
                            Icon(Icons.Default.Delete, stringResource(R.string.cd_delete_spot), tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            if (spot != null) {
                FloatingActionButton(
                    onClick        = onNavigateToVoiceReport,
                    containerColor = MaterialTheme.colorScheme.secondary,
                    contentColor   = MaterialTheme.colorScheme.onSecondary,
                    elevation      = FloatingActionButtonDefaults.elevation(defaultElevation = DsElevation.floating)
                ) {
                    Icon(Icons.Default.Mic, contentDescription = stringResource(R.string.cd_voice_update))
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        if (uiState.isLoading) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(DsSpacing.l),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                repeat(4) { LoadingShimmerCard() }
            }
            return@Scaffold
        }

        if (spot == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                EmptyStatePanel(message = stringResource(R.string.spot_not_found))
            }
            return@Scaffold
        }

        SpotDetailContent(
            spot           = spot,
            reports        = uiState.reports,
            onUpdateStatus = { status -> viewModel.updateStatus(spot.id, status) },
            onPublish      = { viewModel.publishSpot() },
            onRetrySync    = { viewModel.retrySyncSpot() },
            isOwner        = uiState.isOwner,
            modifier       = Modifier.padding(padding)
        )
    }
}

@Composable
private fun SpotDetailContent(
    spot: DumpsterSpot,
    reports: List<com.dumpsterscout.domain.model.PersonalReport>,
    onUpdateStatus: (SpotStatus) -> Unit,
    onPublish: () -> Unit,
    onRetrySync: () -> Unit,
    isOwner: Boolean,
    modifier: Modifier = Modifier
) {
    val accent = categoryColor(spot.category)
    val quickStatusList = listOf(
        stringResource(R.string.quick_status_empty)     to SpotStatus.EMPTY,
        stringResource(R.string.quick_status_good_haul) to SpotStatus.GOOD_HAUL,
        stringResource(R.string.quick_status_half_full) to SpotStatus.HALF_FULL,
        stringResource(R.string.quick_status_locked)    to SpotStatus.LOCKED,
        stringResource(R.string.quick_status_security)  to SpotStatus.SECURITY_ACTIVE,
        stringResource(R.string.quick_status_compactor) to SpotStatus.COMPACTOR_ONLY,
        stringResource(R.string.quick_status_nothing)   to SpotStatus.NOTHING_THERE
    )

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            horizontal = DsSpacing.l,
            vertical = DsSpacing.m
        ),
        verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
    ) {
        // ── Risk banner ────────────────────────────────────────────────────
        item {
            val risks = buildList {
                if (spot.securityCommon) add(stringResource(R.string.risk_security_patrols))
                if (spot.hasCameras)     add(stringResource(R.string.risk_cameras_present))
                if (spot.isLocked)       add(stringResource(R.string.risk_dumpster_locked))
                if (spot.staffDestroyItems) add(stringResource(R.string.risk_staff_destroys))
                if (spot.isCompactor)    add(stringResource(R.string.risk_compactor_only))
            }
            RiskBanner(risks = risks)
        }

        // ── Rich header card ───────────────────────────────────────────────
        item { SpotHeaderCard(spot = spot, accent = accent) }

        // ── Sync / Visibility status row ───────────────────────────────────
        item {
            SpotSyncStatusRow(
                syncStatus = spot.syncStatus,
                visibility = spot.visibility,
                isOwner    = isOwner,
                onPublish  = onPublish,
                onRetrySync = onRetrySync
            )
        }

        // ── Quick status update ────────────────────────────────────────────
        item {
            CollapsibleSection(
                title     = stringResource(R.string.section_quick_update),
                icon      = Icons.Default.TouchApp,
                accent    = accent,
                startOpen = true
            ) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                    items(quickStatusList) { (label, status) ->
                        FilterChip(
                            selected = spot.lastStatus == status,
                            onClick  = { onUpdateStatus(status) },
                            label    = { Text(label, style = MaterialTheme.typography.labelLarge) }
                        )
                    }
                }
            }
        }

        // ── Access information ─────────────────────────────────────────────
        if (spot.accessNotes.isNotBlank() || spot.isFenced || spot.isGated || spot.isLocked || spot.isCompactor) {
            item {
                CollapsibleSection(
                    title     = stringResource(R.string.section_access),
                    icon      = Icons.Default.Key,
                    accent    = accent,
                    startOpen = true
                ) {
                    if (spot.accessNotes.isNotBlank()) {
                        Text(spot.accessNotes, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(DsSpacing.s))
                    }
                    AccessBadgesRow(spot)
                }
            }
        }

        // ── Pickup schedule ────────────────────────────────────────────────
        if (spot.pickupDays.isNotBlank() || spot.pickupTimeWindow.isNotBlank()) {
            item {
                CollapsibleSection(
                    title = stringResource(R.string.section_pickup_schedule),
                    icon  = Icons.Default.Schedule
                ) {
                    if (spot.pickupDays.isNotBlank())       InfoRow(stringResource(R.string.label_days), spot.pickupDays)
                    if (spot.pickupTimeWindow.isNotBlank()) InfoRow(stringResource(R.string.label_time), spot.pickupTimeWindow)
                    InfoRow(
                        stringResource(R.string.label_best_time),
                        spot.bestTimeOfDay.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }
                    )
                }
            }
        }

        // ── Typical finds ──────────────────────────────────────────────────
        if (spot.usualFindings.isNotBlank() || spot.avoidReasons.isNotBlank()) {
            item {
                CollapsibleSection(
                    title = stringResource(R.string.section_typical_finds),
                    icon  = Icons.Default.Inventory2
                ) {
                    if (spot.usualFindings.isNotBlank()) {
                        Text(spot.usualFindings, style = MaterialTheme.typography.bodyMedium)
                    }
                    if (spot.avoidReasons.isNotBlank()) {
                        Spacer(Modifier.height(DsSpacing.xs))
                        InfoRow(
                            label      = stringResource(R.string.label_avoid),
                            value      = spot.avoidReasons,
                            valueColor = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }

        // ── Grade card (animated bars) ─────────────────────────────────────
        if (spot.grade.isGraded()) {
            item { GradeCard(grade = spot.grade) }
        }

        // ── Personal notes ─────────────────────────────────────────────────
        if (spot.personalNotes.isNotBlank()) {
            item {
                CollapsibleSection(
                    title = stringResource(R.string.section_personal_notes),
                    icon  = Icons.AutoMirrored.Filled.Notes
                ) {
                    Text(spot.personalNotes, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        // ── Tags ───────────────────────────────────────────────────────────
        if (spot.tags.isNotEmpty()) {
            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    spot.tags.forEach { tag ->
                        SuggestionChip(
                            onClick = {},
                            label   = { Text(tag, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }
        }

        // ── Recent reports for this spot ───────────────────────────────────
        if (reports.isNotEmpty()) {
            item {
                SectionHeader(title = stringResource(R.string.section_recent_reports))
            }
            items(reports.take(5)) { report ->
                val (_, statusColor) = statusDisplay(report.status)
                Card(
                    modifier  = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.subtle),
                    colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
                    shape     = MaterialTheme.shapes.medium
                ) {
                    Row {
                        Box(
                            Modifier
                                .width(3.dp)
                                .heightIn(min = 56.dp)
                                .background(statusColor)
                        )
                        Column(modifier = Modifier.padding(DsSpacing.m)) {
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)
                                ) {
                                    Icon(
                                        if (report.isFromVoice) Icons.Default.Mic else Icons.Default.Edit,
                                        null,
                                        modifier = Modifier.size(14.dp),
                                        tint = if (report.isFromVoice) ScoutAmberWarm else MaterialTheme.colorScheme.primary
                                    )
                                    StatusChip(status = report.status)
                                }
                                Text(
                                    formatDate(report.timestamp),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (report.notes.isNotBlank()) {
                                Spacer(Modifier.height(DsSpacing.xs))
                                Text(
                                    report.notes,
                                    style    = MaterialTheme.typography.bodySmall,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bottom spacer for FAB clearance
        item { Spacer(Modifier.height(DsSpacing.giant + DsSpacing.xxxl)) }
    }
}

// ── Collapsible section card ───────────────────────────────────────────────────

@Composable
private fun CollapsibleSection(
    title: String,
    icon: ImageVector = Icons.Default.ChevronRight,
    accent: Color? = null,
    startOpen: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    var expanded by remember { mutableStateOf(startOpen) }
    val chevronRotation by animateFloatAsState(
        targetValue = if (expanded) 90f else 0f,
        animationSpec = tween(DsMotion.fast, easing = DsEasing.emphasizedDecelerate),
        label = "chevron_rotation"
    )

    Card(
        modifier  = Modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = tween(DsMotion.medium, easing = DsEasing.emphasizedDecelerate)),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.medium
    ) {
        Column {
            // Optional accent strip
            if (accent != null) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .background(accent)
                )
            }

            // Header row (clickable to toggle)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(DsSpacing.l),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                Icon(
                    icon,
                    null,
                    tint = accent ?: MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    title,
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    Icons.Default.ChevronRight,
                    stringResource(R.string.cd_toggle_section),
                    modifier = Modifier
                        .size(20.dp)
                        .rotate(chevronRotation),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Collapsible content
            AnimatedVisibility(
                visible = expanded,
                enter   = fadeIn(tween(DsMotion.fast)) + expandVertically(tween(DsMotion.medium, easing = DsEasing.emphasizedDecelerate)),
                exit    = fadeOut(tween(DsMotion.fast)) + shrinkVertically(tween(DsMotion.fast, easing = DsEasing.emphasizedAccelerate))
            ) {
                Column(modifier = Modifier.padding(start = DsSpacing.l, end = DsSpacing.l, bottom = DsSpacing.l)) {
                    content()
                }
            }
        }
    }
}

// ── Rich spot header card ──────────────────────────────────────────────────────

@Composable
private fun SpotHeaderCard(spot: DumpsterSpot, accent: Color) {
    Card(
        modifier  = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(listOf(accent.copy(alpha = 0.45f), accent.copy(alpha = 0.10f))),
                shape = MaterialTheme.shapes.large
            ),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.raised),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.large
    ) {
        Box {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .clip(MaterialTheme.shapes.large)
                    .background(accentHeaderBrush(accent))
            )
            Column(modifier = Modifier.padding(DsSpacing.l)) {
                Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                    StatusChip(status = spot.lastStatus)
                    if (spot.isVerified) ConditionTag(label = stringResource(R.string.condition_verified))
                    if (spot.isRetired)  ConditionTag(label = stringResource(R.string.condition_retired), isWarning = true)
                    if (spot.isFavorite) ConditionTag(label = stringResource(R.string.condition_favorite))
                }
                Spacer(Modifier.height(DsSpacing.m))

                Text(
                    spot.category.name.lowercase().replaceFirstChar { it.uppercaseChar() },
                    style = MaterialTheme.typography.labelMedium,
                    color = accent
                )
                if (spot.address.isNotBlank()) {
                    Text(
                        spot.address,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                spot.lastChecked?.let {
                    Text(
                        stringResource(R.string.checked_time_ago, timeAgoString(it)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(Modifier.height(DsSpacing.m))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(DsSpacing.s),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (spot.grade.isGraded()) {
                        SpotStatChip(
                            icon  = Icons.Default.Star,
                            value = "%.1f".format(spot.grade.overall),
                            label = stringResource(R.string.stat_score),
                            color = gradeColor(spot.grade.overall, inverted = false),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (spot.pickupDays.isNotBlank()) {
                        SpotStatChip(
                            icon  = Icons.Default.CalendarToday,
                            value = spot.pickupDays.split(",").firstOrNull() ?: spot.pickupDays,
                            label = stringResource(R.string.stat_pickup),
                            color = ScoutAmberWarm,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    SpotStatChip(
                        icon  = Icons.Default.Place,
                        value = spot.spotLocation.name.lowercase().replace('_', ' ')
                            .replaceFirstChar { it.uppercaseChar() }
                            .take(8),
                        label = stringResource(R.string.stat_location),
                        color = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.weight(1f)
                    )
                    if (spot.dumpsterCount > 1) {
                        SpotStatChip(
                            icon  = Icons.Default.Inventory2,
                            value = spot.dumpsterCount.toString(),
                            label = stringResource(R.string.stat_units),
                            color = CategoryPharmacy,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                if (spot.pickupDays.isNotBlank() || spot.bestTimeOfDay.name != "VARIES") {
                    Spacer(Modifier.height(DsSpacing.s))
                    VisitTimingHint(
                        pickupDays       = spot.pickupDays,
                        bestTimeLabel    = spot.bestTimeOfDay.name.lowercase().replace('_', ' ')
                            .replaceFirstChar { it.uppercaseChar() },
                        lastCheckedLabel = spot.lastChecked?.let { timeAgoString(it) }
                    )
                }
            }
        }
    }
}

// ── Access badges ──────────────────────────────────────────────────────────────

@Composable
private fun AccessBadgesRow(spot: DumpsterSpot) {
    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs), modifier = Modifier.fillMaxWidth()) {
        if (spot.isFenced)       ConditionTag(stringResource(R.string.condition_fenced))
        if (spot.isGated)        ConditionTag(stringResource(R.string.condition_gated))
        if (spot.isLocked)       ConditionTag(stringResource(R.string.condition_locked),    isWarning = true)
        if (spot.isCompactor)    ConditionTag(stringResource(R.string.condition_compactor), isWarning = true)
        if (spot.hasCameras)     ConditionTag(stringResource(R.string.condition_cameras))
        if (spot.securityCommon) ConditionTag(stringResource(R.string.condition_security),  isWarning = true)
    }
}

// ── Previews ───────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "SpotDetail dark")
@Composable
private fun SpotDetailDarkPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        val spot = SampleData.spots.find { it.id == 5L } ?: SampleData.spots.first()
        SpotDetailContent(
            spot           = spot,
            reports        = SampleData.reports.filter { it.spotId == spot.id }.take(3),
            onUpdateStatus = {},
            onPublish      = {},
            onRetrySync    = {},
            isOwner        = true
        )
    }
}

@Preview(showBackground = true, name = "SpotDetail light")
@Composable
private fun SpotDetailLightPreview() {
    DumpsterScoutTheme(darkTheme = false) {
        val spot = SampleData.spots.find { it.id == 5L } ?: SampleData.spots.first()
        SpotDetailContent(
            spot           = spot,
            reports        = SampleData.reports.filter { it.spotId == spot.id }.take(3),
            onUpdateStatus = {},
            onPublish      = {},
            onRetrySync    = {},
            isOwner        = true
        )
    }
}

@Composable
private fun SpotSyncStatusRow(
    syncStatus: SyncStatus,
    visibility: Visibility,
    isOwner: Boolean,
    onPublish: () -> Unit,
    onRetrySync: () -> Unit,
    modifier: Modifier = Modifier
) {
    val syncColor = when (syncStatus) {
        SyncStatus.SYNCED       -> MaterialTheme.colorScheme.primary
        SyncStatus.PENDING_SYNC -> MaterialTheme.colorScheme.tertiary
        SyncStatus.SYNC_FAILED  -> MaterialTheme.colorScheme.error
        SyncStatus.CONFLICT     -> MaterialTheme.colorScheme.error
        SyncStatus.LOCAL_ONLY   -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    val syncLabel = when (syncStatus) {
        SyncStatus.SYNCED       -> stringResource(R.string.sync_status_synced)
        SyncStatus.PENDING_SYNC -> stringResource(R.string.sync_status_pending)
        SyncStatus.SYNC_FAILED  -> stringResource(R.string.sync_status_failed)
        SyncStatus.CONFLICT     -> stringResource(R.string.sync_status_conflict)
        SyncStatus.LOCAL_ONLY   -> stringResource(R.string.sync_status_local_only)
    }
    val visibilityLabel = when (visibility) {
        Visibility.PRIVATE   -> stringResource(R.string.visibility_private)
        Visibility.COMMUNITY -> stringResource(R.string.visibility_community)
        Visibility.PUBLIC    -> stringResource(R.string.visibility_public)
    }
    val visibilityIcon = when (visibility) {
        Visibility.PRIVATE   -> Icons.Default.Lock
        Visibility.COMMUNITY -> Icons.Default.People
        Visibility.PUBLIC    -> Icons.Default.Public
    }

    Row(
        modifier          = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Sync status chip
        AssistChip(
            onClick = {},
            label   = { Text(syncLabel, style = MaterialTheme.typography.labelSmall) },
            leadingIcon = {
                Icon(
                    imageVector        = Icons.Default.CloudSync,
                    contentDescription = null,
                    modifier           = Modifier.size(16.dp),
                    tint               = syncColor
                )
            }
        )
        // Visibility chip
        AssistChip(
            onClick = {},
            label   = { Text(visibilityLabel, style = MaterialTheme.typography.labelSmall) },
            leadingIcon = {
                Icon(
                    imageVector        = visibilityIcon,
                    contentDescription = null,
                    modifier           = Modifier.size(16.dp)
                )
            }
        )
        Spacer(Modifier.weight(1f))
        // Retry button — only visible when sync failed
        if (syncStatus == SyncStatus.SYNC_FAILED || syncStatus == SyncStatus.CONFLICT) {
            OutlinedButton(
                onClick        = onRetrySync,
                contentPadding = PaddingValues(horizontal = DsSpacing.m, vertical = 4.dp),
                colors         = ButtonDefaults.outlinedButtonColors(
                    contentColor = MaterialTheme.colorScheme.error
                )
            ) {
                Icon(
                    imageVector        = Icons.Default.Refresh,
                    contentDescription = stringResource(R.string.cd_retry_sync),
                    modifier           = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text(stringResource(R.string.sync_retry_button), style = MaterialTheme.typography.labelMedium)
            }
        }
        // Publish button — only visible if owner and not already community/public
        if (isOwner && syncStatus != SyncStatus.SYNC_FAILED && syncStatus != SyncStatus.CONFLICT
            && visibility != Visibility.COMMUNITY && visibility != Visibility.PUBLIC) {
            OutlinedButton(
                onClick      = onPublish,
                contentPadding = PaddingValues(horizontal = DsSpacing.m, vertical = 4.dp)
            ) {
                Icon(
                    imageVector        = Icons.Default.IosShare,
                    contentDescription = null,
                    modifier           = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text(stringResource(R.string.publish_spot_button), style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "SpotDetail – not found")
@Composable
private fun SpotDetailNotFoundPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title = stringResource(R.string.spot_detail_title),
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                        }
                    }
                )
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                EmptyStatePanel(message = stringResource(R.string.spot_not_found))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "SpotDetail – loading")
@Composable
private fun SpotDetailLoadingPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title = stringResource(R.string.spot_detail_title),
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(DsSpacing.l),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                repeat(4) { LoadingShimmerCard() }
            }
        }
    }
}
