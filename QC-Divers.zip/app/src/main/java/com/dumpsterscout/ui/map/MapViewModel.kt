package com.dumpsterscout.ui.map

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.repository.SpotRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

data class MapUiState(
    val spots: List<DumpsterSpot> = emptyList(),
    val isLoading: Boolean = true,
    val selectedSpotId: Long? = null,
    val error: String? = null
)

@HiltViewModel
class MapViewModel @Inject constructor(
    private val spotRepository: SpotRepository
) : ViewModel() {

    val uiState: StateFlow<MapUiState> = spotRepository.getActiveSpots()
        .map { spots -> MapUiState(spots = spots, isLoading = false) }
        .catch { e -> emit(MapUiState(isLoading = false, error = e.message ?: "An unexpected error occurred")) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = MapUiState()
        )
}
