package com.dumpsterscout.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.repository.ReportRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HistoryUiState(
    val reports: List<PersonalReport> = emptyList(),
    val filteredReports: List<PersonalReport> = emptyList(),
    val isLoading: Boolean = true,
    val filterPeriod: FilterPeriod = FilterPeriod.ALL,
    val searchQuery: String = "",
    val error: String? = null
)

enum class FilterPeriod { ALL, TODAY, THIS_WEEK }

@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val reportRepository: ReportRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HistoryUiState())
    val uiState: StateFlow<HistoryUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            try {
                reportRepository.getAllReports().collect { reports ->
                    _uiState.update { state ->
                        val filtered = applyFilter(reports, state.filterPeriod, state.searchQuery)
                        state.copy(reports = reports, filteredReports = filtered, isLoading = false)
                    }
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
    }

    fun onFilterPeriodChange(period: FilterPeriod) {
        _uiState.update { state ->
            val filtered = applyFilter(state.reports, period, state.searchQuery)
            state.copy(filterPeriod = period, filteredReports = filtered)
        }
    }

    fun onSearchQueryChange(query: String) {
        _uiState.update { state ->
            val filtered = applyFilter(state.reports, state.filterPeriod, query)
            state.copy(searchQuery = query, filteredReports = filtered)
        }
    }

    fun deleteReport(report: PersonalReport) {
        viewModelScope.launch {
            try {
                reportRepository.deleteReport(report)
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "An unexpected error occurred") }
            }
        }
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }

    private fun applyFilter(
        reports: List<PersonalReport>,
        period: FilterPeriod,
        query: String
    ): List<PersonalReport> {
        val now = System.currentTimeMillis()
        val oneDayMs = 86_400_000L
        val oneWeekMs = 7 * oneDayMs
        return reports.filter { report ->
            val withinPeriod = when (period) {
                FilterPeriod.ALL -> true
                FilterPeriod.TODAY -> (now - report.timestamp) < oneDayMs
                FilterPeriod.THIS_WEEK -> (now - report.timestamp) < oneWeekMs
            }
            val matchesQuery = query.isBlank() ||
                    report.spotName.contains(query, ignoreCase = true) ||
                    report.notes.contains(query, ignoreCase = true) ||
                    report.tags.any { it.contains(query, ignoreCase = true) }
            withinPeriod && matchesQuery
        }
    }
}
