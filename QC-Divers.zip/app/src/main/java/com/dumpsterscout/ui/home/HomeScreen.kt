package com.dumpsterscout.ui.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.ui.components.*
import com.dumpsterscout.ui.theme.*
import com.dumpsterscout.ui.tire.TireStatusChip
import com.dumpsterscout.ui.tire.tireStatusDisplay
import com.dumpsterscout.util.SampleData
import com.dumpsterscout.util.timeAgoString

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToMap: () -> Unit,
    onNavigateToSpotList: () -> Unit,
    onNavigateToVoiceReport: () -> Unit,
    onNavigateToAddSpot: () -> Unit,
    onNavigateToSpotDetail: (Long) -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToFieldMode: () -> Unit = {},
    onNavigateToTireSpotList: () -> Unit = {},
    onNavigateToTireHistory: () -> Unit = {},
    onNavigateToTireVoiceReport: () -> Unit = {},
    viewModel: HomeViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    // Surface any ViewModel errors as a snackbar
    LaunchedEffect(uiState.error) {
        uiState.error?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearError()
        }
    }

    HomeContent(
        uiState = uiState,
        snackbarHostState = snackbarHostState,
        onNavigateToMap = onNavigateToMap,
        onNavigateToSpotList = onNavigateToSpotList,
        onNavigateToVoiceReport = onNavigateToVoiceReport,
        onNavigateToAddSpot = onNavigateToAddSpot,
        onNavigateToSpotDetail = onNavigateToSpotDetail,
        onNavigateToHistory = onNavigateToHistory,
        onNavigateToSettings = onNavigateToSettings,
        onNavigateToFieldMode = onNavigateToFieldMode,
        onNavigateToTireSpotList = onNavigateToTireSpotList,
        onNavigateToTireHistory = onNavigateToTireHistory,
        onNavigateToTireVoiceReport = onNavigateToTireVoiceReport,
        onToggleFavorite = viewModel::toggleFavorite
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeContent(
    uiState: HomeUiState,
    snackbarHostState: SnackbarHostState = remember { SnackbarHostState() },
    onNavigateToMap: () -> Unit,
    onNavigateToSpotList: () -> Unit,
    onNavigateToVoiceReport: () -> Unit,
    onNavigateToAddSpot: () -> Unit,
    onNavigateToSpotDetail: (Long) -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToFieldMode: () -> Unit = {},
    onNavigateToTireSpotList: () -> Unit = {},
    onNavigateToTireHistory: () -> Unit = {},
    onNavigateToTireVoiceReport: () -> Unit = {},
    onToggleFavorite: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title    = stringResource(R.string.home_title),
                subtitle = stringResource(R.string.home_subtitle),
                actions  = {
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = stringResource(R.string.settings_title))
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionCluster(
                onPrimaryClick   = onNavigateToVoiceReport,
                onSecondaryClick = onNavigateToAddSpot,
                primaryContentDescription  = stringResource(R.string.cd_mic_button),
                secondaryContentDescription = stringResource(R.string.cd_add_button)
            )
        },
        bottomBar = {
            DsNavigationBar(
                selectedIndex = 0,
                onItemClick   = { index ->
                    when (index) {
                        1 -> onNavigateToSpotList()
                        2 -> onNavigateToMap()
                        3 -> onNavigateToHistory()
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = modifier
    ) { padding ->
        AnimatedContent(
            targetState = uiState.isLoading,
            transitionSpec = {
                fadeIn(tween(DsMotion.medium, easing = DsEasing.emphasizedDecelerate)) togetherWith
                    fadeOut(tween(DsMotion.fast, easing = DsEasing.emphasizedAccelerate))
            },
            label = "home_loading_transition"
        ) { isLoading ->
            if (isLoading) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(DsSpacing.m),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(DsSpacing.l)
                ) {
                    repeat(4) { LoadingShimmerCard(lineCount = 2) }
                }
            } else {

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(
                start = DsSpacing.l,
                end = DsSpacing.l,
                top = DsSpacing.m,
                bottom = DsSpacing.giant + DsSpacing.giant   // room for FAB cluster
            ),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.l)
        ) {

            // ── Hero stats banner ──────────────────────────────────────────
            item {
                HeroBanner(
                    totalSpots     = uiState.totalSpots,
                    totalReports   = uiState.totalReports,
                    tireSpotsCount = uiState.activeTireSpots,
                    favoriteCount  = uiState.favoriteSpots.size
                )
            }

            // ── Quick actions grid ─────────────────────────────────────────
            item {
                QuickActionsGrid(
                    onVoiceReport        = onNavigateToVoiceReport,
                    onAddSpot            = onNavigateToAddSpot,
                    onOpenMap            = onNavigateToMap,
                    onFieldMode          = onNavigateToFieldMode,
                    onTireVoiceReport    = onNavigateToTireVoiceReport,
                    onTireSpotList       = onNavigateToTireSpotList
                )
            }

            // ── Favorites ──────────────────────────────────────────────────
            if (uiState.favoriteSpots.isNotEmpty()) {
                item {
                    SectionHeader(
                        title    = stringResource(R.string.favorites_title),
                        onSeeAll = onNavigateToSpotList
                    )
                }
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(DsSpacing.m),
                        contentPadding = PaddingValues(horizontal = DsSpacing.xs)
                    ) {
                        items(uiState.favoriteSpots) { spot ->
                            FavoriteSpotCard(
                                spot    = spot,
                                onClick = { onNavigateToSpotDetail(spot.id) }
                            )
                        }
                    }
                }
            }

            // ── Best spots to revisit ──────────────────────────────────────
            val topSpots = uiState.spots
                .filter { it.grade.isGraded() }
                .sortedByDescending { it.grade.overall }
                .take(3)
            if (topSpots.isNotEmpty()) {
                item {
                    SectionHeader(
                        title    = stringResource(R.string.best_spots),
                        onSeeAll = onNavigateToSpotList
                    )
                }
                items(topSpots) { spot ->
                    SpotCard(
                        spot            = spot,
                        onClick         = { onNavigateToSpotDetail(spot.id) },
                        onToggleFavorite = { onToggleFavorite(spot.id) }
                    )
                }
            }

            // ── Recent activity ────────────────────────────────────────────
            item {
                SectionHeader(
                    title    = stringResource(R.string.recent_activity),
                    onSeeAll = onNavigateToHistory
                )
            }

            if (uiState.recentReports.isNotEmpty()) {
                items(uiState.recentReports.take(5)) { report ->
                    ReportListItem(
                        report  = report,
                        onClick = { onNavigateToSpotDetail(report.spotId) }
                    )
                }
            } else {
                item {
                    EmptyStatePanel(
                        message = stringResource(R.string.no_activity_yet),
                        icon    = Icons.AutoMirrored.Filled.Assignment
                    )
                }
            }

            // ── Nearby spots ───────────────────────────────────────────────
            if (uiState.spots.isNotEmpty()) {
                item {
                    SectionHeader(
                        title    = stringResource(R.string.spots_nearby),
                        onSeeAll = onNavigateToSpotList
                    )
                }
                items(uiState.spots.take(5)) { spot ->
                    SpotCard(
                        spot            = spot,
                        onClick         = { onNavigateToSpotDetail(spot.id) },
                        onToggleFavorite = { onToggleFavorite(spot.id) }
                    )
                }
            } else {
                item {
                    EmptyStatePanel(
                        message = stringResource(R.string.no_spots_yet),
                        icon    = Icons.Default.Place
                    )
                }
            }

            // ── Tire Spots section ─────────────────────────────────────────
            item {
                SectionHeader(
                    title    = stringResource(R.string.tire_spots_section_title),
                    onSeeAll = onNavigateToTireSpotList
                )
            }
            item {
                TireSpotsHomeCard(
                    activeCount          = uiState.activeTireSpots,
                    recentTireReports    = uiState.recentTireReports,
                    onNavigateToList     = onNavigateToTireSpotList,
                    onNavigateToHistory  = onNavigateToTireHistory,
                    onVoiceLog           = onNavigateToTireVoiceReport
                )
            }

            // ── Safety disclaimer ──────────────────────────────────────────
            item { DisclaimerBanner() }
        }
            }
        }
    }
}

// ── Quick actions grid ─────────────────────────────────────────────────────────

@Composable
private fun QuickActionsGrid(
    onVoiceReport: () -> Unit,
    onAddSpot: () -> Unit,
    onOpenMap: () -> Unit,
    onFieldMode: () -> Unit,
    onTireVoiceReport: () -> Unit = {},
    onTireSpotList: () -> Unit = {}
) {
    Column(verticalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            QuickActionButton(
                label          = stringResource(R.string.quick_action_voice),
                icon           = Icons.Default.Mic,
                onClick        = onVoiceReport,
                containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                contentColor   = MaterialTheme.colorScheme.secondary,
                modifier       = Modifier.weight(1f)
            )
            QuickActionButton(
                label          = stringResource(R.string.quick_action_add_spot),
                icon           = Icons.Default.AddLocation,
                onClick        = onAddSpot,
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                contentColor   = MaterialTheme.colorScheme.primary,
                modifier       = Modifier.weight(1f)
            )
            QuickActionButton(
                label          = stringResource(R.string.quick_action_map),
                icon           = Icons.Default.Map,
                onClick        = onOpenMap,
                containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.4f),
                contentColor   = MaterialTheme.colorScheme.tertiary,
                modifier       = Modifier.weight(1f)
            )
            QuickActionButton(
                label          = stringResource(R.string.quick_action_night),
                icon           = Icons.Default.FlashlightOn,
                onClick        = onFieldMode,
                containerColor = NightAmber.copy(alpha = 0.15f),
                contentColor   = NightAmber,
                modifier       = Modifier.weight(1f)
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            QuickActionButton(
                label          = stringResource(R.string.quick_action_tire_voice),
                icon           = Icons.Default.Build,
                onClick        = onTireVoiceReport,
                containerColor = TireTireShop.copy(alpha = 0.20f),
                contentColor   = TireTireShop,
                modifier       = Modifier.weight(1f)
            )
            QuickActionButton(
                label          = stringResource(R.string.quick_action_tire_spots),
                icon           = Icons.Default.DirectionsCar,
                onClick        = onTireSpotList,
                containerColor = TireTireShop.copy(alpha = 0.12f),
                contentColor   = TireTireShop.copy(alpha = 0.75f),
                modifier       = Modifier.weight(1f)
            )
        }
    }
}

// ── Favorite spot card (horizontal carousel) ───────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FavoriteSpotCard(spot: DumpsterSpot, onClick: () -> Unit) {
    val accent = categoryColor(spot.category)
    Card(
        onClick   = onClick,
        modifier  = Modifier.width(164.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.raised),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.medium
    ) {
        Column {
            // Gradient header with category label
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(accent.copy(alpha = 0.28f), accent.copy(alpha = 0.04f))
                        )
                    ),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    spot.category.name.lowercase().replaceFirstChar { it.uppercaseChar() },
                    style    = MaterialTheme.typography.labelSmall,
                    color    = accent,
                    modifier = Modifier.padding(horizontal = DsSpacing.m)
                )
            }
            Column(modifier = Modifier.padding(horizontal = DsSpacing.m, vertical = DsSpacing.s)) {
                Text(
                    spot.name,
                    style    = MaterialTheme.typography.labelLarge,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(DsSpacing.xs))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs),
                    verticalAlignment     = Alignment.CenterVertically
                ) {
                    StatusChip(status = spot.lastStatus)
                    if (spot.grade.isGraded()) {
                        GradeScoreBadge(overall = spot.grade.overall)
                    }
                }
            }
        }
    }
}

// ── Report list item ───────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReportListItem(report: PersonalReport, onClick: () -> Unit) {
    val (_, statusColor) = statusDisplay(report.status)
    Card(
        onClick   = onClick,
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.subtle),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.medium
    ) {
        Row {
            // Thin status-colored accent strip
            Box(
                Modifier
                    .width(3.dp)
                    .heightIn(min = 56.dp)
                    .background(statusColor)
            )
            Row(
                modifier  = Modifier.padding(DsSpacing.m),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                Surface(
                    color    = if (report.isFromVoice) MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)
                               else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    shape    = CircleShape,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            if (report.isFromVoice) Icons.Default.Mic else Icons.Default.Edit,
                            contentDescription = null,
                            tint   = if (report.isFromVoice) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(report.spotName, style = MaterialTheme.typography.titleSmall)
                    if (report.notes.isNotBlank()) {
                        Text(
                            report.notes,
                            style    = MaterialTheme.typography.bodySmall,
                            color    = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(DsSpacing.xs)) {
                    StatusChip(status = report.status)
                    Text(
                        timeAgoString(report.timestamp),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

// ── Tire Spots home card ───────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TireSpotsHomeCard(
    activeCount: Int,
    recentTireReports: List<TireReport>,
    onNavigateToList: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onVoiceLog: () -> Unit = {}
) {
    Card(
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.medium
    ) {
        Column(modifier = Modifier.padding(DsSpacing.l)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Build,
                    contentDescription = null,
                    tint     = TireTireShop,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(DsSpacing.s))
                Text(
                    stringResource(R.string.tire_spots_active_count, activeCount),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (recentTireReports.isNotEmpty()) {
                Spacer(Modifier.height(DsSpacing.m))
                Text(
                    stringResource(R.string.tire_spots_recent_activity),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(DsSpacing.xs))
                recentTireReports.take(3).forEach { report ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = DsSpacing.xs),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TireStatusChip(status = report.status)
                        Spacer(Modifier.width(DsSpacing.s))
                        Text(
                            report.spotName,
                            style    = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            timeAgoString(report.timestamp),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(Modifier.height(DsSpacing.m))
            Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                OutlinedButton(onClick = onNavigateToList, modifier = Modifier.weight(1f)) {
                    Icon(Icons.AutoMirrored.Filled.List, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(DsSpacing.xs))
                    Text(stringResource(R.string.tire_spots_btn_list))
                }
                OutlinedButton(onClick = onNavigateToHistory, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.History, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(DsSpacing.xs))
                    Text(stringResource(R.string.tire_spots_btn_log))
                }
                OutlinedButton(
                    onClick = onVoiceLog,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TireTireShop)
                ) {
                    Icon(Icons.Default.Mic, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(DsSpacing.xs))
                    Text(stringResource(R.string.tire_spots_btn_voice))
                }
            }
        }
    }
}

// ── Disclaimer banner ──────────────────────────────────────────────────────────

@Composable
private fun DisclaimerBanner() {
    Surface(
        color    = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f),
        shape    = MaterialTheme.shapes.medium,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier  = Modifier.padding(DsSpacing.m),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            Icon(
                Icons.Default.Warning,
                contentDescription = null,
                tint     = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(18.dp)
            )
            Text(
                stringResource(R.string.safety_disclaimer),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
    }
}

// ── Preview ────────────────────────────────────────────────────────────────────

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "Home dark")
@Composable
private fun HomeDarkPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        HomeContent(
            uiState = HomeUiState(
                spots         = SampleData.spots,
                recentReports = SampleData.reports,
                favoriteSpots = SampleData.spots.filter { it.isFavorite },
                isLoading     = false,
                totalSpots    = SampleData.spots.size,
                totalReports  = SampleData.reports.size,
                activeTireSpots = SampleData.tireSpots.size,
                recentTireReports = SampleData.tireReports
            ),
            onNavigateToMap          = {},
            onNavigateToSpotList     = {},
            onNavigateToVoiceReport  = {},
            onNavigateToAddSpot      = {},
            onNavigateToSpotDetail   = {},
            onNavigateToHistory      = {},
            onNavigateToSettings     = {},
            onNavigateToTireSpotList = {},
            onNavigateToTireHistory  = {},
            onToggleFavorite         = {}
        )
    }
}

@Preview(showBackground = true, name = "Home light")
@Composable
private fun HomeLightPreview() {
    DumpsterScoutTheme(darkTheme = false) {
        HomeContent(
            uiState = HomeUiState(
                spots         = SampleData.spots,
                recentReports = SampleData.reports,
                favoriteSpots = SampleData.spots.filter { it.isFavorite },
                isLoading     = false,
                totalSpots    = SampleData.spots.size,
                totalReports  = SampleData.reports.size,
                activeTireSpots = SampleData.tireSpots.size,
                recentTireReports = SampleData.tireReports
            ),
            onNavigateToMap          = {},
            onNavigateToSpotList     = {},
            onNavigateToVoiceReport  = {},
            onNavigateToAddSpot      = {},
            onNavigateToSpotDetail   = {},
            onNavigateToHistory      = {},
            onNavigateToSettings     = {},
            onNavigateToTireSpotList = {},
            onNavigateToTireHistory  = {},
            onToggleFavorite         = {}
        )
    }
}
