package com.dumpsterscout.ui.tire

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.Notes
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireVoiceParseResult
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.theme.DsEasing
import com.dumpsterscout.ui.theme.DsMotion
import com.dumpsterscout.ui.theme.DsRadius
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.DumpsterScoutTheme
import com.dumpsterscout.ui.theme.GlowCyan20
import com.dumpsterscout.ui.theme.NeonCyan
import com.dumpsterscout.ui.theme.NeonMagenta
import com.dumpsterscout.ui.theme.ScoutAmberWarm
import com.dumpsterscout.ui.theme.ScoutGreenBright
import com.dumpsterscout.ui.theme.ScoutSlateDark
import com.dumpsterscout.ui.theme.ScoutSurface0
import com.dumpsterscout.ui.theme.ScoutSurface1
import com.dumpsterscout.ui.theme.ScoutSurface2
import com.dumpsterscout.ui.theme.StatusGoodHaul
import com.dumpsterscout.ui.theme.StatusSecurity
import com.dumpsterscout.ui.theme.TireTireShop
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.delay

@OptIn(ExperimentalPermissionsApi::class, ExperimentalMaterial3Api::class)
@Composable
fun TireVoiceReportScreen(
    onNavigateBack: () -> Unit,
    onReportSaved: () -> Unit,
    preselectedSpotId: Long? = null,
    viewModel: TireVoiceViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val micPermission = rememberPermissionState(Manifest.permission.RECORD_AUDIO)

    // Pre-select spot if launched from detail screen
    LaunchedEffect(preselectedSpotId) {
        if (preselectedSpotId != null && preselectedSpotId > 0) {
            viewModel.preSelectSpot(preselectedSpotId)
        }
    }

    // Auto-navigate after saved phase
    LaunchedEffect(uiState.phase) {
        if (uiState.phase == TireVoicePhase.SAVED) {
            delay(1500)
            onReportSaved()
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull() ?: ""
            viewModel.onTranscriptReceived(text)
        } else {
            viewModel.onListeningCancelled()
        }
    }

    val voicePrompt = stringResource(R.string.tire_voice_prompt)

    fun launchSpeech() {
        viewModel.onStartListening()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, voicePrompt)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechLauncher.launch(intent)
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title    = stringResource(R.string.tire_voice_title),
                subtitle = when (uiState.phase) {
                    TireVoicePhase.IDLE                        -> stringResource(R.string.voice_subtitle_idle)
                    TireVoicePhase.LISTENING                   -> stringResource(R.string.voice_subtitle_listening)
                    TireVoicePhase.PROCESSING                  -> stringResource(R.string.voice_subtitle_processing)
                    TireVoicePhase.CONFIRM, TireVoicePhase.EDIT -> stringResource(R.string.voice_subtitle_review)
                    TireVoicePhase.SAVED                       -> stringResource(R.string.voice_subtitle_saved)
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            ScoutSurface1,
                            ScoutSurface0
                        )
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(DsSpacing.xxl),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(DsSpacing.l)
            ) {
                // Pre-selected spot banner
                AnimatedVisibility(
                    visible = uiState.matchedSpot != null && uiState.phase == TireVoicePhase.IDLE,
                    enter   = fadeIn(tween(DsMotion.medium)) + expandVertically(tween(DsMotion.medium)),
                    exit    = fadeOut(tween(DsMotion.fast))
                ) {
                    uiState.matchedSpot?.let { spot ->
                        TireVoicePreselectedBanner(spot = spot)
                    }
                }

                // Phase-driven main content
                AnimatedContent(
                    targetState = uiState.phase,
                    transitionSpec = {
                        fadeIn(tween(DsMotion.medium, easing = DsEasing.emphasizedDecelerate)) +
                            slideInVertically(tween(DsMotion.medium, easing = DsEasing.emphasizedDecelerate)) { it / 6 } togetherWith
                            fadeOut(tween(DsMotion.fast, easing = DsEasing.emphasizedAccelerate))
                    },
                    label            = "tire_voice_phase",
                    contentAlignment = Alignment.TopCenter
                ) { phase ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(DsSpacing.l)
                    ) {
                        when (phase) {
                            TireVoicePhase.IDLE -> TireVoiceIdlePhase(
                                micGranted = micPermission.status.isGranted,
                                onTap = {
                                    if (micPermission.status.isGranted) launchSpeech()
                                    else micPermission.launchPermissionRequest()
                                }
                            )
                            TireVoicePhase.LISTENING  -> TireVoiceListeningPhase()
                            TireVoicePhase.PROCESSING -> TireVoiceProcessingPhase()
                            TireVoicePhase.SAVED      -> TireVoiceSavedPhase(
                                spotName = uiState.matchedSpot?.name ?: ""
                            )
                            TireVoicePhase.CONFIRM, TireVoicePhase.EDIT -> Unit
                        }
                    }
                }

                // Confirmation/review panel
                AnimatedVisibility(
                    visible = uiState.phase == TireVoicePhase.CONFIRM || uiState.phase == TireVoicePhase.EDIT,
                    enter   = fadeIn(tween(DsMotion.medium, easing = DsEasing.emphasizedDecelerate)) + expandVertically(tween(DsMotion.medium, easing = DsEasing.emphasizedDecelerate)),
                    exit    = fadeOut(tween(DsMotion.fast, easing = DsEasing.emphasizedAccelerate)) + shrinkVertically(tween(DsMotion.fast, easing = DsEasing.emphasizedAccelerate))
                ) {
                    TireVoiceConfirmPanel(
                        uiState          = uiState,
                        onTranscriptEdit = viewModel::onTranscriptEdited,
                        onNotesEdit      = viewModel::onNotesEdited,
                        onSelectSpot     = viewModel::onSelectSpot,
                        onSave           = viewModel::saveReport,
                        onDiscard        = { viewModel.reset(); onNavigateBack() },
                        onReSpeak        = { launchSpeech() }
                    )
                }

                // Error banner
                AnimatedVisibility(
                    visible = uiState.error != null && uiState.phase == TireVoicePhase.IDLE,
                    enter   = fadeIn(tween(DsMotion.medium)) + expandVertically(tween(DsMotion.medium)),
                    exit    = fadeOut(tween(DsMotion.fast)) + shrinkVertically(tween(DsMotion.fast))
                ) {
                    uiState.error?.let { errorMsg ->
                        Card(
                            colors   = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(DsSpacing.m),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                            ) {
                                Icon(Icons.Default.MicOff, null, tint = MaterialTheme.colorScheme.error)
                                Text(
                                    errorMsg,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(onClick = viewModel::reset) {
                                    Icon(Icons.Default.Close, stringResource(R.string.cd_dismiss_error), tint = MaterialTheme.colorScheme.onErrorContainer)
                                }
                            }
                        }
                    }
                }

                // Mic permission banner
                if (!micPermission.status.isGranted) {
                    TireVoiceMicBanner(onRequest = { micPermission.launchPermissionRequest() })
                }

                // Example phrases (idle only)
                AnimatedVisibility(
                    visible = uiState.phase == TireVoicePhase.IDLE,
                    enter   = fadeIn(tween(DsMotion.medium)),
                    exit    = fadeOut(tween(DsMotion.fast))
                ) {
                    Text(
                        stringResource(R.string.tire_voice_examples),
                        style     = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        color     = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

// ── Pre-selected spot banner ───────────────────────────────────────────────────

@Composable
private fun TireVoicePreselectedBanner(spot: TireSpot) {
    Surface(
        color  = TireTireShop.copy(alpha = 0.12f),
        shape  = MaterialTheme.shapes.medium,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(DsSpacing.m),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            Icon(Icons.Default.Place, null, tint = TireTireShop, modifier = Modifier.size(20.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    stringResource(R.string.tire_voice_logging_for),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(spot.name, style = MaterialTheme.typography.titleSmall)
            }
        }
    }
}

// ── Idle phase ─────────────────────────────────────────────────────────────────

@Composable
private fun TireVoiceIdlePhase(micGranted: Boolean, onTap: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "tire_mic_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue  = 1f,
        targetValue   = 1.12f,
        animationSpec = infiniteRepeatable(
            animation  = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "tire_pulse"
    )
    val ringAlpha by infiniteTransition.animateFloat(
        initialValue  = 0.4f,
        targetValue   = 0f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Restart),
        label         = "tire_ring_alpha"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
    ) {
        Spacer(Modifier.height(DsSpacing.xxxl))
        Box(contentAlignment = Alignment.Center) {
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .border(3.dp, NeonCyan.copy(alpha = ringAlpha), CircleShape)
            )
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .scale(pulseScale * 0.95f)
                    .clip(CircleShape)
                    .border(1.dp, NeonMagenta.copy(alpha = ringAlpha * 0.5f), CircleShape)
            )
            FilledIconButton(
                onClick  = onTap,
                modifier = Modifier.size(96.dp),
                colors   = IconButtonDefaults.filledIconButtonColors(
                    containerColor = NeonCyan,
                    contentColor   = ScoutSlateDark
                )
            ) {
                Icon(Icons.Default.Mic, stringResource(R.string.cd_mic_button), modifier = Modifier.size(44.dp))
            }
        }
        Spacer(Modifier.height(DsSpacing.s))
        Text(
            if (micGranted) stringResource(R.string.voice_tap_to_speak)
            else stringResource(R.string.voice_grant_mic),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            stringResource(R.string.tire_voice_hint),
            style     = MaterialTheme.typography.bodySmall,
            textAlign = TextAlign.Center,
            color     = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ── Listening phase ────────────────────────────────────────────────────────────

@Composable
private fun TireVoiceListeningPhase() {
    val infiniteTransition = rememberInfiniteTransition(label = "tire_listening")
    val scale by infiniteTransition.animateFloat(
        initialValue  = 0.9f,
        targetValue   = 1.1f,
        animationSpec = infiniteRepeatable(tween(600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label         = "tire_listen_scale"
    )
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue  = 0.12f,
        targetValue   = 0.40f,
        animationSpec = infiniteRepeatable(tween(600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label         = "tire_glow"
    )
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
    ) {
        Spacer(Modifier.height(DsSpacing.xxxl))
        Box(contentAlignment = Alignment.Center) {
            // Outer glow halo
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(NeonCyan.copy(alpha = glowAlpha * 0.5f), NeonCyan.copy(alpha = 0f))
                        ),
                        shape = CircleShape
                    )
            )
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .clip(CircleShape)
                    .background(NeonCyan.copy(alpha = glowAlpha))
            )
            FilledIconButton(
                onClick  = {},
                enabled  = false,
                modifier = Modifier.size(96.dp).scale(scale),
                colors   = IconButtonDefaults.filledIconButtonColors(
                    containerColor         = NeonCyan,
                    contentColor           = ScoutSlateDark,
                    disabledContainerColor = NeonCyan,
                    disabledContentColor   = ScoutSlateDark
                )
            ) {
                Icon(Icons.Default.GraphicEq, stringResource(R.string.cd_listening_indicator), modifier = Modifier.size(44.dp))
            }
        }
        Text(
            stringResource(R.string.voice_listening),
            style = MaterialTheme.typography.titleMedium,
            color = NeonCyan
        )
        LinearProgressIndicator(
            modifier = Modifier.width(160.dp).clip(RoundedCornerShape(DsRadius.pill)),
            color = NeonCyan,
            trackColor = GlowCyan20
        )
    }
}

// ── Processing phase ───────────────────────────────────────────────────────────

@Composable
private fun TireVoiceProcessingPhase() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
    ) {
        Spacer(Modifier.height(DsSpacing.xxxl))
        CircularProgressIndicator(modifier = Modifier.size(72.dp), strokeWidth = 4.dp, color = NeonMagenta)
        Text(
            stringResource(R.string.voice_processing),
            style = MaterialTheme.typography.titleMedium,
            color = NeonMagenta
        )
        Text(stringResource(R.string.tire_voice_processing_matching), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ── Saved phase ────────────────────────────────────────────────────────────────

@Composable
private fun TireVoiceSavedPhase(spotName: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "tire_saved_glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue  = 0.08f,
        targetValue   = 0.2f,
        animationSpec = infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label         = "tire_saved_glow_alpha"
    )
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }
    val scaleAnim by animateFloatAsState(
        targetValue   = if (visible) 1f else 0.5f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label         = "tire_saved_scale"
    )
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
    ) {
        Spacer(Modifier.height(DsSpacing.xxxl))
        Box(contentAlignment = Alignment.Center) {
            Box(modifier = Modifier.size(140.dp).scale(scaleAnim).clip(CircleShape).background(StatusGoodHaul.copy(alpha = glowAlpha)))
            FilledIconButton(
                onClick  = {},
                enabled  = false,
                modifier = Modifier.size(96.dp).scale(scaleAnim),
                colors   = IconButtonDefaults.filledIconButtonColors(
                    containerColor         = StatusGoodHaul,
                    contentColor           = ScoutSlateDark,
                    disabledContainerColor = StatusGoodHaul,
                    disabledContentColor   = ScoutSlateDark
                )
            ) {
                Icon(Icons.Default.Check, stringResource(R.string.cd_saved_indicator), modifier = Modifier.size(48.dp))
            }
        }
        Text(
            stringResource(R.string.voice_report_saved),
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
            color = ScoutGreenBright
        )
        if (spotName.isNotBlank()) {
            Text(
                stringResource(R.string.voice_logged_to, spotName),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// ── Confirmation/review panel ──────────────────────────────────────────────────

@Composable
private fun TireVoiceConfirmPanel(
    uiState: TireVoiceUiState,
    onTranscriptEdit: (String) -> Unit,
    onNotesEdit: (String) -> Unit,
    onSelectSpot: (TireSpot) -> Unit,
    onSave: () -> Unit,
    onDiscard: () -> Unit,
    onReSpeak: () -> Unit
) {
    val result = uiState.parseResult ?: return

    Card(
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier.padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                Icon(Icons.Default.Description, null, tint = TireTireShop, modifier = Modifier.size(20.dp))
                Text(stringResource(R.string.tire_voice_parsed_header), style = MaterialTheme.typography.titleSmall)
            }

            // Transcript edit
            OutlinedTextField(
                value         = uiState.editableTranscript,
                onValueChange = onTranscriptEdit,
                label         = { Text(stringResource(R.string.voice_transcript)) },
                modifier      = Modifier.fillMaxWidth(),
                minLines      = 2,
                shape         = MaterialTheme.shapes.medium,
                leadingIcon   = { Icon(Icons.Default.RecordVoiceOver, null, modifier = Modifier.size(18.dp)) }
            )

            // Parsed status chip
            result.status?.let { status ->
                Surface(
                    color  = ScoutSurface1.copy(alpha = 0.8f),
                    shape  = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(DsSpacing.m),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) {
                        Text(
                            stringResource(R.string.voice_detected_status_label),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        TireStatusChip(status = status)
                    }
                }
            }

            // Count + condition summary
            val summaryParts = buildList {
                if (result.estimatedCount > 0) add("~${result.estimatedCount} tires")
                if (result.somePunctured) add("mixed puncture")
                else if (result.arePunctured) add("punctured")
                else if (result.someUnpunctured) add("unpunctured")
                if (result.commonSizes.isNotBlank()) add(result.commonSizes)
                if (result.tireTypes.isNotBlank()) add(result.tireTypes)
            }
            if (summaryParts.isNotEmpty()) {
                Surface(
                    color  = TireTireShop.copy(alpha = 0.08f),
                    shape  = MaterialTheme.shapes.small,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        summaryParts.joinToString(" · "),
                        style    = MaterialTheme.typography.labelMedium,
                        color    = TireTireShop,
                        modifier = Modifier.padding(DsSpacing.m)
                    )
                }
            }

            // Matched spot
            if (uiState.matchedSpot != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors   = CardDefaults.cardColors(containerColor = TireTireShop.copy(alpha = 0.1f)),
                    shape    = MaterialTheme.shapes.medium
                ) {
                    Row {
                        Box(Modifier.width(4.dp).height(56.dp).background(TireTireShop))
                        Row(
                            modifier = Modifier.padding(DsSpacing.m).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                        ) {
                            Icon(Icons.Default.Place, null, modifier = Modifier.size(20.dp), tint = TireTireShop)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(uiState.matchedSpot.name, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    uiState.matchedSpot.category.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TireTireShop
                                )
                            }
                            val confColor = when {
                                result.confidence >= 0.8f -> ScoutGreenBright
                                result.confidence >= 0.5f -> ScoutAmberWarm
                                else                       -> StatusSecurity
                            }
                            Surface(
                                color = confColor.copy(alpha = 0.18f),
                                shape = MaterialTheme.shapes.small
                            ) {
                                Text(
                                    "%.0f%%".format(result.confidence * 100),
                                    style    = MaterialTheme.typography.labelMedium,
                                    color    = confColor,
                                    modifier = Modifier.padding(horizontal = DsSpacing.s, vertical = DsSpacing.xs)
                                )
                            }
                        }
                    }
                }
            } else {
                Surface(
                    color  = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f),
                    shape  = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(DsSpacing.m),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.HelpOutline, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                        Text(stringResource(R.string.voice_no_match), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                }
            }

            // Candidate spot selector
            if (uiState.candidateSpots.size > 1) {
                Text(stringResource(R.string.voice_select_different_spot), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                uiState.candidateSpots.forEach { candidate ->
                    val isSelected = candidate.id == uiState.matchedSpot?.id
                    OutlinedCard(
                        onClick  = { onSelectSpot(candidate) },
                        modifier = Modifier.fillMaxWidth(),
                        colors   = CardDefaults.outlinedCardColors(
                            containerColor = if (isSelected) TireTireShop.copy(alpha = 0.08f) else ScoutSurface2
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(DsSpacing.m),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                        ) {
                            Icon(Icons.Default.Place, null, tint = TireTireShop, modifier = Modifier.size(16.dp))
                            Text(candidate.name, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            if (isSelected) Icon(Icons.Default.CheckCircle, null, tint = TireTireShop, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            // Notes
            OutlinedTextField(
                value         = uiState.editableNotes,
                onValueChange = onNotesEdit,
                label         = { Text(stringResource(R.string.spot_notes)) },
                modifier      = Modifier.fillMaxWidth(),
                minLines      = 2,
                shape         = MaterialTheme.shapes.medium,
                leadingIcon   = { Icon(Icons.AutoMirrored.Filled.Notes, null, modifier = Modifier.size(18.dp)) }
            )

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                OutlinedButton(onClick = onDiscard, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Close, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(DsSpacing.xs))
                    Text(stringResource(R.string.voice_discard))
                }
                FilledTonalButton(onClick = onReSpeak, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Refresh, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(DsSpacing.xs))
                    Text(stringResource(R.string.voice_respeak))
                }
                Button(
                    onClick  = onSave,
                    enabled  = uiState.matchedSpot != null,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Save, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(DsSpacing.xs))
                    Text(stringResource(R.string.voice_save))
                }
            }
        }
    }
}

// ── Mic permission banner ──────────────────────────────────────────────────────

@Composable
private fun TireVoiceMicBanner(onRequest: () -> Unit) {
    Card(
        colors   = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(DsSpacing.m),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            Icon(Icons.Default.MicOff, null, tint = MaterialTheme.colorScheme.error)
            Text(
                stringResource(R.string.mic_permission_rationale),
                style    = MaterialTheme.typography.bodySmall,
                color    = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onRequest) { Text(stringResource(R.string.allow)) }
        }
    }
}

// ── Previews ───────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "TireVoice – IDLE dark")
@Composable
private fun TireVoiceIdlePreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Scaffold { padding ->
            Box(
                Modifier.fillMaxSize().padding(padding).background(Brush.verticalGradient(listOf(ScoutSurface1, ScoutSurface0))),
                contentAlignment = Alignment.Center
            ) {
                TireVoiceIdlePhase(micGranted = true, onTap = {})
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "TireVoice – SAVED dark")
@Composable
private fun TireVoiceSavedPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Scaffold { padding ->
            Box(
                Modifier.fillMaxSize().padding(padding).background(Brush.verticalGradient(listOf(ScoutSurface1, ScoutSurface0))),
                contentAlignment = Alignment.Center
            ) {
                TireVoiceSavedPhase(spotName = "Moline Tire on 5th")
            }
        }
    }
}
