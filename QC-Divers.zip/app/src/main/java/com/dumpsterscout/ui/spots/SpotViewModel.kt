package com.dumpsterscout.ui.spots

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.SpotCategory
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.Visibility
import com.dumpsterscout.domain.repository.ReportRepository
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SpotListUiState(
    val spots: List<DumpsterSpot> = emptyList(),
    val filteredSpots: List<DumpsterSpot> = emptyList(),
    val isLoading: Boolean = true,
    val searchQuery: String = "",
    val filterCategory: SpotCategory? = null,
    val filterStatus: SpotStatus? = null,
    val showFavoritesOnly: Boolean = false,
    val showFilters: Boolean = false,
    val error: String? = null
)

data class SpotDetailUiState(
    val spot: DumpsterSpot? = null,
    val reports: List<PersonalReport> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null,
    val showDeleteDialog: Boolean = false,
    val isDeleted: Boolean = false,
    /** True when the spot was just successfully published to the community layer. */
    val publishedSuccessfully: Boolean = false,
    /** True when the current user owns this spot (can publish/edit). */
    val isOwner: Boolean = false
)

data class AddSpotUiState(
    val spot: DumpsterSpot = DumpsterSpot(name = ""),
    val isLoading: Boolean = false,
    val isSaved: Boolean = false,
    val savedId: Long? = null,
    val error: String? = null
)

@HiltViewModel
class SpotViewModel @Inject constructor(
    private val spotRepository: SpotRepository,
    private val reportRepository: ReportRepository,
    private val userRepository: UserRepository
) : ViewModel() {

    // ── Spot List ──────────────────────────────────────────────────────────
    private val _listState = MutableStateFlow(SpotListUiState())
    val listState: StateFlow<SpotListUiState> = _listState.asStateFlow()

    // ── Spot Detail ────────────────────────────────────────────────────────
    private val _detailState = MutableStateFlow(SpotDetailUiState())
    val detailState: StateFlow<SpotDetailUiState> = _detailState.asStateFlow()

    // ── Favorites ──────────────────────────────────────────────────────────
    val favoriteSpots: StateFlow<List<DumpsterSpot>> = spotRepository.getFavoriteSpots()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    // ── Add/Edit Spot ──────────────────────────────────────────────────────
    private val _addState = MutableStateFlow(AddSpotUiState())
    val addState: StateFlow<AddSpotUiState> = _addState.asStateFlow()

    init {
        loadSpots()
    }

    private fun loadSpots() {
        viewModelScope.launch {
            try {
                spotRepository.getActiveSpots().collect { spots ->
                    _listState.update { state ->
                        val filtered = applyFilters(
                            spots, state.searchQuery, state.filterCategory,
                            state.filterStatus, state.showFavoritesOnly
                        )
                        state.copy(spots = spots, filteredSpots = filtered, isLoading = false)
                    }
                }
            } catch (e: Exception) {
                _listState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
    }

    fun onSearchQueryChange(query: String) {
        _listState.update { state ->
            val filtered = applyFilters(
                state.spots, query, state.filterCategory,
                state.filterStatus, state.showFavoritesOnly
            )
            state.copy(searchQuery = query, filteredSpots = filtered)
        }
    }

    fun onFilterCategoryChange(category: SpotCategory?) {
        _listState.update { state ->
            val filtered = applyFilters(
                state.spots, state.searchQuery, category,
                state.filterStatus, state.showFavoritesOnly
            )
            state.copy(filterCategory = category, filteredSpots = filtered)
        }
    }

    fun onFilterStatusChange(status: SpotStatus?) {
        _listState.update { state ->
            val filtered = applyFilters(
                state.spots, state.searchQuery, state.filterCategory,
                status, state.showFavoritesOnly
            )
            state.copy(filterStatus = status, filteredSpots = filtered)
        }
    }

    fun onShowFavoritesOnlyChange(show: Boolean) {
        _listState.update { state ->
            val filtered = applyFilters(
                state.spots, state.searchQuery, state.filterCategory,
                state.filterStatus, show
            )
            state.copy(showFavoritesOnly = show, filteredSpots = filtered)
        }
    }

    fun toggleFiltersVisible() {
        _listState.update { it.copy(showFilters = !it.showFilters) }
    }

    private fun applyFilters(
        spots: List<DumpsterSpot>,
        query: String,
        category: SpotCategory?,
        status: SpotStatus?,
        favoritesOnly: Boolean
    ): List<DumpsterSpot> {
        return spots.filter { spot ->
            (query.isBlank() || spot.name.contains(query, ignoreCase = true) ||
                    spot.address.contains(query, ignoreCase = true) ||
                    spot.tags.any { it.contains(query, ignoreCase = true) }) &&
                    (category == null || spot.category == category) &&
                    (status == null || spot.lastStatus == status) &&
                    (!favoritesOnly || spot.isFavorite)
        }
    }

    // ── Detail ─────────────────────────────────────────────────────────────
    fun loadSpotDetail(spotId: Long) {
        viewModelScope.launch {
            try {
                _detailState.update { it.copy(isLoading = true) }
                val spot = spotRepository.getSpotById(spotId)
                val localUserId = userRepository.getCurrentUser().first().localId
                val isOwner = spot != null && (spot.ownerUserId == null || spot.ownerUserId == localUserId)
                _detailState.update { it.copy(spot = spot, isOwner = isOwner, isLoading = false) }
            } catch (e: Exception) {
                _detailState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
        viewModelScope.launch {
            try {
                reportRepository.getReportsBySpot(spotId).collect { reports ->
                    _detailState.update { it.copy(reports = reports) }
                }
            } catch (e: Exception) {
                _detailState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
    }

    fun toggleFavorite(spotId: Long) {
        viewModelScope.launch {
            try {
                spotRepository.toggleFavorite(spotId)
            } catch (e: Exception) {
                _detailState.update { it.copy(error = e.message ?: "An unexpected error occurred") }
            }
        }
    }

    fun updateStatus(spotId: Long, status: SpotStatus) {
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                spotRepository.updateLastStatus(spotId, status, now)
                _detailState.update { state ->
                    state.copy(spot = state.spot?.copy(lastStatus = status, lastChecked = now))
                }
            } catch (e: Exception) {
                _detailState.update { it.copy(error = e.message ?: "An unexpected error occurred") }
            }
        }
    }

    fun retireSpot(spotId: Long) {
        viewModelScope.launch {
            try {
                spotRepository.retireSpot(spotId)
            } catch (e: Exception) {
                _detailState.update { it.copy(error = e.message ?: "An unexpected error occurred") }
            }
        }
    }

    fun showDeleteDialog(show: Boolean) {
        _detailState.update { it.copy(showDeleteDialog = show) }
    }

    fun clearDetailError() {
        _detailState.update { it.copy(error = null) }
    }

    fun publishSpot() {
        viewModelScope.launch {
            try {
                val spot = _detailState.value.spot ?: return@launch
                spotRepository.publishSpot(spot.id)
                _detailState.update { it.copy(publishedSuccessfully = true) }
            } catch (e: Exception) {
                _detailState.update { it.copy(error = e.message ?: "Failed to publish spot") }
            }
        }
    }

    fun clearPublishedFlag() {
        _detailState.update { it.copy(publishedSuccessfully = false) }
    }

    /** Re-queue a failed spot sync by re-saving it with PENDING_SYNC status. */
    fun retrySyncSpot() {
        viewModelScope.launch {
            try {
                val spot = _detailState.value.spot ?: return@launch
                // upsertSpot stamps PENDING_SYNC when credentials are configured
                spotRepository.upsertSpot(spot)
                // Reload so the chip reflects the new status
                loadSpotDetail(spot.id)
            } catch (e: Exception) {
                _detailState.update { it.copy(error = e.message ?: "Failed to queue retry") }
            }
        }
    }

    fun deleteSpot() {
        viewModelScope.launch {
            try {
                val spot = _detailState.value.spot ?: return@launch
                spotRepository.deleteSpot(spot)
                _detailState.update { it.copy(isDeleted = true) }
            } catch (e: Exception) {
                _detailState.update { it.copy(error = e.message ?: "An unexpected error occurred") }
            }
        }
    }

    // ── Add/Edit ───────────────────────────────────────────────────────────
    fun loadSpotForEdit(spotId: Long?) {
        if (spotId == null) {
            _addState.value = AddSpotUiState()
            return
        }
        viewModelScope.launch {
            try {
                _addState.update { it.copy(isLoading = true) }
                val spot = spotRepository.getSpotById(spotId)
                _addState.update { it.copy(spot = spot ?: DumpsterSpot(name = ""), isLoading = false) }
            } catch (e: Exception) {
                _addState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
    }

    fun updateSpotField(update: (DumpsterSpot) -> DumpsterSpot) {
        _addState.update { it.copy(spot = update(it.spot)) }
    }

    fun saveSpot() {
        viewModelScope.launch {
            try {
                _addState.update { it.copy(isLoading = true) }
                val id = spotRepository.upsertSpot(_addState.value.spot)
                _addState.update { it.copy(isLoading = false, isSaved = true, savedId = id) }
            } catch (e: Exception) {
                _addState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
    }

    fun clearSaved() {
        _addState.update { it.copy(isSaved = false, savedId = null) }
    }

    fun clearAddError() {
        _addState.update { it.copy(error = null) }
    }
}
