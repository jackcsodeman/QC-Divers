package com.dumpsterscout.ui.spots

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.SpotCategory
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.ui.components.*
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.DumpsterScoutTheme
import com.dumpsterscout.util.SampleData

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpotListScreen(
    onNavigateBack: () -> Unit,
    onNavigateToSpotDetail: (Long) -> Unit,
    onNavigateToAddSpot: () -> Unit,
    onNavigateToMap: () -> Unit,
    viewModel: SpotViewModel = hiltViewModel()
) {
    val uiState by viewModel.listState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.spots_count_title, uiState.filteredSpots.size),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                },
                actions = {
                    IconButton(onClick = viewModel::toggleFiltersVisible) {
                        Icon(
                            if (uiState.showFilters) Icons.Default.FilterListOff else Icons.Default.FilterList,
                            stringResource(R.string.cd_filter_toggle)
                        )
                    }
                    IconButton(onClick = onNavigateToMap) {
                        Icon(Icons.Default.Map, stringResource(R.string.cd_map_view))
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick        = onNavigateToAddSpot,
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor   = MaterialTheme.colorScheme.onPrimaryContainer
            ) {
                Icon(Icons.Default.Add, contentDescription = stringResource(R.string.cd_add_button))
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            // Search bar
            OutlinedTextField(
                value         = uiState.searchQuery,
                onValueChange = viewModel::onSearchQueryChange,
                modifier      = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = DsSpacing.l, vertical = DsSpacing.s),
                placeholder   = { Text(stringResource(R.string.search_spots)) },
                leadingIcon   = { Icon(Icons.Default.Search, null) },
                trailingIcon  = if (uiState.searchQuery.isNotEmpty()) {
                    { IconButton(onClick = { viewModel.onSearchQueryChange("") }) {
                        Icon(Icons.Default.Clear, stringResource(R.string.clear_search)) } }
                } else null,
                singleLine    = true,
                shape         = MaterialTheme.shapes.medium
            )

            // Collapsible filter row
            AnimatedVisibility(
                visible = uiState.showFilters,
                enter   = fadeIn() + expandVertically(),
                exit    = fadeOut() + shrinkVertically()
            ) {
                FilterRow(
                    filterCategory    = uiState.filterCategory,
                    filterStatus      = uiState.filterStatus,
                    showFavoritesOnly = uiState.showFavoritesOnly,
                    onCategoryChange  = viewModel::onFilterCategoryChange,
                    onStatusChange    = viewModel::onFilterStatusChange,
                    onFavoritesChange = viewModel::onShowFavoritesOnlyChange
                )
            }

            when {
                uiState.isLoading -> {
                    Column(
                        modifier = Modifier.padding(DsSpacing.l),
                        verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) { repeat(4) { LoadingShimmerCard() } }
                }
                uiState.filteredSpots.isEmpty() -> {
                    EmptyStatePanel(
                        message  = if (uiState.spots.isEmpty())
                            stringResource(R.string.no_spots_yet)
                        else
                            stringResource(R.string.no_spots_match),
                        icon     = if (uiState.spots.isEmpty())
                            Icons.Default.AddLocation
                        else
                            Icons.Default.SearchOff,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                else -> {
                    LazyColumn(
                        contentPadding      = PaddingValues(horizontal = DsSpacing.l, vertical = DsSpacing.s),
                        verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) {
                        items(uiState.filteredSpots, key = { it.id }) { spot ->
                            SpotCard(
                                spot             = spot,
                                onClick          = { onNavigateToSpotDetail(spot.id) },
                                onToggleFavorite = { viewModel.toggleFavorite(spot.id) }
                            )
                        }
                        item { Spacer(Modifier.height(DsSpacing.giant + DsSpacing.l)) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FilterRow(
    filterCategory: SpotCategory?,
    filterStatus: SpotStatus?,
    showFavoritesOnly: Boolean,
    onCategoryChange: (SpotCategory?) -> Unit,
    onStatusChange: (SpotStatus?) -> Unit,
    onFavoritesChange: (Boolean) -> Unit
) {
    var showCategoryMenu by remember { mutableStateOf(false) }
    var showStatusMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DsSpacing.l, vertical = DsSpacing.xs),
        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
    ) {
        FilterChip(
            selected  = showFavoritesOnly,
            onClick   = { onFavoritesChange(!showFavoritesOnly) },
            label     = { Text(stringResource(R.string.filter_favorites)) },
            leadingIcon = if (showFavoritesOnly) {
                { Icon(Icons.Default.Favorite, null, modifier = Modifier.size(16.dp)) }
            } else null
        )

        Box {
            FilterChip(
                selected = filterCategory != null,
                onClick  = { showCategoryMenu = true },
                label    = {
                    Text(
                        filterCategory?.name?.lowercase()?.replaceFirstChar { it.uppercaseChar() }
                            ?: stringResource(R.string.filter_category)
                    )
                }
            )
            DropdownMenu(expanded = showCategoryMenu, onDismissRequest = { showCategoryMenu = false }) {
                DropdownMenuItem(
                    text    = { Text(stringResource(R.string.filter_all_categories)) },
                    onClick = { onCategoryChange(null); showCategoryMenu = false }
                )
                SpotCategory.entries.forEach { cat ->
                    DropdownMenuItem(
                        text    = { Text(cat.name.lowercase().replaceFirstChar { it.uppercaseChar() }) },
                        onClick = { onCategoryChange(cat); showCategoryMenu = false }
                    )
                }
            }
        }

        Box {
            FilterChip(
                selected = filterStatus != null,
                onClick  = { showStatusMenu = true },
                label    = {
                    Text(
                        filterStatus?.name?.lowercase()?.replace('_', ' ')?.replaceFirstChar { it.uppercaseChar() }
                            ?: stringResource(R.string.filter_status)
                    )
                }
            )
            DropdownMenu(expanded = showStatusMenu, onDismissRequest = { showStatusMenu = false }) {
                DropdownMenuItem(
                    text    = { Text(stringResource(R.string.filter_all_statuses)) },
                    onClick = { onStatusChange(null); showStatusMenu = false }
                )
                listOf(SpotStatus.EMPTY, SpotStatus.FULL, SpotStatus.LOCKED, SpotStatus.GOOD_HAUL).forEach { st ->
                    DropdownMenuItem(
                        text    = { Text(st.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }) },
                        onClick = { onStatusChange(st); showStatusMenu = false }
                    )
                }
            }
        }
    }
}

// ── Previews ──────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "SpotList – filled (dark)")
@Composable
private fun SpotListFilledPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title = "Spots (3)",
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                contentPadding      = PaddingValues(horizontal = DsSpacing.l, vertical = DsSpacing.s),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.s),
                modifier            = Modifier.padding(padding)
            ) {
                items(SampleData.spots, key = { it.id }) { spot ->
                    SpotCard(spot = spot, onClick = {}, onToggleFavorite = {})
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, name = "SpotList – empty")
@Composable
private fun SpotListEmptyPreview() {
    DumpsterScoutTheme {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title = "Spots (0)",
                    navigationIcon = {
                        IconButton(onClick = {}) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                    }
                )
            }
        ) { padding ->
            EmptyStatePanel(
                message  = "No spots match your search.",
                icon     = Icons.Default.SearchOff,
                modifier = Modifier.fillMaxSize().padding(padding)
            )
        }
    }
}
