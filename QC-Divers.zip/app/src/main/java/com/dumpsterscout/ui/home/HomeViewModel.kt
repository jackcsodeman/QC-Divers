package com.dumpsterscout.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.data.local.dao.RoutePlanDao
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.PersonalReport
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.repository.ReportRepository
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.domain.repository.TireReportRepository
import com.dumpsterscout.domain.repository.TireSpotRepository
import com.dumpsterscout.util.SampleData
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val spots: List<DumpsterSpot> = emptyList(),
    val recentReports: List<PersonalReport> = emptyList(),
    val favoriteSpots: List<DumpsterSpot> = emptyList(),
    val isLoading: Boolean = true,
    val totalSpots: Int = 0,
    val totalReports: Int = 0,
    val activeTireSpots: Int = 0,
    val recentTireReports: List<TireReport> = emptyList(),
    val error: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val spotRepository: SpotRepository,
    private val reportRepository: ReportRepository,
    private val tireSpotRepository: TireSpotRepository,
    private val tireReportRepository: TireReportRepository,
    private val appPreferences: AppPreferences,
    private val routePlanDao: RoutePlanDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        seedDemoDataIfNeeded()
        observeData()
    }

    private fun observeData() {
        viewModelScope.launch {
            try {
                combine(
                    combine(
                        spotRepository.getActiveSpots(),
                        spotRepository.getFavoriteSpots(),
                        reportRepository.getRecentReports(10),
                        reportRepository.getReportCount(),
                        tireSpotRepository.getActiveSpots()
                    ) { spots, favorites, recentReports, totalReports, tireSpots ->
                        HomeUiState(
                            spots             = spots,
                            recentReports     = recentReports,
                            favoriteSpots     = favorites,
                            isLoading         = false,
                            totalSpots        = spots.size,
                            totalReports      = totalReports,
                            activeTireSpots   = tireSpots.size
                        )
                    },
                    tireReportRepository.getRecentReports(3)
                ) { state, tireReports ->
                    state.copy(recentTireReports = tireReports)
                }.collect { state ->
                    _uiState.value = state
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
    }

    private fun seedDemoDataIfNeeded() {
        viewModelScope.launch {
            try {
                val seeded = appPreferences.demoDataSeeded.first()
                if (!seeded) {
                    SampleData.spots.forEach { spot ->
                        spotRepository.upsertSpot(spot)
                    }
                    SampleData.reports.forEach { report ->
                        reportRepository.insertReport(report)
                    }
                    SampleData.tireSpots.forEach { spot ->
                        tireSpotRepository.upsertSpot(spot)
                    }
                    SampleData.tireReports.forEach { report ->
                        tireReportRepository.insertReport(report)
                    }
                    SampleData.routes.forEach { route ->
                        routePlanDao.insert(route)
                    }
                    appPreferences.setDemoDataSeeded(true)
                }
            } catch (_: Exception) {
                // Non-critical: demo seeding failure should not block the app
            }
        }
    }

    fun toggleFavorite(spotId: Long) {
        viewModelScope.launch {
            try {
                spotRepository.toggleFavorite(spotId)
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "An unexpected error occurred") }
            }
        }
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }
}
