package com.dumpsterscout.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.stringResource
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.SpotGrade
import com.dumpsterscout.ui.theme.*

/**
 * Grade summary card with animated progress bars.
 * Bars animate from 0 → target value when first displayed, providing visual
 * feedback that the scores have been freshly loaded / updated.
 */
@Composable
fun GradeCard(
    grade: SpotGrade,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(listOf(NeonCyan.copy(alpha = 0.35f), NeonMagenta.copy(alpha = 0.20f))),
                shape = MaterialTheme.shapes.medium
            ),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        shape = MaterialTheme.shapes.medium
    ) {
        // Neon accent header strip
        Box(
            Modifier
                .fillMaxWidth()
                .height(3.dp)
                .background(Brush.horizontalGradient(listOf(NeonCyan, NeonMagenta)))
        )
        Column(modifier = Modifier.padding(DsSpacing.l)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.grade_summary_title), style = MaterialTheme.typography.titleMedium)
                GradeScoreBadge(overall = grade.overall)
            }
            Spacer(Modifier.height(DsSpacing.m))

            // Positive metrics
            GradeRow(label = "Consistency", value = grade.consistency)
            GradeRow(label = "Quality",     value = grade.quality)
            GradeRow(label = "Quantity",    value = grade.quantity)
            GradeRow(label = "Cleanliness", value = grade.cleanliness)

            HorizontalDivider(modifier = Modifier.padding(vertical = DsSpacing.s))

            Text(
                "Risk factors",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(DsSpacing.xs))

            // Negative metrics (inverted color: low value = green)
            GradeRow(label = "Risk",       value = grade.risk,            inverted = true)
            GradeRow(label = "Access",     value = grade.accessDifficulty, inverted = true)
            GradeRow(label = "Legal",      value = grade.legalSensitivity, inverted = true)
        }
    }
}

@Composable
private fun GradeRow(
    label: String,
    value: Float,
    inverted: Boolean = false,
    modifier: Modifier = Modifier
) {
    val color = gradeColor(value, inverted)

    // Animate from 0 → actual value for a satisfying "fill" effect on first load.
    var triggered by remember { mutableStateOf(false) }
    LaunchedEffect(value) { triggered = true }
    val animatedProgress by animateFloatAsState(
        targetValue = if (triggered) (value / 10f).coerceIn(0f, 1f) else 0f,
        animationSpec = tween(durationMillis = DsMotion.slow, delayMillis = DsMotion.fast),
        label = "grade_progress_$label"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.width(96.dp)
        )
        LinearProgressIndicator(
            progress = { animatedProgress },
            modifier = Modifier
                .weight(1f)
                .height(7.dp),
            color = color,
            trackColor = GradeTrack
        )
        Spacer(Modifier.width(DsSpacing.s))
        Text(
            "%.1f".format(value),
            style = MaterialTheme.typography.labelSmall,
            color = color,
            modifier = Modifier.width(28.dp)
        )
    }
}

/** Numeric score → color, with optional inversion for risk-factor bars. */
fun gradeColor(value: Float, inverted: Boolean): Color = if (inverted) {
    if (value <= 3f) GradeHigh else if (value <= 6f) GradeMid else GradeLow
} else {
    if (value >= 7f) GradeHigh else if (value >= 4f) GradeMid else GradeLow
}

/**
 * Compact colored badge showing the overall score.
 * Exported so other components (e.g. [SpotCard]) can reuse it.
 */
@Composable
fun GradeScoreBadge(overall: Float, modifier: Modifier = Modifier) {
    val color = gradeColor(overall, inverted = false)
    Surface(
        color  = color.copy(alpha = 0.22f),
        shape  = MaterialTheme.shapes.small,
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.55f)),
        modifier = modifier
    ) {
        Text(
            text     = "%.1f".format(overall),
            style    = MaterialTheme.typography.titleSmall,
            color    = color,
            modifier = Modifier.padding(horizontal = DsSpacing.m, vertical = DsSpacing.xs)
        )
    }
}

// ── Previews ──────────────────────────────────────────────────────────────────

@Preview(showBackground = true, backgroundColor = 0xFF1A1C22)
@Composable
private fun GradeCardDarkPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        GradeCard(
            grade = SpotGrade(
                overall = 7.5f, consistency = 8f, quality = 7f, quantity = 8f,
                cleanliness = 6f, risk = 3f, accessDifficulty = 2f, legalSensitivity = 4f
            )
        )
    }
}

@Preview(showBackground = true)
@Composable
private fun GradeScoreBadgePreview() {
    DumpsterScoutTheme {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GradeScoreBadge(overall = 8.5f)
            GradeScoreBadge(overall = 5.0f)
            GradeScoreBadge(overall = 2.5f)
        }
    }
}
