package com.dumpsterscout.ui.account

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.AuthState
import com.dumpsterscout.domain.model.LocalUser
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountScreen(
    onNavigateBack: () -> Unit,
    viewModel: AccountViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    AccountScreenContent(
        uiState       = uiState,
        onNavigateBack = onNavigateBack,
        onEvent       = viewModel::onEvent
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun AccountScreenContent(
    uiState: AccountUiState,
    onNavigateBack: () -> Unit,
    onEvent: (AccountUiEvent) -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.error) {
        if (uiState.error != null) {
            snackbarHostState.showSnackbar(uiState.error!!)
            onEvent(AccountUiEvent.ClearError)
        }
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.account_title),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            stringResource(R.string.cd_navigate_back)
                        )
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = ScoutSurface0
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(DsSpacing.l)
        ) {
            when (uiState.authState) {
                AuthState.SIGNED_IN -> {
                    SignedInContent(
                        user    = uiState.user,
                        loading = uiState.isLoading,
                        onSignOut = { onEvent(AccountUiEvent.SignOut) }
                    )
                    Spacer(Modifier.height(DsSpacing.l))
                    SyncActiveCard()
                    Spacer(Modifier.height(DsSpacing.m))
                    SyncHowItWorksCard()
                }
                AuthState.SIGNED_OUT -> {
                    SignedOutContent(
                        otpSent = uiState.otpSent,
                        loading = uiState.isLoading,
                        onSendOtp   = { email -> onEvent(AccountUiEvent.SendOtp(email)) },
                        onVerifyOtp = { email, token -> onEvent(AccountUiEvent.VerifyOtp(email, token)) },
                        onResetOtp  = { onEvent(AccountUiEvent.ResetOtpSent) }
                    )
                    Spacer(Modifier.height(DsSpacing.l))
                    SyncBenefitsCard()
                }
                AuthState.LOADING -> {
                    Box(Modifier.fillMaxWidth().padding(DsSpacing.xl), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            Spacer(Modifier.height(DsSpacing.xl))
            LocalPrivacyCard()
        }
    }
}

// ── Signed-in ──────────────────────────────────────────────────────────────────

@Composable
private fun SignedInContent(
    user: LocalUser?,
    loading: Boolean,
    onSignOut: () -> Unit
) {
    Card(
        modifier  = Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card)
    ) {
        Column(
            modifier = Modifier.padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                Surface(
                    modifier = Modifier.size(48.dp),
                    shape    = MaterialTheme.shapes.large,
                    color    = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                ) {
                    Icon(
                        Icons.Default.Person,
                        contentDescription = null,
                        modifier = Modifier.padding(10.dp).fillMaxSize(),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Column {
                    Text(
                        text  = user?.displayName?.takeIf { it.isNotBlank() }
                            ?: stringResource(R.string.account_anonymous_display_name),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text  = stringResource(R.string.account_signed_in_label),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
            if (user?.remoteUserId != null) {
                Text(
                    text  = stringResource(R.string.account_uid_label, user.remoteUserId.take(8)),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            OutlinedButton(
                onClick  = onSignOut,
                enabled  = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (loading) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Default.Logout, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(DsSpacing.xs))
                    Text(stringResource(R.string.account_sign_out))
                }
            }
        }
    }
}

// ── Signed-out ─────────────────────────────────────────────────────────────────

@Composable
private fun SignedOutContent(
    otpSent: Boolean,
    loading: Boolean,
    onSendOtp: (String) -> Unit,
    onVerifyOtp: (String, String) -> Unit,
    onResetOtp: () -> Unit
) {
    if (!otpSent) {
        EmailInputCard(loading = loading, onSendOtp = onSendOtp)
    } else {
        OtpInputCard(loading = loading, onVerifyOtp = onVerifyOtp, onBack = onResetOtp)
    }
}

@Composable
private fun EmailInputCard(
    loading: Boolean,
    onSendOtp: (String) -> Unit
) {
    var email by remember { mutableStateOf("") }
    val keyboard = LocalSoftwareKeyboardController.current

    Card(
        modifier  = Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card)
    ) {
        Column(
            modifier = Modifier.padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                Icon(
                    Icons.Default.CloudQueue,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    stringResource(R.string.account_sign_in_title),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Text(
                text  = stringResource(R.string.account_sign_in_body),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedTextField(
                value         = email,
                onValueChange = { email = it },
                label         = { Text(stringResource(R.string.account_email_label)) },
                singleLine    = true,
                modifier      = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction    = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = {
                    keyboard?.hide()
                    if (email.isNotBlank()) onSendOtp(email.trim())
                }),
                leadingIcon = { Icon(Icons.Default.Email, null) }
            )
            Button(
                onClick  = { keyboard?.hide(); onSendOtp(email.trim()) },
                enabled  = email.isNotBlank() && !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (loading) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text(stringResource(R.string.account_send_code))
                }
            }
        }
    }
}

@Composable
private fun OtpInputCard(
    loading: Boolean,
    onVerifyOtp: (String, String) -> Unit,
    onBack: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current

    Card(
        modifier  = Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card)
    ) {
        Column(
            modifier = Modifier.padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                Icon(
                    Icons.Default.MarkEmailRead,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    stringResource(R.string.account_enter_code_title),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Text(
                text  = stringResource(R.string.account_enter_code_body),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedTextField(
                value         = email,
                onValueChange = { email = it },
                label         = { Text(stringResource(R.string.account_email_label)) },
                singleLine    = true,
                modifier      = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction    = ImeAction.Next
                ),
                leadingIcon = { Icon(Icons.Default.Email, null) }
            )
            OutlinedTextField(
                value         = token,
                onValueChange = { if (it.length <= 6) token = it },
                label         = { Text(stringResource(R.string.account_otp_label)) },
                singleLine    = true,
                modifier      = Modifier.fillMaxWidth().focusRequester(focusRequester),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction    = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = {
                    keyboard?.hide()
                    if (email.isNotBlank() && token.length == 6) onVerifyOtp(email.trim(), token)
                }),
                leadingIcon = { Icon(Icons.Default.Pin, null) }
            )
            Button(
                onClick  = { keyboard?.hide(); onVerifyOtp(email.trim(), token) },
                enabled  = email.isNotBlank() && token.length == 6 && !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (loading) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text(stringResource(R.string.account_verify_code))
                }
            }
            TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.account_back_to_email))
            }
        }
    }
}

// ── Sync active card (signed-in) ───────────────────────────────────────────────

@Composable
private fun SyncActiveCard() {
    Card(
        modifier  = Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card)
    ) {
        Row(
            modifier = Modifier.padding(DsSpacing.l),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            Icon(
                Icons.Default.CloudDone,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
            Text(
                text  = stringResource(R.string.account_sync_active_label),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

// ── How sync works card (signed-in) ────────────────────────────────────────────

@Composable
private fun SyncHowItWorksCard() {
    Card(
        modifier  = Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card)
    ) {
        Column(
            modifier = Modifier.padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            Text(
                text  = stringResource(R.string.account_sync_how_it_works_title),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text  = stringResource(R.string.account_sync_how_it_works_body),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// ── Sync benefits card (signed-out) ────────────────────────────────────────────

@Composable
private fun SyncBenefitsCard() {
    Card(
        modifier  = Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card)
    ) {
        Column(
            modifier = Modifier.padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                Icon(
                    Icons.Default.CloudQueue,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    stringResource(R.string.account_cloud_coming_title),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Text(
                text  = stringResource(R.string.account_cloud_coming_body),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            val features = listOf(
                R.string.account_feature_sync,
                R.string.account_feature_sharing,
                R.string.account_feature_ownership,
                R.string.account_feature_private
            )
            features.forEach { resId ->
                Row(
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                ) {
                    Text("•", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary)
                    Text(
                        text  = stringResource(resId),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

// ── Privacy / local-data card ──────────────────────────────────────────────────

@Composable
private fun LocalPrivacyCard() {
    Card(
        modifier  = Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card)
    ) {
        Column(
            modifier = Modifier.padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                Icon(
                    Icons.Default.Storage,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    stringResource(R.string.account_storage_section_title),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Text(
                text  = stringResource(R.string.account_storage_body),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// ── Previews ───────────────────────────────────────────────────────────────────

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "AccountScreen — signed out")
@Composable
private fun AccountScreenSignedOutPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        AccountScreenContent(
            uiState        = AccountUiState(authState = AuthState.SIGNED_OUT),
            onNavigateBack = {},
            onEvent        = {}
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "AccountScreen — signed in")
@Composable
private fun AccountScreenSignedInPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        AccountScreenContent(
            uiState        = AccountUiState(
                authState = AuthState.SIGNED_IN,
                user      = LocalUser(localId = "abc123", displayName = "Scout")
            ),
            onNavigateBack = {},
            onEvent        = {}
        )
    }
}

