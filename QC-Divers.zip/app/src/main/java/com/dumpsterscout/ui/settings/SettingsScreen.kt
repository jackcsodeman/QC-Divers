package com.dumpsterscout.ui.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.DumpsterScoutTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    onNavigateToAbout: () -> Unit = {},
    onNavigateToAccount: () -> Unit = {},
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Handle exported JSON — copy to clipboard
    LaunchedEffect(uiState.exportedJson) {
        uiState.exportedJson?.let { json ->
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText(context.getString(R.string.app_name), json))
            Toast.makeText(context, context.getString(R.string.exported_to_clipboard), Toast.LENGTH_SHORT).show()
            viewModel.clearExportResult()
        }
    }

    // Handle import result
    LaunchedEffect(uiState.importResult) {
        uiState.importResult?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearImportResult()
        }
    }

    // Handle preference save errors
    LaunchedEffect(uiState.prefError) {
        uiState.prefError?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearPrefError()
        }
    }

    // Clear data confirmation dialog
    if (uiState.showClearConfirm) {
        AlertDialog(
            onDismissRequest = viewModel::dismissClearConfirm,
            title    = { Text(stringResource(R.string.clear_all_data_title)) },
            text     = { Text(stringResource(R.string.clear_all_data_message)) },
            confirmButton = {
                TextButton(
                    onClick = viewModel::confirmClearData,
                    colors  = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.delete_everything)) }
            },
            dismissButton = {
                TextButton(onClick = viewModel::dismissClearConfirm) { Text(stringResource(R.string.cancel)) }
            }
        )
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.settings_title),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            SettingsGroup(stringResource(R.string.settings_group_appearance)) {
                ToggleSettingItem(
                    title         = stringResource(R.string.dark_theme),
                    icon          = Icons.Default.DarkMode,
                    checked       = uiState.darkTheme,
                    onCheckedChange = viewModel::setDarkTheme
                )
                ToggleSettingItem(
                    title         = stringResource(R.string.dynamic_color),
                    icon          = Icons.Default.Palette,
                    subtitle      = stringResource(R.string.dynamic_color_desc),
                    checked       = uiState.dynamicColor,
                    onCheckedChange = viewModel::setDynamicColor
                )
                ToggleSettingItem(
                    title         = stringResource(R.string.field_mode),
                    icon          = Icons.Default.FlashlightOn,
                    subtitle      = stringResource(R.string.field_mode_desc),
                    checked       = uiState.fieldMode,
                    onCheckedChange = viewModel::setFieldMode
                )
            }

            SettingsGroup(stringResource(R.string.settings_group_data)) {
                SettingsItem(
                    title   = stringResource(R.string.export_data),
                    icon    = Icons.Default.FileUpload,
                    onClick = viewModel::exportData
                )
                SettingsItem(
                    title   = stringResource(R.string.import_data),
                    icon    = Icons.Default.FileDownload,
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val text = clipboard.primaryClip?.getItemAt(0)?.text?.toString()
                        if (!text.isNullOrBlank()) viewModel.importData(text)
                        else Toast.makeText(context, context.getString(R.string.no_clipboard_data), Toast.LENGTH_SHORT).show()
                    }
                )
                SettingsItem(
                    title      = stringResource(R.string.clear_data),
                    icon       = Icons.Default.DeleteForever,
                    tintColor  = MaterialTheme.colorScheme.error,
                    onClick    = viewModel::requestClearData
                )
            }

            SettingsGroup(stringResource(R.string.about)) {
                SettingsItem(
                    title    = stringResource(R.string.settings_account_title),
                    icon     = Icons.Default.AccountCircle,
                    subtitle = stringResource(R.string.settings_account_subtitle),
                    onClick  = onNavigateToAccount
                )
                SettingsItem(
                    title    = stringResource(R.string.about_dumpster_scout),
                    icon     = Icons.Default.Info,
                    subtitle = stringResource(R.string.app_version_credit),
                    onClick  = onNavigateToAbout
                )
            }

            // Safety note
            Surface(
                color    = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f),
                shape    = MaterialTheme.shapes.medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(DsSpacing.l)
            ) {
                Row(
                    modifier  = Modifier.padding(DsSpacing.m),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                ) {
                    Icon(
                        Icons.Default.Warning, null,
                        tint     = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        stringResource(R.string.safety_disclaimer),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }

            Spacer(Modifier.height(DsSpacing.xxxl))
        }
    }
}

@Composable
private fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(
        title,
        style    = MaterialTheme.typography.labelSmall,
        color    = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(horizontal = DsSpacing.l, vertical = DsSpacing.s)
    )
    Column(content = content)
    HorizontalDivider(modifier = Modifier.padding(vertical = DsSpacing.xs))
}

@Composable
private fun ToggleSettingItem(
    title: String,
    icon: ImageVector,
    subtitle: String? = null,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier  = Modifier
            .fillMaxWidth()
            .padding(horizontal = DsSpacing.l, vertical = DsSpacing.m),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(DsSpacing.l)
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            subtitle?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SettingsItem(
    title: String,
    icon: ImageVector,
    subtitle: String? = null,
    tintColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    onClick: () -> Unit
) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier  = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.l)
        ) {
            Icon(icon, null, tint = tintColor)
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyLarge, color = tintColor)
                subtitle?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ── Previews ──────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "Settings dark")
@Composable
private fun SettingsDarkPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title = "Settings",
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Navigate back")
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                SettingsGroup("Appearance") {
                    ToggleSettingItem(title = "Dark Theme", icon = Icons.Default.DarkMode, checked = true, onCheckedChange = {})
                    ToggleSettingItem(title = "Dynamic Color", icon = Icons.Default.Palette, subtitle = "Material You color from wallpaper (Android 12+)", checked = false, onCheckedChange = {})
                    ToggleSettingItem(title = "Field Mode", icon = Icons.Default.FlashlightOn, subtitle = "Larger controls, night-friendly display", checked = false, onCheckedChange = {})
                }
                SettingsGroup("Data") {
                    SettingsItem(title = "Export Data", icon = Icons.Default.FileUpload, onClick = {})
                    SettingsItem(title = "Import Data", icon = Icons.Default.FileDownload, onClick = {})
                    SettingsItem(title = "Clear All Data", icon = Icons.Default.DeleteForever, tintColor = MaterialTheme.colorScheme.error, onClick = {})
                }
                SettingsGroup("About") {
                    SettingsItem(title = "About Dumpster Scout", icon = Icons.Default.Info, subtitle = "v1.0.0-beta · Jack Sodeman-Dickey", onClick = {})
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, name = "Settings light")
@Composable
private fun SettingsLightPreview() {
    DumpsterScoutTheme(darkTheme = false) {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title = "Settings",
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Navigate back")
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                SettingsGroup("Appearance") {
                    ToggleSettingItem(title = "Dark Theme", icon = Icons.Default.DarkMode, checked = false, onCheckedChange = {})
                    ToggleSettingItem(title = "Field Mode", icon = Icons.Default.FlashlightOn, subtitle = "Larger controls, night-friendly display", checked = false, onCheckedChange = {})
                }
                SettingsGroup("Data") {
                    SettingsItem(title = "Export Data", icon = Icons.Default.FileUpload, onClick = {})
                }
            }
        }
    }
}