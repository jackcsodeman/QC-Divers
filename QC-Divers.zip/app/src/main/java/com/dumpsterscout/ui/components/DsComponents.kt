package com.dumpsterscout.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HistoryToggleOff
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.ui.theme.*

// ─────────────────────────────────────────────────────────────────────────────
// Dumpster Scout — Shared UI Component Library
//
// All reusable, product-specific composables that don't belong to a single
// feature screen.  Import from here rather than duplicating across screens.
// ─────────────────────────────────────────────────────────────────────────────

// ── DumpsterScoutTopBar ───────────────────────────────────────────────────────

/**
 * Standard app top bar with optional subtitle, navigation icon, and actions.
 * Uses [ScoutSurface1] as the container background for the neon cyber-dark identity.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DumpsterScoutTopBar(
    title: String,
    subtitle: String? = null,
    navigationIcon: @Composable (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
    scrollBehavior: TopAppBarScrollBehavior? = null,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        TopAppBar(
            title = {
                Column {
                    Text(
                        title,
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (subtitle != null) {
                        Text(
                            subtitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            },
            navigationIcon = { navigationIcon?.invoke() },
            actions = actions,
            scrollBehavior = scrollBehavior,
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor          = ScoutSurface1,
                scrolledContainerColor  = MaterialTheme.colorScheme.surfaceVariant,
                titleContentColor       = MaterialTheme.colorScheme.onSurface,
                actionIconContentColor  = MaterialTheme.colorScheme.onSurfaceVariant
            )
        )
        HorizontalDivider(
            color     = NeonCyan.copy(alpha = 0.15f),
            thickness = 1.dp
        )
    }
}

// ── SectionHeader ─────────────────────────────────────────────────────────────

/**
 * Labeled section header with an optional "See all" action button.
 * Matches the visual rhythm of the home dashboard sections.
 */
@Composable
fun SectionHeader(
    title: String,
    onSeeAll: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            onSeeAll?.let {
                TextButton(onClick = it, contentPadding = PaddingValues(horizontal = DsSpacing.s)) {
                    Text(stringResource(R.string.action_see_all), style = MaterialTheme.typography.labelLarge)
                }
            }
        }
        HorizontalDivider(
            color     = MaterialTheme.colorScheme.primary.copy(alpha = 0.20f),
            thickness = 1.dp,
            modifier  = Modifier.padding(top = 2.dp)
        )
    }
}

// ── DetailCard ────────────────────────────────────────────────────────────────

/**
 * Titled card used to group related fields on detail screens.
 * Provides consistent inset padding and title treatment.
 */
@Composable
fun DetailCard(
    title: String,
    modifier: Modifier = Modifier,
    accentColor: Color? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape = MaterialTheme.shapes.medium
    ) {
        Column {
            // Optional top accent strip
            if (accentColor != null) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .background(accentColor)
                )
            }
            Column(modifier = Modifier.padding(DsSpacing.l)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(DsSpacing.s))
                content()
            }
        }
    }
}

// ── InfoRow ───────────────────────────────────────────────────────────────────

/** Compact label → value row used inside [DetailCard]. */
@Composable
fun InfoRow(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            "$label:",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(88.dp)
        )
        Text(
            value,
            style = MaterialTheme.typography.bodySmall,
            color = valueColor,
            modifier = Modifier.weight(1f)
        )
    }
}

// ── ConditionTag ──────────────────────────────────────────────────────────────

/**
 * Small filled badge used for access / condition attributes such as "Fenced",
 * "Locked", "Cameras".  [isWarning] tints it with the error color scheme.
 */
@Composable
fun ConditionTag(
    label: String,
    isWarning: Boolean = false,
    modifier: Modifier = Modifier
) {
    val container = if (isWarning) MaterialTheme.colorScheme.errorContainer
                    else MaterialTheme.colorScheme.secondaryContainer
    val content   = if (isWarning) MaterialTheme.colorScheme.onErrorContainer
                    else MaterialTheme.colorScheme.onSecondaryContainer

    Surface(
        color    = container,
        shape    = RoundedCornerShape(DsRadius.chip),
        modifier = modifier
    ) {
        Text(
            label,
            style    = MaterialTheme.typography.labelSmall,
            color    = content,
            modifier = Modifier.padding(horizontal = DsSpacing.s, vertical = DsSpacing.xs)
        )
    }
}

// ── FilterChipGroup ───────────────────────────────────────────────────────────

/**
 * Horizontal scrollable row of [FilterChip]s.
 * [options] is a list of (label, isSelected) pairs.
 */
@Composable
fun FilterChipGroup(
    options: List<Pair<String, Boolean>>,
    onSelect: (index: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
    ) {
        options.forEachIndexed { index, (label, selected) ->
            FilterChip(
                selected = selected,
                onClick  = { onSelect(index) },
                label    = { Text(label, style = MaterialTheme.typography.labelLarge) },
                colors   = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    selectedLabelColor     = MaterialTheme.colorScheme.primary
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled            = true,
                    selected           = selected,
                    selectedBorderColor = NeonCyan.copy(alpha = 0.6f),
                    borderColor        = MaterialTheme.colorScheme.outline
                )
            )
        }
    }
}

// ── EmptyStatePanel ───────────────────────────────────────────────────────────

/**
 * Full-width empty-state panel with an icon, headline, and supporting message.
 * Replaces simple "no data" text cards with something more intentional.
 */
@Composable
fun EmptyStatePanel(
    message: String,
    icon: ImageVector = Icons.Default.Inbox,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.radialGradient(
                    colors = listOf(GlowCyan12, Color.Transparent),
                    radius = DsNeonRadius.hero
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(DsSpacing.xxxl),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            Icon(
                icon,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
            )
            Text(
                message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

// ── ErrorStatePanel ───────────────────────────────────────────────────────────

/** Error panel shown when a data-load fails. */
@Composable
fun ErrorStatePanel(
    message: String,
    onRetry: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(DsSpacing.xxxl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
    ) {
        Icon(
            Icons.Default.WifiOff,
            contentDescription = null,
            modifier = Modifier.size(48.dp),
            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f)
        )
        Text(
            message,
            style  = MaterialTheme.typography.bodyMedium,
            color  = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        onRetry?.let {
            OutlinedButton(onClick = it) { Text(stringResource(R.string.action_retry)) }
        }
    }
}

// ── LoadingShimmerCard ────────────────────────────────────────────────────────

/**
 * Skeleton placeholder card that shimmer-animates while data loads.
 * Drop one or more of these into a [LazyColumn] while [isLoading] is true.
 */
@Composable
fun LoadingShimmerCard(
    modifier: Modifier = Modifier,
    lineCount: Int = 2
) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val shimmerX by transition.animateFloat(
        initialValue = -400f,
        targetValue  = 400f,
        animationSpec = infiniteRepeatable(
            animation  = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_x"
    )

    val shimmerBrush = Brush.linearGradient(
        colors = listOf(
            MaterialTheme.colorScheme.surfaceVariant,
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            MaterialTheme.colorScheme.surfaceVariant
        ),
        start = Offset(shimmerX, 0f),
        end   = Offset(shimmerX + 400f, 0f)
    )

    Card(
        modifier = modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2)
    ) {
        Column(modifier = Modifier.padding(DsSpacing.l), verticalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
            // Title shimmer line
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.6f)
                    .height(16.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(shimmerBrush)
            )
            repeat(lineCount) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(if (it == lineCount - 1) 0.45f else 1f)
                        .height(12.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(shimmerBrush)
                )
            }
        }
    }
}

// ── FloatingActionCluster ─────────────────────────────────────────────────────

/**
 * Stacked pair of FABs: a large primary action (voice/mic) above a standard
 * secondary action (add).  Used on the Home screen and Spot List screen.
 */
@Composable
fun FloatingActionCluster(
    onPrimaryClick: () -> Unit,
    onSecondaryClick: () -> Unit,
    primaryIcon: ImageVector = Icons.Default.Mic,
    secondaryIcon: ImageVector = Icons.Default.Add,
    primaryContentDescription: String = "Primary action",
    secondaryContentDescription: String = "Secondary action",
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
    ) {
        FloatingActionButton(
            onClick          = onPrimaryClick,
            modifier         = Modifier.size(72.dp),
            containerColor   = MaterialTheme.colorScheme.secondary,
            contentColor     = MaterialTheme.colorScheme.onSecondary,
            elevation        = FloatingActionButtonDefaults.elevation(defaultElevation = DsElevation.floating)
        ) {
            Icon(primaryIcon, contentDescription = primaryContentDescription, modifier = Modifier.size(32.dp))
        }
        FloatingActionButton(
            onClick          = onSecondaryClick,
            containerColor   = MaterialTheme.colorScheme.primaryContainer,
            contentColor     = MaterialTheme.colorScheme.onPrimaryContainer,
            elevation        = FloatingActionButtonDefaults.elevation(defaultElevation = DsElevation.floating)
        ) {
            Icon(secondaryIcon, contentDescription = secondaryContentDescription)
        }
    }
}

// ── HeroBanner ────────────────────────────────────────────────────────────────

/**
 * Home-screen hero area with:
 *  - Time-of-day greeting
 *  - Primary green/amber diagonal gradient + radial accent glow
 *  - Three stat columns: spots, reports, favorites
 */
@Composable
fun HeroBanner(
    totalSpots: Int,
    totalReports: Int,
    favoriteCount: Int = 0,
    tireSpotsCount: Int = 0,
    modifier: Modifier = Modifier
) {
    val greeting = remember {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        when {
            hour < 5  -> "Night diving? 🌙"
            hour < 12 -> "Morning run 🌤"
            hour < 17 -> "Afternoon sweep ☀️"
            hour < 21 -> "Evening round 🌆"
            else      -> "Late night diving 🌃"
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.extraLarge)
            .background(HeroNeonGradient)
    ) {
        // Radial magenta glow in bottom-right corner
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            ScoutAmberWarm.copy(alpha = 0.10f),
                            Color.Transparent
                        ),
                        center = androidx.compose.ui.geometry.Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY),
                        radius = 500f
                    )
                )
        )
        // Cyan glow in top-left
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            ScoutGreenBright.copy(alpha = 0.12f),
                            Color.Transparent
                        ),
                        center = androidx.compose.ui.geometry.Offset(0f, 0f),
                        radius = 400f
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            // Greeting line
            Text(
                greeting,
                style = MaterialTheme.typography.labelLarge,
                color = ScoutOnSurfaceDim
            )
            // App wordmark / sub-title line
            Text(
                stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineSmall,
                color = ScoutOnSurface
            )

            Spacer(Modifier.height(DsSpacing.xs))

            // Stats row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                HeroStat(
                    value = totalSpots.toString(),
                    label = stringResource(R.string.hero_stat_spots),
                    accentColor = ScoutGreenBright
                )
                HeroStatDivider()
                HeroStat(
                    value = totalReports.toString(),
                    label = stringResource(R.string.hero_stat_reports),
                    accentColor = ScoutAmberWarm
                )
                if (tireSpotsCount > 0) {
                    HeroStatDivider()
                    HeroStat(
                        value = tireSpotsCount.toString(),
                        label = stringResource(R.string.hero_stat_tire_spots),
                        accentColor = TireTireShop
                    )
                }
                if (favoriteCount > 0) {
                    HeroStatDivider()
                    HeroStat(
                        value = favoriteCount.toString(),
                        label = stringResource(R.string.hero_stat_favorites),
                        accentColor = CategoryPharmacy
                    )
                }
            }
        }
    }
}

@Composable
private fun HeroStat(value: String, label: String, accentColor: Color = MaterialTheme.colorScheme.primary) {
    // Animate the number count-up from 0 to target
    val targetInt = value.toIntOrNull() ?: 0
    val animatedInt by animateIntAsState(
        targetValue   = targetInt,
        animationSpec = tween(durationMillis = DsMotion.slow + DsMotion.medium, easing = DsEasing.emphasizedDecelerate),
        label         = "hero_stat_$label"
    )
    val displayValue = if (targetInt > 0) animatedInt.toString() else value

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            displayValue,
            style = MaterialTheme.typography.displaySmall,
            color = accentColor
        )
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun HeroStatDivider() {
    VerticalDivider(
        modifier  = Modifier.height(48.dp).padding(horizontal = DsSpacing.m),
        color     = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.18f)
    )
}

// ── RiskBanner ────────────────────────────────────────────────────────────────

/**
 * Prominent warning banner shown at the top of a spot's detail page when
 * security, lock, or camera hazards are flagged.  Uses [DsElevation.subtle] so
 * it sits lightly above the page background rather than dominating.
 */
@Composable
fun RiskBanner(
    risks: List<String>,
    modifier: Modifier = Modifier
) {
    if (risks.isEmpty()) return
    val riskText = risks.joinToString(" · ")

    Surface(
        color    = MaterialTheme.colorScheme.surfaceVariant,
        shape    = MaterialTheme.shapes.medium,
        modifier = modifier.fillMaxWidth()
    ) {
        Row {
            // Neon error-colored left strip
            Box(
                Modifier
                    .width(3.dp)
                    .heightIn(min = 40.dp)
                    .background(MaterialTheme.colorScheme.error)
            )
            Row(
                modifier = Modifier.padding(horizontal = DsSpacing.l, vertical = DsSpacing.m),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                Icon(
                    Icons.Default.Warning,
                    contentDescription = null,
                    tint     = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    riskText,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

// ── VisitTimingHint ────────────────────────────────────────────────────────────

/**
 * Compact timing hint used below the quick-action grid.
 * Shows the next pickup day and last-checked time in a tonal chip-style row.
 */
@Composable
fun VisitTimingHint(
    pickupDays: String,
    bestTimeLabel: String,
    lastCheckedLabel: String?,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
    ) {
        if (pickupDays.isNotBlank()) {
            TimingPill(
                icon  = Icons.Default.CalendarToday,
                label = pickupDays,
                color = ScoutAmberWarm
            )
        }
        if (bestTimeLabel.isNotBlank()) {
            TimingPill(
                icon  = Icons.Default.Schedule,
                label = bestTimeLabel,
                color = CategoryPharmacy
            )
        }
        lastCheckedLabel?.let {
            TimingPill(
                icon  = Icons.Default.HistoryToggleOff,
                label = it,
                color = ScoutOnSurfaceDim
            )
        }
    }
}

@Composable
private fun TimingPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    color: Color
) {
    Surface(
        color    = color.copy(alpha = 0.14f),
        shape    = MaterialTheme.shapes.small,
        modifier = Modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = DsSpacing.s, vertical = DsSpacing.xs),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(12.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = color)
        }
    }
}

// ── SpotStatChip ──────────────────────────────────────────────────────────────

/**
 * Compact tonal inline stat: icon + value + label.
 * Used in the spot detail header for fast-scan metrics.
 */
@Composable
fun SpotStatChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: String,
    label: String,
    color: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier
) {
    Surface(
        color    = color.copy(alpha = 0.12f),
        shape    = MaterialTheme.shapes.medium,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = DsSpacing.m, vertical = DsSpacing.s),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(DsSpacing.xs)
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(18.dp))
            Text(value, style = MaterialTheme.typography.labelLarge, color = color)
            Text(label, style = MaterialTheme.typography.labelSmall, color = color.copy(alpha = 0.7f))
        }
    }
}

// ── CandidateSpotCard ─────────────────────────────────────────────────────────

/**
 * Rich clickable card for selecting an alternative spot match in the voice
 * confirmation panel.  Shows the spot name, category color strip, and
 * confidence percentage.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CandidateSpotCard(
    spotName: String,
    category: com.dumpsterscout.domain.model.SpotCategory,
    confidence: Float,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = com.dumpsterscout.ui.components.categoryColor(category)
    Card(
        onClick   = onClick,
        modifier  = modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(
            containerColor = if (isSelected) accent.copy(alpha = 0.15f)
                             else MaterialTheme.colorScheme.surfaceVariant
        ),
        border    = if (isSelected) CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.5f)))
        ) else null,
        shape     = MaterialTheme.shapes.medium
    ) {
        Row {
            // Left accent strip
            Box(
                Modifier
                    .width(4.dp)
                    .heightIn(min = 56.dp)
                    .background(accent)
            )
            Row(
                modifier = Modifier
                    .padding(horizontal = DsSpacing.m, vertical = DsSpacing.s)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(spotName, style = MaterialTheme.typography.bodyMedium)
                    Text(
                        category.name.lowercase().replaceFirstChar { it.uppercaseChar() },
                        style = MaterialTheme.typography.labelSmall,
                        color = accent
                    )
                }
                // Confidence badge
                Surface(
                    color = (if (confidence >= 0.7f) GradeHigh else if (confidence >= 0.4f) GradeMid else GradeLow)
                        .copy(alpha = 0.2f),
                    shape = MaterialTheme.shapes.small
                ) {
                    Text(
                        "%.0f%%".format(confidence * 100),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (confidence >= 0.7f) GradeHigh else if (confidence >= 0.4f) GradeMid else GradeLow,
                        modifier = Modifier.padding(horizontal = DsSpacing.s, vertical = DsSpacing.xs)
                    )
                }
                if (isSelected) {
                    Icon(
                        Icons.Default.CheckCircle,
                        null,
                        tint     = accent,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

// ── QuickActionButton ─────────────────────────────────────────────────────────

/**
 * Compact tonal icon+label button for the quick-action grid on the home screen.
 */
@Composable
fun QuickActionButton(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    containerColor: Color = MaterialTheme.colorScheme.secondaryContainer,
    contentColor: Color = MaterialTheme.colorScheme.onSecondaryContainer,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick      = onClick,
        color        = containerColor,
        shape        = MaterialTheme.shapes.medium,
        tonalElevation = DsElevation.card,
        modifier     = modifier
    ) {
        Column(
            modifier = Modifier.padding(DsSpacing.m),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(DsSpacing.xs)
        ) {
            Icon(icon, contentDescription = label, tint = contentColor, modifier = Modifier.size(24.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = contentColor)
        }
    }
}

// ── DsNavigationBar ───────────────────────────────────────────────────────────

/**
 * Branded bottom navigation bar with custom active indicator treatment.
 * Uses the Scout Green primary for selected items and consistent styling.
 */
@Composable
fun DsNavigationBar(
    selectedIndex: Int,
    onItemClick: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val items = listOf(
        Triple(Icons.Default.Home, stringResource(R.string.nav_home), stringResource(R.string.cd_nav_home)),
        Triple(Icons.Filled.Place, stringResource(R.string.nav_spots), stringResource(R.string.cd_nav_spots)),
        Triple(Icons.Default.Map, stringResource(R.string.nav_map), stringResource(R.string.cd_nav_map)),
        Triple(Icons.Default.History, stringResource(R.string.nav_log), stringResource(R.string.cd_nav_log))
    )

    NavigationBar(
        modifier       = modifier,
        containerColor = ScoutSurface0,
        tonalElevation = DsElevation.card
    ) {
        items.forEachIndexed { index, (icon, label, cd) ->
            val isSelected = index == selectedIndex
            NavigationBarItem(
                selected = isSelected,
                onClick  = { if (!isSelected) onItemClick(index) },
                icon     = {
                    Icon(
                        icon,
                        contentDescription = cd,
                        modifier = Modifier.size(if (isSelected) 26.dp else 24.dp)
                    )
                },
                label    = {
                    Text(
                        label,
                        style = if (isSelected) MaterialTheme.typography.labelMedium
                                else MaterialTheme.typography.labelSmall
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor   = MaterialTheme.colorScheme.primary,
                    selectedTextColor   = MaterialTheme.colorScheme.primary,
                    indicatorColor      = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.90f),
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}

// ── DsSegmentedToggle ─────────────────────────────────────────────────────────

/**
 * Two-option segmented toggle used for map/list view switching.
 * The selected option gets a tonal filled background.
 */
@Composable
fun DsSegmentedToggle(
    options: List<Pair<ImageVector, String>>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        shape = RoundedCornerShape(DsRadius.pill),
        modifier = modifier
    ) {
        Row(modifier = Modifier.padding(2.dp)) {
            options.forEachIndexed { index, (icon, label) ->
                val isSelected = index == selectedIndex
                Surface(
                    onClick = { onSelect(index) },
                    color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                            else Color.Transparent,
                    shape = RoundedCornerShape(DsRadius.pill),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = DsSpacing.m, vertical = DsSpacing.s),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            icon,
                            contentDescription = label,
                            tint = if (isSelected) MaterialTheme.colorScheme.primary
                                   else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(DsSpacing.xs))
                        Text(
                            label,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isSelected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

// ── HistoryEventCard ──────────────────────────────────────────────────────────

/**
 * Richer history event card with a source indicator dot, accent-colored left
 * strip, and condition flag chips for better visual scanning.
 */
@Composable
fun HistoryEventCard(
    spotName: String,
    status: SpotStatus,
    isVoice: Boolean,
    timestamp: String,
    notes: String = "",
    flags: List<String> = emptyList(),
    onClick: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (_, statusColor) = statusDisplay(status)

    Card(
        onClick   = onClick,
        modifier  = modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.subtle),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.medium
    ) {
        Row {
            // Status-colored accent strip
            Box(
                Modifier
                    .width(3.dp)
                    .heightIn(min = 64.dp)
                    .background(statusColor)
            )
            Column(modifier = Modifier.padding(DsSpacing.m).weight(1f)) {
                Row(
                    verticalAlignment      = Alignment.CenterVertically,
                    horizontalArrangement  = Arrangement.spacedBy(DsSpacing.s),
                    modifier               = Modifier.fillMaxWidth()
                ) {
                    // Source indicator
                    Surface(
                        color = if (isVoice) ScoutAmberWarm.copy(alpha = 0.15f)
                                else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        shape = CircleShape,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                            Icon(
                                if (isVoice) Icons.Default.Mic else Icons.Default.Edit,
                                null,
                                modifier = Modifier.size(13.dp),
                                tint = if (isVoice) ScoutAmberWarm else MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Text(
                        spotName,
                        style    = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        timestamp,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(Modifier.height(DsSpacing.xs))
                StatusChip(status = status)

                if (notes.isNotBlank()) {
                    Spacer(Modifier.height(DsSpacing.xs))
                    Text(
                        notes,
                        style    = MaterialTheme.typography.bodySmall,
                        color    = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (flags.isNotEmpty()) {
                    Spacer(Modifier.height(DsSpacing.xs))
                    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)) {
                        flags.take(4).forEach { flag ->
                            ConditionTag(
                                label = flag,
                                isWarning = flag in listOf("Security", "Too late", "Rain damage")
                            )
                        }
                    }
                }
            }
        }
    }
}

// ── DeleteConfirmDialog ───────────────────────────────────────────────────────

/**
 * Reusable destructive-action confirmation dialog.
 * Shows the item name and uses error-colored confirm button.
 */
@Composable
fun DeleteConfirmDialog(
    title: String = "Delete?",
    message: String = "This action cannot be undone.",
    confirmLabel: String = "Delete",
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text  = { Text(message) },
        confirmButton = {
            TextButton(
                onClick = onConfirm,
                colors  = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) { Text(confirmLabel) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    )
}

// ── DsSearchField ─────────────────────────────────────────────────────────────

/**
 * Standard search text field with leading search icon and trailing clear button.
 * Used on SpotList, History, and other search-enabled screens.
 */
@Composable
fun DsSearchField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String = "Search…",
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value         = value,
        onValueChange = onValueChange,
        modifier      = modifier.fillMaxWidth(),
        placeholder   = { Text(placeholder) },
        leadingIcon   = { Icon(Icons.Default.Search, contentDescription = stringResource(R.string.search_label)) },
        trailingIcon  = if (value.isNotEmpty()) {
            {
                IconButton(onClick = { onValueChange("") }) {
                    Icon(Icons.Default.Clear, contentDescription = stringResource(R.string.clear_search))
                }
            }
        } else null,
        singleLine = true,
        shape      = MaterialTheme.shapes.medium
    )
}

// ── Previews ──────────────────────────────────────────────────────────────────

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "HeroBanner dark")
@Composable
private fun HeroBannerPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        HeroBanner(totalSpots = 6, totalReports = 9, tireSpotsCount = 5, favoriteCount = 3)
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "LoadingShimmer dark")
@Composable
private fun LoadingShimmerPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(16.dp)) {
            LoadingShimmerCard()
            LoadingShimmerCard(lineCount = 1)
        }
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "EmptyState dark")
@Composable
private fun EmptyStatePanelPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        EmptyStatePanel(
            message = "No spots saved yet. Tap + to add your first spot.",
            icon = Icons.Default.SearchOff
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "DetailCard dark")
@Composable
private fun DetailCardPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        DetailCard(title = "Access", accentColor = CategoryGrocery) {
            InfoRow(label = "Days",     value = "Mon, Thu")
            InfoRow(label = "Time",     value = "6:00–8:00 AM")
            ConditionTag(label = "Fenced")
            ConditionTag(label = "Locked", isWarning = true)
        }
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "FilterChipGroup dark")
@Composable
private fun FilterChipGroupPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        FilterChipGroup(
            options = listOf("All" to true, "Today" to false, "This Week" to false),
            onSelect = {},
            modifier = Modifier.padding(16.dp)
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "QuickActions dark")
@Composable
private fun QuickActionButtonPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickActionButton(
                label = "Voice",
                icon = Icons.Default.Mic,
                onClick = {},
                containerColor = ScoutAmberDark.copy(alpha = 0.25f),
                contentColor = ScoutAmberLight
            )
            QuickActionButton(
                label = "Browse",
                icon = Icons.Default.GridView,
                onClick = {}
            )
        }
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "DsNavigationBar dark")
@Composable
private fun DsNavigationBarPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        DsNavigationBar(selectedIndex = 0, onItemClick = {})
    }
}

@Preview(showBackground = true, name = "DsNavigationBar light")
@Composable
private fun DsNavigationBarLightPreview() {
    DumpsterScoutTheme(darkTheme = false) {
        DsNavigationBar(selectedIndex = 2, onItemClick = {})
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "DsSegmentedToggle dark")
@Composable
private fun DsSegmentedTogglePreview() {
    DumpsterScoutTheme(darkTheme = true) {
        DsSegmentedToggle(
            options       = listOf(Icons.Default.Map to "Map", Icons.Default.Place to "List"),
            selectedIndex = 0,
            onSelect      = {},
            modifier      = Modifier.padding(16.dp)
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "HistoryEventCard dark")
@Composable
private fun HistoryEventCardPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HistoryEventCard(
                spotName  = "Trader Joe's",
                status    = SpotStatus.GOOD_HAUL,
                isVoice   = true,
                timestamp = "2h ago",
                notes     = "Lots of produce and bread today",
                flags     = listOf("Fresh bags"),
                onClick   = {},
                onDelete  = {}
            )
            HistoryEventCard(
                spotName  = "Whole Foods Market",
                status    = SpotStatus.LOCKED,
                isVoice   = false,
                timestamp = "5h ago",
                flags     = listOf("Security", "Too late"),
                onClick   = {},
                onDelete  = {}
            )
        }
    }
}
