package com.dumpsterscout.ui.voice

import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.VoiceParseResult
import com.dumpsterscout.domain.repository.ReportRepository
import com.dumpsterscout.domain.repository.SpotRepository
import com.dumpsterscout.util.VoiceParser
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class VoicePhase { IDLE, LISTENING, PROCESSING, CONFIRM, EDIT, SAVED }

data class VoiceUiState(
    val phase: VoicePhase = VoicePhase.IDLE,
    val parseResult: VoiceParseResult? = null,
    val matchedSpot: DumpsterSpot? = null,
    val candidateSpots: List<DumpsterSpot> = emptyList(),
    val editableTranscript: String = "",
    val editableNotes: String = "",
    val reportSaved: Boolean = false,
    @StringRes val errorMessageRes: Int? = null
)

@HiltViewModel
class VoiceViewModel @Inject constructor(
    private val spotRepository: SpotRepository,
    private val reportRepository: ReportRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(VoiceUiState())
    val uiState: StateFlow<VoiceUiState> = _uiState.asStateFlow()

    /** Tracks the active parse job so it can be cancelled before starting a new one. */
    private var parseJob: Job? = null

    fun onStartListening() {
        _uiState.update { it.copy(phase = VoicePhase.LISTENING, errorMessageRes = null) }
    }

    fun onListeningCancelled() {
        _uiState.update { it.copy(phase = VoicePhase.IDLE) }
    }

    fun onTranscriptReceived(transcript: String) {
        if (transcript.isBlank()) {
            _uiState.update {
                it.copy(
                    phase = VoicePhase.IDLE,
                    errorMessageRes = R.string.voice_error_no_speech
                )
            }
            return
        }
        _uiState.update { it.copy(phase = VoicePhase.PROCESSING, editableTranscript = transcript) }

        parseJob?.cancel()
        parseJob = viewModelScope.launch {
            val rawResult = VoiceParser.parse(transcript)
            val allSpots = spotRepository.getActiveSpots().first()
            val resolved = VoiceParser.resolveSpot(rawResult, allSpots)

            val matchedSpot = resolved.matchedSpotId?.let { id ->
                allSpots.find { it.id == id }
            }
            val candidates = resolved.candidateSpotIds.mapNotNull { id ->
                allSpots.find { it.id == id }
            }

            _uiState.update { state ->
                state.copy(
                    phase = VoicePhase.CONFIRM,
                    parseResult = resolved,
                    matchedSpot = matchedSpot,
                    candidateSpots = candidates,
                    editableTranscript = transcript,
                    editableNotes = resolved.notes
                )
            }
        }
    }

    fun onTranscriptEdited(newTranscript: String) {
        parseJob?.cancel()
        parseJob = viewModelScope.launch {
            val reparsed = VoiceParser.parse(newTranscript)
            val allSpots = spotRepository.getActiveSpots().first()
            val resolved = VoiceParser.resolveSpot(reparsed, allSpots)

            val matchedSpot = resolved.matchedSpotId?.let { id ->
                allSpots.find { it.id == id }
            }
            val candidates = resolved.candidateSpotIds.mapNotNull { id ->
                allSpots.find { it.id == id }
            }

            _uiState.update { state ->
                state.copy(
                    editableTranscript = newTranscript,
                    parseResult = resolved,
                    matchedSpot = matchedSpot ?: state.matchedSpot,
                    candidateSpots = candidates.ifEmpty { state.candidateSpots },
                    editableNotes = resolved.notes
                )
            }
        }
    }

    fun onNotesEdited(notes: String) {
        _uiState.update { it.copy(editableNotes = notes) }
    }

    fun onSelectSpot(spot: DumpsterSpot) {
        _uiState.update { it.copy(matchedSpot = spot) }
    }

    fun saveReport() {
        val state = _uiState.value
        val spot = state.matchedSpot ?: return
        val result = state.parseResult ?: return

        viewModelScope.launch {
            try {
                val report = VoiceParser.toReport(
                    result = result.copy(notes = state.editableNotes, rawTranscript = state.editableTranscript),
                    spotId = spot.id,
                    spotName = spot.name
                )
                reportRepository.insertReport(report)
                result.status?.let { status ->
                    spotRepository.updateLastStatus(spot.id, status, System.currentTimeMillis())
                }
                _uiState.update { it.copy(phase = VoicePhase.SAVED, reportSaved = true) }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        phase = VoicePhase.IDLE,
                        errorMessageRes = R.string.voice_error_save_failed
                    )
                }
            }
        }
    }

    fun reset() {
        _uiState.value = VoiceUiState()
    }
}
