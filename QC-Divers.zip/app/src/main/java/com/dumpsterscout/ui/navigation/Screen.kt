package com.dumpsterscout.ui.navigation

/**
 * All navigation destinations in the app.
 */
sealed class Screen(val route: String) {
    data object Onboarding : Screen("onboarding")
    data object Home : Screen("home")
    data object SpotList : Screen("spot_list")
    data object AddSpot : Screen("add_spot?spotId={spotId}") {
        fun createRoute(spotId: Long? = null): String =
            if (spotId != null) "add_spot?spotId=$spotId" else "add_spot"
    }
    data object SpotDetail : Screen("spot_detail/{spotId}") {
        fun createRoute(spotId: Long): String = "spot_detail/$spotId"
    }
    data object VoiceReport : Screen("voice_report")
    data object Map : Screen("map")
    data object History : Screen("history")
    data object Settings : Screen("settings")
    data object GearChecklist : Screen("gear_checklist")
    data object Favorites : Screen("favorites")
    data object SavedRoutes : Screen("saved_routes")
    data object FieldMode : Screen("field_mode")
    data object About : Screen("about")

    // ── Tire Spots ────────────────────────────────────────────────────────────
    data object TireSpotList : Screen("tire_spot_list")
    data object AddTireSpot : Screen("add_tire_spot?tireSpotId={tireSpotId}") {
        fun createRoute(tireSpotId: Long? = null): String =
            if (tireSpotId != null) "add_tire_spot?tireSpotId=$tireSpotId" else "add_tire_spot"
    }
    data object TireSpotDetail : Screen("tire_spot_detail/{tireSpotId}") {
        fun createRoute(tireSpotId: Long): String = "tire_spot_detail/$tireSpotId"
    }
    data object TireReport : Screen("tire_report?tireSpotId={tireSpotId}") {
        fun createRoute(tireSpotId: Long? = null): String =
            if (tireSpotId != null) "tire_report?tireSpotId=$tireSpotId" else "tire_report"
    }
    data object TireHistory : Screen("tire_history")
    data object TireVoiceReport : Screen("tire_voice_report?tireSpotId={tireSpotId}") {
        fun createRoute(tireSpotId: Long? = null): String =
            if (tireSpotId != null) "tire_voice_report?tireSpotId=$tireSpotId" else "tire_voice_report"
    }

    // ── Account ───────────────────────────────────────────────────────────────
    data object Account : Screen("account")
}
