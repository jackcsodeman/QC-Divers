package com.dumpsterscout.ui.theme

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.ui.unit.dp

// ─────────────────────────────────────────────────────────────────────────────
// Dumpster Scout Design System — Design Tokens
//
// Spacing, corner radii, elevation, and motion primitives used across
// all components and screens.  Reference these instead of hard-coding dp
// values in individual files so the system is easy to adjust globally.
// ─────────────────────────────────────────────────────────────────────────────

/** 4-dp-increment spacing scale. */
object DsSpacing {
    val xs    = 4.dp
    val s     = 8.dp
    val m     = 12.dp
    val l     = 16.dp
    val xl    = 20.dp
    val xxl   = 24.dp
    val xxxl  = 32.dp
    val giant = 48.dp
}

/** Corner-radius scale — use these instead of raw dp literals. */
object DsRadius {
    val chip       = 8.dp
    val card       = 12.dp
    val largeCard  = 16.dp
    val sheet      = 24.dp
    val pill       = 50.dp
}

/** Elevation scale aligned to Material 3 surface tonal steps. */
object DsElevation {
    val none     = 0.dp
    val subtle   = 1.dp
    val card     = 2.dp
    val raised   = 4.dp
    val floating = 8.dp
    val sheet    = 16.dp
}

// ── Motion ────────────────────────────────────────────────────────────────────

/** Duration constants in milliseconds. */
object DsMotion {
    const val fast    = 150
    const val medium  = 300
    const val slow    = 450
    /** Longer enter — for content appearing from off-screen. */
    const val enter   = 400
    /** Short exit — screens and elements leaving should feel snappy. */
    const val exit    = 200
}

/**
 * Material 3 "Emphasized" easing curves.
 * Use [emphasized] for enter animations, [emphasizedAccelerate] for exits.
 */
object DsEasing {
    val emphasized           = CubicBezierEasing(0.2f, 0f, 0f, 1f)
    val emphasizedDecelerate = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1f)
    val emphasizedAccelerate = CubicBezierEasing(0.3f, 0f, 0.8f, 0.15f)
    val standard             = CubicBezierEasing(0.2f, 0f, 0f, 1f)
}

/** Convenience animation specs pre-built from the token values above. */
object DsSpec {
    fun <T> fast()   = tween<T>(DsMotion.fast)
    fun <T> medium() = tween<T>(DsMotion.medium, easing = DsEasing.standard)
    fun <T> enter()  = tween<T>(DsMotion.enter,  easing = DsEasing.emphasizedDecelerate)
    fun <T> exit()   = tween<T>(DsMotion.exit,   easing = DsEasing.emphasizedAccelerate)
}

/** Glow alpha values for neon overlay treatments. */
object DsGlow {
    const val subtle  = 0.08f
    const val soft    = 0.12f
    const val medium  = 0.20f
    const val strong  = 0.30f
    const val intense = 0.45f
}

/** Neon radius scale for glow/halo effects. */
object DsNeonRadius {
    val tight  = 120f
    val card   = 300f
    val hero   = 600f
    val full   = 1200f
}
