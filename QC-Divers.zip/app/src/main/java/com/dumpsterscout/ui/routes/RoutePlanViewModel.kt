package com.dumpsterscout.ui.routes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.data.local.dao.RoutePlanDao
import com.dumpsterscout.data.local.entity.RoutePlanEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import javax.inject.Inject

data class RoutePlanUi(
    val id: Long,
    val name: String,
    val spotIds: List<Long>,
    val spotCount: Int,
    val notes: String,
    val createdAt: Long
)

data class RoutePlanUiState(
    val routes: List<RoutePlanUi> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null
)

@HiltViewModel
class RoutePlanViewModel @Inject constructor(
    private val dao: RoutePlanDao
) : ViewModel() {

    private val _error = MutableStateFlow<String?>(null)

    val uiState: StateFlow<RoutePlanUiState> = combine(
        dao.getAllRoutePlans(),
        _error
    ) { entities, error ->
        RoutePlanUiState(
            routes    = entities.map { it.toUi() },
            isLoading = false,
            error     = error
        )
    }
        .stateIn(
            scope        = viewModelScope,
            started      = SharingStarted.WhileSubscribed(5_000),
            initialValue = RoutePlanUiState()
        )

    fun createRoute(name: String) {
        viewModelScope.launch {
            try {
                dao.insert(RoutePlanEntity(name = name))
            } catch (e: Exception) {
                _error.value = e.message ?: "An unexpected error occurred"
            }
        }
    }

    fun deleteRoute(id: Long) {
        viewModelScope.launch {
            try {
                dao.getRoutePlanById(id)?.let { dao.delete(it) }
            } catch (e: Exception) {
                _error.value = e.message ?: "An unexpected error occurred"
            }
        }
    }

    fun addSpotToRoute(routeId: Long, spotId: Long) {
        viewModelScope.launch {
            try {
                val route = dao.getRoutePlanById(routeId) ?: return@launch
                val ids = route.parseSpotIds().toMutableList()
                if (spotId !in ids) {
                    ids.add(spotId)
                    dao.update(route.copy(spotIds = ids.toJsonString()))
                }
            } catch (e: Exception) {
                _error.value = e.message ?: "An unexpected error occurred"
            }
        }
    }

    fun removeSpotFromRoute(routeId: Long, spotId: Long) {
        viewModelScope.launch {
            try {
                val route = dao.getRoutePlanById(routeId) ?: return@launch
                val ids = route.parseSpotIds().filter { it != spotId }
                dao.update(route.copy(spotIds = ids.toJsonString()))
            } catch (e: Exception) {
                _error.value = e.message ?: "An unexpected error occurred"
            }
        }
    }

    fun updateRouteNotes(routeId: Long, notes: String) {
        viewModelScope.launch {
            try {
                val route = dao.getRoutePlanById(routeId) ?: return@launch
                dao.update(route.copy(notes = notes))
            } catch (e: Exception) {
                _error.value = e.message ?: "An unexpected error occurred"
            }
        }
    }

    private fun RoutePlanEntity.toUi(): RoutePlanUi {
        val ids = parseSpotIds()
        return RoutePlanUi(
            id = id,
            name = name,
            spotIds = ids,
            spotCount = ids.size,
            notes = notes,
            createdAt = createdAt
        )
    }

    private fun RoutePlanEntity.parseSpotIds(): List<Long> {
        if (spotIds.isBlank() || spotIds == "[]") return emptyList()
        return try {
            val arr = JSONArray(spotIds)
            (0 until arr.length()).map { arr.getLong(it) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun List<Long>.toJsonString(): String {
        val arr = JSONArray()
        forEach { arr.put(it) }
        return arr.toString()
    }
}
