package com.dumpsterscout.ui.map

import android.Manifest
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotCategory
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.ui.components.DsSegmentedToggle
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.EmptyStatePanel
import com.dumpsterscout.ui.components.GradeScoreBadge
import com.dumpsterscout.ui.components.LoadingShimmerCard
import com.dumpsterscout.ui.components.StatusChip
import com.dumpsterscout.ui.components.categoryColor
import com.dumpsterscout.ui.components.statusDisplay
import com.dumpsterscout.ui.theme.*
import com.dumpsterscout.util.SampleData
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import androidx.compose.ui.res.stringResource
import com.dumpsterscout.R
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.google.maps.android.compose.*

private enum class MapViewMode { MAP, LIST }

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun MapScreen(
    onNavigateBack: () -> Unit,
    onNavigateToSpotDetail: (Long) -> Unit,
    onNavigateToAddSpot: () -> Unit,
    viewModel: MapViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val locationPermission = rememberPermissionState(Manifest.permission.ACCESS_FINE_LOCATION)

    var viewMode by remember { mutableStateOf(MapViewMode.MAP) }
    var selectedSpot by remember { mutableStateOf<DumpsterSpot?>(null) }
    var filterStatus by remember { mutableStateOf<SpotStatus?>(null) }

    // Default to Quad Cities center (Bettendorf/Davenport area)
    val defaultPosition = LatLng(41.5208, -90.5718)
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(defaultPosition, 12f)
    }

    // Apply status filter
    val displayedSpots = remember(uiState.spots, filterStatus) {
        if (filterStatus == null) uiState.spots
        else uiState.spots.filter { it.lastStatus == filterStatus }
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.map_title),
                subtitle = stringResource(R.string.spots_count_title, displayedSpots.size),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToAddSpot) {
                        Icon(Icons.Default.AddLocation, stringResource(R.string.cd_add_button))
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // ── MAP / LIST animated content swap ──────────────────────────
            AnimatedContent(
                targetState = viewMode,
                transitionSpec = {
                    fadeIn(tween(DsMotion.medium)) togetherWith fadeOut(tween(DsMotion.exit))
                },
                label = "map_list_toggle"
            ) { mode ->
                when (mode) {
                    MapViewMode.MAP -> MapContent(
                        spots          = displayedSpots,
                        locationGranted = locationPermission.status.isGranted,
                        cameraPositionState = cameraPositionState,
                        selectedSpot   = selectedSpot,
                        onMarkerClick  = { selectedSpot = it },
                        modifier       = Modifier.fillMaxSize()
                    )
                    MapViewMode.LIST -> ListContent(
                        spots          = displayedSpots,
                        isLoading      = uiState.isLoading,
                        onSpotClick    = { onNavigateToSpotDetail(it.id) },
                        modifier       = Modifier.fillMaxSize()
                    )
                }
            }

            // ── Map/List segmented toggle (top-right overlay) ──────────
            DsSegmentedToggle(
                options       = listOf(
                    Icons.Default.Map to stringResource(R.string.map_view),
                    Icons.AutoMirrored.Filled.List to stringResource(R.string.list_view)
                ),
                selectedIndex = if (viewMode == MapViewMode.MAP) 0 else 1,
                onSelect      = { idx ->
                    viewMode = if (idx == 0) MapViewMode.MAP else MapViewMode.LIST
                    selectedSpot = null
                },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(end = DsSpacing.l, top = DsSpacing.s)
            )

            // ── Status filter chips row (top overlay) ──────────────────────
            StatusFilterRow(
                selected = filterStatus,
                onSelect = { filterStatus = if (filterStatus == it) null else it },
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(horizontal = DsSpacing.l, vertical = DsSpacing.s)
            )

            // ── Location permission banner ─────────────────────────────────
            if (!locationPermission.status.isGranted) {
                LocationPermissionBanner(
                    onRequest = { locationPermission.launchPermissionRequest() },
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 56.dp, start = DsSpacing.l, end = DsSpacing.l)
                )
            }

            // ── Selected spot preview card (map mode only) ─────────────────
            AnimatedVisibility(
                visible = viewMode == MapViewMode.MAP && selectedSpot != null,
                enter   = slideInVertically { it } + fadeIn(tween(DsMotion.medium)),
                exit    = slideOutVertically { it } + fadeOut(tween(DsMotion.exit)),
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                selectedSpot?.let { spot ->
                    SpotPreviewCard(
                        spot         = spot,
                        onView       = { onNavigateToSpotDetail(spot.id) },
                        onDismiss    = { selectedSpot = null },
                        modifier     = Modifier
                            .fillMaxWidth()
                            .padding(DsSpacing.l)
                    )
                }
            }
        }
    }
}

// ── Map content ────────────────────────────────────────────────────────────────

@Composable
private fun MapContent(
    spots: List<DumpsterSpot>,
    locationGranted: Boolean,
    cameraPositionState: CameraPositionState,
    selectedSpot: DumpsterSpot?,
    onMarkerClick: (DumpsterSpot) -> Unit,
    modifier: Modifier = Modifier
) {
    GoogleMap(
        modifier = modifier,
        cameraPositionState = cameraPositionState,
        properties = MapProperties(isMyLocationEnabled = locationGranted),
        uiSettings  = MapUiSettings(
            myLocationButtonEnabled = locationGranted,
            zoomControlsEnabled = false
        )
    ) {
        spots.filter { it.latitude != 0.0 && it.longitude != 0.0 }.forEach { spot ->
            val isSelected = spot.id == selectedSpot?.id
            val hue = categoryHue(spot.category)
            Marker(
                state  = MarkerState(LatLng(spot.latitude, spot.longitude)),
                title  = spot.name,
                snippet = spot.lastStatus.name.lowercase().replace('_', ' '),
                icon   = BitmapDescriptorFactory.defaultMarker(
                    if (isSelected) BitmapDescriptorFactory.HUE_YELLOW else hue
                ),
                alpha  = if (isSelected) 1f else 0.85f,
                onClick = {
                    onMarkerClick(spot)
                    false
                }
            )
        }
    }
}

/** Maps a SpotCategory to a Google Maps marker hue value (0–360). */
private fun categoryHue(category: SpotCategory): Float = when (category) {
    SpotCategory.GROCERY           -> BitmapDescriptorFactory.HUE_CYAN
    SpotCategory.BAKERY            -> BitmapDescriptorFactory.HUE_ORANGE
    SpotCategory.PHARMACY          -> BitmapDescriptorFactory.HUE_AZURE
    SpotCategory.RETAIL            -> BitmapDescriptorFactory.HUE_VIOLET
    SpotCategory.RESTAURANT        -> BitmapDescriptorFactory.HUE_RED
    SpotCategory.APARTMENT_COMPLEX -> BitmapDescriptorFactory.HUE_GREEN
    SpotCategory.OFFICE            -> BitmapDescriptorFactory.HUE_BLUE
    SpotCategory.WAREHOUSE         -> 80f   // yellow-green
    SpotCategory.ELECTRONICS       -> 195f   // deep sky blue-green (distinct from GROCERY cyan)
    SpotCategory.FURNITURE         -> BitmapDescriptorFactory.HUE_ROSE
    SpotCategory.OTHER             -> BitmapDescriptorFactory.HUE_MAGENTA
}

// ── List content ───────────────────────────────────────────────────────────────

@Composable
private fun ListContent(
    spots: List<DumpsterSpot>,
    isLoading: Boolean,
    onSpotClick: (DumpsterSpot) -> Unit,
    modifier: Modifier = Modifier
) {
    when {
        isLoading -> LazyColumn(
            modifier = modifier.padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) { items(5) { LoadingShimmerCard() } }

        spots.isEmpty() -> EmptyStatePanel(
            message = stringResource(R.string.no_spots_match_filter),
            icon = Icons.Default.SearchOff,
            modifier = modifier
        )

        else -> LazyColumn(
            modifier = modifier,
            contentPadding = PaddingValues(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            items(spots, key = { it.id }) { spot ->
                MapSpotListCard(spot = spot, onClick = { onSpotClick(spot) })
            }
        }
    }
}

/** Compact card used in the list-mode of the explore screen. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MapSpotListCard(spot: DumpsterSpot, onClick: () -> Unit) {
    val accent = categoryColor(spot.category)
    Card(
        onClick   = onClick,
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.medium
    ) {
        Row {
            // Left accent strip
            Box(
                Modifier
                    .width(4.dp)
                    .heightIn(min = 72.dp)
                    .background(accent)
            )
            Row(
                modifier = Modifier
                    .padding(DsSpacing.m)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                // Category dot
                Box(
                    Modifier
                        .size(10.dp)
                        .clip(RoundedCornerShape(50))
                        .background(accent)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        spot.name,
                        style    = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (spot.address.isNotBlank()) {
                        Text(
                            spot.address,
                            style    = MaterialTheme.typography.bodySmall,
                            color    = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(DsSpacing.xs)
                ) {
                    StatusChip(status = spot.lastStatus)
                    if (spot.grade.isGraded()) {
                        GradeScoreBadge(overall = spot.grade.overall)
                    }
                }
            }
        }
    }
}

// ── Selected spot preview card ─────────────────────────────────────────────────

@Composable
private fun SpotPreviewCard(
    spot: DumpsterSpot,
    onView: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = categoryColor(spot.category)
    val (statusLabel, _) = statusDisplay(spot.lastStatus)

    Card(
        modifier  = modifier,
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.sheet),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.large
    ) {
        Column {
            // Gradient accent header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(accent, accent.copy(alpha = 0.3f))
                        )
                    )
            )
            Row(
                modifier  = Modifier.padding(DsSpacing.l),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(spot.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)
                    ) {
                        Text(
                            spot.category.name.lowercase().replaceFirstChar { it.uppercaseChar() },
                            style = MaterialTheme.typography.bodySmall,
                            color = accent
                        )
                        if (spot.isFavorite) {
                            Icon(
                                Icons.Default.Favorite,
                                null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                        if (spot.isVerified) {
                            Icon(
                                Icons.Default.Verified,
                                null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(DsSpacing.xs))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs),
                        verticalAlignment     = Alignment.CenterVertically
                    ) {
                        StatusChip(status = spot.lastStatus)
                        if (spot.grade.isGraded()) {
                            GradeScoreBadge(overall = spot.grade.overall)
                        }
                    }
                }
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
                ) {
                    Button(
                        onClick = onView,
                        contentPadding = PaddingValues(horizontal = DsSpacing.l, vertical = DsSpacing.s)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(DsSpacing.xs))
                        Text(stringResource(R.string.action_view))
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, stringResource(R.string.cd_dismiss_preview), modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

// ── Status filter row ──────────────────────────────────────────────────────────

@Composable
private fun StatusFilterRow(
    selected: SpotStatus?,
    onSelect: (SpotStatus) -> Unit,
    modifier: Modifier = Modifier
) {
    val quickStatuses = listOf(
        SpotStatus.GOOD_HAUL,
        SpotStatus.EMPTY,
        SpotStatus.LOCKED,
        SpotStatus.SECURITY_ACTIVE,
        SpotStatus.COMPACTOR_ONLY
    )
    Row(
        modifier              = modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
    ) {
        quickStatuses.forEach { status ->
            val (label, color) = statusDisplay(status)
            FilterChip(
                selected = selected == status,
                onClick  = { onSelect(status) },
                label    = { Text(label, style = MaterialTheme.typography.labelSmall) },
                colors   = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = color.copy(alpha = 0.2f),
                    selectedLabelColor     = color
                )
            )
        }
    }
}

// ── Location permission banner ─────────────────────────────────────────────────

@Composable
private fun LocationPermissionBanner(onRequest: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        color    = MaterialTheme.colorScheme.secondaryContainer,
        shape    = MaterialTheme.shapes.medium,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(DsSpacing.m),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            Icon(Icons.Default.LocationOff, null, tint = MaterialTheme.colorScheme.secondary)
            Text(
                stringResource(R.string.enable_location_prompt),
                style    = MaterialTheme.typography.bodySmall,
                color    = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onRequest) { Text(stringResource(R.string.allow)) }
        }
    }
}

// ── Previews ───────────────────────────────────────────────────────────────────

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "SpotPreviewCard dark")
@Composable
private fun SpotPreviewCardPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        SpotPreviewCard(
            spot     = SampleData.spots.first(),
            onView   = {},
            onDismiss = {}
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "MapSpotListCard dark")
@Composable
private fun MapSpotListCardPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SampleData.spots.take(3).forEach { spot ->
                MapSpotListCard(spot = spot, onClick = {})
            }
        }
    }
}
