package com.dumpsterscout.ui.field

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.dumpsterscout.R
import com.dumpsterscout.ui.theme.*

// ─────────────────────────────────────────────────────────────────────────────
// FieldModeScreen
//
// A purpose-built quick-access hub designed for outdoor, one-handed, low-light
// use.  Large touch targets, high contrast, night-friendly amber palette,
// minimal chrome, and only the three most important actions per dive.
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun FieldModeScreen(
    onNavigateBack: () -> Unit,
    onNavigateToVoiceReport: () -> Unit,
    onNavigateToMap: () -> Unit,
    onNavigateToSpotList: () -> Unit,
    onNavigateToAddSpot: () -> Unit,
    onNavigateToGearChecklist: () -> Unit
) {
    // Night-field surface — very dark with warm amber tint
    val nightBg = Brush.verticalGradient(
        colors = listOf(NightSurface, NightSurfaceRaised)
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(nightBg)
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // ── Top bar ────────────────────────────────────────────────────
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = DsSpacing.l, vertical = DsSpacing.m),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack, modifier = Modifier.size(48.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.cd_navigate_back),
                        tint     = NightText,
                        modifier = Modifier.size(28.dp)
                    )
                }
                Spacer(Modifier.width(DsSpacing.s))
                Column {
                    Text(
                        stringResource(R.string.field_mode_title),
                        style = MaterialTheme.typography.titleLarge,
                        color = NightText
                    )
                    Text(
                        stringResource(R.string.field_mode_subtitle),
                        style = MaterialTheme.typography.bodySmall,
                        color = NightTextDim
                    )
                }
                Spacer(Modifier.weight(1f))
                // Night mode indicator pill
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(NightAmber.copy(alpha = 0.2f))
                        .padding(horizontal = DsSpacing.m, vertical = DsSpacing.xs)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)
                    ) {
                        Icon(
                            Icons.Default.Brightness3,
                            null,
                            tint     = NightAmber,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(stringResource(R.string.field_mode_night_label), style = MaterialTheme.typography.labelSmall, color = NightAmber)
                    }
                }
            }

            HorizontalDivider(
                color     = NightAmber.copy(alpha = 0.15f),
                thickness = 1.dp,
                modifier  = Modifier.padding(horizontal = DsSpacing.l)
            )

            Spacer(Modifier.height(DsSpacing.xxl))

            // ── PRIMARY action — Voice report ──────────────────────────────
            Box(
                modifier          = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = DsSpacing.xxl),
                contentAlignment  = Alignment.Center
            ) {
                FieldPrimaryAction(
                    label     = "Voice Report",
                    subLabel  = "Tap to log this spot",
                    icon      = Icons.Default.Mic,
                    color     = NightAmber,
                    onClick   = onNavigateToVoiceReport
                )
            }

            Spacer(Modifier.height(DsSpacing.xxxl))

            // ── Secondary 2-wide grid ──────────────────────────────────────
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = DsSpacing.xxl),
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.l)
            ) {
                FieldSecondaryAction(
                    label   = "Nearby Map",
                    icon    = Icons.Default.Map,
                    color   = CategoryPharmacy,
                    onClick = onNavigateToMap,
                    modifier = Modifier.weight(1f)
                )
                FieldSecondaryAction(
                    label   = "Spot List",
                    icon    = Icons.AutoMirrored.Filled.FormatListBulleted,
                    color   = CategoryGrocery,
                    onClick = onNavigateToSpotList,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(DsSpacing.l))

            // ── Tertiary 2-wide grid ───────────────────────────────────────
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = DsSpacing.xxl),
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.l)
            ) {
                FieldSecondaryAction(
                    label   = "Add Spot",
                    icon    = Icons.Default.AddLocation,
                    color   = ScoutGreenBright,
                    onClick = onNavigateToAddSpot,
                    modifier = Modifier.weight(1f)
                )
                FieldSecondaryAction(
                    label   = "Gear Check",
                    icon    = Icons.Default.Backpack,
                    color   = ScoutAmberWarm,
                    onClick = onNavigateToGearChecklist,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.weight(1f))

            // ── Bottom safety note ─────────────────────────────────────────
            Text(
                "Respect property · Leave no mess · Stay safe",
                style     = MaterialTheme.typography.labelSmall,
                color     = NightTextDim,
                textAlign = TextAlign.Center,
                modifier  = Modifier
                    .fillMaxWidth()
                    .padding(bottom = DsSpacing.xxl)
            )
        }
    }
}

// ── Field action components ────────────────────────────────────────────────────

/**
 * Large primary tap target — used for the most-important field action.
 * Full-width, tall, and brightly colored.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FieldPrimaryAction(
    label: String,
    subLabel: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        onClick   = onClick,
        modifier  = Modifier
            .fillMaxWidth()
            .height(120.dp),
        colors    = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.15f)),
        border    = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(listOf(color.copy(alpha = 0.6f), color.copy(alpha = 0.3f)))
        ),
        shape     = MaterialTheme.shapes.extraLarge
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(DsSpacing.xxl),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.l)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.25f))
            ) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint     = color,
                    modifier = Modifier.size(36.dp)
                )
            }
            Column {
                Text(
                    label,
                    style = MaterialTheme.typography.titleLarge,
                    color = color
                )
                Text(
                    subLabel,
                    style = MaterialTheme.typography.bodyMedium,
                    color = NightTextDim
                )
            }
        }
    }
}

/**
 * Medium-sized secondary action card.
 * Equal-width, so two can sit side by side in a 2-column grid.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FieldSecondaryAction(
    label: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick  = onClick,
        modifier = modifier.height(90.dp),
        colors   = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f)),
        border   = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(listOf(color.copy(alpha = 0.4f), color.copy(alpha = 0.15f)))
        ),
        shape    = MaterialTheme.shapes.large
    ) {
        Column(
            modifier              = Modifier
                .fillMaxSize()
                .padding(DsSpacing.m),
            horizontalAlignment   = Alignment.CenterHorizontally,
            verticalArrangement   = Arrangement.Center
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint     = color,
                modifier = Modifier.size(28.dp)
            )
            Spacer(Modifier.height(DsSpacing.xs))
            Text(
                label,
                style     = MaterialTheme.typography.bodyMedium,
                color     = NightText,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ── Previews ───────────────────────────────────────────────────────────────────

@Preview(showBackground = true, backgroundColor = 0xFF0A0B0E, name = "FieldModeScreen")
@Composable
private fun FieldModeScreenPreview() {
    DumpsterScoutTheme(darkTheme = true, fieldMode = true) {
        FieldModeScreen(
            onNavigateBack          = {},
            onNavigateToVoiceReport = {},
            onNavigateToMap         = {},
            onNavigateToSpotList    = {},
            onNavigateToAddSpot     = {},
            onNavigateToGearChecklist = {}
        )
    }
}
