package com.dumpsterscout.ui.tire

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.ui.theme.DumpsterScoutTheme
import com.dumpsterscout.ui.theme.DsMotion
import com.dumpsterscout.ui.theme.GradeLow
import com.dumpsterscout.ui.theme.ScoutAmberLight
import com.dumpsterscout.ui.theme.ScoutAmberWarm
import com.dumpsterscout.ui.theme.ScoutGreenBright
import com.dumpsterscout.ui.theme.StatusEmpty
import com.dumpsterscout.ui.theme.StatusFull
import com.dumpsterscout.ui.theme.StatusGoodHaul
import com.dumpsterscout.ui.theme.StatusHalfFull
import com.dumpsterscout.ui.theme.StatusLocked
import com.dumpsterscout.ui.theme.StatusOverflowing
import com.dumpsterscout.ui.theme.CategoryGrocery

/**
 * Chip displaying the current [TireSpotStatus] with animated color transitions.
 */
@Composable
fun TireStatusChip(
    status: TireSpotStatus,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val (label, rawColor) = tireStatusDisplay(status)
    val icon = tireStatusIcon(status)
    val cd = stringResource(R.string.cd_status_chip, label)

    val color by animateColorAsState(
        targetValue = rawColor,
        animationSpec = tween(DsMotion.medium),
        label = "tire_status_chip_color"
    )

    AssistChip(
        onClick = onClick ?: {},
        enabled = onClick != null,
        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
        leadingIcon = icon?.let {
            { Icon(it, contentDescription = null, modifier = Modifier.size(14.dp), tint = color) }
        },
        modifier = modifier.semantics { contentDescription = cd },
        colors = AssistChipDefaults.assistChipColors(
            containerColor          = color.copy(alpha = 0.18f),
            labelColor              = color,
            leadingIconContentColor = color
        ),
        border = AssistChipDefaults.assistChipBorder(
            enabled     = true,
            borderColor = color.copy(alpha = 0.55f)
        )
    )
}

/** Returns the human-readable label and accent color for a given [TireSpotStatus]. */
@Composable
fun tireStatusDisplay(status: TireSpotStatus): Pair<String, Color> = when (status) {
    TireSpotStatus.NO_TIRES           -> stringResource(R.string.tire_status_no_tires)       to StatusEmpty
    TireSpotStatus.A_FEW_OUT          -> stringResource(R.string.tire_status_a_few_out)      to ScoutAmberLight
    TireSpotStatus.MANY_OUT           -> stringResource(R.string.tire_status_many_out)        to StatusFull
    TireSpotStatus.GOOD_USABLE        -> stringResource(R.string.tire_status_good_usable)     to StatusGoodHaul
    TireSpotStatus.MOSTLY_JUNK        -> stringResource(R.string.tire_status_mostly_junk)     to StatusOverflowing
    TireSpotStatus.ALL_PUNCTURED      -> stringResource(R.string.tire_status_all_punctured)   to GradeLow
    TireSpotStatus.SOME_PUNCTURED     -> stringResource(R.string.tire_status_some_punctured)  to StatusHalfFull
    TireSpotStatus.UNPUNCTURED        -> stringResource(R.string.tire_status_unpunctured)     to ScoutGreenBright
    TireSpotStatus.ALREADY_PICKED     -> stringResource(R.string.tire_status_already_picked)  to StatusLocked
    TireSpotStatus.GONE_FAST          -> stringResource(R.string.tire_status_gone_fast)       to ScoutAmberWarm
    TireSpotStatus.LOCKED_INACCESSIBLE -> stringResource(R.string.tire_status_locked)         to StatusLocked
    TireSpotStatus.MOVED_REMOVED      -> stringResource(R.string.tire_status_moved_removed)   to GradeLow
    TireSpotStatus.WORTH_CHECKING     -> stringResource(R.string.tire_status_worth_checking)  to CategoryGrocery
    TireSpotStatus.FRESH_DROP         -> stringResource(R.string.tire_status_fresh_drop)      to StatusGoodHaul
    TireSpotStatus.NOT_WORTH_IT       -> stringResource(R.string.tire_status_not_worth_it)    to StatusEmpty
    TireSpotStatus.UNKNOWN            -> stringResource(R.string.tire_status_unknown)         to StatusLocked
}

/** Small leading icon per status. */
fun tireStatusIcon(status: TireSpotStatus): ImageVector? = when (status) {
    TireSpotStatus.NO_TIRES           -> Icons.Default.RadioButtonUnchecked
    TireSpotStatus.A_FEW_OUT          -> Icons.AutoMirrored.Filled.TrendingDown
    TireSpotStatus.MANY_OUT           -> Icons.Default.CheckCircle
    TireSpotStatus.GOOD_USABLE        -> Icons.Default.Star
    TireSpotStatus.MOSTLY_JUNK,
    TireSpotStatus.ALL_PUNCTURED,
    TireSpotStatus.NOT_WORTH_IT       -> Icons.Default.Block
    TireSpotStatus.SOME_PUNCTURED     -> Icons.Default.Warning
    TireSpotStatus.UNPUNCTURED,
    TireSpotStatus.FRESH_DROP         -> Icons.Default.CheckCircle
    TireSpotStatus.ALREADY_PICKED,
    TireSpotStatus.LOCKED_INACCESSIBLE,
    TireSpotStatus.MOVED_REMOVED      -> Icons.Default.RemoveCircleOutline
    TireSpotStatus.GONE_FAST          -> Icons.AutoMirrored.Filled.TrendingDown
    TireSpotStatus.WORTH_CHECKING     -> Icons.Default.CheckCircle
    TireSpotStatus.UNKNOWN            -> Icons.AutoMirrored.Filled.HelpOutline
}

// ── Previews ──────────────────────────────────────────────────────────────────

@Preview(showBackground = true, backgroundColor = 0xFF1A1C22)
@Composable
private fun TireStatusChipGoodUsablePreview() {
    DumpsterScoutTheme(darkTheme = true) {
        TireStatusChip(status = TireSpotStatus.GOOD_USABLE)
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF1A1C22)
@Composable
private fun TireStatusChipAllPuncturedPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        TireStatusChip(status = TireSpotStatus.ALL_PUNCTURED)
    }
}
