package com.dumpsterscout.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.data.preferences.AppPreferences
import com.dumpsterscout.domain.repository.ReportRepository
import com.dumpsterscout.domain.repository.SpotRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val darkTheme: Boolean = false,
    val dynamicColor: Boolean = true,
    val fieldMode: Boolean = false,
    val exportedJson: String? = null,
    val importResult: String? = null,
    val showClearConfirm: Boolean = false,
    val prefError: String? = null
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val appPreferences: AppPreferences,
    private val spotRepository: SpotRepository,
    private val reportRepository: ReportRepository
) : ViewModel() {

    private val _exportedJson = MutableStateFlow<String?>(null)
    private val _importResult = MutableStateFlow<String?>(null)
    private val _showClearConfirm = MutableStateFlow(false)
    private val _prefError = MutableStateFlow<String?>(null)

    val uiState: StateFlow<SettingsUiState> = combine(
        appPreferences.darkTheme,
        appPreferences.dynamicColor,
        appPreferences.fieldMode,
        _exportedJson,
        _importResult,
        _showClearConfirm,
        _prefError
    ) { values ->
        SettingsUiState(
            darkTheme        = values[0] as Boolean,
            dynamicColor     = values[1] as Boolean,
            fieldMode        = values[2] as Boolean,
            exportedJson     = values[3] as String?,
            importResult     = values[4] as String?,
            showClearConfirm = values[5] as Boolean,
            prefError        = values[6] as String?
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = SettingsUiState()
    )

    fun setDarkTheme(enabled: Boolean) {
        viewModelScope.launch {
            try {
                appPreferences.setDarkTheme(enabled)
            } catch (e: Exception) {
                _prefError.value = "Failed to save setting: ${e.message}"
            }
        }
    }

    fun setDynamicColor(enabled: Boolean) {
        viewModelScope.launch {
            try {
                appPreferences.setDynamicColor(enabled)
            } catch (e: Exception) {
                _prefError.value = "Failed to save setting: ${e.message}"
            }
        }
    }

    fun setFieldMode(enabled: Boolean) {
        viewModelScope.launch {
            try {
                appPreferences.setFieldMode(enabled)
            } catch (e: Exception) {
                _prefError.value = "Failed to save setting: ${e.message}"
            }
        }
    }

    fun clearPrefError() {
        _prefError.value = null
    }

    fun exportData() {
        viewModelScope.launch {
            try {
                val json = spotRepository.exportToJson()
                _exportedJson.value = json
            } catch (e: Exception) {
                _exportedJson.value = null
                _importResult.value = "Export failed: ${e.message}"
            }
        }
    }

    fun clearExportResult() {
        _exportedJson.value = null
    }

    fun importData(json: String) {
        viewModelScope.launch {
            try {
                val count = spotRepository.importFromJson(json)
                _importResult.value = "Imported $count spots successfully."
            } catch (e: Exception) {
                _importResult.value = "Import failed: ${e.message}"
            }
        }
    }

    fun clearImportResult() {
        _importResult.value = null
    }

    fun requestClearData() {
        _showClearConfirm.value = true
    }

    fun dismissClearConfirm() {
        _showClearConfirm.value = false
    }

    fun confirmClearData() {
        viewModelScope.launch {
            try {
                reportRepository.deleteAllReports()
                spotRepository.deleteAllSpots()
                _showClearConfirm.value = false
            } catch (e: Exception) {
                _showClearConfirm.value = false
                _importResult.value = "Clear failed: ${e.message}"
            }
        }
    }
}
