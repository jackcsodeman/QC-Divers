package com.dumpsterscout.ui.about

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dumpsterscout.R
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.theme.*

// ─────────────────────────────────────────────────────────────────────────────
// About Screen — The story of Dumpster Scout
// ─────────────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(
    onNavigateBack: () -> Unit
) {
    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.about),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // ── Hero header with animated gradient ──────────────────────────
            AboutHeroHeader()

            Spacer(Modifier.height(DsSpacing.xxl))

            // ── Creator section ─────────────────────────────────────────────
            CreatorCard()

            Spacer(Modifier.height(DsSpacing.l))

            // ── Origin story ────────────────────────────────────────────────
            OriginStoryCard()

            Spacer(Modifier.height(DsSpacing.l))

            // ── Feature badges ──────────────────────────────────────────────
            FeatureBadgesSection()

            Spacer(Modifier.height(DsSpacing.l))

            // ── Release status card ─────────────────────────────────────────
            ReleaseStatusCard()

            Spacer(Modifier.height(DsSpacing.l))

            // ── Tech stack badges ───────────────────────────────────────────
            TechStackSection()

            Spacer(Modifier.height(DsSpacing.xxl))

            // ── Version footer ──────────────────────────────────────────────
            VersionFooter()

            Spacer(Modifier.height(DsSpacing.giant))
        }
    }
}

// ── Hero header ────────────────────────────────────────────────────────────────

@Composable
private fun AboutHeroHeader() {
    val infiniteTransition = rememberInfiniteTransition(label = "hero_gradient")
    val gradientOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "gradient_shift"
    )
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logo_pulse"
    )
    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring_rotation"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(280.dp)
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF001A20),   // deep cyan-tinted base
                        ScoutSurface0,       // near-black blue (== 0xFF060810)
                        Color(0xFF1B0026),   // deep magenta shadow
                        Color(0xFF00141A),   // cycle back to cyan dark
                        Color(0xFF001A20)    // loop back
                    ),
                    start = Offset(gradientOffset, 0f),
                    end = Offset(gradientOffset + 600f, 600f)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // Cyan radial burst
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            NeonCyan.copy(alpha = 0.18f),
                            Color.Transparent
                        ),
                        center = Offset(100f, 100f),
                        radius = 350f
                    )
                )
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            NeonMagenta.copy(alpha = 0.14f),
                            Color.Transparent
                        ),
                        center = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY),
                        radius = 400f
                    )
                )
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            NeonBlue.copy(alpha = 0.08f),
                            Color.Transparent
                        ),
                        center = Offset(Float.POSITIVE_INFINITY, 0f),
                        radius = 300f
                    )
                )
        )

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // Animated logo ring
            Box(contentAlignment = Alignment.Center) {
                // Outer rotating neon ring
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .rotate(ringRotation)
                        .border(
                            width = 2.dp,
                            brush = Brush.sweepGradient(
                                colors = listOf(
                                    NeonCyan,
                                    NeonMagenta,
                                    NeonBlue,
                                    CategoryRetail,
                                    NeonCyan
                                )
                            ),
                            shape = CircleShape
                        )
                )
                // Inner pulsing circle
                Box(
                    modifier = Modifier
                        .size(92.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    NeonCyanDeep,
                                    ScoutSurface0
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "🗑️",
                        fontSize = 40.sp
                    )
                }
            }

            Spacer(Modifier.height(DsSpacing.l))

            Text(
                "Dumpster Scout",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = (-0.5).sp
                ),
                color = Color.White
            )
            Spacer(Modifier.height(DsSpacing.xs))
            Text(
                "Field intelligence for resourceful people",
                style = MaterialTheme.typography.bodyMedium,
                color = ScoutOnSurfaceDim,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ── Creator card ───────────────────────────────────────────────────────────────

@Composable
private fun CreatorCard() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DsSpacing.l),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.raised),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape = MaterialTheme.shapes.large
    ) {
        Column {
            // Rainbow accent header
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                ScoutGreenBright,
                                CategoryGrocery,
                                CategoryPharmacy,
                                ScoutAmberWarm,
                                CategoryBakery,
                                CategoryRetail
                            )
                        )
                    )
            )

            Row(
                modifier = Modifier.padding(DsSpacing.l),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.l)
            ) {
                // Avatar
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(NeonCyan, NeonMagenta)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "JS",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }

                Column {
                    Text(
                        "Jack Sodeman-Dickey",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Text(
                        "Creator & Solo Developer",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

// ── Origin story card ──────────────────────────────────────────────────────────

@Composable
private fun OriginStoryCard() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DsSpacing.l),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.card),
        colors = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape = MaterialTheme.shapes.large
    ) {
        Column(modifier = Modifier.padding(DsSpacing.l)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                Icon(
                    Icons.Default.AutoStories,
                    null,
                    tint = NeonMagenta,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    "The Origin Story",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = NeonMagenta
                )
            }

            Spacer(Modifier.height(DsSpacing.m))

            Text(
                "It started behind a Trader Joe's at 11 PM on a Tuesday.",
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(Modifier.height(DsSpacing.s))

            Text(
                "I'd been doing runs for months — hitting the same spots, keeping mental " +
                "notes about which dumpsters got emptied when, which ones had cameras, which " +
                "bakeries threw out perfectly good bread at closing time. But I kept forgetting " +
                "details. Was it the Tuesday or Thursday pickup at that Whole Foods? Did that " +
                "pharmacy lock their bin last week or was that the other one?\n\n" +
                "I tried spreadsheets. I tried notes apps. I even tried pinning stuff on " +
                "Google Maps. Nothing worked the way my brain needed it to — quick logging " +
                "while standing in a dark parking lot with one hand, voice notes I could file " +
                "in two seconds, a grading system that actually told me if a spot was worth " +
                "the drive.\n\n" +
                "So I built Dumpster Scout. For me. A personal field notebook that lives in " +
                "my pocket, works in the dark, and remembers everything I can't. All data " +
                "stays on your device by default — sign in to enable cloud sync and opt-in " +
                "community spot sharing.\n\n" +
                "Now it tracks tire spots too — same offline-first, voice-first approach " +
                "for logging counts, puncture state, and condition on the fly.\n\n" +
                "If you're reading this, you probably get it. Happy diving. 🤙",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                lineHeight = 22.sp
            )
        }
    }
}

// ── Feature badges ─────────────────────────────────────────────────────────────

@Composable
private fun FeatureBadgesSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DsSpacing.l),
        verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
    ) {
        Text(
            "CAPABILITIES",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            letterSpacing = 2.sp,
            modifier = Modifier.padding(bottom = DsSpacing.xs)
        )

        // Row 1
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            FeatureBadge(
                icon = Icons.Default.Mic,
                label = stringResource(R.string.feature_badge_voice_report),
                color = ScoutAmberWarm,
                modifier = Modifier.weight(1f)
            )
            FeatureBadge(
                icon = Icons.Default.Map,
                label = stringResource(R.string.feature_badge_map_intel),
                color = CategoryPharmacy,
                modifier = Modifier.weight(1f)
            )
            FeatureBadge(
                icon = Icons.Default.Star,
                label = stringResource(R.string.feature_badge_spot_grading),
                color = ScoutGreenBright,
                modifier = Modifier.weight(1f)
            )
        }

        // Row 2
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            FeatureBadge(
                icon = Icons.Default.FlashlightOn,
                label = stringResource(R.string.feature_badge_night_mode),
                color = NightAmber,
                modifier = Modifier.weight(1f)
            )
            FeatureBadge(
                icon = Icons.Default.Security,
                label = stringResource(R.string.feature_badge_risk_tracking),
                color = StatusSecurity,
                modifier = Modifier.weight(1f)
            )
            FeatureBadge(
                icon = Icons.Default.Route,
                label = stringResource(R.string.feature_badge_route_plans),
                color = CategoryRetail,
                modifier = Modifier.weight(1f)
            )
        }

        // Row 3
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            FeatureBadge(
                icon = Icons.Default.OfflineBolt,
                label = stringResource(R.string.feature_badge_offline),
                color = CategoryGrocery,
                modifier = Modifier.weight(1f)
            )
            FeatureBadge(
                icon = Icons.Default.Lock,
                label = stringResource(R.string.feature_badge_private),
                color = ScoutSlateLight,
                modifier = Modifier.weight(1f)
            )
            FeatureBadge(
                icon = Icons.Default.Schedule,
                label = stringResource(R.string.feature_badge_timing_intel),
                color = CategoryBakery,
                modifier = Modifier.weight(1f)
            )
        }

        // Row 4
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            FeatureBadge(
                icon = Icons.Default.Build,
                label = stringResource(R.string.feature_badge_tire_spots),
                color = TireTireShop,
                modifier = Modifier.weight(1f)
            )
            FeatureBadge(
                icon = Icons.Default.RecordVoiceOver,
                label = stringResource(R.string.feature_badge_tire_voice),
                color = TireMechanic,
                modifier = Modifier.weight(1f)
            )
            FeatureBadge(
                icon = Icons.Default.History,
                label = stringResource(R.string.feature_badge_field_history),
                color = CategoryPharmacy,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun FeatureBadge(
    icon: ImageVector,
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = MaterialTheme.shapes.medium,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = DsSpacing.s, vertical = DsSpacing.m),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(DsSpacing.xs)
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(22.dp))
            Text(
                label,
                style = MaterialTheme.typography.labelSmall,
                color = color,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}

// ── Release status card ────────────────────────────────────────────────────────

@Composable
private fun ReleaseStatusCard() {
    val infiniteTransition = rememberInfiniteTransition(label = "rc_pulse")
    val borderAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue  = 0.7f,
        animationSpec = infiniteRepeatable(
            animation  = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rc_border_alpha"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DsSpacing.l)
            .border(
                width = 2.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        ScoutGreenBright.copy(alpha = borderAlpha),
                        NeonCyan.copy(alpha = borderAlpha),
                        ScoutGreenBright.copy(alpha = borderAlpha)
                    )
                ),
                shape = MaterialTheme.shapes.large
            ),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.raised),
        colors    = CardDefaults.cardColors(
            containerColor = ScoutGreenBright.copy(alpha = 0.06f)
        ),
        shape = MaterialTheme.shapes.large
    ) {
        Column(modifier = Modifier.padding(DsSpacing.l)) {
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                Surface(
                    color    = ScoutGreenBright.copy(alpha = 0.18f),
                    shape    = CircleShape,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            Icons.Default.Verified,
                            contentDescription = null,
                            tint     = ScoutGreenBright,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Column {
                    Text(
                        stringResource(R.string.release_status_title),
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = ScoutGreenBright
                    )
                    Text(
                        stringResource(R.string.release_status_subtitle),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.height(DsSpacing.m))

            Text(
                stringResource(R.string.release_status_body),
                style      = MaterialTheme.typography.bodySmall,
                color      = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                lineHeight = 18.sp
            )

            Spacer(Modifier.height(DsSpacing.m))

            Column(verticalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                FeatureProgressRow(label = stringResource(R.string.release_feature_core),   progress = 1.00f, color = ScoutGreenBright)
                FeatureProgressRow(label = stringResource(R.string.release_feature_ui),     progress = 0.95f, color = NeonCyan)
                FeatureProgressRow(label = stringResource(R.string.release_feature_voice),  progress = 0.98f, color = ScoutAmberWarm)
                FeatureProgressRow(label = stringResource(R.string.release_feature_map),    progress = 0.90f, color = CategoryGrocery)
                FeatureProgressRow(label = stringResource(R.string.release_feature_routes), progress = 0.85f, color = CategoryRetail)
                FeatureProgressRow(label = stringResource(R.string.release_feature_tire),   progress = 0.95f, color = TireTireShop)
            }
        }
    }
}

@Composable
private fun FeatureProgressRow(
    label: String,
    progress: Float,
    color: Color
) {
    var triggered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { triggered = true }
    val animatedProgress by animateFloatAsState(
        targetValue   = if (triggered) progress else 0f,
        animationSpec = tween(durationMillis = 900, delayMillis = 150, easing = FastOutSlowInEasing),
        label         = "feature_progress_$label"
    )

    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
            )
            Text(
                if (progress >= 1.0f) "✓" else "${(progress * 100).toInt()}%",
                style = MaterialTheme.typography.labelSmall,
                color = color
            )
        }
        LinearProgressIndicator(
            progress    = { animatedProgress },
            modifier    = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(DsRadius.pill)),
            color       = color,
            trackColor  = color.copy(alpha = 0.12f)
        )
    }
}

// ── Tech stack section ─────────────────────────────────────────────────────────

@Composable
private fun TechStackSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DsSpacing.l),
        verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
    ) {
        Text(
            "BUILT WITH",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            letterSpacing = 2.sp,
            modifier = Modifier.padding(bottom = DsSpacing.xs)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            TechBadge(label = "Kotlin",   color = CategoryRetail,     modifier = Modifier.weight(1f))
            TechBadge(label = "Compose",  color = CategoryPharmacy,   modifier = Modifier.weight(1f))
            TechBadge(label = "Material 3", color = ScoutGreenBright, modifier = Modifier.weight(1f))
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            TechBadge(label = "Room DB",  color = CategoryGrocery,    modifier = Modifier.weight(1f))
            TechBadge(label = "Hilt DI",  color = ScoutAmberWarm,     modifier = Modifier.weight(1f))
            TechBadge(label = "MVVM",     color = CategoryBakery,     modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun TechBadge(
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = color.copy(alpha = 0.10f),
        shape = RoundedCornerShape(DsRadius.pill),
        modifier = modifier
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
            color = color,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = DsSpacing.m, vertical = DsSpacing.s)
        )
    }
}

// ── Version footer ─────────────────────────────────────────────────────────────

@Composable
private fun VersionFooter() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(DsSpacing.xs)
    ) {
        HorizontalDivider(
            modifier = Modifier
                .fillMaxWidth(0.3f)
                .padding(bottom = DsSpacing.s),
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f)
        )
        Text(
            "v1.0.0-beta",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
        )
        Text(
            "Made with 🧤 and late nights",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
        )
        Text(
            "© 2024 Jack Sodeman-Dickey",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
        )
    }
}

// ── Previews ───────────────────────────────────────────────────────────────────

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "About dark")
@Composable
private fun AboutDarkPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        AboutScreen(onNavigateBack = {})
    }
}

@Preview(showBackground = true, name = "About light")
@Composable
private fun AboutLightPreview() {
    DumpsterScoutTheme(darkTheme = false) {
        AboutScreen(onNavigateBack = {})
    }
}
