package com.dumpsterscout.ui.tire

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.TireSpotCategory
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.EmptyStatePanel
import com.dumpsterscout.ui.components.LoadingShimmerCard
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.DumpsterScoutTheme
import com.dumpsterscout.util.SampleData

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TireSpotListScreen(
    onNavigateBack: () -> Unit,
    onNavigateToTireSpotDetail: (Long) -> Unit,
    onNavigateToAddTireSpot: () -> Unit,
    viewModel: TireSpotViewModel = hiltViewModel()
) {
    val uiState by viewModel.listState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.tire_spots_count_title, uiState.filteredSpots.size),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                },
                actions = {
                    IconButton(onClick = viewModel::toggleFiltersVisible) {
                        Icon(
                            if (uiState.showFilters) Icons.Default.FilterListOff else Icons.Default.FilterList,
                            stringResource(R.string.cd_filter_toggle)
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick        = onNavigateToAddTireSpot,
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor   = MaterialTheme.colorScheme.onPrimaryContainer
            ) {
                Icon(Icons.Default.Add, contentDescription = stringResource(R.string.cd_add_button))
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            OutlinedTextField(
                value         = uiState.searchQuery,
                onValueChange = viewModel::onSearchQueryChange,
                modifier      = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = DsSpacing.l, vertical = DsSpacing.s),
                placeholder   = { Text(stringResource(R.string.search_tire_spots)) },
                leadingIcon   = { Icon(Icons.Default.Search, null) },
                trailingIcon  = if (uiState.searchQuery.isNotEmpty()) {
                    {
                        IconButton(onClick = { viewModel.onSearchQueryChange("") }) {
                            Icon(Icons.Default.Clear, stringResource(R.string.clear_search))
                        }
                    }
                } else null,
                singleLine    = true,
                shape         = MaterialTheme.shapes.medium
            )

            AnimatedVisibility(
                visible = uiState.showFilters,
                enter   = fadeIn() + expandVertically(),
                exit    = fadeOut() + shrinkVertically()
            ) {
                TireFilterRow(
                    filterCategory    = uiState.filterCategory,
                    filterStatus      = uiState.filterStatus,
                    showFavoritesOnly = uiState.showFavoritesOnly,
                    onCategoryChange  = viewModel::onFilterCategoryChange,
                    onStatusChange    = viewModel::onFilterStatusChange,
                    onFavoritesChange = viewModel::onShowFavoritesOnlyChange
                )
            }

            when {
                uiState.isLoading -> {
                    Column(
                        modifier = Modifier.padding(DsSpacing.l),
                        verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) { repeat(4) { LoadingShimmerCard() } }
                }
                uiState.filteredSpots.isEmpty() -> {
                    EmptyStatePanel(
                        message  = if (uiState.spots.isEmpty())
                            stringResource(R.string.no_tire_spots_yet)
                        else
                            stringResource(R.string.no_tire_spots_match),
                        icon     = if (uiState.spots.isEmpty())
                            Icons.Default.AddLocation
                        else
                            Icons.Default.SearchOff,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                else -> {
                    LazyColumn(
                        contentPadding      = PaddingValues(horizontal = DsSpacing.l, vertical = DsSpacing.s),
                        verticalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) {
                        items(uiState.filteredSpots, key = { it.id }) { spot ->
                            TireSpotCard(
                                spot             = spot,
                                onClick          = { onNavigateToTireSpotDetail(spot.id) },
                                onToggleFavorite = { viewModel.toggleFavorite(spot.id) }
                            )
                        }
                        item { Spacer(Modifier.height(DsSpacing.giant + DsSpacing.l)) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TireFilterRow(
    filterCategory: TireSpotCategory?,
    filterStatus: TireSpotStatus?,
    showFavoritesOnly: Boolean,
    onCategoryChange: (TireSpotCategory?) -> Unit,
    onStatusChange: (TireSpotStatus?) -> Unit,
    onFavoritesChange: (Boolean) -> Unit
) {
    var showCategoryMenu by remember { mutableStateOf(false) }
    var showStatusMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DsSpacing.l, vertical = DsSpacing.xs),
        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
    ) {
        FilterChip(
            selected    = showFavoritesOnly,
            onClick     = { onFavoritesChange(!showFavoritesOnly) },
            label       = { Text(stringResource(R.string.filter_favorites)) },
            leadingIcon = if (showFavoritesOnly) {
                { Icon(Icons.Default.Favorite, null, modifier = Modifier.size(16.dp)) }
            } else null
        )

        Box {
            FilterChip(
                selected = filterCategory != null,
                onClick  = { showCategoryMenu = true },
                label    = {
                    Text(
                        filterCategory?.name?.lowercase()?.replace('_', ' ')?.replaceFirstChar { it.uppercaseChar() }
                            ?: stringResource(R.string.filter_category)
                    )
                }
            )
            DropdownMenu(expanded = showCategoryMenu, onDismissRequest = { showCategoryMenu = false }) {
                DropdownMenuItem(
                    text    = { Text(stringResource(R.string.filter_all_categories)) },
                    onClick = { onCategoryChange(null); showCategoryMenu = false }
                )
                TireSpotCategory.entries.forEach { cat ->
                    DropdownMenuItem(
                        text    = { Text(cat.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }) },
                        onClick = { onCategoryChange(cat); showCategoryMenu = false }
                    )
                }
            }
        }

        Box {
            FilterChip(
                selected = filterStatus != null,
                onClick  = { showStatusMenu = true },
                label    = {
                    Text(
                        filterStatus?.name?.lowercase()?.replace('_', ' ')?.replaceFirstChar { it.uppercaseChar() }
                            ?: stringResource(R.string.filter_status)
                    )
                }
            )
            DropdownMenu(expanded = showStatusMenu, onDismissRequest = { showStatusMenu = false }) {
                DropdownMenuItem(
                    text    = { Text(stringResource(R.string.filter_all_statuses)) },
                    onClick = { onStatusChange(null); showStatusMenu = false }
                )
                listOf(
                    TireSpotStatus.GOOD_USABLE,
                    TireSpotStatus.MANY_OUT,
                    TireSpotStatus.ALL_PUNCTURED,
                    TireSpotStatus.NO_TIRES,
                    TireSpotStatus.LOCKED_INACCESSIBLE
                ).forEach { st ->
                    DropdownMenuItem(
                        text    = { Text(st.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }) },
                        onClick = { onStatusChange(st); showStatusMenu = false }
                    )
                }
            }
        }
    }
}

// ── Previews ──────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "TireSpotList – filled (dark)")
@Composable
private fun TireSpotListFilledPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title = "Tire Spots (4)",
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                contentPadding      = PaddingValues(horizontal = DsSpacing.l, vertical = DsSpacing.s),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.s),
                modifier            = Modifier.padding(padding)
            ) {
                items(SampleData.tireSpots, key = { it.id }) { spot ->
                    TireSpotCard(spot = spot, onClick = {}, onToggleFavorite = {})
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, name = "TireSpotList – empty")
@Composable
private fun TireSpotListEmptyPreview() {
    DumpsterScoutTheme {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title = "Tire Spots (0)",
                    navigationIcon = {
                        IconButton(onClick = {}) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                    }
                )
            }
        ) { padding ->
            EmptyStatePanel(
                message  = "No tire spots match your search.",
                icon     = Icons.Default.SearchOff,
                modifier = Modifier.fillMaxSize().padding(padding)
            )
        }
    }
}
