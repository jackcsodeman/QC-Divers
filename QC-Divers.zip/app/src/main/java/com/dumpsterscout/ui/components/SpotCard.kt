package com.dumpsterscout.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.SpotCategory
import com.dumpsterscout.domain.model.SyncStatus
import com.dumpsterscout.domain.model.Visibility
import com.dumpsterscout.ui.theme.*
import com.dumpsterscout.util.SampleData
import com.dumpsterscout.util.timeAgoString

/** Maps a [SpotCategory] to its distinctive accent color. */
fun categoryColor(category: SpotCategory): Color = when (category) {
    SpotCategory.GROCERY          -> CategoryGrocery
    SpotCategory.BAKERY           -> CategoryBakery
    SpotCategory.PHARMACY         -> CategoryPharmacy
    SpotCategory.RETAIL           -> CategoryRetail
    SpotCategory.RESTAURANT       -> CategoryRestaurant
    SpotCategory.APARTMENT_COMPLEX -> CategoryApartment
    SpotCategory.OFFICE           -> CategoryOffice
    SpotCategory.WAREHOUSE        -> CategoryWarehouse
    SpotCategory.ELECTRONICS      -> CategoryElectronics
    SpotCategory.FURNITURE        -> CategoryFurniture
    SpotCategory.OTHER            -> CategoryOther
}

/**
 * Spot summary card with a left-side category-color accent strip for instant
 * visual identification at a glance.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpotCard(
    spot: DumpsterSpot,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (statusLabel, _) = statusDisplay(spot.lastStatus)
    val cd = stringResource(R.string.cd_spot_card, spot.name, statusLabel)
    val accentColor = categoryColor(spot.category)

    // Animate the favorite icon color for tactile feedback.
    val favTint by animateColorAsState(
        targetValue = if (spot.isFavorite) MaterialTheme.colorScheme.primary
                      else MaterialTheme.colorScheme.onSurfaceVariant,
        animationSpec = tween(DsMotion.medium),
        label = "fav_tint"
    )

    Card(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .semantics { contentDescription = cd },
        elevation = CardDefaults.cardElevation(
            defaultElevation = DsElevation.card,
            pressedElevation  = DsElevation.subtle
        ),
        colors = CardDefaults.cardColors(
            containerColor = ScoutSurface2
        ),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.25f)),
        shape = MaterialTheme.shapes.medium
    ) {
        Row {
            // ── Category accent strip ────────────────────────────────────────
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .fillMaxHeight()
                    .clip(MaterialTheme.shapes.medium)
                    .background(accentColor)
            )

            // ── Card content ─────────────────────────────────────────────────
            Column(modifier = Modifier.padding(DsSpacing.l)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        // Name + badges row
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)
                        ) {
                            Text(
                                text = spot.name,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            if (spot.isVerified) {
                                Icon(
                                    Icons.Default.Verified,
                                    contentDescription = stringResource(R.string.cd_spot_verified),
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                            if (spot.isLocked) {
                                Icon(
                                    Icons.Default.Lock,
                                    contentDescription = stringResource(R.string.cd_spot_locked),
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                        // Category + address
                        val categoryLabel = spot.category.name
                            .lowercase().replaceFirstChar { it.uppercaseChar() }
                        val subtitle = if (spot.address.isNotBlank()) spot.address else categoryLabel
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Favorite toggle
                    val favCd = stringResource(R.string.cd_favorite_button, spot.name)
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier.semantics { contentDescription = favCd }
                    ) {
                        Icon(
                            imageVector = if (spot.isFavorite) Icons.Default.Favorite
                                          else Icons.Default.FavoriteBorder,
                            contentDescription = null,
                            tint = favTint
                        )
                    }
                }

                Spacer(Modifier.height(DsSpacing.s))

                // Status + grade + timestamp row
                Row(
                    horizontalArrangement = Arrangement.spacedBy(DsSpacing.s),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusChip(status = spot.lastStatus)
                    if (spot.grade.isGraded()) {
                        GradeScoreBadge(overall = spot.grade.overall)
                    }
                    Spacer(Modifier.weight(1f))
                    // Sync / visibility micro-badge
                    val (syncIcon, syncCd) = when (spot.syncStatus) {
                        SyncStatus.LOCAL_ONLY   -> Pair(Icons.Default.CloudOff, stringResource(R.string.sync_status_local_only))
                        SyncStatus.PENDING_SYNC -> Pair(Icons.Default.CloudSync, stringResource(R.string.sync_status_pending))
                        SyncStatus.SYNCED       -> if (spot.visibility == Visibility.COMMUNITY)
                            Pair(Icons.Default.People, stringResource(R.string.visibility_community))
                        else
                            Pair(Icons.Default.Cloud, stringResource(R.string.sync_status_synced))
                        SyncStatus.SYNC_FAILED  -> Pair(Icons.Default.Warning, stringResource(R.string.sync_status_failed))
                        SyncStatus.CONFLICT     -> Pair(Icons.Default.Warning, stringResource(R.string.sync_status_conflict))
                    }
                    val syncTint = when (spot.syncStatus) {
                        SyncStatus.SYNCED       -> MaterialTheme.colorScheme.primary
                        SyncStatus.PENDING_SYNC -> MaterialTheme.colorScheme.tertiary
                        SyncStatus.SYNC_FAILED,
                        SyncStatus.CONFLICT     -> MaterialTheme.colorScheme.error
                        SyncStatus.LOCAL_ONLY   -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    Icon(
                        imageVector        = syncIcon,
                        contentDescription = syncCd,
                        modifier           = Modifier.size(14.dp),
                        tint               = syncTint
                    )
                    spot.lastChecked?.let { ts ->
                        Text(
                            text = timeAgoString(ts),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Tags (up to 3)
                if (spot.tags.isNotEmpty()) {
                    Spacer(Modifier.height(DsSpacing.s))
                    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)) {
                        spot.tags.take(3).forEach { tag ->
                            SuggestionChip(
                                onClick = {},
                                label = { Text(tag, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.height(24.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ── Previews ──────────────────────────────────────────────────────────────────

@Preview(showBackground = true, backgroundColor = 0xFF12141A)
@Composable
private fun SpotCardDarkPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        SpotCard(
            spot = SampleData.spots.first(),
            onClick = {},
            onToggleFavorite = {}
        )
    }
}

@Preview(showBackground = true)
@Composable
private fun SpotCardLightPreview() {
    DumpsterScoutTheme(darkTheme = false) {
        SpotCard(
            spot = SampleData.spots.first(),
            onClick = {},
            onToggleFavorite = {}
        )
    }
}
