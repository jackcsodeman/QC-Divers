package com.dumpsterscout.ui.gear

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.dumpsterscout.R
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.theme.*

private data class GearItem(val id: Int, val label: String, val emoji: String, val category: String = "Essential")

private val defaultGear = listOf(
    GearItem(0,  "Gloves",                 "🧤", "Safety"),
    GearItem(1,  "Grabber / Reaching tool","🔧", "Tools"),
    GearItem(2,  "Flashlight / Headlamp",  "🔦", "Lighting"),
    GearItem(3,  "Extra bags / totes",      "🛍", "Carry"),
    GearItem(4,  "Hand sanitizer",          "🧴", "Safety"),
    GearItem(5,  "Containers / bins",       "📦", "Carry"),
    GearItem(6,  "Water bottle",            "💧", "Essential"),
    GearItem(7,  "Knife / box cutter",      "🔪", "Tools"),
    GearItem(8,  "Rain gear / poncho",      "🌧",  "Weather"),
    GearItem(9,  "Boots",                   "👢", "Safety")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GearChecklistScreen(onNavigateBack: () -> Unit) {
    var checkedItems by remember { mutableStateOf(setOf<Int>()) }
    val progress = if (defaultGear.isEmpty()) 0f else checkedItems.size.toFloat() / defaultGear.size
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(DsMotion.medium),
        label = "gear_progress"
    )
    val allDone = checkedItems.size == defaultGear.size

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title    = stringResource(R.string.gear_checklist),
                subtitle = stringResource(R.string.gear_packed_subtitle, checkedItems.size, defaultGear.size),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                },
                actions = {
                    TextButton(
                        onClick  = { checkedItems = emptySet() },
                        enabled  = checkedItems.isNotEmpty()
                    ) { Text(stringResource(R.string.gear_reset)) }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // ── Progress section ───────────────────────────────────────────
            Column(
                modifier = Modifier.padding(horizontal = DsSpacing.l, vertical = DsSpacing.s)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val progressColor = when {
                        allDone         -> GradeHigh
                        progress >= 0.5f -> GradeMid
                        else            -> MaterialTheme.colorScheme.primary
                    }
                    Text(
                        if (allDone) stringResource(R.string.gear_all_packed)
                        else stringResource(R.string.gear_packed_progress, (progress * 100).toInt()),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (allDone) GradeHigh else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(DsSpacing.xs))
                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(MaterialTheme.shapes.small),
                    color    = when {
                        allDone         -> GradeHigh
                        progress >= 0.5f -> GradeMid
                        else            -> MaterialTheme.colorScheme.primary
                    },
                    trackColor = GradeTrack
                )
            }

            // ── All-done banner ────────────────────────────────────────────
            if (allDone) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = DsSpacing.l, vertical = DsSpacing.xs),
                    colors = CardDefaults.cardColors(
                        containerColor = GradeHigh.copy(alpha = 0.15f)
                    ),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Row(
                        modifier = Modifier.padding(DsSpacing.m),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = stringResource(R.string.cd_all_items_checked), tint = GradeHigh, modifier = Modifier.size(20.dp))
                        Text(
                            stringResource(R.string.gear_all_packed_message),
                            style = MaterialTheme.typography.bodyMedium,
                            color = GradeHigh
                        )
                    }
                }
            }

            // ── Checklist ──────────────────────────────────────────────────
            LazyColumn(
                contentPadding = PaddingValues(
                    start  = DsSpacing.l,
                    end    = DsSpacing.l,
                    top    = DsSpacing.s,
                    bottom = DsSpacing.xxxl
                ),
                verticalArrangement = Arrangement.spacedBy(DsSpacing.xs)
            ) {
                items(defaultGear, key = { it.id }) { item ->
                    GearChecklistItem(
                        item      = item,
                        checked   = item.id in checkedItems,
                        onToggle  = { checked ->
                            checkedItems = if (checked) checkedItems + item.id else checkedItems - item.id
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GearChecklistItem(
    item: GearItem,
    checked: Boolean,
    onToggle: (Boolean) -> Unit
) {
    val bgColor by animateColorAsState(
        targetValue = if (checked) GradeHigh.copy(alpha = 0.08f)
                      else ScoutSurface2,
        animationSpec = tween(DsMotion.fast),
        label = "gear_item_bg"
    )
    val textColor by animateColorAsState(
        targetValue = if (checked) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                      else MaterialTheme.colorScheme.onSurface,
        animationSpec = tween(DsMotion.fast),
        label = "gear_item_text"
    )

    Card(
        onClick    = { onToggle(!checked) },
        colors     = CardDefaults.cardColors(containerColor = bgColor),
        elevation  = CardDefaults.cardElevation(defaultElevation = if (checked) DsElevation.none else DsElevation.subtle),
        shape      = MaterialTheme.shapes.medium,
        modifier   = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(DsSpacing.m),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            // Emoji badge
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Text(item.emoji, style = MaterialTheme.typography.titleMedium)
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    item.label,
                    style          = MaterialTheme.typography.bodyMedium,
                    color          = textColor,
                    textDecoration = if (checked) TextDecoration.LineThrough else TextDecoration.None
                )
                Text(
                    item.category,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = if (checked) 0.4f else 0.7f)
                )
            }

            // Checkbox
            Checkbox(
                checked         = checked,
                onCheckedChange = onToggle,
                colors          = CheckboxDefaults.colors(
                    checkedColor = GradeHigh,
                    checkmarkColor = Color.White
                )
            )
        }
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "GearChecklist dark")
@Composable
private fun GearChecklistPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        GearChecklistScreen(onNavigateBack = {})
    }
}
