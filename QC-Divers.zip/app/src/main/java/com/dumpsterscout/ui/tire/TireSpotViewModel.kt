package com.dumpsterscout.ui.tire

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.PuncturePattern
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireSpotCategory
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.domain.repository.TireReportRepository
import com.dumpsterscout.domain.repository.TireSpotRepository
import com.dumpsterscout.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class TireSpotListUiState(
    val spots: List<TireSpot> = emptyList(),
    val filteredSpots: List<TireSpot> = emptyList(),
    val isLoading: Boolean = true,
    val searchQuery: String = "",
    val filterCategory: TireSpotCategory? = null,
    val filterStatus: TireSpotStatus? = null,
    val showFavoritesOnly: Boolean = false,
    val showFilters: Boolean = false,
    val error: String? = null
)

data class TireSpotDetailUiState(
    val spot: TireSpot? = null,
    val reports: List<TireReport> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null,
    val showDeleteDialog: Boolean = false,
    val isDeleted: Boolean = false,
    val isOwner: Boolean = true,
    val publishedSuccessfully: Boolean = false
)

data class AddTireSpotUiState(
    val spot: TireSpot = TireSpot(name = ""),
    val isLoading: Boolean = false,
    val isSaved: Boolean = false,
    val savedId: Long? = null,
    val error: String? = null
)

data class TireReportUiState(
    val report: TireReport = TireReport(tireSpotId = 0),
    val spotName: String = "",
    val isLoading: Boolean = false,
    val isSaved: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class TireSpotViewModel @Inject constructor(
    private val tireSpotRepository: TireSpotRepository,
    private val tireReportRepository: TireReportRepository,
    private val userRepository: UserRepository
) : ViewModel() {

    // ── Spot List ──────────────────────────────────────────────────────────────
    private val _listState = MutableStateFlow(TireSpotListUiState())
    val listState: StateFlow<TireSpotListUiState> = _listState.asStateFlow()

    // ── Spot Detail ────────────────────────────────────────────────────────────
    private val _detailState = MutableStateFlow(TireSpotDetailUiState())
    val detailState: StateFlow<TireSpotDetailUiState> = _detailState.asStateFlow()

    // ── Add/Edit Spot ──────────────────────────────────────────────────────────
    private val _addState = MutableStateFlow(AddTireSpotUiState())
    val addState: StateFlow<AddTireSpotUiState> = _addState.asStateFlow()

    // ── Quick Report ───────────────────────────────────────────────────────────
    private val _reportState = MutableStateFlow(TireReportUiState())
    val reportState: StateFlow<TireReportUiState> = _reportState.asStateFlow()

    init {
        loadTireSpots()
    }

    private fun loadTireSpots() {
        viewModelScope.launch {
            try {
                tireSpotRepository.getActiveSpots().collect { spots ->
                    _listState.update { state ->
                        val filtered = applyListFilters(
                            spots, state.searchQuery, state.filterCategory,
                            state.filterStatus, state.showFavoritesOnly
                        )
                        state.copy(spots = spots, filteredSpots = filtered, isLoading = false)
                    }
                }
            } catch (e: Exception) {
                _listState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
    }

    fun onSearchQueryChange(query: String) {
        _listState.update { state ->
            val filtered = applyListFilters(
                state.spots, query, state.filterCategory,
                state.filterStatus, state.showFavoritesOnly
            )
            state.copy(searchQuery = query, filteredSpots = filtered)
        }
    }

    fun onFilterCategoryChange(category: TireSpotCategory?) {
        _listState.update { state ->
            val filtered = applyListFilters(
                state.spots, state.searchQuery, category,
                state.filterStatus, state.showFavoritesOnly
            )
            state.copy(filterCategory = category, filteredSpots = filtered)
        }
    }

    fun onFilterStatusChange(status: TireSpotStatus?) {
        _listState.update { state ->
            val filtered = applyListFilters(
                state.spots, state.searchQuery, state.filterCategory,
                status, state.showFavoritesOnly
            )
            state.copy(filterStatus = status, filteredSpots = filtered)
        }
    }

    fun onShowFavoritesOnlyChange(show: Boolean) {
        _listState.update { state ->
            val filtered = applyListFilters(
                state.spots, state.searchQuery, state.filterCategory,
                state.filterStatus, show
            )
            state.copy(showFavoritesOnly = show, filteredSpots = filtered)
        }
    }

    fun toggleFiltersVisible() {
        _listState.update { it.copy(showFilters = !it.showFilters) }
    }

    private fun applyListFilters(
        spots: List<TireSpot>,
        query: String,
        category: TireSpotCategory?,
        status: TireSpotStatus?,
        favoritesOnly: Boolean
    ): List<TireSpot> = spots.filter { spot ->
        (query.isBlank() || spot.name.contains(query, ignoreCase = true) ||
                spot.address.contains(query, ignoreCase = true) ||
                spot.tags.any { it.contains(query, ignoreCase = true) }) &&
                (category == null || spot.category == category) &&
                (status == null || spot.lastStatus == status) &&
                (!favoritesOnly || spot.isFavorite)
    }

    // ── Detail ─────────────────────────────────────────────────────────────────
    fun loadTireSpotDetail(spotId: Long) {
        viewModelScope.launch {
            try {
                _detailState.update { it.copy(isLoading = true) }
                val spot = tireSpotRepository.getSpotById(spotId)
                val localUserId = userRepository.getCurrentUser().first().localId
                val isOwner = spot != null && (spot.ownerUserId == null || spot.ownerUserId == localUserId)
                _detailState.update { it.copy(spot = spot, isOwner = isOwner, isLoading = false) }
            } catch (e: Exception) {
                _detailState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
        viewModelScope.launch {
            try {
                tireReportRepository.getReportsBySpot(spotId).collect { reports ->
                    _detailState.update { it.copy(reports = reports) }
                }
            } catch (e: Exception) {
                _detailState.update { it.copy(error = e.message ?: "An unexpected error occurred") }
            }
        }
    }

    fun toggleFavorite(spotId: Long) {
        viewModelScope.launch {
            try {
                tireSpotRepository.toggleFavorite(spotId)
            } catch (e: Exception) {
                _detailState.update { it.copy(error = e.message ?: "An unexpected error occurred") }
            }
        }
    }

    fun updateStatus(spotId: Long, status: TireSpotStatus) {
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                tireSpotRepository.updateLastStatus(spotId, status, now)
                _detailState.update { state ->
                    state.copy(spot = state.spot?.copy(lastStatus = status, lastChecked = now))
                }
            } catch (e: Exception) {
                _detailState.update { it.copy(error = e.message ?: "An unexpected error occurred") }
            }
        }
    }

    fun showDeleteDialog(show: Boolean) {
        _detailState.update { it.copy(showDeleteDialog = show) }
    }

    fun clearDetailError() {
        _detailState.update { it.copy(error = null) }
    }

    fun publishSpot() {
        viewModelScope.launch {
            try {
                val spot = _detailState.value.spot ?: return@launch
                tireSpotRepository.publishSpot(spot.id)
                _detailState.update { it.copy(publishedSuccessfully = true) }
            } catch (e: Exception) {
                _detailState.update { it.copy(error = e.message ?: "Failed to publish spot") }
            }
        }
    }

    fun clearPublishedFlag() {
        _detailState.update { it.copy(publishedSuccessfully = false) }
    }

    /** Re-queue a failed tire spot sync by re-saving it with PENDING_SYNC status. */
    fun retrySyncSpot() {
        viewModelScope.launch {
            try {
                val spot = _detailState.value.spot ?: return@launch
                // upsertSpot stamps PENDING_SYNC when credentials are configured
                tireSpotRepository.upsertSpot(spot)
                // Reload so the chip reflects the new status
                loadTireSpotDetail(spot.id)
            } catch (e: Exception) {
                _detailState.update { it.copy(error = e.message ?: "Failed to queue retry") }
            }
        }
    }

    fun deleteSpot() {
        viewModelScope.launch {
            try {
                val spot = _detailState.value.spot ?: return@launch
                tireSpotRepository.deleteSpot(spot)
                _detailState.update { it.copy(isDeleted = true) }
            } catch (e: Exception) {
                _detailState.update { it.copy(error = e.message ?: "An unexpected error occurred") }
            }
        }
    }

    // ── Add/Edit ───────────────────────────────────────────────────────────────
    fun loadSpotForEdit(spotId: Long?) {
        if (spotId == null) {
            _addState.value = AddTireSpotUiState()
            return
        }
        viewModelScope.launch {
            try {
                _addState.update { it.copy(isLoading = true) }
                val spot = tireSpotRepository.getSpotById(spotId)
                _addState.update { it.copy(spot = spot ?: TireSpot(name = ""), isLoading = false) }
            } catch (e: Exception) {
                _addState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
    }

    fun updateField(update: (TireSpot) -> TireSpot) {
        _addState.update { it.copy(spot = update(it.spot)) }
    }

    fun saveSpot() {
        viewModelScope.launch {
            try {
                _addState.update { it.copy(isLoading = true) }
                val id = tireSpotRepository.upsertSpot(_addState.value.spot)
                _addState.update { it.copy(isLoading = false, isSaved = true, savedId = id) }
            } catch (e: Exception) {
                _addState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
    }

    fun clearSaved() {
        _addState.update { it.copy(isSaved = false, savedId = null) }
    }

    fun clearAddError() {
        _addState.update { it.copy(error = null) }
    }

    // ── Quick Report ───────────────────────────────────────────────────────────
    fun initReport(spotId: Long, spotName: String) {
        _reportState.value = TireReportUiState(
            report = TireReport(tireSpotId = spotId),
            spotName = spotName
        )
    }

    fun updateReportField(update: (TireReport) -> TireReport) {
        _reportState.update { it.copy(report = update(it.report)) }
    }

    fun saveReport() {
        viewModelScope.launch {
            try {
                _reportState.update { it.copy(isLoading = true) }
                val report = _reportState.value.report
                tireReportRepository.insertReport(report)
                // Also update the spot's last status and last checked time
                if (report.status != TireSpotStatus.UNKNOWN) {
                    tireSpotRepository.updateLastStatus(
                        report.tireSpotId, report.status, report.timestamp
                    )
                }
                _reportState.update { it.copy(isLoading = false, isSaved = true) }
            } catch (e: Exception) {
                _reportState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
    }

    fun clearReportSaved() {
        _reportState.update { it.copy(isSaved = false) }
    }
}
