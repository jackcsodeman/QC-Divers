package com.dumpsterscout.ui.tire

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireVoiceParseResult
import com.dumpsterscout.domain.repository.TireReportRepository
import com.dumpsterscout.domain.repository.TireSpotRepository
import com.dumpsterscout.util.TireVoiceParser
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class TireVoicePhase { IDLE, LISTENING, PROCESSING, CONFIRM, EDIT, SAVED }

data class TireVoiceUiState(
    val phase: TireVoicePhase = TireVoicePhase.IDLE,
    val parseResult: TireVoiceParseResult? = null,
    val matchedSpot: TireSpot? = null,
    val candidateSpots: List<TireSpot> = emptyList(),
    val editableTranscript: String = "",
    val editableNotes: String = "",
    val preselectedSpotId: Long? = null,
    val reportSaved: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class TireVoiceViewModel @Inject constructor(
    private val tireSpotRepository: TireSpotRepository,
    private val tireReportRepository: TireReportRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(TireVoiceUiState())
    val uiState: StateFlow<TireVoiceUiState> = _uiState.asStateFlow()

    /** Tracks the active parse job so it can be cancelled before starting a new one. */
    private var parseJob: Job? = null

    /** Optionally pre-select a spot (when launched from TireSpotDetailScreen) */
    fun preSelectSpot(spotId: Long) {
        _uiState.update { it.copy(preselectedSpotId = spotId) }
        viewModelScope.launch {
            val spot = tireSpotRepository.getActiveSpots().first().find { it.id == spotId }
            if (spot != null) _uiState.update { it.copy(matchedSpot = spot) }
        }
    }

    fun onStartListening() {
        _uiState.update { it.copy(phase = TireVoicePhase.LISTENING, error = null) }
    }

    fun onListeningCancelled() {
        _uiState.update { it.copy(phase = TireVoicePhase.IDLE) }
    }

    fun onTranscriptReceived(transcript: String) {
        if (transcript.isBlank()) {
            _uiState.update { it.copy(phase = TireVoicePhase.IDLE, error = "No speech detected.") }
            return
        }
        _uiState.update { it.copy(phase = TireVoicePhase.PROCESSING, editableTranscript = transcript) }

        parseJob?.cancel()
        parseJob = viewModelScope.launch {
            val rawResult = TireVoiceParser.parse(transcript)
            val allSpots = tireSpotRepository.getActiveSpots().first()

            // Use pre-selected spot as nearest hint
            val nearestId = _uiState.value.preselectedSpotId
            val resolved = TireVoiceParser.resolveSpot(rawResult, allSpots, nearestId)

            val matchedSpot = resolved.matchedSpotId?.let { id ->
                allSpots.find { it.id == id }
            } ?: _uiState.value.matchedSpot   // keep preselected if no name match

            val candidates = resolved.candidateSpotIds.mapNotNull { id ->
                allSpots.find { it.id == id }
            }

            _uiState.update { state ->
                state.copy(
                    phase             = TireVoicePhase.CONFIRM,
                    parseResult       = resolved,
                    matchedSpot       = matchedSpot,
                    candidateSpots    = candidates,
                    editableTranscript = transcript,
                    editableNotes     = resolved.notes
                )
            }
        }
    }

    fun onTranscriptEdited(newTranscript: String) {
        parseJob?.cancel()
        parseJob = viewModelScope.launch {
            val reparsed = TireVoiceParser.parse(newTranscript)
            val allSpots = tireSpotRepository.getActiveSpots().first()
            val nearestId = _uiState.value.preselectedSpotId
            val resolved = TireVoiceParser.resolveSpot(reparsed, allSpots, nearestId)

            val matchedSpot = resolved.matchedSpotId?.let { id ->
                allSpots.find { it.id == id }
            }
            val candidates = resolved.candidateSpotIds.mapNotNull { id ->
                allSpots.find { it.id == id }
            }

            _uiState.update { state ->
                state.copy(
                    editableTranscript = newTranscript,
                    parseResult        = resolved,
                    matchedSpot        = matchedSpot ?: state.matchedSpot,
                    candidateSpots     = candidates.ifEmpty { state.candidateSpots },
                    editableNotes      = resolved.notes
                )
            }
        }
    }

    fun onNotesEdited(notes: String) {
        _uiState.update { it.copy(editableNotes = notes) }
    }

    fun onSelectSpot(spot: TireSpot) {
        _uiState.update { it.copy(matchedSpot = spot) }
    }

    fun saveReport() {
        val state = _uiState.value
        val spot = state.matchedSpot ?: return
        val result = state.parseResult ?: return

        viewModelScope.launch {
            try {
                val report = TireVoiceParser.toReport(
                    result    = result.copy(notes = state.editableNotes, rawTranscript = state.editableTranscript),
                    spotId    = spot.id,
                    spotName  = spot.name
                )
                tireReportRepository.insertReport(report)
                result.status?.let { status ->
                    tireSpotRepository.updateLastStatus(spot.id, status, System.currentTimeMillis())
                }
                _uiState.update { it.copy(phase = TireVoicePhase.SAVED, reportSaved = true) }
            } catch (e: Exception) {
                _uiState.update { it.copy(phase = TireVoicePhase.IDLE, error = "Save failed: ${e.message}") }
            }
        }
    }

    fun reset() {
        val preselected = _uiState.value.preselectedSpotId
        val matchedSpot = _uiState.value.matchedSpot.takeIf { _uiState.value.preselectedSpotId != null }
        _uiState.value = TireVoiceUiState(
            preselectedSpotId = preselected,
            matchedSpot       = matchedSpot
        )
    }
}
