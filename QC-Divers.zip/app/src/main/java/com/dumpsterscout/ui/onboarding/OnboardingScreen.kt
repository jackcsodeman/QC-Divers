package com.dumpsterscout.ui.onboarding

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.dumpsterscout.R
import com.dumpsterscout.ui.theme.*
import kotlinx.coroutines.launch

data class OnboardingPage(
    val title: String,
    val description: String,
    val emoji: String,
    /** Icon shown in the central badge (replaces the raw emoji in the rich version). */
    val icon: ImageVector = Icons.Default.Star,
    /** Gradient start color for this page's background. */
    val gradientStart: Color = ScoutSurface0,
    /** Gradient end color – creates the pager's distinct-per-page character. */
    val gradientEnd: Color = ScoutSurface3,
    /** Accent color for the icon badge and page indicator. */
    val accent: Color = ScoutGreenBright
)

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun OnboardingScreen(
    onFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pages = listOf(
        OnboardingPage(
            title         = stringResource(R.string.onboarding_title_1),
            description   = stringResource(R.string.onboarding_desc_1),
            emoji         = "📍",
            icon          = Icons.Default.Pin,
            gradientStart = ScoutSurface0,
            gradientEnd   = Color(0xFF0D2A1A),
            accent        = ScoutGreenBright
        ),
        OnboardingPage(
            title         = stringResource(R.string.onboarding_title_2),
            description   = stringResource(R.string.onboarding_desc_2),
            emoji         = "🎤",
            icon          = Icons.Default.Mic,
            gradientStart = ScoutSurface0,
            gradientEnd   = Color(0xFF1A1600),
            accent        = ScoutAmberWarm
        ),
        OnboardingPage(
            title         = stringResource(R.string.onboarding_title_3),
            description   = stringResource(R.string.onboarding_desc_3),
            emoji         = "🗺️",
            icon          = Icons.Default.Map,
            gradientStart = ScoutSurface0,
            gradientEnd   = Color(0xFF0A1A25),
            accent        = CategoryPharmacy
        )
    )

    val pagerState = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    val currentPage = pagerState.currentPage
    val currentAccent = pages[currentPage].accent

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(pages[currentPage].gradientStart, pages[currentPage].gradientEnd)
                )
            )
            .systemBarsPadding()
    ) {
        // Skip button
        TextButton(
            onClick  = onFinished,
            modifier = Modifier.align(Alignment.TopEnd).padding(DsSpacing.l)
        ) {
            Text(
                stringResource(R.string.skip),
                color = ScoutOnSurfaceDim
            )
        }

        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // ── Pager ──────────────────────────────────────────────────────
            HorizontalPager(
                state    = pagerState,
                modifier = Modifier.weight(1f)
            ) { page ->
                OnboardingPageContent(page = pages[page])
            }

            // ── Page indicators ────────────────────────────────────────────
            Row(
                modifier              = Modifier.padding(vertical = DsSpacing.l),
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                repeat(pages.size) { index ->
                    val isSelected = pagerState.currentPage == index
                    val dotWidth by animateDpAsState(
                        targetValue = if (isSelected) 24.dp else 6.dp,
                        animationSpec = spring(stiffness = Spring.StiffnessMedium),
                        label = "dot_width"
                    )
                    Box(
                        modifier = Modifier
                            .height(6.dp)
                            .width(dotWidth)
                            .clip(CircleShape)
                            .background(
                                if (isSelected) currentAccent
                                else MaterialTheme.colorScheme.outlineVariant
                            )
                    )
                }
            }

            // ── Navigation buttons ─────────────────────────────────────────
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = DsSpacing.xxl, vertical = DsSpacing.l),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                AnimatedContent(
                    targetState = currentPage > 0,
                    transitionSpec = { fadeIn(tween(DsMotion.fast)) togetherWith fadeOut(tween(DsMotion.fast)) },
                    label = "back_btn"
                ) { showBack ->
                    if (showBack) {
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    pagerState.animateScrollToPage(currentPage - 1)
                                }
                            }
                        ) {
                            Text(stringResource(R.string.cancel))
                        }
                    } else {
                        Spacer(Modifier.width(80.dp))
                    }
                }

                AnimatedContent(
                    targetState = currentPage < pages.size - 1,
                    transitionSpec = {
                        (slideInHorizontally { it } + fadeIn(tween(DsMotion.medium))) togetherWith
                            (slideOutHorizontally { -it } + fadeOut(tween(DsMotion.exit)))
                    },
                    label = "next_btn"
                ) { showNext ->
                    if (showNext) {
                        Button(
                            onClick = {
                                scope.launch {
                                    pagerState.animateScrollToPage(currentPage + 1)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = currentAccent)
                        ) {
                            Text(stringResource(R.string.next))
                        }
                    } else {
                        Button(
                            onClick = onFinished,
                            colors = ButtonDefaults.buttonColors(containerColor = currentAccent)
                        ) {
                            Text(stringResource(R.string.get_started))
                        }
                    }
                }
            }

            Spacer(Modifier.height(DsSpacing.l))
        }
    }
}

// ── Per-page content ───────────────────────────────────────────────────────────

@Composable
private fun OnboardingPageContent(page: OnboardingPage, modifier: Modifier = Modifier) {
    Column(
        modifier              = modifier
            .fillMaxSize()
            .padding(DsSpacing.xxxl),
        horizontalAlignment   = Alignment.CenterHorizontally,
        verticalArrangement   = Arrangement.Center
    ) {
        // Large icon badge with accent glow ring
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(120.dp)
                .clip(CircleShape)
                .background(page.accent.copy(alpha = 0.15f))
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(page.accent.copy(alpha = 0.25f))
            ) {
                Icon(
                    imageVector       = page.icon,
                    contentDescription = null,
                    tint              = page.accent,
                    modifier          = Modifier.size(40.dp)
                )
            }
        }

        Spacer(Modifier.height(DsSpacing.xxxl))

        Text(
            text      = page.title,
            style     = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center,
            color     = ScoutOnSurface
        )
        Spacer(Modifier.height(DsSpacing.l))
        Text(
            text      = page.description,
            style     = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color     = ScoutOnSurfaceDim
        )
    }
}

// ── Preview ────────────────────────────────────────────────────────────────────

@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "Onboarding dark")
@Composable
private fun OnboardingPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        OnboardingScreen(onFinished = {})
    }
}
