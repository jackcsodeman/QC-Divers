package com.dumpsterscout.ui.voice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.Notes
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.DumpsterSpot
import com.dumpsterscout.domain.model.FillLevel
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.domain.model.TimeRelevance
import com.dumpsterscout.domain.model.VoiceParseResult
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.StatusChip
import com.dumpsterscout.ui.components.categoryColor
import com.dumpsterscout.ui.components.statusDisplay
import com.dumpsterscout.ui.theme.*
import com.dumpsterscout.util.SampleData
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun VoiceReportScreen(
    onNavigateBack: () -> Unit,
    onReportSaved: () -> Unit,
    viewModel: VoiceViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val micPermission = rememberPermissionState(Manifest.permission.RECORD_AUDIO)

    // Auto-navigate after saved phase shows for 1.5s
    LaunchedEffect(uiState.phase) {
        if (uiState.phase == VoicePhase.SAVED) {
            delay(1500)
            onReportSaved()
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull() ?: ""
            viewModel.onTranscriptReceived(text)
        } else {
            viewModel.onListeningCancelled()
        }
    }

    fun launchSpeech() {
        viewModel.onStartListening()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your report…")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechLauncher.launch(intent)
    }

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.voice_title),
                subtitle = when (uiState.phase) {
                    VoicePhase.IDLE       -> stringResource(R.string.voice_subtitle_idle)
                    VoicePhase.LISTENING  -> stringResource(R.string.voice_subtitle_listening)
                    VoicePhase.PROCESSING -> stringResource(R.string.voice_subtitle_processing)
                    VoicePhase.CONFIRM, VoicePhase.EDIT -> stringResource(R.string.voice_subtitle_review)
                    VoicePhase.SAVED      -> stringResource(R.string.voice_subtitle_saved)
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            ScoutSurface1,
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(DsSpacing.xxl),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(DsSpacing.l)
            ) {
                // ── Phase-driven UI ───────────────────────────────────────
                AnimatedContent(
                    targetState = uiState.phase,
                    transitionSpec = {
                        fadeIn(tween(DsMotion.medium, easing = DsEasing.emphasizedDecelerate)) +
                            slideInVertically(tween(DsMotion.medium, easing = DsEasing.emphasizedDecelerate)) { it / 6 } togetherWith
                            fadeOut(tween(DsMotion.fast, easing = DsEasing.emphasizedAccelerate))
                    },
                    label = "voice_phase_content",
                    contentAlignment = Alignment.TopCenter
                ) { phase ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(DsSpacing.l)
                    ) {
                        when (phase) {
                            VoicePhase.IDLE -> IdlePhase(
                                micGranted = micPermission.status.isGranted,
                                onTap = {
                                    if (micPermission.status.isGranted) launchSpeech()
                                    else micPermission.launchPermissionRequest()
                                }
                            )
                            VoicePhase.LISTENING -> ListeningPhase()
                            VoicePhase.PROCESSING -> ProcessingPhase()
                            VoicePhase.SAVED -> SavedPhase(
                                spotName = uiState.matchedSpot?.name ?: ""
                            )
                            VoicePhase.CONFIRM, VoicePhase.EDIT -> Unit
                        }
                    }
                }

                // ── Confirmation panel ────────────────────────────────────
                AnimatedVisibility(
                    visible = uiState.phase == VoicePhase.CONFIRM || uiState.phase == VoicePhase.EDIT,
                    enter   = fadeIn(tween(DsMotion.medium, easing = DsEasing.emphasizedDecelerate)) + expandVertically(tween(DsMotion.medium, easing = DsEasing.emphasizedDecelerate)),
                    exit    = fadeOut(tween(DsMotion.fast, easing = DsEasing.emphasizedAccelerate)) + shrinkVertically(tween(DsMotion.fast, easing = DsEasing.emphasizedAccelerate))
                ) {
                    ConfirmationPanel(
                        uiState           = uiState,
                        onTranscriptEdit  = viewModel::onTranscriptEdited,
                        onNotesEdit       = viewModel::onNotesEdited,
                        onSelectSpot      = viewModel::onSelectSpot,
                        onSave            = viewModel::saveReport,
                        onDiscard         = { viewModel.reset(); onNavigateBack() },
                        onReSpeak         = { launchSpeech() }
                    )
                }

                // ── Error banner ─────────────────────────────────────────
                AnimatedVisibility(
                    visible = uiState.errorMessageRes != null && uiState.phase == VoicePhase.IDLE,
                    enter   = fadeIn(tween(DsMotion.medium)) + expandVertically(tween(DsMotion.medium)),
                    exit    = fadeOut(tween(DsMotion.fast)) + shrinkVertically(tween(DsMotion.fast))
                ) {
                    uiState.errorMessageRes?.let { errorRes ->
                        Card(
                            colors   = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.errorContainer
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(DsSpacing.m),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                            ) {
                                Icon(
                                    Icons.Default.MicOff,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error
                                )
                                Text(
                                    stringResource(errorRes),
                                    style    = MaterialTheme.typography.bodySmall,
                                    color    = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(onClick = viewModel::reset) {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = stringResource(R.string.cd_dismiss_error),
                                        tint = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                }
                            }
                        }
                    }
                }

                // ── Mic permission banner ─────────────────────────────────
                if (!micPermission.status.isGranted) {
                    MicPermissionBanner(
                        onRequest = { micPermission.launchPermissionRequest() }
                    )
                }

                // ── Instructions (idle only) ──────────────────────────────
                AnimatedVisibility(
                    visible = uiState.phase == VoicePhase.IDLE,
                    enter   = fadeIn(tween(DsMotion.medium)),
                    exit    = fadeOut(tween(DsMotion.fast))
                ) {
                    Text(
                        stringResource(R.string.voice_examples),
                        style     = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        color     = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

// ── Idle phase: animated breathing mic button ──────────────────────────────────

@Composable
private fun IdlePhase(micGranted: Boolean, onTap: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "mic_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue  = 1f,
        targetValue   = 1.12f,
        animationSpec = infiniteRepeatable(
            animation  = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )
    val ringAlpha by infiniteTransition.animateFloat(
        initialValue  = 0.4f,
        targetValue   = 0f,
        animationSpec = infiniteRepeatable(
            animation  = tween(900),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring_alpha"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
    ) {
        Spacer(Modifier.height(DsSpacing.xxxl))
        Box(contentAlignment = Alignment.Center) {
            // Outer pulsing ring — grey for IDLE (pre-active state)
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .border(
                        width = 3.dp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = ringAlpha),
                        shape = CircleShape
                    )
            )
            // Second inner ring — subtle primary glow
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .scale(pulseScale * 0.95f)
                    .clip(CircleShape)
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = ringAlpha * 0.5f),
                        shape = CircleShape
                    )
            )
            // Main mic button — NeonCyan
            FilledIconButton(
                onClick  = onTap,
                modifier = Modifier.size(96.dp),
                colors   = IconButtonDefaults.filledIconButtonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor   = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Icon(
                    Icons.Default.Mic,
                    contentDescription = stringResource(R.string.cd_mic_button),
                    modifier = Modifier.size(44.dp)
                )
            }
        }
        Spacer(Modifier.height(DsSpacing.s))
        Text(
            if (micGranted) stringResource(R.string.voice_tap_to_speak) else stringResource(R.string.voice_grant_mic),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            stringResource(R.string.voice_example_phrase),
            style = MaterialTheme.typography.bodySmall,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ── Listening phase ────────────────────────────────────────────────────────────

@Composable
private fun ListeningPhase() {
    val infiniteTransition = rememberInfiniteTransition(label = "listening")
    val scale by infiniteTransition.animateFloat(
        initialValue  = 0.9f,
        targetValue   = 1.1f,
        animationSpec = infiniteRepeatable(
            animation  = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "listening_scale"
    )
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.1f,
        targetValue  = 0.35f,
        animationSpec = infiniteRepeatable(
            animation  = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
    ) {
        Spacer(Modifier.height(DsSpacing.xxxl))
        Box(contentAlignment = Alignment.Center) {
            // VoiceGlowBrush radial cyan glow background
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .background(VoiceGlowBrush)
            )
            // Animated cyan glow ring
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .clip(CircleShape)
                    .background(NeonCyan.copy(alpha = glowAlpha))
            )
            FilledIconButton(
                onClick  = {},
                enabled  = false,
                modifier = Modifier.size(96.dp).scale(scale),
                colors   = IconButtonDefaults.filledIconButtonColors(
                    containerColor         = MaterialTheme.colorScheme.primary,
                    contentColor           = MaterialTheme.colorScheme.onPrimary,
                    disabledContainerColor = MaterialTheme.colorScheme.primary,
                    disabledContentColor   = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Icon(Icons.Default.GraphicEq, contentDescription = stringResource(R.string.cd_listening_indicator), modifier = Modifier.size(44.dp))
            }
        }
        Text(stringResource(R.string.voice_listening), style = MaterialTheme.typography.titleMedium)
        LinearProgressIndicator(
            modifier = Modifier
                .width(160.dp)
                .clip(RoundedCornerShape(DsRadius.pill))
        )
    }
}

// ── Processing phase ───────────────────────────────────────────────────────────

@Composable
private fun ProcessingPhase() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
    ) {
        Spacer(Modifier.height(DsSpacing.xxxl))
        CircularProgressIndicator(
            modifier = Modifier.size(72.dp),
            strokeWidth = 4.dp,
            color = MaterialTheme.colorScheme.secondary
        )
        Text(stringResource(R.string.voice_processing), style = MaterialTheme.typography.titleMedium)
        Text(
            stringResource(R.string.voice_processing_matching),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ── Saved phase: success confirmation ──────────────────────────────────────────

@Composable
private fun SavedPhase(spotName: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "saved_glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue  = 0.08f,
        targetValue   = 0.2f,
        animationSpec = infiniteRepeatable(
            animation  = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "saved_glow_alpha"
    )

    // Scale-in animation
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }
    val scaleAnim by animateFloatAsState(
        targetValue = if (visible) 1f else 0.5f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness    = Spring.StiffnessLow
        ),
        label = "saved_scale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
    ) {
        Spacer(Modifier.height(DsSpacing.xxxl))
        Box(contentAlignment = Alignment.Center) {
            // Electric green glow — SAVED state
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .scale(scaleAnim)
                    .clip(CircleShape)
                    .background(StatusGoodHaul.copy(alpha = glowAlpha))
            )
            FilledIconButton(
                onClick  = {},
                enabled  = false,
                modifier = Modifier
                    .size(96.dp)
                    .scale(scaleAnim),
                colors   = IconButtonDefaults.filledIconButtonColors(
                    containerColor         = StatusGoodHaul,
                    contentColor           = MaterialTheme.colorScheme.onPrimary,
                    disabledContainerColor = StatusGoodHaul,
                    disabledContentColor   = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Icon(Icons.Default.Check, contentDescription = stringResource(R.string.cd_saved_indicator), modifier = Modifier.size(48.dp))
            }
        }
        Text(
            stringResource(R.string.voice_report_saved),
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
            color = StatusGoodHaul
        )
        if (spotName.isNotBlank()) {
            Text(
                stringResource(R.string.voice_logged_to, spotName),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// ── Confirmation panel ─────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConfirmationPanel(
    uiState: VoiceUiState,
    onTranscriptEdit: (String) -> Unit,
    onNotesEdit: (String) -> Unit,
    onSelectSpot: (DumpsterSpot) -> Unit,
    onSave: () -> Unit,
    onDiscard: () -> Unit,
    onReSpeak: () -> Unit
) {
    val result = uiState.parseResult ?: return

    Card(
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = DsElevation.raised),
        colors    = CardDefaults.cardColors(containerColor = ScoutSurface2),
        shape     = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier.padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.m)
        ) {
            // Section header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                Icon(
                    Icons.Default.Description,
                    null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Text(stringResource(R.string.voice_parsed_report_header), style = MaterialTheme.typography.titleSmall)
            }

            // Transcript
            OutlinedTextField(
                value         = uiState.editableTranscript,
                onValueChange = onTranscriptEdit,
                label         = { Text(stringResource(R.string.voice_transcript)) },
                modifier      = Modifier.fillMaxWidth(),
                minLines      = 2,
                shape         = MaterialTheme.shapes.medium,
                leadingIcon   = { Icon(Icons.Default.RecordVoiceOver, null, modifier = Modifier.size(18.dp)) }
            )

            // Detected status
            result.status?.let { status ->
                Surface(
                    color  = ScoutSurface1.copy(alpha = 0.8f),
                    shape  = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(DsSpacing.m),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) {
                        Text(
                            stringResource(R.string.voice_detected_status_label),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        StatusChip(status = status)
                    }
                }
            }

            // Matched spot card
            if (uiState.matchedSpot != null) {
                val spotAccent = categoryColor(uiState.matchedSpot.category)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors   = CardDefaults.cardColors(
                        containerColor = spotAccent.copy(alpha = 0.12f)
                    ),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Row {
                        // Accent strip
                        Box(
                            Modifier
                                .width(4.dp)
                                .height(56.dp)
                                .background(spotAccent)
                        )
                        Row(
                            modifier = Modifier
                                .padding(DsSpacing.m)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                        ) {
                            Icon(
                                Icons.Default.Place,
                                null,
                                modifier = Modifier.size(20.dp),
                                tint = spotAccent
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    uiState.matchedSpot.name,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    uiState.matchedSpot.category.name.lowercase()
                                        .replaceFirstChar { it.uppercaseChar() },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = spotAccent
                                )
                            }
                            // Confidence badge
                            val confColor = when {
                                result.confidence >= 0.8f -> StatusGoodHaul
                                result.confidence >= 0.5f -> NeonMagenta
                                else                       -> StatusSecurity
                            }
                            Surface(
                                color = confColor.copy(alpha = 0.18f),
                                shape = MaterialTheme.shapes.small
                            ) {
                                Text(
                                    "%.0f%%".format(result.confidence * 100),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = confColor,
                                    modifier = Modifier.padding(horizontal = DsSpacing.s, vertical = DsSpacing.xs)
                                )
                            }
                        }
                    }
                }
            } else {
                Surface(
                    color  = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f),
                    shape  = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(DsSpacing.m),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.HelpOutline,
                            null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            stringResource(R.string.voice_no_match),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            // Alternative candidate spots
            if (uiState.candidateSpots.size > 1) {
                Text(
                    stringResource(R.string.voice_select_different_spot),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                uiState.candidateSpots.forEach { candidate ->
                    val isSelected = candidate.id == uiState.matchedSpot?.id
                    val cAccent = categoryColor(candidate.category)
                    OutlinedCard(
                        onClick  = { onSelectSpot(candidate) },
                        modifier = Modifier.fillMaxWidth(),
                        border   = CardDefaults.outlinedCardBorder().copy(
                            brush = if (isSelected) Brush.linearGradient(listOf(cAccent, cAccent.copy(alpha = 0.5f)))
                                    else Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.outline))
                        ),
                        colors = CardDefaults.outlinedCardColors(
                            containerColor = if (isSelected) cAccent.copy(alpha = 0.08f) else ScoutSurface2
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(DsSpacing.m),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
                        ) {
                            Icon(
                                Icons.Default.Place,
                                null,
                                tint = cAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                candidate.name,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f)
                            )
                            if (isSelected) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    null,
                                    tint = cAccent,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Notes
            OutlinedTextField(
                value         = uiState.editableNotes,
                onValueChange = onNotesEdit,
                label         = { Text(stringResource(R.string.spot_notes)) },
                modifier      = Modifier.fillMaxWidth(),
                minLines      = 2,
                shape         = MaterialTheme.shapes.medium,
                leadingIcon   = { Icon(Icons.AutoMirrored.Filled.Notes, null, modifier = Modifier.size(18.dp)) }
            )

            // Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
            ) {
                OutlinedButton(
                    onClick  = onDiscard,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Close, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(DsSpacing.xs))
                    Text(stringResource(R.string.voice_discard))
                }
                FilledTonalButton(
                    onClick  = onReSpeak,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Refresh, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(DsSpacing.xs))
                    Text(stringResource(R.string.voice_respeak))
                }
                Button(
                    onClick  = onSave,
                    enabled  = uiState.matchedSpot != null,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Save, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(DsSpacing.xs))
                    Text(stringResource(R.string.voice_save))
                }
            }
        }
    }
}

// ── Mic permission banner ──────────────────────────────────────────────────────

@Composable
private fun MicPermissionBanner(onRequest: () -> Unit) {
    Card(
        colors    = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
        modifier  = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(DsSpacing.m),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)
        ) {
            Icon(Icons.Default.MicOff, null, tint = MaterialTheme.colorScheme.error)
            Text(
                stringResource(R.string.mic_permission_rationale),
                style    = MaterialTheme.typography.bodySmall,
                color    = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onRequest) { Text(stringResource(R.string.allow)) }
        }
    }
}

// ── Preview ────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "VoiceReport IDLE dark")
@Composable
private fun VoiceIdlePreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Scaffold { padding ->
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Brush.verticalGradient(listOf(ScoutSurface3, ScoutSurface0))),
                contentAlignment = Alignment.Center
            ) {
                IdlePhase(micGranted = true, onTap = {})
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "VoiceReport CONFIRM dark")
@Composable
private fun VoiceConfirmPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        val matchedSpot = SampleData.spots.find { it.id == 5L } ?: SampleData.spots.first()
        val parseResult = VoiceParseResult(
            parsedSpotName  = "Hy-Vee Bettendorf",
            status          = SpotStatus.GOOD_HAUL,
            fillLevel       = FillLevel.FULL,
            timeRelevance   = TimeRelevance.TONIGHT,
            notes           = "Produce and bakery bags — sealed. Deli sandwiches still cold.",
            tags            = listOf("produce", "bakery", "deli"),
            rawTranscript   = "Hy-Vee Bettendorf good haul tonight, produce bakery jackpot",
            confidence      = 0.92f,
            matchedSpotId   = matchedSpot.id
        )
        val uiState = VoiceUiState(
            phase             = VoicePhase.CONFIRM,
            parseResult       = parseResult,
            matchedSpot       = matchedSpot,
            editableTranscript = "Hy-Vee Bettendorf good haul tonight, produce bakery jackpot",
            editableNotes     = "Produce and bakery bags — sealed. Deli sandwiches still cold."
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(ScoutSurface3, ScoutSurface0)))
                .padding(16.dp)
        ) {
            ConfirmationPanel(
                uiState          = uiState,
                onTranscriptEdit = {},
                onNotesEdit      = {},
                onSelectSpot     = {},
                onSave           = {},
                onDiscard        = {},
                onReSpeak        = {}
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "VoiceReport SAVED dark")
@Composable
private fun VoiceSavedPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Scaffold { padding ->
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Brush.verticalGradient(listOf(ScoutSurface3, ScoutSurface0))),
                contentAlignment = Alignment.Center
            ) {
                SavedPhase(spotName = "Trader Joe's")
            }
        }
    }
}
