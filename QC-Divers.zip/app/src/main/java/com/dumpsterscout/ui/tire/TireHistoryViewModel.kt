package com.dumpsterscout.ui.tire

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dumpsterscout.domain.model.TireReport
import com.dumpsterscout.domain.repository.TireReportRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class TireHistoryUiState(
    val reports: List<TireReport> = emptyList(),
    val filteredReports: List<TireReport> = emptyList(),
    val isLoading: Boolean = true,
    val filterPeriod: TireFilterPeriod = TireFilterPeriod.ALL,
    val searchQuery: String = "",
    val error: String? = null
)

enum class TireFilterPeriod { ALL, TODAY, THIS_WEEK }

@HiltViewModel
class TireHistoryViewModel @Inject constructor(
    private val tireReportRepository: TireReportRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(TireHistoryUiState())
    val uiState: StateFlow<TireHistoryUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            try {
                tireReportRepository.getAllReports().collect { reports ->
                    _uiState.update { state ->
                        val filtered = applyFilter(reports, state.filterPeriod, state.searchQuery)
                        state.copy(reports = reports, filteredReports = filtered, isLoading = false)
                    }
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "An unexpected error occurred", isLoading = false) }
            }
        }
    }

    fun onFilterPeriodChange(period: TireFilterPeriod) {
        _uiState.update { state ->
            val filtered = applyFilter(state.reports, period, state.searchQuery)
            state.copy(filterPeriod = period, filteredReports = filtered)
        }
    }

    fun onSearchQueryChange(query: String) {
        _uiState.update { state ->
            val filtered = applyFilter(state.reports, state.filterPeriod, query)
            state.copy(searchQuery = query, filteredReports = filtered)
        }
    }

    fun deleteReport(report: TireReport) {
        viewModelScope.launch {
            try {
                tireReportRepository.deleteReport(report)
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "An unexpected error occurred") }
            }
        }
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }

    private fun applyFilter(
        reports: List<TireReport>,
        period: TireFilterPeriod,
        query: String
    ): List<TireReport> {
        val now = System.currentTimeMillis()
        val oneDayMs = 86_400_000L
        val oneWeekMs = 7 * oneDayMs
        return reports.filter { report ->
            val withinPeriod = when (period) {
                TireFilterPeriod.ALL       -> true
                TireFilterPeriod.TODAY     -> (now - report.timestamp) < oneDayMs
                TireFilterPeriod.THIS_WEEK -> (now - report.timestamp) < oneWeekMs
            }
            val matchesQuery = query.isBlank() ||
                    report.spotName.contains(query, ignoreCase = true) ||
                    report.notes.contains(query, ignoreCase = true)
            withinPeriod && matchesQuery
        }
    }
}
