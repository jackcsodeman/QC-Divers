package com.dumpsterscout.ui.tire

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.TireCondition
import com.dumpsterscout.domain.model.TireSpotStatus
import com.dumpsterscout.domain.model.TreadQuality
import com.dumpsterscout.ui.components.DumpsterScoutTopBar
import com.dumpsterscout.ui.components.EmptyStatePanel
import com.dumpsterscout.ui.theme.DsSpacing
import com.dumpsterscout.ui.theme.DumpsterScoutTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TireReportScreen(
    tireSpotId: Long?,
    onNavigateBack: () -> Unit,
    viewModel: TireSpotViewModel = hiltViewModel()
) {
    val uiState by viewModel.reportState.collectAsStateWithLifecycle()

    LaunchedEffect(tireSpotId) {
        if (tireSpotId != null) {
            viewModel.initReport(tireSpotId, "")
        }
    }

    LaunchedEffect(uiState.isSaved) {
        if (uiState.isSaved) {
            viewModel.clearReportSaved()
            onNavigateBack()
        }
    }

    if (tireSpotId == null) {
        EmptyStatePanel(
            message  = stringResource(R.string.tire_report_no_spot),
            icon     = Icons.Default.Warning
        )
        return
    }

    val report = uiState.report

    Scaffold(
        topBar = {
            DumpsterScoutTopBar(
                title = stringResource(R.string.tire_report_title),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                    }
                },
                actions = {
                    TextButton(
                        onClick  = viewModel::saveReport,
                        enabled  = !uiState.isLoading
                    ) {
                        Text(stringResource(R.string.save))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(DsSpacing.l),
            verticalArrangement = Arrangement.spacedBy(DsSpacing.l)
        ) {
            // Status picker
            Text(
                stringResource(R.string.tire_report_section_status),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            QuickStatusGrid(
                currentStatus = report.status,
                onStatusSelect = { viewModel.updateReportField { r -> r.copy(status = it) } }
            )

            // Count section
            Text(
                stringResource(R.string.tire_report_section_counts),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.m)
            ) {
                TireCountStepper(
                    label   = stringResource(R.string.tire_report_total_label),
                    value   = report.estimatedCount,
                    onInc   = { viewModel.updateReportField { r -> r.copy(estimatedCount = r.estimatedCount + 1) } },
                    onDec   = { viewModel.updateReportField { r -> r.copy(estimatedCount = maxOf(0, r.estimatedCount - 1)) } },
                    modifier = Modifier.weight(1f)
                )
                TireCountStepper(
                    label   = stringResource(R.string.tire_report_usable_label),
                    value   = report.estimatedUsableCount,
                    onInc   = { viewModel.updateReportField { r -> r.copy(estimatedUsableCount = r.estimatedUsableCount + 1) } },
                    onDec   = { viewModel.updateReportField { r -> r.copy(estimatedUsableCount = maxOf(0, r.estimatedUsableCount - 1)) } },
                    modifier = Modifier.weight(1f)
                )
            }

            // Puncture state toggle
            Text(
                stringResource(R.string.tire_report_section_puncture),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.s)) {
                PunctureOption(
                    label    = stringResource(R.string.tire_report_all_punctured),
                    selected = report.arePunctured,
                    onClick  = { viewModel.updateReportField { r -> r.copy(arePunctured = true, somePunctured = false, someUnpunctured = false) } }
                )
                PunctureOption(
                    label    = stringResource(R.string.tire_report_some_punctured),
                    selected = report.somePunctured,
                    onClick  = { viewModel.updateReportField { r -> r.copy(arePunctured = false, somePunctured = true, someUnpunctured = false) } }
                )
                PunctureOption(
                    label    = stringResource(R.string.tire_report_some_unpunctured),
                    selected = report.someUnpunctured,
                    onClick  = { viewModel.updateReportField { r -> r.copy(arePunctured = false, somePunctured = false, someUnpunctured = true) } }
                )
            }

            // Tread quality
            Text(
                stringResource(R.string.tire_report_section_tread),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            var showTreadMenu by remember { mutableStateOf(false) }
            Box {
                OutlinedTextField(
                    value         = report.treadQuality.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() },
                    onValueChange = {},
                    label         = { Text(stringResource(R.string.tire_report_tread_quality)) },
                    readOnly      = true,
                    modifier      = Modifier.fillMaxWidth(),
                    trailingIcon  = {
                        IconButton(onClick = { showTreadMenu = true }) {
                            Icon(Icons.Default.ArrowDropDown, null)
                        }
                    },
                    shape = MaterialTheme.shapes.medium
                )
                DropdownMenu(expanded = showTreadMenu, onDismissRequest = { showTreadMenu = false }) {
                    TreadQuality.entries.forEach { tq ->
                        DropdownMenuItem(
                            text    = { Text(tq.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }) },
                            onClick = { viewModel.updateReportField { r -> r.copy(treadQuality = tq) }; showTreadMenu = false }
                        )
                    }
                }
            }

            // Damage flags
            Text(
                stringResource(R.string.tire_report_section_damage),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Column(verticalArrangement = Arrangement.spacedBy(DsSpacing.xs)) {
                TireCheckRow(
                    label   = stringResource(R.string.tire_report_sidewall_damage),
                    checked = report.sidewallDamage,
                    onCheckedChange = { viewModel.updateReportField { r -> r.copy(sidewallDamage = it) } }
                )
                TireCheckRow(
                    label   = stringResource(R.string.tire_report_dry_rot),
                    checked = report.dryRot,
                    onCheckedChange = { viewModel.updateReportField { r -> r.copy(dryRot = it) } }
                )
                TireCheckRow(
                    label   = stringResource(R.string.tire_report_repair_visible),
                    checked = report.repairVisible,
                    onCheckedChange = { viewModel.updateReportField { r -> r.copy(repairVisible = it) } }
                )
                TireCheckRow(
                    label   = stringResource(R.string.tire_report_already_picked),
                    checked = report.alreadyPickedThrough,
                    onCheckedChange = { viewModel.updateReportField { r -> r.copy(alreadyPickedThrough = it) } }
                )
                TireCheckRow(
                    label   = stringResource(R.string.tire_report_looked_fresh),
                    checked = report.lookedFreshOut,
                    onCheckedChange = { viewModel.updateReportField { r -> r.copy(lookedFreshOut = it) } }
                )
            }

            // Notes
            OutlinedTextField(
                value         = report.notes,
                onValueChange = { viewModel.updateReportField { r -> r.copy(notes = it) } },
                label         = { Text(stringResource(R.string.spot_notes)) },
                modifier      = Modifier.fillMaxWidth(),
                minLines      = 3,
                shape         = MaterialTheme.shapes.medium
            )

            // Save button
            Button(
                onClick  = viewModel::saveReport,
                modifier = Modifier.fillMaxWidth(),
                enabled  = !uiState.isLoading
            ) {
                if (uiState.isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                } else {
                    Text(stringResource(R.string.save))
                }
            }

            Spacer(Modifier.height(DsSpacing.giant))
        }
    }
}

@Composable
private fun QuickStatusGrid(
    currentStatus: TireSpotStatus,
    onStatusSelect: (TireSpotStatus) -> Unit
) {
    val quickStatuses = listOf(
        TireSpotStatus.GOOD_USABLE,
        TireSpotStatus.MANY_OUT,
        TireSpotStatus.A_FEW_OUT,
        TireSpotStatus.UNPUNCTURED,
        TireSpotStatus.SOME_PUNCTURED,
        TireSpotStatus.ALL_PUNCTURED,
        TireSpotStatus.ALREADY_PICKED,
        TireSpotStatus.NO_TIRES,
        TireSpotStatus.FRESH_DROP,
        TireSpotStatus.LOCKED_INACCESSIBLE,
        TireSpotStatus.WORTH_CHECKING,
        TireSpotStatus.GONE_FAST
    )
    Column(verticalArrangement = Arrangement.spacedBy(DsSpacing.xs)) {
        quickStatuses.chunked(3).forEach { row ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs),
                modifier = Modifier.fillMaxWidth()
            ) {
                row.forEach { status ->
                    TireStatusChip(
                        status  = status,
                        onClick = { onStatusSelect(status) },
                        modifier = Modifier.weight(1f)
                    )
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun TireCountStepper(
    label: String,
    value: Int,
    onInc: () -> Unit,
    onDec: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors   = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape    = MaterialTheme.shapes.medium
    ) {
        Column(
            modifier            = Modifier.padding(DsSpacing.m),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                IconButton(onClick = onDec) { Icon(Icons.Default.Remove, null) }
                Text(
                    value.toString(),
                    style    = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.width(40.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                IconButton(onClick = onInc) { Icon(Icons.Default.Add, null) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PunctureOption(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    FilterChip(
        selected = selected,
        onClick  = onClick,
        label    = { Text(label, style = MaterialTheme.typography.labelSmall) }
    )
}

@Composable
private fun TireCheckRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier          = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Spacer(Modifier.width(DsSpacing.s))
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

// ── Previews ──────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, backgroundColor = 0xFF12141A, name = "TireReport – dark")
@Composable
private fun TireReportScreenPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        Scaffold(
            topBar = {
                DumpsterScoutTopBar(
                    title = "Log Tire Spot",
                    navigationIcon = {
                        IconButton(onClick = {}) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.cd_navigate_back))
                        }
                    }
                )
            }
        ) { padding ->
            Box(modifier = Modifier.padding(padding).padding(DsSpacing.l)) {
                Text("Tire report form…")
            }
        }
    }
}
