package com.dumpsterscout.ui.tire

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.PuncturePattern
import com.dumpsterscout.domain.model.TireSpot
import com.dumpsterscout.domain.model.TireSpotCategory
import com.dumpsterscout.ui.theme.*
import com.dumpsterscout.util.SampleData
import com.dumpsterscout.util.timeAgoString

/** Maps a [TireSpotCategory] to its distinctive accent color. */
fun tireCategoryColor(category: TireSpotCategory): Color = when (category) {
    TireSpotCategory.TIRE_SHOP    -> TireTireShop
    TireSpotCategory.MECHANIC_SHOP -> TireMechanic
    TireSpotCategory.DEALERSHIP   -> TireDealership
    TireSpotCategory.GARAGE       -> TireGarage
    TireSpotCategory.SALVAGE_YARD -> TireSalvage
    TireSpotCategory.ROADSIDE_LOT -> TireRoadside
    TireSpotCategory.WAREHOUSE    -> TireWarehouse
    TireSpotCategory.OTHER        -> TireOther
}

/**
 * Tire spot summary card with a left-side category-color accent strip.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TireSpotCard(
    spot: TireSpot,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (statusLabel, _) = tireStatusDisplay(spot.lastStatus)
    val cd = stringResource(R.string.cd_tire_spot_card, spot.name, statusLabel)
    val accentColor = tireCategoryColor(spot.category)

    val favTint by animateColorAsState(
        targetValue = if (spot.isFavorite) MaterialTheme.colorScheme.primary
                      else MaterialTheme.colorScheme.onSurfaceVariant,
        animationSpec = tween(DsMotion.medium),
        label = "fav_tint"
    )

    Card(
        onClick   = onClick,
        modifier  = modifier
            .fillMaxWidth()
            .semantics { contentDescription = cd },
        elevation = CardDefaults.cardElevation(
            defaultElevation = DsElevation.card,
            pressedElevation  = DsElevation.subtle
        ),
        colors = CardDefaults.cardColors(
            containerColor = ScoutSurface2
        ),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.25f)),
        shape = MaterialTheme.shapes.medium
    ) {
        Row {
            // Category accent strip
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .fillMaxHeight()
                    .clip(MaterialTheme.shapes.medium)
                    .background(accentColor)
            )

            Column(modifier = Modifier.padding(DsSpacing.l)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)
                        ) {
                            Text(
                                text = spot.name,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            if (spot.isVerified) {
                                Icon(
                                    Icons.Default.Verified,
                                    contentDescription = stringResource(R.string.condition_verified),
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                            if (spot.isLocked) {
                                Icon(
                                    Icons.Default.Lock,
                                    contentDescription = stringResource(R.string.condition_locked),
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                        val categoryLabel = spot.category.name
                            .lowercase().replace('_', ' ').replaceFirstChar { it.uppercaseChar() }
                        val subtitle = if (spot.address.isNotBlank()) spot.address else categoryLabel
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    val favCd = stringResource(R.string.cd_favorite_button, spot.name)
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier.semantics { contentDescription = favCd }
                    ) {
                        Icon(
                            imageVector = if (spot.isFavorite) Icons.Default.Favorite
                                          else Icons.Default.FavoriteBorder,
                            contentDescription = null,
                            tint = favTint
                        )
                    }
                }

                Spacer(Modifier.height(DsSpacing.s))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(DsSpacing.s),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TireStatusChip(status = spot.lastStatus)
                    // Puncture pattern badge
                    if (spot.puncturePattern != PuncturePattern.UNKNOWN) {
                        val ppLabel = when (spot.puncturePattern) {
                            PuncturePattern.USUALLY_PUNCTURED   -> stringResource(R.string.puncture_usually)
                            PuncturePattern.SOMETIMES_PUNCTURED -> stringResource(R.string.puncture_sometimes)
                            PuncturePattern.USUALLY_UNPUNCTURED -> stringResource(R.string.puncture_usually_not)
                            PuncturePattern.UNKNOWN             -> ""
                        }
                        if (ppLabel.isNotBlank()) {
                            SuggestionChip(
                                onClick = {},
                                label   = { Text(ppLabel, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.height(24.dp)
                            )
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    spot.lastChecked?.let { ts ->
                        Text(
                            text = timeAgoString(ts),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (spot.tags.isNotEmpty()) {
                    Spacer(Modifier.height(DsSpacing.s))
                    Row(horizontalArrangement = Arrangement.spacedBy(DsSpacing.xs)) {
                        spot.tags.take(3).forEach { tag ->
                            SuggestionChip(
                                onClick = {},
                                label   = { Text(tag, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.height(24.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ── Previews ──────────────────────────────────────────────────────────────────

@Preview(showBackground = true, backgroundColor = 0xFF12141A)
@Composable
private fun TireSpotCardDarkPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        TireSpotCard(
            spot = SampleData.tireSpots.first(),
            onClick = {},
            onToggleFavorite = {}
        )
    }
}

@Preview(showBackground = true)
@Composable
private fun TireSpotCardLightPreview() {
    DumpsterScoutTheme(darkTheme = false) {
        TireSpotCard(
            spot = SampleData.tireSpots.first(),
            onClick = {},
            onToggleFavorite = {}
        )
    }
}
