package com.dumpsterscout.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.dumpsterscout.R
import com.dumpsterscout.domain.model.SpotStatus
import com.dumpsterscout.ui.theme.DumpsterScoutTheme
import com.dumpsterscout.ui.theme.DsMotion
import androidx.compose.animation.core.tween
import com.dumpsterscout.ui.theme.*

/**
 * Chip displaying the current [SpotStatus] with a status-specific icon and
 * animated color transitions when the status changes (e.g. after a quick update).
 */
@Composable
fun StatusChip(
    status: SpotStatus,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val (label, rawColor) = statusDisplay(status)
    val icon = statusIcon(status)
    val cd = stringResource(R.string.cd_status_chip, label)

    // Animate color changes so quick-status updates feel smooth.
    val color by animateColorAsState(
        targetValue = rawColor,
        animationSpec = tween(DsMotion.medium),
        label = "status_chip_color"
    )

    AssistChip(
        onClick = onClick ?: {},
        enabled = onClick != null,
        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
        leadingIcon = icon?.let {
            { Icon(it, contentDescription = null, modifier = Modifier.size(14.dp), tint = color) }
        },
        modifier = modifier.semantics { contentDescription = cd },
        colors = AssistChipDefaults.assistChipColors(
            containerColor       = color.copy(alpha = 0.18f),
            labelColor           = color,
            leadingIconContentColor = color
        ),
        border = AssistChipDefaults.assistChipBorder(
            enabled     = true,
            borderColor = color.copy(alpha = 0.55f)
        )
    )
}

/** Returns the human-readable label and accent color for a given [SpotStatus]. */
@Composable
fun statusDisplay(status: SpotStatus): Pair<String, Color> =
    when (status) {
        SpotStatus.EMPTY                -> "Empty"     to StatusEmpty
        SpotStatus.HALF_FULL            -> "Half Full" to StatusHalfFull
        SpotStatus.FULL                 -> "Full"      to StatusFull
        SpotStatus.OVERFLOWING          -> "Overflow"  to StatusOverflowing
        SpotStatus.LOCKED               -> "Locked"    to StatusLocked
        SpotStatus.COMPACTOR_ONLY       -> "Compactor" to StatusCompactor
        SpotStatus.GOOD_HAUL            -> "Good Haul" to StatusGoodHaul
        SpotStatus.SECURITY_ACTIVE      -> "Security"  to StatusSecurity
        SpotStatus.CONSTRUCTION_REMOVED -> "Removed"   to GradeLow
        SpotStatus.ALREADY_PICKED_THROUGH -> "Picked"  to StatusLocked
        SpotStatus.NOTHING_THERE        -> "Nothing"   to StatusEmpty
        SpotStatus.UNKNOWN              -> "Unknown"   to StatusLocked
    }

/** Small leading icon per status for instant scanability. */
fun statusIcon(status: SpotStatus): ImageVector? = when (status) {
    SpotStatus.EMPTY                  -> Icons.Default.RadioButtonUnchecked
    SpotStatus.GOOD_HAUL              -> Icons.Default.Star
    SpotStatus.FULL, SpotStatus.HALF_FULL -> Icons.Default.CheckCircle
    SpotStatus.OVERFLOWING            -> Icons.Default.ExpandMore
    SpotStatus.LOCKED                 -> Icons.Default.Lock
    SpotStatus.SECURITY_ACTIVE        -> Icons.Default.Warning
    SpotStatus.COMPACTOR_ONLY         -> Icons.Default.Block
    SpotStatus.NOTHING_THERE,
    SpotStatus.ALREADY_PICKED_THROUGH -> Icons.Default.RemoveCircleOutline
    else                              -> null
}

// ── Previews ─────────────────────────────────────────────────────────────────

@Preview(showBackground = true, backgroundColor = 0xFF1A1C22)
@Composable
private fun StatusChipGoodHaulPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        StatusChip(status = SpotStatus.GOOD_HAUL)
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF1A1C22)
@Composable
private fun StatusChipLockedPreview() {
    DumpsterScoutTheme(darkTheme = true) {
        StatusChip(status = SpotStatus.LOCKED)
    }
}
