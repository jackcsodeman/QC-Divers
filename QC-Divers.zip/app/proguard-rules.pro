# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.

# Keep Room entities
-keep class com.dumpsterscout.data.local.entity.** { *; }

# Keep domain models for JSON serialization
-keep class com.dumpsterscout.domain.model.** { *; }

# Keep remote DTOs used by Supabase Postgrest serialization
-keep class com.dumpsterscout.data.remote.dto.** { *; }

# Hilt
-keep class dagger.hilt.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ApplicationComponentManager { *; }

# Coil
-dontwarn coil.**

# Maps
-keep class com.google.android.gms.maps.** { *; }

# Supabase / Ktor / kotlinx-serialization
-keep class io.github.jan.supabase.** { *; }
-dontwarn io.github.jan.supabase.**
-keep class io.ktor.** { *; }
-dontwarn io.ktor.**
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class **$$serializer { *; }
-keep @kotlinx.serialization.Serializable class * { *; }
-keepclassmembers @kotlinx.serialization.Serializable class * {
    *** Companion;
    kotlinx.serialization.KSerializer serializer(...);
}
