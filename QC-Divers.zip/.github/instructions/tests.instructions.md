---
applyTo: "app/src/test/**/*.kt"
---

# Unit test conventions

## Framework and structure

- Use **JUnit 4** (`@Test`, `@Before`, `@After`).
- Test class name: `<Subject>Test` (e.g., `SpotViewModelTest`, `VoiceParserTest`).
- Test method name: `` fun `action condition - expected`() `` (backtick-quoted, human-readable phrase — e.g., `` fun `parse empty today - returns empty status`() ``).
- One logical assertion per test; prefer multiple focused tests over one omnibus test.

## Coroutines

- Wrap coroutine tests in `runTest { … }`; no custom `MainDispatcherRule` is required.
- Use `advanceUntilIdle()` to flush pending coroutines before asserting.

## Flow / StateFlow

- Use **Turbine** (`turbine`) for collecting flows in tests:
  ```kotlin
  viewModel.uiState.test {
      val state = awaitItem()
      assertEquals(expected, state.someField)
      cancelAndIgnoreRemainingEvents()
  }
  ```

## Fakes

- Use `FakeSpotRepository` and `FakeReportRepository` (in `fake/` package) instead of mocking Room.
- Use **MockK** only for external collaborators (e.g., `LocationClient`) that cannot be faked easily.
- Fakes must implement the domain repository interface and hold an in-memory `MutableList`.

## Assertions

- Prefer `org.junit.Assert` assertions (via `import org.junit.Assert.*`) such as `assertEquals`, `assertTrue`, `assertFalse`, `assertNull`, and `assertNotNull` for consistency.
- For collection assertions use `assertTrue(collection.contains(element))` or check `.size` explicitly.

## What NOT to test

- Do **not** test Android framework classes (Activities, Services) in unit tests — use instrumented tests for those.
- Do **not** test data-class `copy()` or `equals()` — they are language guarantees.
- Do **not** mock domain models — instantiate them directly.
