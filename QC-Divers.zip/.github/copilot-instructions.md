# Dumpster Scout — GitHub Copilot Instructions

## Project overview

**Dumpster Scout** is a private, offline-first Android app for personal dumpster-diving field notes.
It is a single-user app — no cloud sync, no community features, no public sharing.
The codebase is 100 % Kotlin with Jetpack Compose + Material 3.

## Tech stack (always use these, never substitute)

| Layer | Technology |
|---|---|
| Language | Kotlin only — no Java |
| UI | Jetpack Compose + Material 3 |
| Architecture | Single-activity, MVVM, UDF (StateFlow → ViewModel → UI) |
| DI | Hilt (`@HiltViewModel`, `@Inject`, `@Module`) |
| Database | Room (`@Entity`, `@Dao`, `@Database`) |
| Preferences | AndroidX DataStore (Preferences) |
| Navigation | Navigation Compose (`NavController`, `Screen` sealed class) |
| Images | Coil (`rememberAsyncImagePainter`) |
| Maps | Maps Compose + Play Services Location |
| Background | WorkManager |
| Coroutines | `kotlinx.coroutines` + `Flow`/`StateFlow` |
| Testing | JUnit 4 + MockK + Turbine + `kotlinx-coroutines-test` |

## Package structure

```
com.dumpsterscout/
├── di/                  Hilt modules (DatabaseModule, RepositoryModule)
├── data/
│   ├── local/           Room entities, DAOs, DumpsterScoutDatabase
│   ├── preferences/     AppPreferences (DataStore)
│   ├── mapper/          Entity ↔ Domain mappers
│   └── repository/      *Impl classes
├── domain/
│   ├── model/           Pure-Kotlin data classes, enums (no Android imports)
│   └── repository/      Interfaces for each repository
├── ui/
│   ├── theme/           Color, Type, Theme (DumpsterScoutTheme, LocalFieldMode)
│   ├── navigation/      Screen sealed class, DumpsterScoutNavGraph
│   ├── components/      Reusable composables (SpotCard, StatusChip, GradeCard)
│   └── <feature>/       <Feature>Screen.kt + <Feature>ViewModel.kt per screen
├── util/                VoiceParser (pure Kotlin), SampleData, Extensions
├── DumpsterScoutApp.kt  @HiltAndroidApp
└── MainActivity.kt      Single activity
```

## Architecture rules

- **Domain models** in `domain/model/` must be pure Kotlin — **no Android imports**.
- **ViewModels** must expose `StateFlow<UiState>` and accept `UiEvent` sealed classes; never expose `MutableStateFlow` directly.
- **Repositories** must have an interface in `domain/repository/` and an `*Impl` in `data/repository/`.
- **Hilt modules** provide all dependencies; never construct repositories or DAOs manually.
- **Navigation** uses the `Screen` sealed class for all routes; never use raw string literals.
- State hoisting: composable functions receive state and callbacks, no side-effecting logic inside composables.

## Coding style

- Prefer idiomatic Kotlin: `data class`, `sealed class`, `when`, extension functions, `copy()`.
- `when` expressions must be exhaustive (seal all branches).
- Keep composables small (≤ 80 lines); extract helper composables freely.
- Use `@Preview` for every major composable.
- Use `@OptIn(ExperimentalMaterial3Api::class)` (or the relevant annotation) when using experimental M3 APIs — never suppress without annotating.
- No `!!` force-unwrap — use `?.let`, `?: return`, or safe casting.
- All date/time as epoch millis (`Long`); use `Extensions.kt` helpers for formatting.
- Tags are `List<String>` stored as JSON array strings in Room entity columns; mappers handle conversion (with a comma-separated fallback).
- Comments only where logic is non-obvious; do **not** comment out working code.

## Privacy & safety rules (always enforce)

- All data stays **on-device**; never add network calls, analytics, or crash reporters.
- `allowBackup=false` in the manifest; cloud backup is excluded in `backup_rules.xml`.
- Never add multi-user, sharing, feeds, public profiles, or moderation features.
- Include the safety disclaimer ("respect property, leave no mess") in any user-facing text about locations.

## Testing conventions

- Unit tests live in `app/src/test/`; fake repositories (`FakeSpotRepository`, `FakeReportRepository`) are in `app/src/test/…/fake/`.
- Every ViewModel must have a corresponding unit test class.
- Use `StandardTestDispatcher` + `runTest` for coroutine tests.
- Use Turbine (`turbine`) for Flow/StateFlow testing.
- Fake repositories implement the domain interfaces and hold in-memory `MutableList`.

## Build configuration

- `compileSdk = 36`, `minSdk = 26`, `targetSdk = 35`
- Java 17 source compatibility, with `jvmTarget = 17` via `compilerOptions`
- Stable toolchain: AGP `8.9.2`, Gradle `8.11.1`, Kotlin `2.2.0`, Hilt `2.57`, AndroidX Hilt `1.3.0`
- Room schema export enabled (`exportSchema = true`) → `app/schemas/`
- Google Maps API key via Gradle property `MAPS_API_KEY` → `manifestPlaceholders`
- All dependency versions managed in `gradle/libs.versions.toml` (version catalog)

## What NOT to do

- Do **not** add new libraries without updating `libs.versions.toml`.
- Do **not** use `GlobalScope` — use `viewModelScope` or injected `CoroutineScope`.
- Do **not** call Android APIs from `domain/model/` classes.
- Do **not** hardcode strings visible to users — use `strings.xml`.
- Do **not** add cloud sync, login, or network features.
