# Add Unit Test

Write a unit test class for **`${subjectClass}`** in the Dumpster Scout project.

## Setup

```kotlin
class ${subjectClass}Test {

    private lateinit var fakeSpotRepository: FakeSpotRepository
    private lateinit var subject: ${subjectClass}

    @Before
    fun setUp() {
        fakeSpotRepository = FakeSpotRepository()
        subject = ${subjectClass}(fakeSpotRepository)
    }
}
```

## Test cases to cover

For each public function / exposed `StateFlow` in `${subjectClass}`:

1. **Happy path** — nominal input produces expected output or state.
2. **Empty / null / edge case** — empty list, null fields, zero values.
3. **Error path** — repository throws, flow emits error, invalid input.

## Naming convention

Use backtick-quoted, human-readable names:

```kotlin
@Test fun `load spots with data - emits spot list`() { … }
@Test fun `load spots empty repo - emits empty state`() { … }
@Test fun `on event delete spot - removes from repository`() { … }
```

## Flow / StateFlow assertions

Use Turbine:
```kotlin
subject.uiState.test {
    val initial = awaitItem()
    assertEquals(false, initial.isLoading)
    cancelAndIgnoreRemainingEvents()
}
```

## Constraints

- Use `FakeSpotRepository` and `FakeReportRepository` (not MockK) for repository collaborators.
- Use `runTest { advanceUntilIdle() }` for coroutine tests.
- Place the file in `app/src/test/java/com/dumpsterscout/`.
- Do **not** test Android framework or UI — pure Kotlin / ViewModel tests only.
