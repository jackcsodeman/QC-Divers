# New Screen Scaffold

Create a new Dumpster Scout screen named **`${screenName}`** using the project's MVVM + Compose architecture.

## What to generate

### 1. `ui/${featurePackage}/${screenName}UiState.kt`
A `data class ${screenName}UiState(…)` that holds all display-ready values (no raw Room entities).
Include an `isLoading: Boolean = false` and `errorMessage: String? = null` field.

### 2. `ui/${featurePackage}/${screenName}UiEvent.kt`
A `sealed class ${screenName}UiEvent` with one `data class` or `data object` per user action.

### 3. `ui/${featurePackage}/${screenName}ViewModel.kt`
```kotlin
@HiltViewModel
class ${screenName}ViewModel @Inject constructor(
    private val spotRepository: SpotRepository,
    // add other dependencies as needed
) : ViewModel() {

    private val _uiState = MutableStateFlow(${screenName}UiState())
    val uiState: StateFlow<${screenName}UiState> = _uiState.asStateFlow()

    fun onEvent(event: ${screenName}UiEvent) {
        // handle events
    }
}
```

### 4. `ui/${featurePackage}/${screenName}Screen.kt`
```kotlin
@Composable
fun ${screenName}Screen(
    onNavigateUp: () -> Unit,
    viewModel: ${screenName}ViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    // Scaffold + content
}

@Preview(showBackground = true)
@Composable
private fun ${screenName}ScreenPreview() {
    DumpsterScoutTheme {
        // preview with fake state
    }
}
```

### 5. Register the route
- Add `${screenName}` to the `Screen` sealed class in `ui/navigation/Screen.kt`.
- Add a `composable(Screen.${screenName}.route) { … }` entry in `DumpsterScoutNavGraph.kt`.

## Constraints
- Domain models are pure Kotlin — never import Android in `domain/`.
- Use `LocalFieldMode.current` to adjust touch targets in field mode.
- Include one `@Preview` per major composable.
- Add a ViewModel unit test class `${screenName}ViewModelTest` using `FakeSpotRepository`.
