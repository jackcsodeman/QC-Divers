# Add Field to DumpsterSpot

Add a new field **`${fieldName}: ${fieldType}`** to the `DumpsterSpot` domain model and wire it
through the full stack.

## Steps

### 1. Domain model — `domain/model/DumpsterSpot.kt`
Add the property with a sensible default:
```kotlin
val ${fieldName}: ${fieldType} = ${defaultValue},
```

### 2. Room entity — `data/local/entity/DumpsterSpotEntity.kt`
Add the matching column using Room's default column naming (camelCase property name):
```kotlin
val ${fieldName}: ${fieldType} = ${defaultValue},
```
If `${fieldType}` is a non-primitive (e.g., `List<String>`, enum), persist it as a `String`
column following the existing convention (JSON array string for lists, enum name for enums) and
handle conversion in the mapper functions instead of adding Room `@TypeConverter`s.
### 3. Database migration
Increment the `@Database(version = …)` number and add a `Migration(oldVersion, newVersion)` in
`DumpsterScoutDatabase.kt`:
```kotlin
val MIGRATION_X_Y = object : Migration(X, Y) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE dumpster_spots ADD COLUMN ${columnName} ${sqlType} NOT NULL DEFAULT ${sqlDefault}")
    }
}
```
Add the migration to `.addMigrations(…)` in the Room builder.

### 4. Mapper — `data/mapper/SpotMapper.kt`
Map the new field in both directions:
```kotlin
// Entity → Domain
${fieldName} = entity.${fieldName},
// Domain → Entity
${fieldName} = domain.${fieldName},
```

### 5. UI — `ui/spots/AddSpotScreen.kt` and/or `SpotDetailScreen.kt`
Add an appropriate input control (text field, checkbox, dropdown, chip group) for the new field.
Bind it through `SpotUiState` and handle it in `SpotViewModel.onEvent(…)`.

### 6. Tests
- Update `FakeSpotRepository` seed data to include the new field.
- Add a test case in `SpotViewModelTest` (or the relevant test class) verifying the field is saved
  and loaded correctly.

## Constraints

- Default value must not break existing data (Room migration required).
- Domain model must stay pure Kotlin — no Android imports.
- All user-visible labels go in `strings.xml`.
