# Dumpster Scout — 20 QA & Visual Operations Checklist

Tasks to verify the app looks correct, operates as intended, and delivers a high-quality field experience.
Run this checklist before every significant release.

---

## Visual Integrity

1. **Dark-mode coherence pass** — Open every screen in dark mode and verify there are no unintended light or white surfaces. All background layers should use the design-token surfaces (`ScoutSurface0` through `ScoutSurface4`), never raw `Color.White`.

2. **Color-contrast audit** — Use the accessibility scanner (or Figma contrast checker) to verify every primary text/background pairing meets WCAG AA (4.5:1). Pay extra attention to status chips, grade badges, and label text on neon-accent surfaces.

3. **Typography scale sanity** — On a Pixel 4a (5.8" 1080p) and a Pixel Tablet (11" 2560×1600), confirm no text is truncated, clipped, or overlapping on any screen. All `TextOverflow.Ellipsis` guards should be respected.

4. **Icon and asset review** — Confirm every `Icon()` renders at the correct size and is not blurry (vector vs. raster). Check that all icon uses come from `material-icons-extended` and no deprecated icon names remain.

5. **Gradient and glow rendering** — On a physical device (not emulator), verify that gradient brushes on hero sections, card headers, and neon-glow accents render without banding. Test on AMOLED screens (Samsung Galaxy S-series) where pure blacks are critical.

6. **Neon accent consistency** — Spot-check 5 random screens side-by-side and confirm the neon accent (electric cyan / magenta) is applied consistently: same hue on chips, FABs, active nav indicators, and focused fields. No screen should use the old Scout Green as its primary accent.

7. **Component state coverage** — For each reusable component (SpotCard, TireSpotCard, StatusChip, GradeCard), verify all states are visually distinct: default, pressed, disabled, selected, error. Run in Compose Preview with each state variant.

---

## Functional Correctness

8. **End-to-end spot creation flow** — Add a new Dumpster Spot via AddSpotScreen with all fields filled (name, category, tags, notes, grade, coordinates). Verify it appears immediately in SpotListScreen, MapScreen, HistoryScreen, and FavoritesScreen after marking as favorite.

9. **Voice report full cycle** — Launch VoiceReportScreen, speak a multi-field phrase (e.g., "Grocery bin on Main St, half full, checked this morning"), confirm all parsed fields populate the confirm screen, save, and verify the new report appears in HistoryScreen with correct timestamps.

10. **Tire voice report full cycle** — Mirror the voice report test on TireVoiceReportScreen. Confirm tireSize, treadDepth, and time relevance fields parse correctly. Verify the report saves to the correct TireSpot record.

11. **Field Mode activation** — Tap the "Night" quick action on HomeScreen. Confirm FieldModeScreen opens with the amber NightField palette, enlarged touch targets, and that returning via back restores the standard dark theme without a flash.

12. **Saved Routes round-trip** — Plan a route with at least 3 stops in SavedRoutesScreen, save it, close the app, reopen, and verify the route is still present with all stops intact (Room persistence check).

13. **Favorites persistence** — Mark 3 spots as favorite, close the app, reopen, navigate to FavoritesScreen and confirm all 3 are still listed. Un-favorite one and confirm it disappears from the favorites list without disappearing from the main list.

14. **Filter & sort correctness** — On SpotListScreen, apply each available filter (by category, by status, by grade range) individually and combined. Verify the result set matches the expected spots. Reset filters and confirm all spots return.

---

## Navigation & State Restoration

15. **Back-stack integrity** — From each leaf screen (SpotDetailScreen, TireSpotDetailScreen, VoiceReportScreen, AboutScreen), press the system back button and confirm you land on the correct parent screen — not the home screen or a blank state.

16. **Process death recovery** — Enable "Don't keep activities" in Developer Options, navigate deep into SpotDetailScreen, switch to another app, return. Confirm the app restores to SpotDetailScreen with the correct spot data (saved instance state / nav argument).

17. **Orientation change stability** — Rotate the device during an active voice recording on VoiceReportScreen. Confirm the `VoicePhase` state is preserved (LISTENING phase resumes or gracefully resets — no crash and no blank screen).

---

## Field-Use & Edge Cases

18. **No-location cold start** — Deny location permission and launch the app. Verify MapScreen shows a permission explanation card (not a crash), and all other screens that don't require location continue to work normally.

19. **Empty state coverage** — Confirm every screen that lists data (SpotListScreen, HistoryScreen, FavoritesScreen, TireSpotListScreen, TireHistoryScreen, SavedRoutesScreen, GearChecklistScreen) shows the designed empty-state illustration and CTA when there is no data, and not a blank white or black rectangle.

20. **Large-data performance** — Seed the database with 500 spots via `SampleData` (or a debug seed function). Run through SpotListScreen scroll, search, filter, and map cluster rendering. Confirm no visible jank (< 16 ms frame budget) and no ANR within a 10-second session.
